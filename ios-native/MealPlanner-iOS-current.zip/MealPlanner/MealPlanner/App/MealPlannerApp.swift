import SwiftUI
import UserNotifications

@main
struct MealPlannerApp: App {
    init() {
        AppTheme.configureGlobalAppearance()

        MealPlannerNotificationResponseRouter.shared
            .installAsNotificationDelegate()
    }

    @State private var sessionStore = SessionStore()
    @State private var refreshCoordinator = AppRefreshCoordinator()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(sessionStore)
                .environment(refreshCoordinator)
        }
    }
}
