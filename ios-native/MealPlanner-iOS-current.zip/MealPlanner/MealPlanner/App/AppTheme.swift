import SwiftUI
import UIKit

enum AppAppearancePreference:
    String,
    CaseIterable,
    Identifiable {
    case system
    case light
    case dark

    var id: String {
        rawValue
    }

    var displayName: String {
        switch self {
        case .system:
            "System"
        case .light:
            "Light"
        case .dark:
            "Dark"
        }
    }

    var colorScheme: ColorScheme? {
        switch self {
        case .system:
            nil
        case .light:
            .light
        case .dark:
            .dark
        }
    }

    var interfaceStyle: UIUserInterfaceStyle {
        switch self {
        case .system:
            .unspecified
        case .light:
            .light
        case .dark:
            .dark
        }
    }
}

enum AppTheme {
    static let appearanceStorageKey =
        "prepflow.appearancePreference"

    static let accent = Color.green

    static let groupedBackground =
        Color(uiColor: .systemGroupedBackground)

    static let secondaryGroupedBackground =
        Color(uiColor: .secondarySystemGroupedBackground)

    static let tertiaryGroupedBackground =
        Color(uiColor: .tertiarySystemGroupedBackground)

    static let cardBackground =
        Color(uiColor: .secondarySystemGroupedBackground)

    static let elevatedCardBackground =
        Color(uiColor: .tertiarySystemGroupedBackground)

    static let separator =
        Color(uiColor: .separator)

    static func preference(
        from rawValue: String
    ) -> AppAppearancePreference {
        AppAppearancePreference(rawValue: rawValue) ?? .dark
    }

    static func configureGlobalAppearance(
        for preference: AppAppearancePreference
    ) {
        UIView.appearance().overrideUserInterfaceStyle =
            preference.interfaceStyle

        applyWindowInterfaceStyle(preference.interfaceStyle)

        let tabAppearance = UITabBarAppearance()
        tabAppearance.configureWithDefaultBackground()
        tabAppearance.backgroundColor =
            UIColor.secondarySystemGroupedBackground
                .withAlphaComponent(0.92)
        tabAppearance.shadowColor =
            UIColor.separator.withAlphaComponent(0.45)

        UITabBar.appearance().standardAppearance =
            tabAppearance
        UITabBar.appearance().scrollEdgeAppearance =
            tabAppearance
        UITabBar.appearance().tintColor =
            UIColor.systemGreen
        UITabBar.appearance().unselectedItemTintColor =
            UIColor.secondaryLabel

        let navigationAppearance =
            UINavigationBarAppearance()
        navigationAppearance.configureWithDefaultBackground()
        navigationAppearance.backgroundColor =
            UIColor.systemGroupedBackground
                .withAlphaComponent(0.96)
        navigationAppearance.shadowColor = UIColor.clear
        navigationAppearance.titleTextAttributes = [
            .foregroundColor: UIColor.label
        ]
        navigationAppearance.largeTitleTextAttributes = [
            .foregroundColor: UIColor.label
        ]

        UINavigationBar.appearance().standardAppearance =
            navigationAppearance
        UINavigationBar.appearance().compactAppearance =
            navigationAppearance
        UINavigationBar.appearance().scrollEdgeAppearance =
            navigationAppearance
        UINavigationBar.appearance().tintColor =
            UIColor.systemGreen
    }

    static func configureGlobalAppearance() {
        let rawValue =
            UserDefaults.standard.string(
                forKey: appearanceStorageKey
            ) ?? AppAppearancePreference.dark.rawValue

        configureGlobalAppearance(
            for: preference(from: rawValue)
        )
    }

    static func applyWindowInterfaceStyle(
        _ style: UIUserInterfaceStyle
    ) {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap(\.windows)
            .forEach { window in
                window.overrideUserInterfaceStyle = style
            }
    }
}

extension View {
    func prepFlowAppSurface(
        appearance: AppAppearancePreference
    ) -> some View {
        self
            .preferredColorScheme(appearance.colorScheme)
            .tint(AppTheme.accent)
            .background(AppTheme.groupedBackground)
            .onAppear {
                AppTheme.configureGlobalAppearance(
                    for: appearance
                )
            }
    }

    func mealPlannerDarkSurface() -> some View {
        self
            .tint(AppTheme.accent)
            .background(AppTheme.groupedBackground)
    }

    func mealPlannerCard() -> some View {
        self
            .background(
                RoundedRectangle(
                    cornerRadius: 24,
                    style: .continuous
                )
                .fill(AppTheme.cardBackground)
            )
    }
}
