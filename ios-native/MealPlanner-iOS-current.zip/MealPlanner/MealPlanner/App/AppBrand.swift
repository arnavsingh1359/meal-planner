import Foundation

nonisolated enum AppBrand {
    static let displayName = "PrepFlow"
    static let shortTagline = "Plan. Prep. Eat."
    static let authSubtitle = "Plan meals, prep smart, and stay on schedule."
    static let loadingText = "Loading PrepFlow…"
    static let defaultUserName = "PrepFlow User"
}
