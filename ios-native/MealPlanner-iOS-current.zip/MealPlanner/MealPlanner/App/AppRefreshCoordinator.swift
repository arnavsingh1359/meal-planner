import Foundation
import Observation

/// Coordinates lightweight cross-tab invalidation.
///
/// Pages still use pull-to-refresh for explicit reloads, but writes in one
/// feature mark dependent features stale so the next visible render reloads
/// current data instead of showing stale Supabase state.
@MainActor
@Observable
final class AppRefreshCoordinator {
    private(set) var todayVersion = 0
    private(set) var weekVersion = 0
    private(set) var scheduleVersion = 0
    private(set) var recipesVersion = 0
    private(set) var shoppingVersion = 0
    private(set) var pantryVersion = 0
    private(set) var settingsVersion = 0

    func markAllChanged() {
        todayVersion += 1
        weekVersion += 1
        scheduleVersion += 1
        recipesVersion += 1
        shoppingVersion += 1
        pantryVersion += 1
        settingsVersion += 1
    }

    func weekPlanChanged() {
        weekVersion += 1
        todayVersion += 1
        scheduleVersion += 1
        shoppingVersion += 1
    }

    func scheduleChanged() {
        scheduleVersion += 1
        todayVersion += 1
    }

    func taskCompletionChanged() {
        scheduleVersion += 1
        todayVersion += 1
    }

    func pantryChanged() {
        pantryVersion += 1
        shoppingVersion += 1
        todayVersion += 1
    }

    func shoppingChanged() {
        shoppingVersion += 1
        todayVersion += 1
    }

    func shoppingChecklistChanged() {
        todayVersion += 1
    }

    func recipesChanged() {
        recipesVersion += 1
        weekVersion += 1
        scheduleVersion += 1
        shoppingVersion += 1
        todayVersion += 1
    }

    func settingsChanged() {
        settingsVersion += 1
        weekVersion += 1
        scheduleVersion += 1
        shoppingVersion += 1
        todayVersion += 1
    }
}
