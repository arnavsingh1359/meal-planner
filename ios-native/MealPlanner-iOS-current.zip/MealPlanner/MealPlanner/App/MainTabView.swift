import SwiftUI

enum MainTab: Hashable {
    case today
    case week
    case recipes
    case shopping
    case more
}

private enum MoreRoute: Hashable {
    case account
    case settings
    case schedule
    case pantry
}

private enum DevelopmentLaunch {
    static let initialTab: MainTab = .today
    static let initialMorePath: [MoreRoute] = []
}

struct MainTabView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    @Environment(\.scenePhase)
    private var scenePhase

    @State private var selectedTab =
        DevelopmentLaunch.initialTab

    @State private var morePath =
        DevelopmentLaunch.initialMorePath

    @State private var targetWeekDate: Date?
    @State private var targetScheduleDate: Date?
    @State private var targetShoppingDate: Date?
    @State private var planningOpenRequestID = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack {
                TodayView(planningOpenRequestID: planningOpenRequestID) { destination in
                    switch destination {
                    case .week:
                        targetWeekDate = nil
                        selectedTab = .week

                    case .weekStarting(let date):
                        targetWeekDate = date
                        selectedTab = .week

                    case .recipes:
                        selectedTab = .recipes

                    case .shopping:
                        targetShoppingDate = nil
                        selectedTab = .shopping

                    case .shoppingStarting(let date):
                        targetShoppingDate = date
                        selectedTab = .shopping

                    case .schedule:
                        targetScheduleDate = nil
                        morePath = [.schedule]
                        selectedTab = .more

                    case .scheduleStarting(let date):
                        targetScheduleDate = date
                        morePath = [.schedule]
                        selectedTab = .more

                    case .pantry:
                        morePath = [.pantry]
                        selectedTab = .more
                    }
                }
            }
            .tabItem {
                Label(
                    "Today",
                    systemImage: "house"
                )
            }
            .tag(MainTab.today)

            NavigationStack {
                WeekView(targetDate: targetWeekDate)
            }
            .tabItem {
                Label(
                    "Week",
                    systemImage: "calendar"
                )
            }
            .tag(MainTab.week)

            NavigationStack {
                RecipesView()
            }
            .tabItem {
                Label(
                    "Recipes",
                    systemImage: "book.closed"
                )
            }
            .tag(MainTab.recipes)

            NavigationStack {
                ShoppingView(targetDate: targetShoppingDate)
            }
            .tabItem {
                Label(
                    "Shopping",
                    systemImage: "cart"
                )
            }
            .tag(MainTab.shopping)

            NavigationStack(path: $morePath) {
                MoreView()
                    .navigationDestination(
                        for: MoreRoute.self
                    ) { route in
                        switch route {
                        case .account:
                            AccountView()

                        case .settings:
                            SettingsView()

                        case .schedule:
                            ScheduleView(targetDate: targetScheduleDate)

                        case .pantry:
                            PantryView()
                        }
                    }
            }
            .tabItem {
                Label(
                    "More",
                    systemImage: "ellipsis.circle"
                )
            }
            .tag(MainTab.more)
        }
        .tint(.green)
        .onAppear {
            MealPlannerNotificationResponseRouter.shared.setHandler { route in
                handleNotificationRoute(route)
            }
        }
        .task {
            await rescheduleNotificationsIfPossible()
        }
        .onChange(of: scenePhase) { _, newPhase in
            guard newPhase == .active else {
                return
            }

            Task {
                await rescheduleNotificationsIfPossible()
            }
        }
    }

    private func handleNotificationRoute(
        _ route: MealPlannerNotificationRoute
    ) {
        switch route {
        case .today:
            selectedTab = .today

        case .planning:
            selectedTab = .today
            planningOpenRequestID += 1

        case .week:
            targetWeekDate = nil
            selectedTab = .week

        case .schedule:
            targetScheduleDate = nil
            morePath = [.schedule]
            selectedTab = .more

        case .shopping:
            targetShoppingDate = nil
            selectedTab = .shopping

        case .pantry:
            morePath = [.pantry]
            selectedTab = .more
        }
    }

    private func rescheduleNotificationsIfPossible() async {
        guard sessionStore.isAuthenticated else {
            await MealPlannerNotificationCenter.shared
                .clearMealPlannerNotifications(
                    removeDelivered: true
                )
            return
        }

        await MealPlannerNotificationSyncStore.shared
            .rescheduleAll()
    }
}


private struct PlaceholderView: View {
    let title: String
    let icon: String

    var body: some View {
        ContentUnavailableView(
            title,
            systemImage: icon,
            description: Text(
                "This section will be connected next."
            )
        )
        .navigationTitle(title)
    }
}

private struct MoreView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    @State private var isClearingNotifications = false
    @State private var isSchedulingDebugNotifications = false
    @State private var debugStatusMessage: String?

    var body: some View {
        List {
            Section("Account") {
                NavigationLink(
                    value: MoreRoute.account
                ) {
                    Label(
                        "Account settings",
                        systemImage:
                            "person.crop.circle"
                    )
                }

                LabeledContent(
                    "Signed in as",
                    value: sessionStore.userEmail
                )
            }

            Section("Planning") {
                NavigationLink(
                    value: MoreRoute.settings
                ) {
                    Label(
                        "Meal settings",
                        systemImage:
                            "slider.horizontal.3"
                    )
                }

                NavigationLink(
                    value: MoreRoute.schedule
                ) {
                    Label(
                        "Schedule",
                        systemImage: "clock"
                    )
                }

                NavigationLink(
                    value: MoreRoute.pantry
                ) {
                    Label(
                        "Pantry",
                        systemImage: "cabinet"
                    )
                }
            }

            Section("Reminder maintenance") {
                Button {
                    isClearingNotifications = true
                    Task {
                        await MealPlannerNotificationSyncStore.shared
                            .clearOldMealPlannerNotifications()
                        debugStatusMessage = "Meal Planner reminders cleared."
                        isClearingNotifications = false
                    }
                } label: {
                    Label(
                        isClearingNotifications
                        ? "Clearing reminders…"
                        : "Clear Meal Planner reminders",
                        systemImage: "bell.slash"
                    )
                }
                .disabled(isClearingNotifications)

                Button {
                    Task {
                        await MealPlannerNotificationSyncStore.shared
                            .rescheduleAll()
                        debugStatusMessage = "Meal Planner reminders rescheduled."
                    }
                } label: {
                    Label(
                        "Reschedule reminders",
                        systemImage: "arrow.clockwise"
                    )
                }

                if let debugStatusMessage {
                    Text(debugStatusMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            #if DEBUG
            Section("Debug notification testing") {
                Button {
                    scheduleAllDebugNotifications()
                } label: {
                    Label(
                        isSchedulingDebugNotifications
                        ? "Scheduling debug reminders…"
                        : "Send all debug reminders",
                        systemImage: "bell.badge"
                    )
                }
                .disabled(isSchedulingDebugNotifications)

                Button(role: .destructive) {
                    Task {
                        await MealPlannerNotificationCenter.shared
                            .clearDebugMealPlannerNotifications()
                        debugStatusMessage = "Debug reminders cleared."
                    }
                } label: {
                    Label(
                        "Clear debug reminders",
                        systemImage: "trash"
                    )
                }

                ForEach(MealPlannerNotificationKind.allCases, id: \.self) { kind in
                    Button {
                        scheduleDebugNotification(kind)
                    } label: {
                        Label(
                            debugButtonTitle(for: kind),
                            systemImage: debugButtonIcon(for: kind)
                        )
                    }
                    .disabled(isSchedulingDebugNotifications)
                }

                Divider()

                Button {
                    MealPlannerNotificationResponseRouter.shared.simulate(
                        route: .planning
                    )
                } label: {
                    Label(
                        "Simulate weekly planning tap",
                        systemImage: "calendar.badge.clock"
                    )
                }

                Button {
                    MealPlannerNotificationResponseRouter.shared.simulate(
                        route: .schedule
                    )
                } label: {
                    Label(
                        "Simulate schedule notification tap",
                        systemImage: "clock"
                    )
                }

                Button {
                    MealPlannerNotificationResponseRouter.shared.simulate(
                        route: .shopping
                    )
                } label: {
                    Label(
                        "Simulate shopping notification tap",
                        systemImage: "cart"
                    )
                }

                Text(
                    "Tap a debug notification button, send the app to the background, and wait about 10 seconds. iOS usually does not show notification banners while the app is foregrounded."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }
            #endif
        }
        .navigationTitle("More")
    }

    #if DEBUG
    private func scheduleAllDebugNotifications() {
        isSchedulingDebugNotifications = true
        Task {
            let scheduled = await MealPlannerNotificationCenter.shared
                .scheduleAllDebugReminders()
            debugStatusMessage = scheduled
                ? "All debug reminders scheduled. Background the app now."
                : "Notification permission denied or scheduling failed."
            isSchedulingDebugNotifications = false
        }
    }

    private func scheduleDebugNotification(
        _ kind: MealPlannerNotificationKind
    ) {
        isSchedulingDebugNotifications = true
        Task {
            let scheduled = await MealPlannerNotificationCenter.shared
                .scheduleDebugReminder(
                    kind: kind,
                    delaySeconds: 10
                )
            debugStatusMessage = scheduled
                ? "\(debugButtonTitle(for: kind)) scheduled. Background the app now."
                : "Notification permission denied or scheduling failed."
            isSchedulingDebugNotifications = false
        }
    }

    private func debugButtonTitle(
        for kind: MealPlannerNotificationKind
    ) -> String {
        switch kind {
        case .weeklyPlanning:
            return "Weekly planning in 10 sec"
        case .cookingSession:
            return "Cooking session in 10 sec"
        case .cookingTask:
            return "Cooking task in 10 sec"
        case .passiveTaskFinished:
            return "Passive step done in 10 sec"
        case .readyByRisk:
            return "Ready-by risk in 10 sec"
        case .overdueTask:
            return "Overdue task in 10 sec"
        case .shoppingReminder:
            return "Shopping reminder in 10 sec"
        }
    }

    private func debugButtonIcon(
        for kind: MealPlannerNotificationKind
    ) -> String {
        switch kind {
        case .weeklyPlanning:
            return "calendar.badge.clock"
        case .cookingSession:
            return "flame"
        case .cookingTask:
            return "timer"
        case .passiveTaskFinished:
            return "hourglass"
        case .readyByRisk:
            return "exclamationmark.triangle"
        case .overdueTask:
            return "clock.badge.exclamationmark"
        case .shoppingReminder:
            return "cart"
        }
    }
    #endif
}
