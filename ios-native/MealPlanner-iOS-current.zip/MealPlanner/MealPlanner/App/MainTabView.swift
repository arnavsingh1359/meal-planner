import SwiftUI

enum MainTab: Hashable {
    case today
    case week
    case recipes
    case shopping
    case more
}

private enum MoreRoute: Hashable {
    case account
    case settings
    case schedule
    case pantry
}

private enum DevelopmentLaunch {
    #if DEBUG
    static let initialTab: MainTab = .more
    static let initialMorePath: [MoreRoute] = [
        .schedule
    ]
    #else
    static let initialTab: MainTab = .today
    static let initialMorePath: [MoreRoute] = []
    #endif
}

struct MainTabView: View {
    @State private var selectedTab =
        DevelopmentLaunch.initialTab

    @State private var morePath =
        DevelopmentLaunch.initialMorePath

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack {
                TodayView()
            }
            .tabItem {
                Label(
                    "Today",
                    systemImage: "house"
                )
            }
            .tag(MainTab.today)

            NavigationStack {
                WeekView()
            }
            .tabItem {
                Label(
                    "Week",
                    systemImage: "calendar"
                )
            }
            .tag(MainTab.week)

            NavigationStack {
                RecipesView()
            }
            .tabItem {
                Label(
                    "Recipes",
                    systemImage: "book.closed"
                )
            }
            .tag(MainTab.recipes)

            NavigationStack {
                PlaceholderView(
                    title: "Shopping",
                    icon: "cart"
                )
            }
            .tabItem {
                Label(
                    "Shopping",
                    systemImage: "cart"
                )
            }
            .tag(MainTab.shopping)

            NavigationStack(path: $morePath) {
                MoreView()
                    .navigationDestination(
                        for: MoreRoute.self
                    ) { route in
                        switch route {
                        case .account:
                            AccountView()

                        case .settings:
                            SettingsView()

                        case .schedule:
                            ScheduleView()

                        case .pantry:
                            PlaceholderView(
                                title: "Pantry",
                                icon: "cabinet"
                            )
                        }
                    }
            }
            .tabItem {
                Label(
                    "More",
                    systemImage: "ellipsis.circle"
                )
            }
            .tag(MainTab.more)
        }
        .tint(.green)
    }
}

private struct TodayView: View {
    var body: some View {
        ContentUnavailableView(
            "Today",
            systemImage: "fork.knife",
            description: Text(
                "Your meals and preparation tasks will appear here."
            )
        )
        .navigationTitle("Today")
    }
}

private struct PlaceholderView: View {
    let title: String
    let icon: String

    var body: some View {
        ContentUnavailableView(
            title,
            systemImage: icon,
            description: Text(
                "This section will be connected next."
            )
        )
        .navigationTitle(title)
    }
}

private struct MoreView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    var body: some View {
        List {
            Section("Account") {
                NavigationLink(
                    value: MoreRoute.account
                ) {
                    Label(
                        "Account settings",
                        systemImage:
                            "person.crop.circle"
                    )
                }

                LabeledContent(
                    "Signed in as",
                    value: sessionStore.userEmail
                )
            }

            Section("Planning") {
                NavigationLink(
                    value: MoreRoute.settings
                ) {
                    Label(
                        "Meal settings",
                        systemImage:
                            "slider.horizontal.3"
                    )
                }

                NavigationLink(
                    value: MoreRoute.schedule
                ) {
                    Label(
                        "Schedule",
                        systemImage: "clock"
                    )
                }

                NavigationLink(
                    value: MoreRoute.pantry
                ) {
                    Label(
                        "Pantry",
                        systemImage: "cabinet"
                    )
                }
            }
        }
        .navigationTitle("More")
    }
}
