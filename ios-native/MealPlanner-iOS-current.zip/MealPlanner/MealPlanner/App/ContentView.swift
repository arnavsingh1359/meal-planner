import SwiftUI

struct ContentView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    @AppStorage(AppTheme.appearanceStorageKey)
    private var appearanceRawValue =
        AppAppearancePreference.dark.rawValue

    private var appearancePreference:
        AppAppearancePreference {
        AppTheme.preference(from: appearanceRawValue)
    }

    var body: some View {
        Group {
            if sessionStore.isLoading {
                ProgressView(AppBrand.loadingText)
            } else if sessionStore.isAuthenticated {
                MainTabView()
            } else {
                AuthView()
            }
        }
        .prepFlowAppSurface(
            appearance: appearancePreference
        )
        .onChange(of: appearanceRawValue) { _, newValue in
            AppTheme.configureGlobalAppearance(
                for: AppTheme.preference(from: newValue)
            )
        }
        .animation(
            .easeInOut,
            value: sessionStore.isAuthenticated
        )
    }
}

#Preview {
    ContentView()
        .environment(SessionStore())
        .environment(AppRefreshCoordinator())
}
