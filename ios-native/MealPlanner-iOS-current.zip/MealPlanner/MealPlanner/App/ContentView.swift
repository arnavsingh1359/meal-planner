import SwiftUI

struct ContentView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    var body: some View {
        Group {
            if sessionStore.isLoading {
                ProgressView("Loading Meal Planner…")
            } else if sessionStore.isAuthenticated {
                MainTabView()
            } else {
                AuthView()
            }
        }
        .animation(
            .easeInOut,
            value: sessionStore.isAuthenticated
        )
    }
}

#Preview {
    ContentView()
        .environment(SessionStore())
        .environment(AppRefreshCoordinator())
}
