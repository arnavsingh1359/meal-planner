import SwiftUI

struct AuthView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    @State private var email = ""
    @State private var password = ""
    @State private var isCreatingAccount = false
    @State private var isSubmitting = false
    @State private var errorMessage: String?
    @State private var successMessage: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    header

                    VStack(spacing: 16) {
                        TextField(
                            "Email address",
                            text: $email
                        )
                        .textContentType(.emailAddress)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)

                        SecureField(
                            "Password",
                            text: $password
                        )
                        .textContentType(
                            isCreatingAccount
                                ? .newPassword
                                : .password
                        )
                        .textFieldStyle(.roundedBorder)
                    }

                    if let errorMessage {
                        Text(errorMessage)
                            .font(.footnote)
                            .foregroundStyle(.red)
                            .frame(
                                maxWidth: .infinity,
                                alignment: .leading
                            )
                    }

                    if let successMessage {
                        Text(successMessage)
                            .font(.footnote)
                            .foregroundStyle(.green)
                            .frame(
                                maxWidth: .infinity,
                                alignment: .leading
                            )
                    }

                    Button {
                        Task {
                            await submit()
                        }
                    } label: {
                        Group {
                            if isSubmitting {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Text(
                                    isCreatingAccount
                                        ? "Create account"
                                        : "Sign in"
                                )
                                .fontWeight(.semibold)
                            }
                        }
                        .frame(
                            maxWidth: .infinity,
                            minHeight: 48
                        )
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(
                        isSubmitting
                            || email.trimmingCharacters(
                                in: .whitespacesAndNewlines
                            ).isEmpty
                            || password.isEmpty
                    )

                    Button {
                        isCreatingAccount.toggle()
                        errorMessage = nil
                        successMessage = nil
                    } label: {
                        Text(
                            isCreatingAccount
                                ? "Already have an account? Sign in"
                                : "Need an account? Create one"
                        )
                    }
                    .disabled(isSubmitting)
                }
                .padding(24)
                .frame(maxWidth: 520)
                .frame(maxWidth: .infinity)
            }
            .background(
                Color(.systemGroupedBackground)
            )
        }
    }

    private var header: some View {
        VStack(spacing: 12) {
            Image(systemName: "fork.knife.circle.fill")
                .font(.system(size: 72))
                .foregroundStyle(.green)

            Text(AppBrand.displayName)
                .font(.largeTitle.bold())

            Text(
                isCreatingAccount
                    ? "Create your account"
                    : AppBrand.authSubtitle
            )
            .multilineTextAlignment(.center)
            .foregroundStyle(.secondary)
        }
        .padding(.top, 36)
    }

    @MainActor
    private func submit() async {
        errorMessage = nil
        successMessage = nil

        let cleanedEmail = email.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard cleanedEmail.contains("@") else {
            errorMessage = "Enter a valid email address."
            return
        }

        guard password.count >= 6 else {
            errorMessage =
                "Password must contain at least 6 characters."
            return
        }

        isSubmitting = true

        defer {
            isSubmitting = false
        }

        do {
            if isCreatingAccount {
                let requiresEmailConfirmation =
                    try await sessionStore.signUp(
                        email: cleanedEmail,
                        password: password
                    )

                if requiresEmailConfirmation {
                    successMessage =
                        "Check your email to confirm your account."
                    password = ""
                }
            } else {
                try await sessionStore.signIn(
                    email: cleanedEmail,
                    password: password
                )
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

#Preview {
    AuthView()
        .environment(SessionStore())
}
