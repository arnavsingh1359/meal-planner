import SwiftUI

private enum TodayPalette {
    static let pageBackground = Color.black
    static let cardBackground = Color(red: 0.075, green: 0.078, blue: 0.086)
    static let elevatedCardBackground = Color(red: 0.105, green: 0.11, blue: 0.122)
    static let secondaryCardBackground = Color(red: 0.095, green: 0.098, blue: 0.108)
    static let cardStroke = Color.white.opacity(0.08)
    static let subtleStroke = Color.white.opacity(0.055)
    static let greenWash = Color.green.opacity(0.16)
    static let orangeWash = Color.orange.opacity(0.16)
}

struct TodayView: View {
    @State private var store = TodayStore()
    @State private var planningStore = WeeklyPlanningStore()
    @State private var showWeeklyPlanning = false
#if DEBUG
    @AppStorage("debug.forceWeeklyPlanningPrompt")
    private var debugForceWeeklyPlanningPrompt = false
#endif
    let planningOpenRequestID: Int
    let onNavigate: (TodayNavigationDestination) -> Void

    init(
        planningOpenRequestID: Int = 0,
        onNavigate: @escaping (TodayNavigationDestination) -> Void = { _ in }
    ) {
        self.planningOpenRequestID = planningOpenRequestID
        self.onNavigate = onNavigate
    }

    var body: some View {
        ZStack {
            TodayPalette.pageBackground
                .ignoresSafeArea()

            ScrollView {
                VStack(
                    alignment: .leading,
                    spacing: 18
                ) {
                    header

                    if let errorMessage = store.errorMessage {
                        errorBanner(errorMessage)
                    }

                    if store.isLoading && !store.hasLoaded {
                        loadingView
                    } else {
                        weeklyPlanningPrompt
                        summaryGrid
                        nextUpCard
                        mealsSection
                        tasksSection
                        weekSnapshotSection
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 54)
                .padding(.bottom, 110)
            }
            .refreshable {
                await store.refresh()
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
#if DEBUG
            ToolbarItem(placement: .topBarLeading) {
                Menu {
                    Toggle(
                        "Force weekly planning card",
                        isOn: $debugForceWeeklyPlanningPrompt
                    )

                    Button("Open planning workflow") {
                        showWeeklyPlanning = true
                    }
                } label: {
                    Image(systemName: "ladybug")
                }
                .accessibilityLabel("Debug planning controls")
            }
#endif

            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    Task {
                        await store.refresh()
                        await planningStore.refresh()
                    }
                } label: {
                    if store.isLoading {
                        ProgressView()
                    } else {
                        Image(systemName: "arrow.clockwise")
                    }
                }
                .accessibilityLabel("Refresh Today")
            }
        }
        .sheet(isPresented: $showWeeklyPlanning) {
            WeeklyPlanningView(
                store: planningStore,
                onNavigate: onNavigate
            )
        }
        .task {
            await store.load()
            await planningStore.load()
        }
        .onAppear {
            Task {
                await store.refreshWhenPageBecomesVisible()
                await planningStore.refresh()
            }
        }
        .onChange(of: planningOpenRequestID) { _, newValue in
            guard newValue > 0 else {
                return
            }

            showWeeklyPlanning = true
        }
    }



    @ViewBuilder
    private var weeklyPlanningPrompt: some View {
        if shouldShowWeeklyPlanningPrompt {
            Button {
                showWeeklyPlanning = true
            } label: {
                VStack(alignment: .leading, spacing: 12) {
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "calendar.badge.clock")
                            .font(.title2)
                            .foregroundStyle(.green)
                            .frame(width: 34, height: 34)

                        VStack(alignment: .leading, spacing: 5) {
                            Text(planningStore.progress.callToActionTitle)
                                .font(.headline.weight(.bold))
                                .foregroundStyle(.primary)

                            Text(planningStore.weekTitle)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.secondary)

                            Text(planningStore.urgencyText)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(2)
                        }

                        Spacer()

                        Image(systemName: "chevron.right")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.tertiary)
                    }

                    ProgressView(value: planningStore.progress.status.progressFraction)
                        .tint(.green)

                    Text(planningStore.progress.summaryText)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.primary)
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(TodayPalette.cardBackground)
                .clipShape(RoundedRectangle(cornerRadius: 22))
                .overlay(
                    RoundedRectangle(cornerRadius: 22)
                        .stroke(TodayPalette.cardStroke, lineWidth: 1)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 22)
                        .stroke(TodayPalette.cardStroke, lineWidth: 1)
                )
            }
            .buttonStyle(.plain)
            .accessibilityLabel(planningStore.progress.callToActionTitle)
            .accessibilityValue(planningStore.progress.summaryText)
        }
    }

    private var shouldShowWeeklyPlanningPrompt: Bool {
#if DEBUG
        planningStore.shouldShowPrompt || debugForceWeeklyPlanningPrompt
#else
        planningStore.shouldShowPrompt
#endif
    }

    private var header: some View {
        AppScreenHeader(
            title: "Today",
            subtitle: store.todayTitle
        )
    }

    private var loadingView: some View {
        VStack(spacing: 14) {
            ProgressView()
            Text("Loading your day…")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 80)
    }

    private var summaryGrid: some View {
        LazyVGrid(
            columns: [
                GridItem(.flexible(), spacing: 10),
                GridItem(.flexible(), spacing: 10)
            ],
            spacing: 10
        ) {
            SummaryTile(
                title: "Meals",
                value: "\(store.summary.mealCountToday)",
                detail: "planned today",
                systemImage: "fork.knife"
            ) {
                onNavigate(.week)
            }

            SummaryTile(
                title: "Tasks",
                value: store.summary.taskCompletionText,
                detail: "today",
                systemImage: "checklist"
            ) {
                onNavigate(.schedule)
            }

            SummaryTile(
                title: "Shopping",
                value: "\(store.summary.shoppingItemsRemainingThisWeek)",
                detail: "items this week",
                systemImage: "cart"
            ) {
                onNavigate(.shopping)
            }

            SummaryTile(
                title: "Warnings",
                value: "\(store.summary.scheduleWarningsThisWeek)",
                detail: "this week",
                systemImage: store.summary.hasUrgentIssues
                    ? "exclamationmark.triangle.fill"
                    : "checkmark.circle.fill",
                isWarning: store.summary.hasUrgentIssues
            ) {
                onNavigate(.schedule)
            }
        }
    }

    @ViewBuilder
    private var nextUpCard: some View {
        if let task = store.nextTask {
            HStack(alignment: .top, spacing: 14) {
                CompletionButton(
                    isCompleted: task.isCompleted,
                    label: "Mark \(task.title) complete"
                ) {
                    Task {
                        await store.toggleCompletion(task)
                    }
                }

                Button {
                    onNavigate(.schedule)
                } label: {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(spacing: 10) {
                            Image(systemName: "clock.fill")
                                .foregroundStyle(.green)

                            Text("Next up")
                                .font(.headline)

                            Spacer()

                            Text(task.timeText())
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.secondary)
                        }

                        Text(task.title)
                            .font(.title3.weight(.bold))
                            .foregroundStyle(.primary)

                        if let quantityText = task.quantitySummaryText {
                            Label(
                                quantityText,
                                systemImage: "scalemass"
                            )
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.primary)
                            .lineLimit(2)
                        }

                        HStack(spacing: 8) {
                            Label(
                                task.durationText,
                                systemImage: "timer"
                            )

                            if task.hasConflict
                                || task.warningMessage != nil {
                                Label(
                                    "Needs attention",
                                    systemImage: "exclamationmark.triangle.fill"
                                )
                                .foregroundStyle(.orange)
                            }
                        }
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.plain)
            }
            .padding(18)
            .background(TodayPalette.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 24))
            .overlay(
                RoundedRectangle(cornerRadius: 24)
                    .stroke(TodayPalette.cardStroke, lineWidth: 1)
            )
            .shadow(
                color: .black.opacity(0.35),
                radius: 16,
                y: 8
            )
            .accessibilityElement(children: .contain)
        }
    }

    private var mealsSection: some View {
        DashboardSection(
            title: "Meals",
            emptyTitle: "No meals planned today",
            emptySystemImage: "fork.knife"
        ) {
            ForEach(store.todayMeals) { meal in
                MealRow(meal: meal) {
                    onNavigate(.week)
                }
            }
        } isEmpty: {
            store.todayMeals.isEmpty
        }
    }

    private var tasksSection: some View {
        DashboardSection(
            title: "Tasks",
            emptyTitle: "No scheduled tasks today",
            emptySystemImage: "checklist"
        ) {
            VStack(spacing: 14) {
                ForEach(store.taskSections) { section in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(section.status.title)
                            .font(.subheadline.weight(.bold))
                            .foregroundStyle(.secondary)
                            .padding(.horizontal, 4)

                        VStack(spacing: 8) {
                            ForEach(section.tasks) { task in
                                TaskRow(
                                    task: task,
                                    status: section.status,
                                    toggle: {
                                        Task {
                                            await store.toggleCompletion(task)
                                        }
                                    },
                                    openSchedule: {
                                        onNavigate(.schedule)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        } isEmpty: {
            store.todayTasks.isEmpty
        }
    }

    private var weekSnapshotSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("This week")
                .font(.title2.weight(.bold))

            VStack(spacing: 10) {
                SnapshotRow(
                    title: "Meals planned",
                    value: "\(store.summary.mealsPlannedThisWeek)",
                    systemImage: "calendar"
                ) {
                    onNavigate(.week)
                }

                SnapshotRow(
                    title: "Tasks remaining",
                    value: "\(store.summary.tasksRemainingThisWeek)",
                    systemImage: "clock"
                ) {
                    onNavigate(.schedule)
                }

                SnapshotRow(
                    title: "Shopping items",
                    value: "\(store.summary.shoppingItemsRemainingThisWeek)",
                    systemImage: "cart"
                ) {
                    onNavigate(.shopping)
                }
            }
        }
    }

    private func errorBanner(_ message: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.orange)

            Text(message)
                .font(.footnote)
                .foregroundStyle(.primary)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(TodayPalette.orangeWash)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

private struct SummaryTile: View {
    let title: String
    let value: String
    let detail: String
    let systemImage: String
    var isWarning = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: systemImage)
                        .foregroundStyle(isWarning ? .orange : .green)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.tertiary)
                }

                Text(value)
                    .font(.title2.weight(.bold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)

                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.primary)

                    Text(detail)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(TodayPalette.elevatedCardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(TodayPalette.cardStroke, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Open \(title)")
        .accessibilityValue("\(value), \(detail)")
    }
}

private struct DashboardSection<Content: View>: View {
    let title: String
    let emptyTitle: String
    let emptySystemImage: String
    @ViewBuilder let content: Content
    let isEmpty: () -> Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.title2.weight(.bold))

            if isEmpty() {
                HStack(spacing: 12) {
                    Image(systemName: emptySystemImage)
                        .foregroundStyle(.secondary)
                    Text(emptyTitle)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
                .padding(18)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(TodayPalette.cardBackground)
                .clipShape(RoundedRectangle(cornerRadius: 22))
                .overlay(
                    RoundedRectangle(cornerRadius: 22)
                        .stroke(TodayPalette.cardStroke, lineWidth: 1)
                )
            } else {
                content
            }
        }
    }
}

private struct MealRow: View {
    let meal: TodayMealItem
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: "fork.knife.circle.fill")
                    .font(.title3)
                    .foregroundStyle(.green)

                VStack(alignment: .leading, spacing: 4) {
                    Text(meal.slotName)
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)

                    Text(meal.recipeName)
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.primary)

                    Text(meal.servingText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .padding(16)
            .background(TodayPalette.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 22))
            .overlay(
                RoundedRectangle(cornerRadius: 22)
                    .stroke(TodayPalette.cardStroke, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Open \(meal.slotName), \(meal.recipeName)")
        .accessibilityValue(meal.servingText)
    }
}

private struct TaskRow: View {
    let task: TodayTaskItem
    let status: TodayTaskStatus
    let toggle: () -> Void
    let openSchedule: () -> Void

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            CompletionButton(
                isCompleted: task.isCompleted,
                label: task.isCompleted
                    ? "Mark \(task.title) incomplete"
                    : "Mark \(task.title) complete",
                action: toggle
            )

            Button(action: openSchedule) {
                HStack(alignment: .center, spacing: 10) {
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 8) {
                            Text(task.title)
                                .font(.headline.weight(.bold))
                                .foregroundStyle(.primary)
                                .strikethrough(task.isCompleted)

                            if task.hasConflict
                                || task.warningMessage != nil {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .font(.caption)
                                    .foregroundStyle(.orange)
                            }
                        }

                        if let quantityText = task.quantitySummaryText {
                            Label(
                                quantityText,
                                systemImage: "scalemass"
                            )
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.primary)
                            .lineLimit(2)
                        }

                        HStack(spacing: 8) {
                            Text(task.timeText())
                            Text("•")
                            Text(task.durationText)
                        }
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)

                        if let warning = task.warningMessage,
                           !warning.isEmpty {
                            Text(warning)
                                .font(.caption2)
                                .foregroundStyle(.orange)
                                .lineLimit(2)
                        }
                    }

                    Spacer()

                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.tertiary)
                }
            }
            .buttonStyle(.plain)
        }
        .padding(14)
        .background(
            status == .nextUp
                ? TodayPalette.greenWash
                : TodayPalette.secondaryCardBackground
        )
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(status == .nextUp ? Color.green.opacity(0.28) : TodayPalette.subtleStroke, lineWidth: 1)
        )
        .opacity(task.isCompleted ? 0.55 : 1)
        .accessibilityElement(children: .contain)
    }
}

private struct CompletionButton: View {
    let isCompleted: Bool
    let label: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(
                systemName: isCompleted
                    ? "checkmark.circle.fill"
                    : "circle"
            )
            .font(.title2)
            .foregroundStyle(isCompleted ? .green : .secondary)
            .frame(width: 44, height: 44)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

private struct SnapshotRow: View {
    let title: String
    let value: String
    let systemImage: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: systemImage)
                    .foregroundStyle(.green)
                    .frame(width: 24)

                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)

                Spacer()

                Text(value)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.primary)

                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .padding(14)
            .background(TodayPalette.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .overlay(
                RoundedRectangle(cornerRadius: 18)
                    .stroke(TodayPalette.cardStroke, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Open \(title)")
        .accessibilityValue(value)
    }
}
