import Foundation

nonisolated enum TodayTaskStatus: String, Codable, Hashable {
    case overdue
    case nextUp
    case later
    case completed

    var title: String {
        switch self {
        case .overdue:
            return "Overdue"
        case .nextUp:
            return "Next up"
        case .later:
            return "Later today"
        case .completed:
            return "Completed"
        }
    }

    var sortOrder: Int {
        switch self {
        case .overdue:
            return 0
        case .nextUp:
            return 1
        case .later:
            return 2
        case .completed:
            return 3
        }
    }
}

nonisolated struct TodayTaskItem:
    Identifiable,
    Hashable,
    ScheduledTaskQuantityContext {

    let id: UUID
    let weekPlanEntryID: UUID
    let recipeID: UUID
    let recipeTaskID: UUID?
    let title: String
    let instructions: String?
    let scheduledStart: Date
    let scheduledEnd: Date
    let activeMinutes: Int
    let passiveMinutes: Int
    let isCompleted: Bool
    let hasConflict: Bool
    let warningMessage: String?
    let batchServings: Double
    let coveredWeekPlanEntryIDs: [UUID]
    let isSharedPrep: Bool
    let sharedPrepKey: String?
    let quantityLines: [ScheduledTaskQuantityDisplayLine]
    let position: Int

    var quantitySummaryText: String? {
        guard !quantityLines.isEmpty else {
            return nil
        }

        return quantityLines
            .map(\.text)
            .joined(separator: " • ")
    }

    var durationMinutes: Int {
        max(0, activeMinutes + passiveMinutes)
    }

    var durationText: String {
        AppDurationFormatter.string(
            minutes: durationMinutes
        )
    }

    func timeText(
        calendar: Calendar = .current
    ) -> String {
        scheduledStart.formatted(
            .dateTime.hour().minute()
        )
    }

    func status(
        now: Date,
        nextUnfinishedTaskID: UUID?
    ) -> TodayTaskStatus {
        if isCompleted {
            return .completed
        }

        if scheduledEnd < now {
            return .overdue
        }

        if id == nextUnfinishedTaskID {
            return .nextUp
        }

        return .later
    }
}

nonisolated struct TodayMealItem: Identifiable, Hashable {
    let id: UUID
    let recipeID: UUID
    let mealDate: String
    let slotName: String
    let slotPosition: Int
    let recipeName: String
    let servings: Double
    let notes: String

    var servingText: String {
        let amount = servings.formatted(
            .number.precision(
                .fractionLength(0...2)
            )
        )

        return "\(amount) serving\(servings == 1 ? "" : "s")"
    }
}

nonisolated struct TodaySummary: Hashable {
    let mealCountToday: Int
    let taskCountToday: Int
    let completedTaskCountToday: Int
    let overdueTaskCountToday: Int
    let warningCountToday: Int
    let mealsPlannedThisWeek: Int
    let tasksRemainingThisWeek: Int
    let shoppingItemsRemainingThisWeek: Int
    let scheduleWarningsThisWeek: Int

    var taskCompletionText: String {
        guard taskCountToday > 0 else {
            return "No tasks"
        }

        return "\(completedTaskCountToday)/\(taskCountToday) done"
    }

    var hasUrgentIssues: Bool {
        overdueTaskCountToday > 0
            || warningCountToday > 0
            || scheduleWarningsThisWeek > 0
    }
}

nonisolated struct TodayTaskSection: Identifiable, Hashable {
    let status: TodayTaskStatus
    let tasks: [TodayTaskItem]

    var id: TodayTaskStatus {
        status
    }
}

nonisolated enum TodayNavigationDestination: Hashable {
    case week
    case recipes
    case shopping
    case schedule
    case pantry
}

nonisolated enum TodayDashboardBuilder {
    static func nextUnfinishedTaskID(
        tasks: [TodayTaskItem],
        now: Date
    ) -> UUID? {
        tasks
            .filter { task in
                !task.isCompleted && task.scheduledEnd >= now
            }
            .sorted { lhs, rhs in
                taskSort(lhs: lhs, rhs: rhs)
            }
            .first?
            .id
    }

    static func taskSections(
        tasks: [TodayTaskItem],
        now: Date
    ) -> [TodayTaskSection] {
        let nextID = nextUnfinishedTaskID(
            tasks: tasks,
            now: now
        )

        let grouped = Dictionary(
            grouping: tasks.sorted { lhs, rhs in
                taskSort(lhs: lhs, rhs: rhs)
            }
        ) { task in
            task.status(
                now: now,
                nextUnfinishedTaskID: nextID
            )
        }

        return TodayTaskStatus.allCasesForDisplay
            .compactMap { status in
                guard let tasks = grouped[status], !tasks.isEmpty else {
                    return nil
                }

                return TodayTaskSection(
                    status: status,
                    tasks: tasks
                )
            }
    }

    static func summary(
        todayTasks: [TodayTaskItem],
        weekTasks: [TodayTaskItem],
        todayMeals: [TodayMealItem],
        weekMealCount: Int,
        shoppingItemsRemaining: Int,
        now: Date
    ) -> TodaySummary {
        TodaySummary(
            mealCountToday: todayMeals.count,
            taskCountToday: todayTasks.count,
            completedTaskCountToday:
                todayTasks.filter(\.isCompleted).count,
            overdueTaskCountToday:
                todayTasks.filter {
                    !$0.isCompleted
                        && $0.scheduledEnd < now
                }.count,
            warningCountToday:
                todayTasks.filter {
                    $0.hasConflict
                        || $0.warningMessage != nil
                }.count,
            mealsPlannedThisWeek: weekMealCount,
            tasksRemainingThisWeek:
                weekTasks.filter { !$0.isCompleted }.count,
            shoppingItemsRemainingThisWeek:
                shoppingItemsRemaining,
            scheduleWarningsThisWeek:
                weekTasks.filter {
                    $0.hasConflict
                        || $0.warningMessage != nil
                }.count
        )
    }

    static func sortedMeals(
        _ meals: [TodayMealItem]
    ) -> [TodayMealItem] {
        meals.sorted { lhs, rhs in
            if lhs.slotPosition != rhs.slotPosition {
                return lhs.slotPosition < rhs.slotPosition
            }

            if lhs.slotName != rhs.slotName {
                return lhs.slotName
                    .localizedCaseInsensitiveCompare(
                        rhs.slotName
                    ) == .orderedAscending
            }

            return lhs.recipeName
                .localizedCaseInsensitiveCompare(
                    rhs.recipeName
                ) == .orderedAscending
        }
    }

    static func taskSort(
        lhs: TodayTaskItem,
        rhs: TodayTaskItem
    ) -> Bool {
        if lhs.scheduledStart != rhs.scheduledStart {
            return lhs.scheduledStart < rhs.scheduledStart
        }

        return lhs.position < rhs.position
    }
}

private extension TodayTaskStatus {
    static let allCasesForDisplay: [TodayTaskStatus] = [
        .overdue,
        .nextUp,
        .later,
        .completed
    ]
}
