import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class TodayStore {
    private(set) var isLoading = false
    private(set) var hasLoaded = false
    private(set) var todayMeals: [TodayMealItem] = []
    private(set) var todayTasks: [TodayTaskItem] = []
    private(set) var weekTasks: [TodayTaskItem] = []
    private(set) var summary = TodaySummary(
        mealCountToday: 0,
        taskCountToday: 0,
        completedTaskCountToday: 0,
        overdueTaskCountToday: 0,
        warningCountToday: 0,
        mealsPlannedThisWeek: 0,
        tasksRemainingThisWeek: 0,
        shoppingItemsRemainingThisWeek: 0,
        scheduleWarningsThisWeek: 0
    )

    var errorMessage: String?

    private var weekMealCount = 0
    private var shoppingItemsRemaining = 0
    private var weekStartsOnMonday = true
    private var calendar = Calendar.current
    private var loadedAt: Date?

    var todayTitle: String {
        Date().formatted(
            .dateTime.weekday(.wide)
                .month(.abbreviated)
                .day()
        )
    }

    var taskSections: [TodayTaskSection] {
        TodayDashboardBuilder.taskSections(
            tasks: todayTasks,
            now: Date()
        )
    }

    var nextTask: TodayTaskItem? {
        let nextID = TodayDashboardBuilder
            .nextUnfinishedTaskID(
                tasks: todayTasks,
                now: Date()
            )

        return todayTasks.first {
            $0.id == nextID
        }
    }

    func load(force: Bool = false) async {
        guard !isLoading else {
            return
        }

        if hasLoaded, !force, !isStale {
            return
        }

        isLoading = true
        errorMessage = nil

        defer {
            isLoading = false
        }

        do {
            let session = try await AppSupabase
                .client
                .auth
                .session

            try await loadPreference(
                userID: session.user.id
            )

            let today = Date()
            let todayKey = dateString(today)
            let weekStart = startOfWeek(
                containing: today
            )
            let weekEnd = calendar.date(
                byAdding: .day,
                value: 6,
                to: weekStart
            ) ?? weekStart

            var loadFailures: [String] = []

            do {
                let meals = try await loadMealData(
                    userID: session.user.id,
                    todayKey: todayKey,
                    weekStart: weekStart,
                    weekEnd: weekEnd
                )

                todayMeals = TodayDashboardBuilder
                    .sortedMeals(meals.todayMeals)
                weekMealCount = meals.weekMealCount
            } catch {
                todayMeals = []
                weekMealCount = 0
                loadFailures.append(
                    "Meals: \(friendlyError(error))"
                )
            }

            do {
                let tasks = try await loadTaskData(
                    userID: session.user.id,
                    todayKey: todayKey,
                    weekStart: weekStart,
                    weekEnd: weekEnd
                )

                todayTasks = tasks.todayTasks
                weekTasks = tasks.weekTasks
            } catch {
                todayTasks = []
                weekTasks = []
                loadFailures.append(
                    "Tasks: \(friendlyError(error))"
                )
            }

            do {
                shoppingItemsRemaining = try await loadShoppingCount(
                    userID: session.user.id,
                    weekStart: weekStart,
                    weekEnd: weekEnd
                )
            } catch {
                shoppingItemsRemaining = 0
                loadFailures.append(
                    "Shopping: \(friendlyError(error))"
                )
            }

            errorMessage = loadFailures.isEmpty
                ? nil
                : loadFailures.joined(separator: " • ")

            rebuildSummary()
            loadedAt = Date()
            hasLoaded = true
        } catch {
            if !(error is CancellationError) {
                errorMessage = error.localizedDescription
            }
        }
    }

    func refresh() async {
        await load(force: true)
    }

    func refreshWhenPageBecomesVisible() async {
        await load(force: true)
    }

    func toggleCompletion(
        _ task: TodayTaskItem
    ) async {
        do {
            let payload = ScheduleCompletionUpdate(
                isCompleted: !task.isCompleted
            )

            let updated: TodayTaskDatabaseRow =
                try await AppSupabase
                    .client
                    .from("schedule_tasks")
                    .update(payload)
                    .eq(
                        "id",
                        value: task.id.uuidString
                    )
                    .select(
                        TodayTaskDatabaseRow.selectColumns
                    )
                    .single()
                    .execute()
                    .value

            replaceTask(
                updated.item(
                    quantityLines:
                        existingQuantityLines(
                            for: task.id
                        )
                )
            )
            rebuildSummary()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private var isStale: Bool {
        guard let loadedAt else {
            return true
        }

        return Date().timeIntervalSince(loadedAt) > 15
    }

    private func loadPreference(userID: UUID) async throws {
        do {
            let preference: WeekStartPreference =
                try await AppSupabase
                    .client
                    .from("account_preferences")
                    .select("week_starts_on")
                    .eq(
                        "user_id",
                        value: userID.uuidString
                    )
                    .single()
                    .execute()
                    .value

            weekStartsOnMonday =
                preference.weekStartsOn.lowercased()
                != "sunday"
        } catch {
            weekStartsOnMonday = true
        }
    }

    private func loadMealData(
        userID: UUID,
        todayKey: String,
        weekStart: Date,
        weekEnd: Date
    ) async throws -> (
        todayMeals: [TodayMealItem],
        weekMealCount: Int
    ) {
        let weekStartKey = dateString(weekStart)
        let weekEndKey = dateString(weekEnd)

        async let entryRequest: [WeekPlanEntry] =
            AppSupabase.client
                .from("week_plan_entries")
                .select()
                .eq("user_id", value: userID.uuidString)
                .gte("meal_date", value: weekStartKey)
                .lte("meal_date", value: weekEndKey)
                .order("meal_date", ascending: true)
                .order("position", ascending: true)
                .execute()
                .value

        async let recipeRequest: [TodayRecipeRow] =
            AppSupabase.client
                .from("recipes")
                .select("id,name")
                .execute()
                .value

        async let slotRequest: [WeekMealSlot] =
            AppSupabase.client
                .from("meal_slot_preferences")
                .select(
                    "id,day_of_week,position,name,recipe_category,eat_time,ready_time,preparation_mode"
                )
                .eq("user_id", value: userID.uuidString)
                .order("day_of_week", ascending: true)
                .order("position", ascending: true)
                .execute()
                .value

        let entries = try await entryRequest
        let recipes = try await recipeRequest
        let slots = try await slotRequest

        let recipeByID = Dictionary(
            uniqueKeysWithValues: recipes.map {
                ($0.id, $0)
            }
        )

        let slotByID = Dictionary(
            uniqueKeysWithValues: slots.map {
                ($0.id, $0)
            }
        )

        let todayMeals = entries
            .filter { $0.mealDate == todayKey }
            .map { entry in
                let slot = slotByID[entry.mealSlotID]
                let recipe = recipeByID[entry.recipeID]

                return TodayMealItem(
                    id: entry.id,
                    recipeID: entry.recipeID,
                    mealDate: entry.mealDate,
                    slotName: slot?.name ?? "Meal",
                    slotPosition: slot?.position ?? entry.position,
                    recipeName: recipe?.name ?? "Recipe",
                    servings: entry.servings,
                    notes: entry.notes
                )
            }

        return (
            todayMeals,
            entries.count
        )
    }

    private func loadTaskData(
        userID: UUID,
        todayKey: String,
        weekStart: Date,
        weekEnd: Date
    ) async throws -> (
        todayTasks: [TodayTaskItem],
        weekTasks: [TodayTaskItem]
    ) {
        let weekStartKey = dateString(weekStart)
        let weekEndKey = dateString(weekEnd)

        let rows: [TodayTaskDatabaseRow] =
            try await AppSupabase
                .client
                .from("schedule_tasks")
                .select(
                    TodayTaskDatabaseRow.selectColumns
                )
                .eq("user_id", value: userID.uuidString)
                .gte("task_date", value: weekStartKey)
                .lte("task_date", value: weekEndKey)
                .order("scheduled_start", ascending: true)
                .order("position", ascending: true)
                .execute()
                .value

        guard !rows.isEmpty else {
            return ([], [])
        }

        async let entryRequest: [WeekPlanEntry] =
            AppSupabase.client
                .from("week_plan_entries")
                .select()
                .eq("user_id", value: userID.uuidString)
                .gte("meal_date", value: weekStartKey)
                .lte("meal_date", value: weekEndKey)
                .order("meal_date", ascending: true)
                .order("position", ascending: true)
                .execute()
                .value

        async let recipeRequest:
            [ScheduleRecipeSummary] =
            AppSupabase.client
                .from("recipes")
                .select(
                    """
                    id,
                    name,
                    default_servings,
                    minimum_batch_servings,
                    maximum_batch_servings,
                    refrigerator_life_days
                    """
                )
                .execute()
                .value

        async let recipeTaskRequest:
            [ScheduleRecipeTask] =
            AppSupabase.client
                .from("recipe_tasks")
                .select(
                    """
                    id,
                    recipe_id,
                    title,
                    instructions,
                    task_type,
                    active_minutes,
                    passive_minutes,
                    day_offset,
                    start_before_meal_minutes,
                    can_batch,
                    batch_key,
                    can_make_ahead,
                    maximum_make_ahead_hours,
                    storage_method,
                    unattended,
                    blocks_active_work,
                    position
                    """
                )
                .execute()
                .value

        async let prepOperationRequest:
            [ScheduleRecipePrepOperation] =
            AppSupabase.client
                .from("recipe_prep_operations")
                .select(
                    """
                    id,
                    recipe_id,
                    ingredient_position,
                    source_step_positions,
                    canonical_ingredient_name,
                    display_ingredient_name,
                    action,
                    preparation_state,
                    quantity,
                    unit,
                    can_make_ahead,
                    maximum_make_ahead_hours,
                    storage_method,
                    batch_key,
                    confidence,
                    manually_edited,
                    analysis_version,
                    position
                    """
                )
                .execute()
                .value

        async let ingredientRequest:
            [ScheduleRecipeIngredient] =
            AppSupabase.client
                .from("recipe_ingredients")
                .select(
                    """
                    id,
                    recipe_id,
                    name,
                    quantity,
                    unit,
                    preparation_note,
                    is_optional,
                    scaling_behavior,
                    position
                    """
                )
                .execute()
                .value

        let entries = try await entryRequest
        let recipes = try await recipeRequest
        let recipeTasks = try await recipeTaskRequest
        let prepOperations = try await prepOperationRequest
        let ingredients = try await ingredientRequest

        let weekTasks = rows.map {
            row in

            let preliminary = row.item()

            let quantityLines =
                ScheduledTaskQuantityResolver.lines(
                    for: preliminary,
                    entries: entries,
                    recipes: recipes,
                    recipeTasks: recipeTasks,
                    prepOperations: prepOperations,
                    ingredients: ingredients,
                    limit: 2
                )

            return row.item(
                quantityLines: quantityLines
            )
        }

        let todayTasks = weekTasks.filter {
            dateString($0.scheduledStart) == todayKey
        }

        return (
            todayTasks,
            weekTasks
        )
    }

    private func loadShoppingCount(
        userID: UUID,
        weekStart: Date,
        weekEnd: Date
    ) async throws -> Int {
        let weekStartKey = dateString(weekStart)
        let weekEndKey = dateString(weekEnd)

        async let entryRequest: [WeekPlanEntry] =
            AppSupabase.client
                .from("week_plan_entries")
                .select()
                .eq("user_id", value: userID.uuidString)
                .gte("meal_date", value: weekStartKey)
                .lte("meal_date", value: weekEndKey)
                .order("meal_date", ascending: true)
                .order("position", ascending: true)
                .execute()
                .value

        async let recipeRequest: [TodayShoppingRecipeRow] =
            AppSupabase.client
                .from("recipes")
                .select("id,name,default_servings")
                .execute()
                .value

        async let ingredientRequest: [TodayShoppingRecipeIngredientRow] =
            AppSupabase.client
                .from("recipe_ingredients")
                .select(
                    "id,recipe_id,name,quantity,unit,is_optional,scaling_behavior,shopping_included,position"
                )
                .execute()
                .value

        async let slotRequest: [WeekMealSlot] =
            AppSupabase.client
                .from("meal_slot_preferences")
                .select(
                    "id,day_of_week,position,name,recipe_category,eat_time,ready_time,preparation_mode"
                )
                .eq("user_id", value: userID.uuidString)
                .order("day_of_week", ascending: true)
                .order("position", ascending: true)
                .execute()
                .value

        async let pantryRequest = loadPantryItems(
            userID: userID
        )

        let entries = try await entryRequest
        let recipes = try await recipeRequest
        let ingredientRows = try await ingredientRequest
        let slots = try await slotRequest
        let pantryItems = try await pantryRequest

        let recipeByID = Dictionary(
            uniqueKeysWithValues: recipes.map {
                ($0.id, $0)
            }
        )

        let slotByID = Dictionary(
            uniqueKeysWithValues: slots.map {
                ($0.id, $0)
            }
        )

        let plannedMeals: [ShoppingPlannedMeal] = entries.reduce(
            into: []
        ) { result, entry in
            guard let recipe = recipeByID[entry.recipeID] else {
                return
            }

            result.append(
                ShoppingPlannedMeal(
                    id: entry.id,
                    recipeID: entry.recipeID,
                    recipeName: recipe.name,
                    mealDate: entry.mealDate,
                    slotName: slotByID[entry.mealSlotID]?.name ?? "Meal",
                    servings: entry.servings,
                    baseServings: recipe.defaultServings ?? 1
                )
            )
        }

        let plannedRecipeIDs = Set(entries.map(\.recipeID))
        let ingredients = ingredientRows
            .filter {
                plannedRecipeIDs.contains($0.recipeID)
            }
            .map(ShoppingRecipeIngredient.init)

        return ShoppingListEngine.generate(
            plannedMeals: plannedMeals,
            recipeIngredients: ingredients,
            pantryItems: pantryItems
        ).count
    }

    private func loadPantryItems(
        userID: UUID
    ) async throws -> [PantryStockItem] {
        let pantryRows: [PantryItemDatabaseRow] =
            try await AppSupabase.client
                .from("pantry_items")
                .select("*")
                .eq("user_id", value: userID.uuidString)
                .order("updated_at", ascending: false)
                .execute()
                .value

        guard !pantryRows.isEmpty else {
            return []
        }

        let ingredients: [PantryIngredientDatabaseRow] =
            try await AppSupabase.client
                .from("ingredients")
                .select(
                    "id,user_id,name,category,default_unit,approximate_allowed"
                )
                .eq("user_id", value: userID.uuidString)
                .execute()
                .value

        let ingredientByID = Dictionary(
            uniqueKeysWithValues: ingredients.map {
                ($0.id, $0)
            }
        )

        return pantryRows.map { row in
            row.stockItem(
                using: ingredientByID[row.ingredientID]
            )
        }
    }

    private func existingQuantityLines(
        for taskID: UUID
    ) -> [ScheduledTaskQuantityDisplayLine] {
        todayTasks.first {
            $0.id == taskID
        }?.quantityLines
        ?? weekTasks.first {
            $0.id == taskID
        }?.quantityLines
        ?? []
    }

    private func replaceTask(_ task: TodayTaskItem) {
        if let index = todayTasks.firstIndex(
            where: { $0.id == task.id }
        ) {
            todayTasks[index] = task
        }

        if let index = weekTasks.firstIndex(
            where: { $0.id == task.id }
        ) {
            weekTasks[index] = task
        }
    }

    private func rebuildSummary() {
        summary = TodayDashboardBuilder.summary(
            todayTasks: todayTasks,
            weekTasks: weekTasks,
            todayMeals: todayMeals,
            weekMealCount: weekMealCount,
            shoppingItemsRemaining: shoppingItemsRemaining,
            now: Date()
        )
    }

    private func friendlyError(_ error: Error) -> String {
        if let decodingError = error as? DecodingError {
            switch decodingError {
            case .keyNotFound(let key, _):
                return "Missing field \(key.stringValue)."
            case .valueNotFound(_, let context):
                return context.debugDescription
            case .typeMismatch(_, let context):
                return context.debugDescription
            case .dataCorrupted(let context):
                return context.debugDescription
            @unknown default:
                return decodingError.localizedDescription
            }
        }

        return error.localizedDescription
    }

    private func startOfWeek(containing date: Date) -> Date {
        let startWeekday = weekStartsOnMonday ? 2 : 1
        let weekday = calendar.component(
            .weekday,
            from: date
        )
        let offset = (weekday - startWeekday + 7) % 7
        let start = calendar.date(
            byAdding: .day,
            value: -offset,
            to: date
        ) ?? date

        return calendar.startOfDay(for: start)
    }

    private func dateString(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = calendar
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }
}

private struct TodayRecipeRow: Codable, Identifiable, Hashable {
    let id: UUID
    let name: String
}

private struct TodayShoppingRecipeRow:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let name: String
    let defaultServings: Double?

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case defaultServings = "default_servings"
    }
}

private struct TodayShoppingRecipeIngredientRow:
    Decodable,
    Identifiable,
    Hashable {

    let id: UUID
    let recipeID: UUID
    let name: String
    let quantity: Double
    let unit: String
    let isOptional: Bool
    let scalingBehavior: String
    let shoppingIncluded: Bool
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case recipeID = "recipe_id"
        case name
        case quantity
        case unit
        case isOptional = "is_optional"
        case scalingBehavior = "scaling_behavior"
        case shoppingIncluded = "shopping_included"
        case position
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        id = try container.decode(UUID.self, forKey: .id)
        recipeID = try container.decode(UUID.self, forKey: .recipeID)
        name = try container.decodeIfPresent(
            String.self,
            forKey: .name
        ) ?? "Ingredient"
        quantity = try container.decodeIfPresent(
            Double.self,
            forKey: .quantity
        ) ?? 0
        unit = try container.decodeIfPresent(
            String.self,
            forKey: .unit
        ) ?? ""
        isOptional = try container.decodeIfPresent(
            Bool.self,
            forKey: .isOptional
        ) ?? false
        scalingBehavior = try container.decodeIfPresent(
            String.self,
            forKey: .scalingBehavior
        ) ?? "linear"
        shoppingIncluded = try container.decodeIfPresent(
            Bool.self,
            forKey: .shoppingIncluded
        ) ?? true
        position = try container.decodeIfPresent(
            Int.self,
            forKey: .position
        ) ?? 0
    }
}

private extension ShoppingRecipeIngredient {
    init(_ row: TodayShoppingRecipeIngredientRow) {
        self.init(
            id: row.id,
            recipeID: row.recipeID,
            name: row.name,
            quantity: row.quantity,
            unit: row.unit,
            isOptional: row.isOptional,
            scalingBehavior: row.scalingBehavior,
            shoppingIncluded: row.shoppingIncluded,
            position: row.position
        )
    }
}

private struct TodayTaskDatabaseRow:
    Decodable,
    Identifiable,
    Hashable {

    static let selectColumns = """
    id,week_plan_entry_id,recipe_id,recipe_task_id,title,instructions,
    scheduled_start,scheduled_end,is_completed,
    has_conflict,warning_message,active_minutes,
    passive_minutes,batch_servings,covered_week_plan_entry_ids,is_shared_prep,
    shared_prep_key,position
    """

    let id: UUID
    let weekPlanEntryID: UUID
    let recipeID: UUID
    let recipeTaskID: UUID?
    let title: String
    let instructions: String?
    let scheduledStart: Date
    let scheduledEnd: Date
    let isCompleted: Bool
    let hasConflict: Bool
    let warningMessage: String?
    let activeMinutes: Int
    let passiveMinutes: Int
    let batchServings: Double
    let coveredWeekPlanEntryIDs: [UUID]
    let isSharedPrep: Bool
    let sharedPrepKey: String?
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case weekPlanEntryID = "week_plan_entry_id"
        case recipeID = "recipe_id"
        case recipeTaskID = "recipe_task_id"
        case title
        case instructions
        case scheduledStart = "scheduled_start"
        case scheduledEnd = "scheduled_end"
        case isCompleted = "is_completed"
        case hasConflict = "has_conflict"
        case warningMessage = "warning_message"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case batchServings = "batch_servings"
        case coveredWeekPlanEntryIDs = "covered_week_plan_entry_ids"
        case isSharedPrep = "is_shared_prep"
        case sharedPrepKey = "shared_prep_key"
        case position
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        id = try container.decode(UUID.self, forKey: .id)
        weekPlanEntryID = try container.decodeIfPresent(
            UUID.self,
            forKey: .weekPlanEntryID
        ) ?? id
        recipeID = try container.decode(UUID.self, forKey: .recipeID)
        recipeTaskID = try container.decodeIfPresent(
            UUID.self,
            forKey: .recipeTaskID
        )
        title = try container.decodeIfPresent(
            String.self,
            forKey: .title
        ) ?? "Task"
        instructions = try container.decodeIfPresent(
            String.self,
            forKey: .instructions
        )

        let start = try container.decode(
            Date.self,
            forKey: .scheduledStart
        )
        scheduledStart = start

        activeMinutes = try container.decodeIfPresent(
            Int.self,
            forKey: .activeMinutes
        ) ?? 0
        passiveMinutes = try container.decodeIfPresent(
            Int.self,
            forKey: .passiveMinutes
        ) ?? 0

        scheduledEnd = try container.decodeIfPresent(
            Date.self,
            forKey: .scheduledEnd
        ) ?? start.addingTimeInterval(
            TimeInterval(max(0, activeMinutes + passiveMinutes) * 60)
        )

        isCompleted = try container.decodeIfPresent(
            Bool.self,
            forKey: .isCompleted
        ) ?? false
        hasConflict = try container.decodeIfPresent(
            Bool.self,
            forKey: .hasConflict
        ) ?? false
        warningMessage = try container.decodeIfPresent(
            String.self,
            forKey: .warningMessage
        )
        batchServings = try container.decodeIfPresent(
            Double.self,
            forKey: .batchServings
        ) ?? 1
        coveredWeekPlanEntryIDs = try container.decodeIfPresent(
            [UUID].self,
            forKey: .coveredWeekPlanEntryIDs
        ) ?? []
        isSharedPrep = try container.decodeIfPresent(
            Bool.self,
            forKey: .isSharedPrep
        ) ?? false
        sharedPrepKey = try container.decodeIfPresent(
            String.self,
            forKey: .sharedPrepKey
        )
        position = try container.decodeIfPresent(
            Int.self,
            forKey: .position
        ) ?? 0
    }

    func item(
        quantityLines: [ScheduledTaskQuantityDisplayLine] = []
    ) -> TodayTaskItem {
        TodayTaskItem(
            id: id,
            weekPlanEntryID: weekPlanEntryID,
            recipeID: recipeID,
            recipeTaskID: recipeTaskID,
            title: title,
            instructions: instructions,
            scheduledStart: scheduledStart,
            scheduledEnd: scheduledEnd,
            activeMinutes: activeMinutes,
            passiveMinutes: passiveMinutes,
            isCompleted: isCompleted,
            hasConflict: hasConflict,
            warningMessage: warningMessage,
            batchServings: batchServings,
            coveredWeekPlanEntryIDs: coveredWeekPlanEntryIDs,
            isSharedPrep: isSharedPrep,
            sharedPrepKey: sharedPrepKey,
            quantityLines: quantityLines,
            position: position
        )
    }
}
