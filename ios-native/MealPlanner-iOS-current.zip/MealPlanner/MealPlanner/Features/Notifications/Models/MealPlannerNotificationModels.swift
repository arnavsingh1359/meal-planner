import Foundation

nonisolated enum MealPlannerNotificationKind: String, Codable, Hashable, CaseIterable {
    case weeklyPlanning
    case cookingSession
    case cookingTask
    case passiveTaskFinished
    case readyByRisk
    case overdueTask
    case shoppingReminder

    var debugTitle: String {
        switch self {
        case .weeklyPlanning:
            return "Debug: Weekly planning"
        case .cookingSession:
            return "Debug: Cooking session"
        case .cookingTask:
            return "Debug: Cooking task"
        case .passiveTaskFinished:
            return "Debug: Passive step complete"
        case .readyByRisk:
            return "Debug: Ready-by risk"
        case .overdueTask:
            return "Debug: Overdue task"
        case .shoppingReminder:
            return "Debug: Shopping reminder"
        }
    }

    var debugBody: String {
        switch self {
        case .weeklyPlanning:
            return "Plan next week’s meals so shopping and batch cooking are ready."
        case .cookingSession:
            return "Batch cooking starts soon: grouped prep and cooking tasks are ready."
        case .cookingTask:
            return "Start a scheduled cooking task now."
        case .passiveTaskFinished:
            return "A passive step like marinating, soaking, or resting is complete."
        case .readyByRisk:
            return "Start now to keep the meal on schedule."
        case .overdueTask:
            return "A cooking task is overdue and still incomplete."
        case .shoppingReminder:
            return "Your shopping list still has unchecked items."
        }
    }

    var debugDestination: String {
        switch self {
        case .weeklyPlanning:
            return "planning"
        case .shoppingReminder:
            return "shopping"
        default:
            return "schedule"
        }
    }
}


nonisolated struct MealPlannerNotificationDraft: Identifiable, Hashable {
    let id: String
    let kind: MealPlannerNotificationKind
    let title: String
    let body: String
    let fireDate: Date
    let threadIdentifier: String
    let destination: String

    var userInfo: [String: String] {
        [
            "source": "meal_planner",
            "kind": kind.rawValue,
            "destination": destination
        ]
    }
}

nonisolated struct MealPlannerNotificationTask: Identifiable, Hashable {
    let id: UUID
    let title: String
    let scheduledStart: Date
    let scheduledEnd: Date
    let activeMinutes: Int
    let passiveMinutes: Int
    let isCompleted: Bool
    let hasConflict: Bool
    let warningMessage: String?
    let batchID: UUID?
    let batchMealCount: Int
    let isSharedPrep: Bool
    let position: Int

    var blocksActiveWork: Bool {
        activeMinutes > 0
    }

    var hasPassiveWait: Bool {
        passiveMinutes > 0
    }

    var shouldNotifyWhenPassiveEnds: Bool {
        guard hasPassiveWait else {
            return false
        }

        let key = title.lowercased()
        return key.contains("marinate")
            || key.contains("soak")
            || key.contains("rest")
            || key.contains("proof")
            || key.contains("chill")
            || key.contains("refrigerate")
            || key.contains("ferment")
            || passiveMinutes >= 30
    }
}

nonisolated struct MealPlannerNotificationPlanningInput: Hashable {
    let weekStart: Date
    let isComplete: Bool
    let nextStepTitle: String
}

nonisolated struct MealPlannerNotificationShoppingInput: Hashable {
    let weekStart: Date
    let uncheckedItemCount: Int
}

nonisolated enum MealPlannerNotificationPlanner {
    static let identifierPrefix = "mealplanner."

    static func makeAllNotifications(
        planning: MealPlannerNotificationPlanningInput?,
        tasks: [MealPlannerNotificationTask],
        shopping: MealPlannerNotificationShoppingInput?,
        now: Date = Date(),
        calendar: Calendar = .current
    ) -> [MealPlannerNotificationDraft] {
        var drafts: [MealPlannerNotificationDraft] = []

        if let planning {
            drafts.append(
                contentsOf: weeklyPlanningReminders(
                    input: planning,
                    now: now,
                    calendar: calendar
                )
            )
        }

        drafts.append(
            contentsOf: cookingReminders(
                tasks: tasks,
                now: now,
                calendar: calendar
            )
        )

        if let shopping {
            drafts.append(
                contentsOf: shoppingReminders(
                    input: shopping,
                    now: now,
                    calendar: calendar
                )
            )
        }

        return drafts
            .filter { $0.fireDate > now }
            .sorted { $0.fireDate < $1.fireDate }
    }

    static func weeklyPlanningReminders(
        input: MealPlannerNotificationPlanningInput,
        now: Date = Date(),
        calendar: Calendar = .current
    ) -> [MealPlannerNotificationDraft] {
        guard !input.isComplete else {
            return []
        }

        let saturday = saturdayBeforePlanningWeek(
            weekStart: input.weekStart,
            calendar: calendar
        )

        let sunday = calendar.date(
            byAdding: .day,
            value: 1,
            to: saturday
        ) ?? input.weekStart

        let reminders: [(Date, Int, String, String)] = [
            (
                saturday,
                14,
                "Plan next week’s meals",
                "Start the weekly planning flow so shopping and batch cooking are ready."
            ),
            (
                saturday,
                18,
                "Finish next week’s meal plan",
                "Still incomplete: \(input.nextStepTitle). Finish this tonight."
            ),
            (
                sunday,
                8,
                "Shopping list needs to be ready",
                "Finish weekly planning before Sunday shopping. Next: \(input.nextStepTitle)."
            ),
            (
                sunday,
                10,
                "Final meal planning reminder",
                "Finish the checklist now so shopping and batch cooking can happen on time."
            )
        ]

        return reminders.compactMap { date, hour, title, body in
            guard let fireDate = dateAt(
                date,
                hour: hour,
                minute: 0,
                calendar: calendar
            ) else {
                return nil
            }

            return MealPlannerNotificationDraft(
                id: "\(identifierPrefix)weekly-planning.\(isoDate(input.weekStart)).\(hour)",
                kind: .weeklyPlanning,
                title: title,
                body: body,
                fireDate: fireDate,
                threadIdentifier: "mealplanner.weekly-planning",
                destination: "planning"
            )
        }
        .filter { $0.fireDate > now }
    }

    static func cookingReminders(
        tasks: [MealPlannerNotificationTask],
        now: Date = Date(),
        calendar: Calendar = .current
    ) -> [MealPlannerNotificationDraft] {
        let pendingActiveTasks = tasks
            .filter { !$0.isCompleted }
            .filter { $0.activeMinutes > 0 }
            .sorted {
                if $0.scheduledStart == $1.scheduledStart {
                    return $0.position < $1.position
                }
                return $0.scheduledStart < $1.scheduledStart
            }

        // Future/current active tasks are eligible for normal cooking-session,
        // individual start, passive-finish, and ready-risk reminders.
        // Fully elapsed tasks must not be discarded entirely because they still
        // need an overdue reminder. That is handled separately below.
        let schedulableActiveTasks = pendingActiveTasks
            .filter { $0.scheduledEnd > now }

        let clusters = cookingSessionClusters(
            tasks: schedulableActiveTasks,
            calendar: calendar
        )

        var clusteredTaskIDs = Set<UUID>()
        var drafts: [MealPlannerNotificationDraft] = []

        for cluster in clusters where cluster.tasks.count >= 2 {
            clusteredTaskIDs.formUnion(cluster.tasks.map(\.id))
            drafts.append(
                contentsOf: sessionReminders(
                    cluster: cluster,
                    now: now
                )
            )
        }

        for task in schedulableActiveTasks where !clusteredTaskIDs.contains(task.id) {
            drafts.append(
                contentsOf: individualTaskReminders(
                    task: task,
                    now: now
                )
            )
        }

        for task in tasks
            where !task.isCompleted
                && task.shouldNotifyWhenPassiveEnds
                && task.scheduledEnd > now {
            drafts.append(
                passiveCompletionReminder(
                    task: task
                )
            )
        }

        for task in schedulableActiveTasks {
            if let risk = readyByRiskReminder(
                task: task,
                now: now
            ) {
                drafts.append(risk)
            }
        }

        for task in pendingActiveTasks where task.scheduledStart < now {
            if let overdue = overdueReminder(
                task: task,
                now: now
            ) {
                drafts.append(overdue)
            }
        }

        return drafts
            .filter { $0.fireDate > now }
            .sorted { $0.fireDate < $1.fireDate }
    }

    static func shoppingReminders(
        input: MealPlannerNotificationShoppingInput,
        now: Date = Date(),
        calendar: Calendar = .current
    ) -> [MealPlannerNotificationDraft] {
        guard input.uncheckedItemCount > 0 else {
            return []
        }

        let saturday = saturdayBeforePlanningWeek(
            weekStart: input.weekStart,
            calendar: calendar
        )
        let sunday = calendar.date(
            byAdding: .day,
            value: 1,
            to: saturday
        ) ?? input.weekStart

        let specs: [(Int, String, String)] = [
            (
                8,
                "Shopping list still has items",
                "You have \(input.uncheckedItemCount) unchecked shopping item\(input.uncheckedItemCount == 1 ? "" : "s") for next week."
            ),
            (
                10,
                "Grocery reminder",
                "Finish shopping before batch cooking starts."
            )
        ]

        return specs.compactMap { hour, title, body in
            guard let fireDate = dateAt(
                sunday,
                hour: hour,
                minute: 0,
                calendar: calendar
            ) else {
                return nil
            }

            return MealPlannerNotificationDraft(
                id: "\(identifierPrefix)shopping.\(isoDate(input.weekStart)).\(hour)",
                kind: .shoppingReminder,
                title: title,
                body: body,
                fireDate: fireDate,
                threadIdentifier: "mealplanner.shopping",
                destination: "shopping"
            )
        }
        .filter { $0.fireDate > now }
    }

    static func cookingSessionClusters(
        tasks: [MealPlannerNotificationTask],
        calendar: Calendar = .current
    ) -> [MealPlannerNotificationSession] {
        var clusters: [MealPlannerNotificationSession] = []

        for task in tasks.sorted(by: { $0.scheduledStart < $1.scheduledStart }) {
            if var last = clusters.last,
               calendar.isDate(
                    last.start,
                    inSameDayAs: task.scheduledStart
               ),
               task.scheduledStart <= last.end.addingTimeInterval(20 * 60) {
                last.tasks.append(task)
                last.end = max(last.end, task.scheduledEnd)
                clusters[clusters.count - 1] = last
            } else {
                clusters.append(
                    MealPlannerNotificationSession(
                        start: task.scheduledStart,
                        end: task.scheduledEnd,
                        tasks: [task]
                    )
                )
            }
        }

        return clusters
    }

    private static func sessionReminders(
        cluster: MealPlannerNotificationSession,
        now: Date
    ) -> [MealPlannerNotificationDraft] {
        let taskCount = cluster.tasks.count
        let activeMinutes = cluster.tasks.reduce(0) { $0 + $1.activeMinutes }
        let firstTitle = cluster.tasks.first?.title ?? "Cooking"
        let duration = AppDurationFormatter.string(minutes: activeMinutes)

        let before = cluster.start.addingTimeInterval(-30 * 60)
        let sessionKey = stableSessionKey(cluster)

        return [
            MealPlannerNotificationDraft(
                id: "\(identifierPrefix)cooking-session.\(sessionKey).before",
                kind: .cookingSession,
                title: "Batch cooking starts in 30 minutes",
                body: "\(taskCount) tasks, about \(duration) active work. First: \(firstTitle).",
                fireDate: before,
                threadIdentifier: "mealplanner.cooking",
                destination: "schedule"
            ),
            MealPlannerNotificationDraft(
                id: "\(identifierPrefix)cooking-session.\(sessionKey).start",
                kind: .cookingSession,
                title: "Cooking session starts now",
                body: "Start \(firstTitle). \(taskCount) tasks are grouped together.",
                fireDate: cluster.start,
                threadIdentifier: "mealplanner.cooking",
                destination: "schedule"
            )
        ]
        .filter { $0.fireDate > now }
    }

    private static func individualTaskReminders(
        task: MealPlannerNotificationTask,
        now: Date
    ) -> [MealPlannerNotificationDraft] {
        let before = task.scheduledStart.addingTimeInterval(-15 * 60)
        let duration = AppDurationFormatter.string(minutes: task.activeMinutes + task.passiveMinutes)

        return [
            MealPlannerNotificationDraft(
                id: "\(identifierPrefix)cooking-task.\(task.id.uuidString).before",
                kind: .cookingTask,
                title: "Upcoming cooking task",
                body: "In 15 min: \(task.title) • \(duration)",
                fireDate: before,
                threadIdentifier: "mealplanner.cooking",
                destination: "schedule"
            ),
            MealPlannerNotificationDraft(
                id: "\(identifierPrefix)cooking-task.\(task.id.uuidString).start",
                kind: .cookingTask,
                title: "Start now",
                body: task.title,
                fireDate: task.scheduledStart,
                threadIdentifier: "mealplanner.cooking",
                destination: "schedule"
            )
        ]
        .filter { $0.fireDate > now }
    }

    private static func passiveCompletionReminder(
        task: MealPlannerNotificationTask
    ) -> MealPlannerNotificationDraft {
        MealPlannerNotificationDraft(
            id: "\(identifierPrefix)passive-finished.\(task.id.uuidString)",
            kind: .passiveTaskFinished,
            title: "Passive step is done",
            body: "\(task.title) should be ready for the next step.",
            fireDate: task.scheduledEnd,
            threadIdentifier: "mealplanner.cooking",
            destination: "schedule"
        )
    }

    private static func readyByRiskReminder(
        task: MealPlannerNotificationTask,
        now: Date
    ) -> MealPlannerNotificationDraft? {
        let fireDate = task.scheduledStart.addingTimeInterval(10 * 60)
        guard fireDate > now else {
            return nil
        }

        return MealPlannerNotificationDraft(
            id: "\(identifierPrefix)ready-risk.\(task.id.uuidString)",
            kind: .readyByRisk,
            title: "Start now to stay on schedule",
            body: "\(task.title) is part of today’s meal plan.",
            fireDate: fireDate,
            threadIdentifier: "mealplanner.cooking",
            destination: "schedule"
        )
    }

    private static func overdueReminder(
        task: MealPlannerNotificationTask,
        now: Date
    ) -> MealPlannerNotificationDraft? {
        let fireDate = now.addingTimeInterval(2 * 60)
        guard task.scheduledStart.addingTimeInterval(20 * 60) < now else {
            return nil
        }

        return MealPlannerNotificationDraft(
            id: "\(identifierPrefix)overdue.\(task.id.uuidString)",
            kind: .overdueTask,
            title: "Overdue cooking task",
            body: "\(task.title) was scheduled earlier and is still incomplete.",
            fireDate: fireDate,
            threadIdentifier: "mealplanner.cooking",
            destination: "schedule"
        )
    }

    static func debugReminder(
        kind: MealPlannerNotificationKind,
        fireDate: Date = Date().addingTimeInterval(10)
    ) -> MealPlannerNotificationDraft {
        MealPlannerNotificationDraft(
            id: "\(identifierPrefix)debug.\(kind.rawValue).\(UUID().uuidString)",
            kind: kind,
            title: kind.debugTitle,
            body: kind.debugBody,
            fireDate: fireDate,
            threadIdentifier: "mealplanner.debug",
            destination: kind.debugDestination
        )
    }

    static func allDebugReminders(
        startingAt startDate: Date = Date(),
        spacingSeconds: TimeInterval = 10
    ) -> [MealPlannerNotificationDraft] {
        MealPlannerNotificationKind.allCases.enumerated().map { index, kind in
            debugReminder(
                kind: kind,
                fireDate: startDate.addingTimeInterval(
                    spacingSeconds * Double(index + 1)
                )
            )
        }
    }

    private static func saturdayBeforePlanningWeek(
        weekStart: Date,
        calendar: Calendar
    ) -> Date {
        var date = calendar.startOfDay(for: weekStart)

        for _ in 0..<7 {
            if calendar.component(.weekday, from: date) == 7 {
                return date
            }

            date = calendar.date(
                byAdding: .day,
                value: -1,
                to: date
            ) ?? date.addingTimeInterval(-86_400)
        }

        return calendar.date(
            byAdding: .day,
            value: -1,
            to: weekStart
        ) ?? weekStart
    }

    private static func dateAt(
        _ date: Date,
        hour: Int,
        minute: Int,
        calendar: Calendar
    ) -> Date? {
        var components = calendar.dateComponents(
            [.year, .month, .day],
            from: date
        )
        components.hour = hour
        components.minute = minute
        components.second = 0
        return calendar.date(from: components)
    }

    private static func stableSessionKey(
        _ session: MealPlannerNotificationSession
    ) -> String {
        let firstID = session.tasks.first?.id.uuidString ?? UUID().uuidString
        return "\(isoDateTime(session.start)).\(firstID)"
    }

    private static func isoDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    private static func isoDateTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyyMMddHHmmss"
        return formatter.string(from: date)
    }
}

nonisolated struct MealPlannerNotificationSession: Hashable {
    var start: Date
    var end: Date
    var tasks: [MealPlannerNotificationTask]
}
