import Foundation
import UserNotifications

@MainActor
final class MealPlannerNotificationCenter {
    static let shared = MealPlannerNotificationCenter()

    private let center: UNUserNotificationCenter

    private init(
        center: UNUserNotificationCenter = .current()
    ) {
        self.center = center
    }

    func authorizationStatus() async -> UNAuthorizationStatus {
        await center.notificationSettings().authorizationStatus
    }

    func requestAuthorizationIfNeeded() async -> Bool {
        let status = await authorizationStatus()

        switch status {
        case .authorized, .provisional, .ephemeral:
            return true
        case .denied:
            return false
        case .notDetermined:
            do {
                return try await center.requestAuthorization(
                    options: [.alert, .badge, .sound]
                )
            } catch {
                return false
            }
        @unknown default:
            return false
        }
    }

    func replaceMealPlannerNotifications(
        with drafts: [MealPlannerNotificationDraft],
        removeDelivered: Bool = true
    ) async {
        let authorized = await requestAuthorizationIfNeeded()
        guard authorized else {
            return
        }

        await clearMealPlannerNotifications(
            removeDelivered: removeDelivered
        )

        for draft in drafts.prefix(60) {
            let content = UNMutableNotificationContent()
            content.title = draft.title
            content.body = draft.body
            content.sound = .default
            content.threadIdentifier = draft.threadIdentifier
            content.userInfo = draft.userInfo

            let components = Calendar.current.dateComponents(
                [.year, .month, .day, .hour, .minute, .second],
                from: draft.fireDate
            )

            let trigger = UNCalendarNotificationTrigger(
                dateMatching: components,
                repeats: false
            )

            let request = UNNotificationRequest(
                identifier: draft.id,
                content: content,
                trigger: trigger
            )

            do {
                try await center.add(request)
            } catch {
                continue
            }
        }
    }

    func clearMealPlannerNotifications(
        removeDelivered: Bool = true
    ) async {
        let pending = await center.pendingNotificationRequests()
        let pendingIDs = pending
            .map(\.identifier)
            .filter {
                $0.hasPrefix(
                    MealPlannerNotificationPlanner.identifierPrefix
                )
            }

        if !pendingIDs.isEmpty {
            center.removePendingNotificationRequests(
                withIdentifiers: pendingIDs
            )
        }

        guard removeDelivered else {
            return
        }

        let delivered = await center.deliveredNotifications()
        let deliveredIDs = delivered
            .map(\.request.identifier)
            .filter {
                $0.hasPrefix(
                    MealPlannerNotificationPlanner.identifierPrefix
                )
            }

        if !deliveredIDs.isEmpty {
            center.removeDeliveredNotifications(
                withIdentifiers: deliveredIDs
            )
        }
    }


    func scheduleDebugReminder(
        kind: MealPlannerNotificationKind,
        delaySeconds: TimeInterval = 10
    ) async -> Bool {
        await scheduleDebugReminders(
            [
                MealPlannerNotificationPlanner.debugReminder(
                    kind: kind,
                    fireDate: Date().addingTimeInterval(delaySeconds)
                )
            ],
            clearExistingDebugReminders: false
        )
    }

    func scheduleAllDebugReminders() async -> Bool {
        await scheduleDebugReminders(
            MealPlannerNotificationPlanner.allDebugReminders(
                startingAt: Date(),
                spacingSeconds: 10
            ),
            clearExistingDebugReminders: true
        )
    }

    private func scheduleDebugReminders(
        _ drafts: [MealPlannerNotificationDraft],
        clearExistingDebugReminders: Bool
    ) async -> Bool {
        let authorized = await requestAuthorizationIfNeeded()
        guard authorized else {
            return false
        }

        if clearExistingDebugReminders {
            await clearDebugMealPlannerNotifications()
        }

        for draft in drafts {
            let content = UNMutableNotificationContent()
            content.title = draft.title
            content.body = draft.body
            content.sound = .default
            content.threadIdentifier = draft.threadIdentifier
            content.userInfo = draft.userInfo

            let seconds = max(1, draft.fireDate.timeIntervalSinceNow)
            let trigger = UNTimeIntervalNotificationTrigger(
                timeInterval: seconds,
                repeats: false
            )

            let request = UNNotificationRequest(
                identifier: draft.id,
                content: content,
                trigger: trigger
            )

            do {
                try await center.add(request)
            } catch {
                return false
            }
        }

        return true
    }

    func clearDebugMealPlannerNotifications() async {
        let pending = await center.pendingNotificationRequests()
        let pendingIDs = pending
            .map(\.identifier)
            .filter {
                $0.hasPrefix(
                    "\(MealPlannerNotificationPlanner.identifierPrefix)debug."
                )
            }

        if !pendingIDs.isEmpty {
            center.removePendingNotificationRequests(
                withIdentifiers: pendingIDs
            )
        }

        let delivered = await center.deliveredNotifications()
        let deliveredIDs = delivered
            .map(\.request.identifier)
            .filter {
                $0.hasPrefix(
                    "\(MealPlannerNotificationPlanner.identifierPrefix)debug."
                )
            }

        if !deliveredIDs.isEmpty {
            center.removeDeliveredNotifications(
                withIdentifiers: deliveredIDs
            )
        }
    }

    func clearEverythingFromThisApp() async {
        center.removeAllPendingNotificationRequests()
        center.removeAllDeliveredNotifications()
    }
}
