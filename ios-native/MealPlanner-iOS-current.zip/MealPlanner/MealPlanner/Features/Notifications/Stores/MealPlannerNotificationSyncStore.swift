import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class MealPlannerNotificationSyncStore {
    static let shared = MealPlannerNotificationSyncStore()

    private(set) var isSyncing = false
    private(set) var lastSyncedAt: Date?
    private(set) var lastScheduledCount = 0
    private(set) var errorMessage: String?

    private let calendar = Calendar.current

    private init() {}

    func rescheduleAll() async {
        guard !isSyncing else {
            return
        }

        isSyncing = true
        errorMessage = nil

        defer {
            isSyncing = false
        }

        do {
            let session = try await AppSupabase.client.auth.session
            let userID = session.user.id
            let mondayStart = await loadWeekStartPreference(userID: userID)
            let weekStart = nextPlanningWeekStart(mondayStart: mondayStart)
            let weekStartKey = dateString(weekStart)

            let progress = await loadPlanningProgress(
                userID: userID,
                weekStartKey: weekStartKey
            )

            let tasks = try await loadUpcomingTasks(userID: userID)

            let shoppingInput = makeShoppingInput(
                progress: progress,
                weekStart: weekStart
            )

            let drafts = MealPlannerNotificationPlanner.makeAllNotifications(
                planning: MealPlannerNotificationPlanningInput(
                    weekStart: weekStart,
                    isComplete: progress.status.isComplete,
                    nextStepTitle: progress.nextIncompleteStep?.shortTitle ?? "Planning"
                ),
                tasks: tasks,
                shopping: shoppingInput,
                now: Date(),
                calendar: calendar
            )

            await MealPlannerNotificationCenter.shared
                .replaceMealPlannerNotifications(
                    with: drafts,
                    removeDelivered: true
                )

            lastScheduledCount = drafts.count
            lastSyncedAt = Date()
        } catch {
            if !(error is CancellationError) {
                errorMessage = error.localizedDescription
            }
        }
    }

    func clearOldMealPlannerNotifications() async {
        await MealPlannerNotificationCenter.shared
            .clearMealPlannerNotifications(
                removeDelivered: true
            )
        lastScheduledCount = 0
        lastSyncedAt = Date()
    }

    private func loadPlanningProgress(
        userID: UUID,
        weekStartKey: String
    ) async -> WeeklyPlanningProgress {
        do {
            let row: WeeklyPlanningProgressRow = try await AppSupabase.client
                .from("weekly_planning_statuses")
                .select(WeeklyPlanningProgressRow.selectColumns)
                .eq("user_id", value: userID.uuidString)
                .eq("week_start", value: weekStartKey)
                .single()
                .execute()
                .value

            return row.progress
        } catch {
            return WeeklyPlanningProgress(
                userID: userID,
                weekStart: weekStartKey
            )
        }
    }

    private func loadUpcomingTasks(
        userID: UUID
    ) async throws -> [MealPlannerNotificationTask] {
        let now = Date()
        let until = calendar.date(
            byAdding: .day,
            value: 10,
            to: now
        ) ?? now.addingTimeInterval(10 * 86_400)

        let rows: [NotificationScheduleTaskRow] = try await AppSupabase.client
            .from("schedule_tasks")
            .select(NotificationScheduleTaskRow.selectColumns)
            .eq("user_id", value: userID.uuidString)
            .eq("is_completed", value: false)
            .gte("scheduled_end", value: isoTimestamp(now.addingTimeInterval(-60 * 60)))
            .lte("scheduled_start", value: isoTimestamp(until))
            .order("scheduled_start", ascending: true)
            .execute()
            .value

        return rows.map(\.notificationTask)
    }

    private func makeShoppingInput(
        progress: WeeklyPlanningProgress,
        weekStart: Date
    ) -> MealPlannerNotificationShoppingInput? {
        guard progress.shoppingGeneratedAt != nil
            || progress.status.progressOrder >= WeeklyPlanningStatus.shoppingGenerated.progressOrder
        else {
            return nil
        }

        guard !progress.status.isComplete
            || calendar.component(.weekday, from: Date()) != 1
        else {
            return MealPlannerNotificationShoppingInput(
                weekStart: weekStart,
                uncheckedItemCount: 1
            )
        }

        return MealPlannerNotificationShoppingInput(
            weekStart: weekStart,
            uncheckedItemCount: 1
        )
    }

    private func loadWeekStartPreference(userID: UUID) async -> Bool {
        do {
            let preference: NotificationWeekStartPreference = try await AppSupabase.client
                .from("account_preferences")
                .select("week_starts_on")
                .eq("user_id", value: userID.uuidString)
                .single()
                .execute()
                .value

            return preference.weekStartsOn.lowercased() != "sunday"
        } catch {
            return true
        }
    }

    private func nextPlanningWeekStart(mondayStart: Bool) -> Date {
        let thisWeek = startOfWeek(
            containing: Date(),
            mondayStart: mondayStart
        )

        return calendar.date(
            byAdding: .day,
            value: 7,
            to: thisWeek
        ) ?? thisWeek
    }

    private func startOfWeek(
        containing date: Date,
        mondayStart: Bool
    ) -> Date {
        var calendar = calendar
        calendar.firstWeekday = mondayStart ? 2 : 1

        let components = calendar.dateComponents(
            [.yearForWeekOfYear, .weekOfYear],
            from: date
        )

        return calendar.date(from: components)
            ?? calendar.startOfDay(for: date)
    }

    private func dateString(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = calendar
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    private func isoTimestamp(_ date: Date) -> String {
        ISO8601DateFormatter().string(from: date)
    }
}

private struct NotificationWeekStartPreference: Decodable {
    let weekStartsOn: String

    enum CodingKeys: String, CodingKey {
        case weekStartsOn = "week_starts_on"
    }
}

private struct NotificationScheduleTaskRow: Decodable, Identifiable {
    let id: UUID
    let title: String
    let scheduledStart: Date
    let scheduledEnd: Date
    let activeMinutes: Int
    let passiveMinutes: Int
    let isCompleted: Bool
    let hasConflict: Bool
    let warningMessage: String?
    let batchID: UUID?
    let batchMealCount: Int?
    let isSharedPrep: Bool?
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case title
        case scheduledStart = "scheduled_start"
        case scheduledEnd = "scheduled_end"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case isCompleted = "is_completed"
        case hasConflict = "has_conflict"
        case warningMessage = "warning_message"
        case batchID = "batch_id"
        case batchMealCount = "batch_meal_count"
        case isSharedPrep = "is_shared_prep"
        case position
    }

    static let selectColumns = "id,title,scheduled_start,scheduled_end,active_minutes,passive_minutes,is_completed,has_conflict,warning_message,batch_id,batch_meal_count,is_shared_prep,position"

    var notificationTask: MealPlannerNotificationTask {
        MealPlannerNotificationTask(
            id: id,
            title: title,
            scheduledStart: scheduledStart,
            scheduledEnd: scheduledEnd,
            activeMinutes: activeMinutes,
            passiveMinutes: passiveMinutes,
            isCompleted: isCompleted,
            hasConflict: hasConflict,
            warningMessage: warningMessage,
            batchID: batchID,
            batchMealCount: batchMealCount ?? 1,
            isSharedPrep: isSharedPrep ?? false,
            position: position
        )
    }
}
