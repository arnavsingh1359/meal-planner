import Foundation
import UserNotifications

nonisolated enum MealPlannerNotificationRoute: String, Hashable, CaseIterable {
    case today
    case planning
    case week
    case schedule
    case shopping
    case pantry

    static func fromUserInfo(
        _ userInfo: [AnyHashable: Any]
    ) -> MealPlannerNotificationRoute? {
        guard let source = userInfo["source"] as? String,
              source == "meal_planner" else {
            return nil
        }

        guard let destination = userInfo["destination"] as? String else {
            return .today
        }

        return MealPlannerNotificationRoute(rawValue: destination) ?? .today
    }
}

final class MealPlannerNotificationResponseRouter: NSObject, UNUserNotificationCenterDelegate {
    static let shared = MealPlannerNotificationResponseRouter()

    private let lock = NSLock()
    private var pendingRoute: MealPlannerNotificationRoute?
    private var handler: ((MealPlannerNotificationRoute) -> Void)?

    private override init() {
        super.init()
    }

    func installAsNotificationDelegate() {
        UNUserNotificationCenter.current().delegate = self
    }

    func setHandler(
        _ handler: @escaping (MealPlannerNotificationRoute) -> Void
    ) {
        lock.lock()
        self.handler = handler
        let route = pendingRoute
        pendingRoute = nil
        lock.unlock()

        if let route {
            DispatchQueue.main.async {
                handler(route)
            }
        }
    }

    #if DEBUG
    func simulate(route: MealPlannerNotificationRoute) {
        deliver(route)
    }
    #endif

    private func deliver(
        _ route: MealPlannerNotificationRoute
    ) {
        lock.lock()
        let handler = handler
        if handler == nil {
            pendingRoute = route
        }
        lock.unlock()

        guard let handler else {
            return
        }

        DispatchQueue.main.async {
            handler(route)
        }
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        [.banner, .list, .sound]
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse
    ) async {
        guard let route = MealPlannerNotificationRoute.fromUserInfo(
            response.notification.request.content.userInfo
        ) else {
            return
        }

        deliver(route)
    }
}
