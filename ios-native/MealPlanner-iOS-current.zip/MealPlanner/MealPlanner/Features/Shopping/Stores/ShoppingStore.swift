import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class ShoppingStore {
    private(set) var generatedItems: [ShoppingListItem] = []
    private(set) var plannedMeals: [ShoppingPlannedMeal] = []
    private(set) var pantryItems: [PantryStockItem] = []
    private(set) var isLoading = false
    private(set) var hasLoaded = false
    var errorMessage: String?
    var showCheckedItems = true

    private(set) var manualItems: [ManualShoppingItem] = []
    private(set) var checkedItemIDs: Set<String> = []

    private var calendar = Calendar.current
    private var mondayStart = true
    private var weekStartDate = Date()

    var weekTitle: String {
        guard let end = calendar.date(byAdding: .day, value: 6, to: weekStartDate) else {
            return "This week"
        }

        return "\(weekStartDate.formatted(.dateTime.month(.abbreviated).day())) – \(end.formatted(.dateTime.month(.abbreviated).day().year()))"
    }

    var weekStartKey: String {
        dateString(weekStartDate)
    }

    var checklistItems: [ShoppingChecklistItem] {
        ShoppingChecklistBuilder.build(
            generatedItems: generatedItems,
            manualItems: manualItems,
            checkedItemIDs: checkedItemIDs,
            showCheckedItems: showCheckedItems
        )
    }

    var groupedChecklistItems: [(category: String, items: [ShoppingChecklistItem])] {
        ShoppingChecklistBuilder.grouped(checklistItems)
    }

    var totalItemCount: Int {
        generatedItems.count + manualItems.filter(\.isValid).count
    }

    var visibleItemCount: Int {
        checklistItems.count
    }

    var checkedItemCount: Int {
        checkedItemIDs.intersection(
            Set((generatedItems.map { "generated:\($0.id)" }) + manualItems.map(\.stableChecklistID))
        ).count
    }

    var plannedMealCount: Int { plannedMeals.count }

    var isCurrentWeek: Bool {
        weekStartKey == dateString(startOfWeek(containing: Date()))
    }

    func load(force: Bool = false) async {
        guard !isLoading else { return }
        guard force || !hasLoaded else { return }

        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            let session = try await AppSupabase.client.auth.session

            do {
                let preference: WeekStartPreference = try await AppSupabase.client
                    .from("account_preferences")
                    .select("week_starts_on")
                    .eq("user_id", value: session.user.id.uuidString)
                    .single()
                    .execute()
                    .value

                mondayStart = preference.weekStartsOn.lowercased() != "sunday"
            } catch {
                mondayStart = true
            }

            if !hasLoaded {
                weekStartDate = startOfWeek(containing: Date())
            }

            try await loadSelectedWeek(userID: session.user.id)
            hasLoaded = true
        } catch {
            if !(error is CancellationError) {
                errorMessage = error.localizedDescription
            }
        }
    }

    func refresh() async {
        await load(force: true)
    }

    func refreshWhenPageBecomesVisible() async {
        await load(force: true)
    }

    func goToPreviousWeek() async {
        shiftWeek(by: -7)
        await load(force: true)
    }

    func goToNextWeek() async {
        shiftWeek(by: 7)
        await load(force: true)
    }

    func goToCurrentWeek() async {
        weekStartDate = startOfWeek(containing: Date())
        await load(force: true)
    }

    func toggleChecked(_ item: ShoppingChecklistItem) {
        if checkedItemIDs.contains(item.id) {
            checkedItemIDs.remove(item.id)
        } else {
            checkedItemIDs.insert(item.id)
        }

        saveLocalChecklistState()
    }

    func addManualItem(
        name: String,
        quantity: Double,
        unit: String,
        category: String,
        note: String
    ) {
        let item = ManualShoppingItem(
            weekStart: weekStartKey,
            name: name,
            quantity: quantity,
            unit: unit,
            category: category,
            note: note
        )

        guard item.isValid else { return }

        manualItems.append(item)
        saveLocalChecklistState()
    }

    func deleteManualItem(id: UUID) {
        manualItems.removeAll { $0.id == id }
        checkedItemIDs = checkedItemIDs.filter { !$0.contains(id.uuidString) }
        saveLocalChecklistState()
    }

    private func loadSelectedWeek(userID: UUID) async throws {
        guard let weekEnd = calendar.date(byAdding: .day, value: 6, to: weekStartDate) else {
            generatedItems = []
            plannedMeals = []
            return
        }

        async let entryRequest: [WeekPlanEntry] = AppSupabase.client
            .from("week_plan_entries")
            .select()
            .gte("meal_date", value: dateString(weekStartDate))
            .lte("meal_date", value: dateString(weekEnd))
            .order("meal_date", ascending: true)
            .order("position", ascending: true)
            .execute()
            .value

        async let recipeRequest: [ShoppingRecipeRow] = AppSupabase.client
            .from("recipes")
            .select("id,name,default_servings")
            .execute()
            .value

        async let ingredientRequest: [ShoppingRecipeIngredientRow] = AppSupabase.client
            .from("recipe_ingredients")
            .select("id,recipe_id,name,quantity,unit,is_optional,scaling_behavior,shopping_included,position")
            .execute()
            .value

        async let slotRequest: [WeekMealSlot] = AppSupabase.client
            .from("meal_slot_preferences")
            .select("id,day_of_week,position,name,recipe_category,eat_time,ready_time,preparation_mode")
            .eq("user_id", value: userID.uuidString)
            .order("day_of_week", ascending: true)
            .order("position", ascending: true)
            .execute()
            .value

        async let pantryRequest: [PantryStockItem] = loadPantryItems(
            userID: userID
        )

        let entries = try await entryRequest
        let recipes = try await recipeRequest
        let ingredientRows = try await ingredientRequest
        let slots = try await slotRequest
        let loadedPantry = try await pantryRequest

        let recipeByID = Dictionary(uniqueKeysWithValues: recipes.map { ($0.id, $0) })
        let slotByID = Dictionary(uniqueKeysWithValues: slots.map { ($0.id, $0) })
        let plannedRecipeIDs = Set(entries.map(\.recipeID))

        plannedMeals = entries.compactMap { entry in
            guard let recipe = recipeByID[entry.recipeID] else {
                return nil
            }

            let slotName = slotByID[entry.mealSlotID]?.name ?? "Meal"

            return ShoppingPlannedMeal(
                id: entry.id,
                recipeID: entry.recipeID,
                recipeName: recipe.name,
                mealDate: entry.mealDate,
                slotName: slotName,
                servings: entry.servings,
                baseServings: recipe.defaultServings ?? 1
            )
        }

        let ingredients = ingredientRows
            .filter { plannedRecipeIDs.contains($0.recipeID) }
            .map(ShoppingRecipeIngredient.init)

        pantryItems = loadedPantry
        generatedItems = ShoppingListEngine.generate(
            plannedMeals: plannedMeals,
            recipeIngredients: ingredients,
            pantryItems: loadedPantry
        )

        loadLocalChecklistState()
        pruneCheckedItems()
        saveLocalChecklistState()
    }

    private func loadLocalChecklistState() {
        let snapshot = ShoppingChecklistLocalStorage.load(
            weekStart: weekStartKey
        )
        checkedItemIDs = snapshot.checkedItemIDs
        manualItems = snapshot.manualItems
            .filter { $0.weekStart == weekStartKey }
            .filter(\.isValid)
    }

    private func saveLocalChecklistState() {
        ShoppingChecklistLocalStorage.save(
            ShoppingChecklistSnapshot(
                checkedItemIDs: checkedItemIDs,
                manualItems: manualItems
            ),
            weekStart: weekStartKey
        )
    }

    private func pruneCheckedItems() {
        let validIDs = Set(
            generatedItems.map { "generated:\($0.id)" }
                + manualItems.map(\.stableChecklistID)
        )

        checkedItemIDs = checkedItemIDs.intersection(validIDs)
    }

    private func shiftWeek(by days: Int) {
        weekStartDate = calendar.date(
            byAdding: .day,
            value: days,
            to: weekStartDate
        ) ?? weekStartDate
    }

    private func loadPantryItems(userID: UUID) async throws -> [PantryStockItem] {
        let pantryRows: [PantryItemDatabaseRow] = try await AppSupabase.client
            .from("pantry_items")
            .select("*")
            .eq("user_id", value: userID.uuidString)
            .order("updated_at", ascending: false)
            .execute()
            .value

        guard !pantryRows.isEmpty else {
            return []
        }

        let ingredients: [PantryIngredientDatabaseRow] = try await AppSupabase.client
            .from("ingredients")
            .select("id,user_id,name,category,default_unit,approximate_allowed")
            .eq("user_id", value: userID.uuidString)
            .execute()
            .value

        let ingredientByID = Dictionary(
            uniqueKeysWithValues: ingredients.map { ($0.id, $0) }
        )

        return pantryRows.map { row in
            row.stockItem(using: ingredientByID[row.ingredientID])
        }
    }

    private func startOfWeek(containing date: Date) -> Date {
        let startWeekday = mondayStart ? 2 : 1
        let weekday = calendar.component(.weekday, from: date)
        let offset = (weekday - startWeekday + 7) % 7
        let start = calendar.date(byAdding: .day, value: -offset, to: date) ?? date
        return calendar.startOfDay(for: start)
    }

    private func dateString(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = calendar
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }
}

private struct ShoppingRecipeRow: Codable, Identifiable, Hashable {
    let id: UUID
    let name: String
    let defaultServings: Double?

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case defaultServings = "default_servings"
    }
}

private struct ShoppingRecipeIngredientRow: Codable, Identifiable, Hashable {
    let id: UUID
    let recipeID: UUID
    let name: String
    let quantity: Double
    let unit: String
    let isOptional: Bool
    let scalingBehavior: String
    let shoppingIncluded: Bool
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case recipeID = "recipe_id"
        case name
        case quantity
        case unit
        case isOptional = "is_optional"
        case scalingBehavior = "scaling_behavior"
        case shoppingIncluded = "shopping_included"
        case position
    }
}

private extension ShoppingRecipeIngredient {
    init(_ row: ShoppingRecipeIngredientRow) {
        self.init(
            id: row.id,
            recipeID: row.recipeID,
            name: row.name,
            quantity: row.quantity,
            unit: row.unit,
            isOptional: row.isOptional,
            scalingBehavior: row.scalingBehavior,
            shoppingIncluded: row.shoppingIncluded,
            position: row.position
        )
    }
}
