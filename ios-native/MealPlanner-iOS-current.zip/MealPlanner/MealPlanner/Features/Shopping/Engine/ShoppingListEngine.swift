import Foundation

nonisolated enum ShoppingListEngine {
    static func generate(
        plannedMeals: [ShoppingPlannedMeal],
        recipeIngredients: [ShoppingRecipeIngredient],
        pantryItems: [PantryStockItem]
    ) -> [ShoppingListItem] {
        guard !plannedMeals.isEmpty else {
            return []
        }

        let mealsByRecipe = Dictionary(
            grouping: plannedMeals,
            by: \.recipeID
        )

        var requiredBuckets: [ShoppingIngredientKey: ShoppingBucket] = [:]

        for ingredient in recipeIngredients where ingredient.shoppingIncluded {
            guard let meals = mealsByRecipe[ingredient.recipeID], !meals.isEmpty else {
                continue
            }

            guard ingredient.quantity > 0 else {
                continue
            }

            guard ingredient.scalingBehavior != "to_taste" else {
                continue
            }

            for meal in meals {
                let normalized = ShoppingIngredientNormalizer.normalize(
                    name: ingredient.name,
                    unit: ingredient.unit
                )

                guard normalized.baseQuantityMultiplier > 0 else {
                    continue
                }

                let scaledQuantity: Double
                if ingredient.scalingBehavior == "fixed"
                    || meal.baseServings <= 0 {
                    scaledQuantity = ingredient.quantity
                } else {
                    scaledQuantity = ingredient.quantity
                        * meal.servings
                        / meal.baseServings
                }

                let baseQuantity = scaledQuantity
                    * normalized.baseQuantityMultiplier

                guard baseQuantity > 0 else {
                    continue
                }

                let key = ShoppingIngredientKey(
                    canonicalName: normalized.canonicalName,
                    unitFamily: normalized.unitFamily,
                    baseUnit: normalized.baseUnit
                )

                var bucket = requiredBuckets[key]
                    ?? ShoppingBucket(
                        key: key,
                        displayName: normalized.displayName,
                        category: ShoppingIngredientNormalizer.category(
                            for: normalized.canonicalName
                        )
                    )

                bucket.requiredQuantity += baseQuantity
                bucket.sourceRecipeNames.insert(meal.recipeName)
                bucket.sourceMealIDs.insert(meal.id)
                requiredBuckets[key] = bucket
            }
        }

        let pantryCoverage = pantryCoverageByKey(
            pantryItems,
            requiredBuckets: requiredBuckets
        )

        return requiredBuckets.values
            .compactMap { bucket in
                let pantryQuantity = pantryCoverage[bucket.key] ?? 0
                let neededQuantity = max(
                    0,
                    bucket.requiredQuantity - pantryQuantity
                )

                guard neededQuantity > 0.000_001 else {
                    return nil
                }

                let display = displayQuantity(
                    neededQuantity,
                    requiredQuantity: bucket.requiredQuantity,
                    pantryQuantity: pantryQuantity,
                    baseUnit: bucket.key.baseUnit,
                    unitFamily: bucket.key.unitFamily
                )

                return ShoppingListItem(
                    id: bucket.key.id,
                    canonicalName: bucket.key.canonicalName,
                    displayName: bucket.displayName,
                    requiredQuantity: display.requiredQuantity,
                    pantryQuantity: display.pantryQuantity,
                    neededQuantity: display.neededQuantity,
                    unit: display.unit,
                    category: bucket.category,
                    sourceRecipeNames: Array(bucket.sourceRecipeNames).sorted(),
                    sourceMealCount: bucket.sourceMealIDs.count
                )
            }
            .sorted { lhs, rhs in
                if lhs.category == rhs.category {
                    return lhs.displayName.localizedCaseInsensitiveCompare(
                        rhs.displayName
                    ) == .orderedAscending
                }

                return lhs.category.localizedCaseInsensitiveCompare(
                    rhs.category
                ) == .orderedAscending
            }
    }

    private static func pantryCoverageByKey(
        _ pantryItems: [PantryStockItem],
        requiredBuckets: [ShoppingIngredientKey: ShoppingBucket]
    ) -> [ShoppingIngredientKey: Double] {
        var quantities: [ShoppingIngredientKey: Double] = [:]
        var approximateCoverageNames: Set<String> = []

        for item in pantryItems {
            guard item.canSubtractFromShopping else {
                continue
            }

            let normalized = ShoppingIngredientNormalizer.normalize(
                name: item.name,
                unit: item.resolvedUnit
            )

            switch item.normalizedTrackingMode {
            case .approximate:
                approximateCoverageNames.insert(normalized.canonicalName)

            case .exact:
                guard item.quantity > 0, normalized.baseQuantityMultiplier > 0 else {
                    continue
                }

                let key = ShoppingIngredientKey(
                    canonicalName: normalized.canonicalName,
                    unitFamily: normalized.unitFamily,
                    baseUnit: normalized.baseUnit
                )

                quantities[key, default: 0] += item.quantity
                    * normalized.baseQuantityMultiplier
            }
        }

        for bucket in requiredBuckets.values {
            if approximateCoverageNames.contains(bucket.key.canonicalName) {
                quantities[bucket.key] = max(
                    quantities[bucket.key] ?? 0,
                    bucket.requiredQuantity
                )
            }
        }

        return quantities
    }

    private static func displayQuantity(
        _ neededQuantity: Double,
        requiredQuantity: Double,
        pantryQuantity: Double,
        baseUnit: String,
        unitFamily: String
    ) -> (
        neededQuantity: Double,
        requiredQuantity: Double,
        pantryQuantity: Double,
        unit: String
    ) {
        switch unitFamily {
        case "mass" where neededQuantity >= 1_000:
            return (
                neededQuantity / 1_000,
                requiredQuantity / 1_000,
                pantryQuantity / 1_000,
                "kg"
            )

        case "volume" where neededQuantity >= 1_000:
            return (
                neededQuantity / 1_000,
                requiredQuantity / 1_000,
                pantryQuantity / 1_000,
                "L"
            )

        default:
            return (
                neededQuantity,
                requiredQuantity,
                pantryQuantity,
                baseUnit
            )
        }
    }
}

nonisolated struct ShoppingIngredientKey: Hashable {
    let canonicalName: String
    let unitFamily: String
    let baseUnit: String

    var id: String {
        "\(canonicalName)|\(unitFamily)|\(baseUnit)"
    }
}

private struct ShoppingBucket {
    let key: ShoppingIngredientKey
    let displayName: String
    let category: String
    var requiredQuantity: Double = 0
    var sourceRecipeNames: Set<String> = []
    var sourceMealIDs: Set<UUID> = []
}

nonisolated enum ShoppingIngredientNormalizer {
    static func normalize(name: String, unit: String) -> ShoppingNormalizedIngredient {
        let canonicalName = canonicalizeName(name)
        let unitInfo = normalizeUnit(unit)

        return ShoppingNormalizedIngredient(
            canonicalName: canonicalName,
            displayName: displayName(for: canonicalName),
            unitFamily: unitInfo.family,
            baseUnit: unitInfo.baseUnit,
            baseQuantityMultiplier: unitInfo.multiplier
        )
    }

    static func category(for canonicalName: String) -> String {
        switch canonicalName {
        case "apple", "banana", "lemon", "lime", "mango":
            return "Fruit"

        case "basmati rice", "rice", "brown rice", "poha", "semolina", "wheat flour", "maida", "bread", "pasta", "oats":
            return "Grains"

        case "toor dal", "moong dal", "masoor dal", "chana dal", "urad dal", "chickpeas", "rajma", "black beans", "lentils":
            return "Lentils & Beans"

        case "milk", "curd", "yogurt", "paneer", "cheese", "butter", "ghee", "cream":
            return "Dairy"

        case "chicken", "fish", "shrimp", "egg", "mutton", "lamb":
            return "Protein"

        case "salt", "sugar", "jaggery", "oil", "olive oil", "mustard oil", "vinegar", "soy sauce":
            return "Pantry"

        case "turmeric", "cumin", "coriander powder", "red chili powder", "garam masala", "mustard seeds", "curry leaves", "hing", "black pepper", "cardamom", "cloves", "cinnamon":
            return "Spices"

        default:
            return "Produce"
        }
    }

    private static func canonicalizeName(_ name: String) -> String {
        var value = name
            .lowercased()
            .replacingOccurrences(of: "_", with: " ")
            .replacingOccurrences(of: "-", with: " ")
            .replacingOccurrences(of: ",", with: " ")
            .replacingOccurrences(of: "(", with: " ")
            .replacingOccurrences(of: ")", with: " ")

        let removableWords = [
            "fresh", "frozen", "chopped", "diced", "sliced", "minced",
            "crushed", "grated", "peeled", "cubed", "powdered", "ground",
            "whole", "small", "medium", "large", "extra", "finely", "roughly"
        ]

        for word in removableWords {
            value = value.replacingOccurrences(
                of: "\\b\(word)\\b",
                with: " ",
                options: .regularExpression
            )
        }

        value = value
            .split(separator: " ")
            .joined(separator: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        let aliases: [String: String] = [
            "onions": "onion",
            "tomatoes": "tomato",
            "potatoes": "potato",
            "green chilli": "green chili",
            "green chillies": "green chili",
            "green chilies": "green chili",
            "chilli": "chili",
            "chillies": "chili",
            "chilies": "chili",
            "capsicum": "bell pepper",
            "bell peppers": "bell pepper",
            "coriander": "coriander leaves",
            "coriander leaf": "coriander leaves",
            "coriander leaves": "coriander leaves",
            "cilantro": "coriander leaves",
            "cilantro leaves": "coriander leaves",
            "fresh coriander": "coriander leaves",
            "fresh coriander leaves": "coriander leaves",
            "spring onion": "scallion",
            "spring onions": "scallion",
            "green onion": "scallion",
            "green onions": "scallion",
            "curd": "yogurt",
            "dahi": "yogurt",
            "yoghurt": "yogurt",
            "clarified butter": "ghee",
            "ginger garlic paste": "ginger garlic paste",
            "garbanzo beans": "chickpeas",
            "chickpea": "chickpeas",
            "kabuli chana": "chickpeas",
            "kidney beans": "rajma",
            "eggplant": "brinjal",
            "aubergine": "brinjal",
            "okra": "bhindi",
            "lady finger": "bhindi",
            "ladies finger": "bhindi",
            "all purpose flour": "maida",
            "plain flour": "maida",
            "cottage cheese": "paneer",
            "cumin seeds": "cumin",
            "jeera": "cumin",
            "haldi": "turmeric",
            "turmeric powder": "turmeric",
            "dhania powder": "coriander powder",
            "coriander seed powder": "coriander powder",
            "red chilli powder": "red chili powder",
            "red chilly powder": "red chili powder"
        ]

        if let alias = aliases[value] {
            return alias
        }

        if value.hasSuffix("ies"), value.count > 3 {
            return String(value.dropLast(3)) + "y"
        }

        if value.hasSuffix("es"), value.count > 3 {
            return String(value.dropLast(2))
        }

        if value.hasSuffix("s"), value.count > 3 {
            return String(value.dropLast())
        }

        return value.isEmpty ? "unknown" : value
    }

    private static func displayName(for canonicalName: String) -> String {
        canonicalName
            .split(separator: " ")
            .map { word in
                word.prefix(1).uppercased() + word.dropFirst()
            }
            .joined(separator: " ")
    }

    private static func normalizeUnit(_ unit: String) -> (
        family: String,
        baseUnit: String,
        multiplier: Double
    ) {
        let value = unit
            .lowercased()
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: ".", with: "")

        switch value {
        case "g", "gram", "grams", "gm", "gms":
            return ("mass", "g", 1)
        case "kg", "kilogram", "kilograms", "kgs":
            return ("mass", "g", 1_000)
        case "oz", "ounce", "ounces":
            return ("mass", "g", 28.3495)
        case "lb", "lbs", "pound", "pounds":
            return ("mass", "g", 453.592)

        case "ml", "milliliter", "milliliters", "millilitre", "millilitres":
            return ("volume", "ml", 1)
        case "l", "liter", "liters", "litre", "litres":
            return ("volume", "ml", 1_000)
        case "tsp", "teaspoon", "teaspoons":
            return ("volume", "ml", 5)
        case "tbsp", "tablespoon", "tablespoons":
            return ("volume", "ml", 15)
        case "cup", "cups":
            return ("volume", "ml", 240)

        case "", "count", "piece", "pieces", "pc", "pcs", "item", "items", "whole", "clove", "cloves", "bunch", "bunches", "sprig", "sprigs":
            return ("count", "count", 1)

        default:
            return ("custom:\(value)", value, 1)
        }
    }
}

nonisolated struct ShoppingNormalizedIngredient: Hashable {
    let canonicalName: String
    let displayName: String
    let unitFamily: String
    let baseUnit: String
    let baseQuantityMultiplier: Double
}
