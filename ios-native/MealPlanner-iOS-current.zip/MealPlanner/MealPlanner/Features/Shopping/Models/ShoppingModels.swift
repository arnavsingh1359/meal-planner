import Foundation

nonisolated struct ShoppingPlannedMeal: Hashable, Identifiable {
    let id: UUID
    let recipeID: UUID
    let recipeName: String
    let mealDate: String
    let slotName: String
    let servings: Double
    let baseServings: Double
}

nonisolated struct ShoppingRecipeIngredient: Hashable, Identifiable {
    let id: UUID
    let recipeID: UUID
    let name: String
    let quantity: Double
    let unit: String
    let isOptional: Bool
    let scalingBehavior: String
    let shoppingIncluded: Bool
    let position: Int
}

nonisolated struct ShoppingListItem: Hashable, Identifiable {
    let id: String
    let canonicalName: String
    let displayName: String
    let requiredQuantity: Double
    let pantryQuantity: Double
    let neededQuantity: Double
    let unit: String
    let category: String
    let sourceRecipeNames: [String]
    let sourceMealCount: Int

    var quantityText: String {
        ShoppingQuantityFormatter.quantityText(
            neededQuantity,
            unit: unit
        )
    }

    var requiredText: String {
        ShoppingQuantityFormatter.quantityText(
            requiredQuantity,
            unit: unit
        )
    }

    var pantryText: String {
        ShoppingQuantityFormatter.quantityText(
            pantryQuantity,
            unit: unit
        )
    }

    var sourceText: String {
        guard !sourceRecipeNames.isEmpty else {
            return "Weekly menu"
        }

        return sourceRecipeNames.joined(separator: " • ")
    }
}

nonisolated enum ShoppingQuantityFormatter {
    static func quantityText(_ value: Double, unit: String) -> String {
        let cleanedValue = abs(value) < 0.000_001 ? 0 : value
        let amount = cleanedValue.formatted(
            .number.precision(.fractionLength(0...2))
        )

        guard !unit.isEmpty else {
            return amount
        }

        return "\(amount) \(unit)"
    }
}
