import Foundation

nonisolated struct ShoppingPlannedMeal: Hashable, Identifiable {
    let id: UUID
    let recipeID: UUID
    let recipeName: String
    let mealDate: String
    let slotName: String
    let servings: Double
    let baseServings: Double
}

nonisolated struct ShoppingRecipeIngredient: Hashable, Identifiable {
    let id: UUID
    let recipeID: UUID
    let name: String
    let quantity: Double
    let unit: String
    let isOptional: Bool
    let scalingBehavior: String
    let shoppingIncluded: Bool
    let position: Int
}

nonisolated struct ShoppingListItem: Hashable, Identifiable {
    let id: String
    let canonicalName: String
    let displayName: String
    let requiredQuantity: Double
    let pantryQuantity: Double
    let neededQuantity: Double
    let unit: String
    let category: String
    let sourceRecipeNames: [String]
    let sourceMealCount: Int

    var quantityText: String {
        ShoppingQuantityFormatter.quantityText(
            neededQuantity,
            unit: unit
        )
    }

    var requiredText: String {
        ShoppingQuantityFormatter.quantityText(
            requiredQuantity,
            unit: unit
        )
    }

    var pantryText: String {
        ShoppingQuantityFormatter.quantityText(
            pantryQuantity,
            unit: unit
        )
    }

    var sourceText: String {
        guard !sourceRecipeNames.isEmpty else {
            return "Weekly menu"
        }

        return sourceRecipeNames.joined(separator: " • ")
    }

    var compactSourceText: String {
        if sourceMealCount > 1 {
            return "Used in \(sourceMealCount) meals"
        }

        if let firstRecipe = sourceRecipeNames.first, !firstRecipe.isEmpty {
            return "Used in \(firstRecipe)"
        }

        return "Weekly menu"
    }

    var needText: String {
        if pantryQuantity > 0 {
            return "Need \(requiredText) • Pantry \(pantryText)"
        }

        return "Need \(requiredText)"
    }
}

nonisolated enum ShoppingQuantityFormatter {
    static func quantityText(_ value: Double, unit: String) -> String {
        let cleanedValue = abs(value) < 0.000_001 ? 0 : value
        let amount = cleanedValue.formatted(
            .number.precision(.fractionLength(0...2))
        )

        guard !unit.isEmpty else {
            return amount
        }

        return "\(amount) \(unit)"
    }
}

nonisolated enum ShoppingChecklistItemKind: String, Codable, Hashable {
    case generated
    case manual
}

nonisolated struct ManualShoppingItem: Codable, Hashable, Identifiable {
    let id: UUID
    let weekStart: String
    var name: String
    var quantity: Double
    var unit: String
    var category: String
    var note: String
    var createdAt: Date

    init(
        id: UUID = UUID(),
        weekStart: String,
        name: String,
        quantity: Double,
        unit: String,
        category: String = "Miscellaneous",
        note: String = "",
        createdAt: Date = Date()
    ) {
        self.id = id
        self.weekStart = weekStart
        self.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        self.quantity = quantity
        self.unit = unit.trimmingCharacters(in: .whitespacesAndNewlines)
        self.category = category.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? "Miscellaneous"
            : category.trimmingCharacters(in: .whitespacesAndNewlines)
        self.note = note.trimmingCharacters(in: .whitespacesAndNewlines)
        self.createdAt = createdAt
    }

    var isValid: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var stableChecklistID: String {
        "manual:\(weekStart):\(id.uuidString)"
    }

    var quantityText: String {
        guard quantity > 0 else {
            return unit.isEmpty ? "" : unit
        }

        return ShoppingQuantityFormatter.quantityText(
            quantity,
            unit: unit
        )
    }
}

nonisolated struct ShoppingChecklistItem: Hashable, Identifiable {
    let id: String
    let kind: ShoppingChecklistItemKind
    let displayName: String
    let quantityText: String
    let category: String
    let detailText: String
    let secondaryText: String
    let isChecked: Bool
    let manualItemID: UUID?

    var accessibilityLabel: String {
        let status = isChecked ? "checked" : "unchecked"
        return "\(displayName), \(quantityText), \(status)"
    }
}

nonisolated enum ShoppingChecklistBuilder {
    static func build(
        generatedItems: [ShoppingListItem],
        manualItems: [ManualShoppingItem],
        checkedItemIDs: Set<String>,
        showCheckedItems: Bool
    ) -> [ShoppingChecklistItem] {
        let generated = generatedItems.map { item in
            ShoppingChecklistItem(
                id: "generated:\(item.id)",
                kind: .generated,
                displayName: item.displayName,
                quantityText: item.quantityText,
                category: item.category,
                detailText: item.compactSourceText,
                secondaryText: item.needText,
                isChecked: checkedItemIDs.contains("generated:\(item.id)"),
                manualItemID: nil
            )
        }

        let manual = manualItems
            .filter(\.isValid)
            .map { item in
                ShoppingChecklistItem(
                    id: item.stableChecklistID,
                    kind: .manual,
                    displayName: item.name,
                    quantityText: item.quantityText,
                    category: item.category,
                    detailText: item.note.isEmpty ? "Manual item" : "Manual item • \(item.note)",
                    secondaryText: "Added manually",
                    isChecked: checkedItemIDs.contains(item.stableChecklistID),
                    manualItemID: item.id
                )
            }

        return (generated + manual)
            .filter { showCheckedItems || !$0.isChecked }
            .sorted { lhs, rhs in
                if lhs.isChecked != rhs.isChecked {
                    return !lhs.isChecked
                }

                if lhs.category != rhs.category {
                    return lhs.category.localizedCaseInsensitiveCompare(rhs.category) == .orderedAscending
                }

                return lhs.displayName.localizedCaseInsensitiveCompare(rhs.displayName) == .orderedAscending
            }
    }

    static func grouped(
        _ items: [ShoppingChecklistItem]
    ) -> [(category: String, items: [ShoppingChecklistItem])] {
        Dictionary(grouping: items, by: \.category)
            .map { (category: $0.key, items: $0.value) }
            .sorted { lhs, rhs in
                lhs.category.localizedCaseInsensitiveCompare(rhs.category) == .orderedAscending
            }
    }
}

nonisolated struct ShoppingChecklistSnapshot: Codable, Hashable {
    var checkedItemIDs: Set<String>
    var manualItems: [ManualShoppingItem]

    static let empty = ShoppingChecklistSnapshot(
        checkedItemIDs: [],
        manualItems: []
    )
}

nonisolated enum ShoppingChecklistLocalStorage {
    private static let prefix = "shopping.checklist.snapshot."

    static func load(
        weekStart: String,
        defaults: UserDefaults = .standard
    ) -> ShoppingChecklistSnapshot {
        guard let data = defaults.data(forKey: prefix + weekStart) else {
            return .empty
        }

        do {
            return try JSONDecoder().decode(
                ShoppingChecklistSnapshot.self,
                from: data
            )
        } catch {
            return .empty
        }
    }

    static func save(
        _ snapshot: ShoppingChecklistSnapshot,
        weekStart: String,
        defaults: UserDefaults = .standard
    ) {
        do {
            let data = try JSONEncoder().encode(snapshot)
            defaults.set(data, forKey: prefix + weekStart)
        } catch {
            defaults.removeObject(forKey: prefix + weekStart)
        }
    }
}
