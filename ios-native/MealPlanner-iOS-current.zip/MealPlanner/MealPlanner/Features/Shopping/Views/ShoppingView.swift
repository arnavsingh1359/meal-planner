import SwiftUI

struct ShoppingView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    @Environment(AppRefreshCoordinator.self)
    private var refreshCoordinator

    @State private var store = ShoppingStore()
    @State private var showingAddItem = false
    @State private var lastSeenRefreshVersion = -1

    var body: some View {
        Group {
            if sessionStore.isAuthenticated {
                content
            } else {
                ContentUnavailableView(
                    "Please log in",
                    systemImage: "person.crop.circle.badge.exclamationmark",
                    description: Text(
                        "Your shopping list is generated from your weekly menu after you sign in."
                    )
                )
            }
        }
        .navigationTitle("Shopping")
        .task {
            if sessionStore.isAuthenticated {
                await refreshIfNeeded(force: !store.hasLoaded)
            }
        }
        .onAppear {
            guard sessionStore.isAuthenticated else { return }
            Task {
                await refreshIfNeeded(force: false)
            }
        }
        .onChange(of: refreshCoordinator.shoppingVersion) { _, _ in
            guard sessionStore.isAuthenticated else { return }
            Task {
                await refreshIfNeeded(force: false)
            }
        }
        .refreshable {
            await store.refresh()
        }
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button {
                    showingAddItem = true
                } label: {
                    Image(systemName: "plus")
                }
                .disabled(!sessionStore.isAuthenticated)

                Button {
                    Task { await store.refresh() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .disabled(store.isLoading)
            }
        }
        .sheet(isPresented: $showingAddItem) {
            AddManualShoppingItemView(store: store)
        }
    }


    private func refreshIfNeeded(force: Bool) async {
        let version = refreshCoordinator.shoppingVersion

        guard force || version != lastSeenRefreshVersion else {
            return
        }

        lastSeenRefreshVersion = version
        await store.refresh()
    }

    @ViewBuilder
    private var content: some View {
        if store.isLoading, !store.hasLoaded {
            ProgressView("Building shopping list…")
        } else if let errorMessage = store.errorMessage {
            ContentUnavailableView(
                "Could not load shopping list",
                systemImage: "exclamationmark.triangle",
                description: Text(errorMessage)
            )
        } else {
            List {
                summarySection

                if store.totalItemCount == 0 {
                    emptySection
                } else {
                    optionsSection

                    ForEach(store.groupedChecklistItems, id: \.category) { group in
                        Section(group.category) {
                            ForEach(group.items) { item in
                                ShoppingChecklistRow(
                                    item: item,
                                    onToggle: {
                                        store.toggleChecked(item)
                                        refreshCoordinator.shoppingChecklistChanged()
                                    }
                                )
                                .swipeActions(edge: .trailing) {
                                    if let manualItemID = item.manualItemID {
                                        Button(role: .destructive) {
                                            store.deleteManualItem(id: manualItemID)
                                            refreshCoordinator.shoppingChecklistChanged()
                                        } label: {
                                            Label("Delete", systemImage: "trash")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
        }
    }

    private var summarySection: some View {
        Section {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    Button {
                        Task { await store.goToPreviousWeek() }
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(.headline)
                    }
                    .buttonStyle(.borderless)
                    .disabled(store.isLoading)

                    VStack(alignment: .leading, spacing: 4) {
                        Text(store.weekTitle)
                            .font(.subheadline.weight(.semibold))

                        Text("Generated from \(store.plannedMealCount) planned meal\(store.plannedMealCount == 1 ? "" : "s")")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    if !store.isCurrentWeek {
                        Button("Today") {
                            Task { await store.goToCurrentWeek() }
                        }
                        .font(.caption.weight(.semibold))
                        .buttonStyle(.borderless)
                        .disabled(store.isLoading)
                    }

                    Button {
                        Task { await store.goToNextWeek() }
                    } label: {
                        Image(systemName: "chevron.right")
                            .font(.headline)
                    }
                    .buttonStyle(.borderless)
                    .disabled(store.isLoading)
                }

                HStack(spacing: 12) {
                    Label(
                        "\(store.totalItemCount) item\(store.totalItemCount == 1 ? "" : "s")",
                        systemImage: "cart"
                    )

                    Label(
                        "\(store.checkedItemCount) checked",
                        systemImage: "checkmark.circle"
                    )
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
            .padding(.vertical, 2)
        }
    }

    private var optionsSection: some View {
        Section {
            Toggle(
                "Show checked items",
                isOn: Binding(
                    get: { store.showCheckedItems },
                    set: { store.showCheckedItems = $0 }
                )
            )
                .font(.subheadline)
        }
    }

    private var emptySection: some View {
        Section {
            ContentUnavailableView(
                "No shopping items",
                systemImage: "cart.badge.checkmark",
                description: Text(
                    store.plannedMealCount == 0
                        ? "Add meals to the Week tab, or use + for miscellaneous household items."
                        : "Your pantry covers the selected weekly menu. Use + for miscellaneous household items."
                )
            )
            .listRowBackground(Color.clear)
        }
    }
}

private struct ShoppingChecklistRow: View {
    let item: ShoppingChecklistItem
    let onToggle: () -> Void

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Button(action: onToggle) {
                Image(systemName: item.isChecked ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(item.isChecked ? .green : .secondary)
                    .frame(width: 28, height: 28)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(item.accessibilityLabel)

            VStack(alignment: .leading, spacing: 3) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(item.displayName)
                        .font(.body.weight(.semibold))
                        .strikethrough(item.isChecked)
                        .foregroundStyle(item.isChecked ? .secondary : .primary)
                        .lineLimit(1)

                    Spacer(minLength: 8)

                    if !item.quantityText.isEmpty {
                        Text(item.quantityText)
                            .font(.body.weight(.semibold))
                            .monospacedDigit()
                            .foregroundStyle(item.isChecked ? .secondary : .primary)
                    }
                }

                Text(item.detailText)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)

                Text(item.secondaryText)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
            }
        }
        .padding(.vertical, 3)
        .opacity(item.isChecked ? 0.55 : 1)
    }
}

private struct AddManualShoppingItemView: View {
    @Environment(\.dismiss)
    private var dismiss

    @Environment(AppRefreshCoordinator.self)
    private var refreshCoordinator

    let store: ShoppingStore

    @State private var name = ""
    @State private var quantity = ""
    @State private var unit = ""
    @State private var category = "Miscellaneous"
    @State private var note = ""

    private let categories = [
        "Miscellaneous",
        "Household",
        "Pantry",
        "Produce",
        "Dairy",
        "Protein",
        "Frozen",
        "Snacks",
        "Personal Care"
    ]

    var body: some View {
        NavigationStack {
            Form {
                Section("Item") {
                    TextField("Paper towels", text: $name)
                        .textInputAutocapitalization(.words)

                    HStack {
                        TextField("Qty", text: $quantity)
                            .keyboardType(.decimalPad)

                        TextField("Unit", text: $unit)
                            .textInputAutocapitalization(.never)
                    }

                    Picker("Category", selection: $category) {
                        ForEach(categories, id: \.self) { value in
                            Text(value).tag(value)
                        }
                    }
                }

                Section("Optional note") {
                    TextField("Store, brand, size, reminder…", text: $note, axis: .vertical)
                        .lineLimit(2...4)
                }
            }
            .navigationTitle("Add Item")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") {
                        store.addManualItem(
                            name: name,
                            quantity: Double(quantity) ?? 0,
                            unit: unit,
                            category: category,
                            note: note
                        )
                        refreshCoordinator.shoppingChecklistChanged()
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}
