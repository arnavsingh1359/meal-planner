import SwiftUI

struct ShoppingView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    @State private var store = ShoppingStore()

    var body: some View {
        Group {
            if sessionStore.isAuthenticated {
                content
            } else {
                ContentUnavailableView(
                    "Please log in",
                    systemImage: "person.crop.circle.badge.exclamationmark",
                    description: Text(
                        "Your shopping list is generated from your weekly menu after you sign in."
                    )
                )
            }
        }
        .navigationTitle("Shopping")
        .task {
            if sessionStore.isAuthenticated, !store.hasLoaded {
                await store.load()
            }
        }
        .refreshable {
            await store.refresh()
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    Task { await store.refresh() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .disabled(store.isLoading)
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        if store.isLoading, !store.hasLoaded {
            ProgressView("Building shopping list…")
        } else if let errorMessage = store.errorMessage {
            ContentUnavailableView(
                "Could not load shopping list",
                systemImage: "exclamationmark.triangle",
                description: Text(errorMessage)
            )
        } else if store.items.isEmpty {
            ContentUnavailableView(
                "No shopping needed",
                systemImage: "cart.badge.checkmark",
                description: Text(
                    store.plannedMealCount == 0
                        ? "Add meals to the Week tab to generate a shopping list."
                        : "Your pantry covers the currently planned weekly menu."
                )
            )
        } else {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Label(
                            "Generated from \(store.plannedMealCount) planned meal\(store.plannedMealCount == 1 ? "" : "s")",
                            systemImage: "calendar"
                        )
                        .font(.subheadline.weight(.semibold))

                        Text(store.weekTitle)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)
                }

                ForEach(store.groupedItems, id: \.category) { group in
                    Section(group.category) {
                        ForEach(group.items) { item in
                            ShoppingListRow(item: item)
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
        }
    }
}

private struct ShoppingListRow: View {
    let item: ShoppingListItem

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(item.displayName)
                    .font(.body.weight(.semibold))

                Spacer()

                Text(item.quantityText)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
            }

            Text(item.sourceText)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)

            HStack(spacing: 10) {
                Label(
                    "Need \(item.requiredText)",
                    systemImage: "fork.knife"
                )

                if item.pantryQuantity > 0 {
                    Label(
                        "Pantry \(item.pantryText)",
                        systemImage: "cabinet"
                    )
                }
            }
            .font(.caption2)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}
