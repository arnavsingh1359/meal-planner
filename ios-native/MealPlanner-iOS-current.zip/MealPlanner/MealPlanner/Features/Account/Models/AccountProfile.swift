import Foundation

nonisolated struct AccountProfile: Codable, Equatable {
    let userID: UUID
    var displayName: String
    var avatarURL: String?
    var bio: String?
    var publicProfileEnabled: Bool
    var showAvatarPublicly: Bool
    let createdAt: Date
    let updatedAt: Date

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case displayName = "display_name"
        case avatarURL = "avatar_url"
        case bio
        case publicProfileEnabled =
            "public_profile_enabled"
        case showAvatarPublicly =
            "show_avatar_publicly"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
}

nonisolated struct AccountPreferences: Codable, Equatable {
    let userID: UUID
    var timeFormat: String
    var measurementSystem: String
    var weekStartsOn: String
    var defaultRecipeTab: String
    var suppressNonSevereWarnings: Bool
    let createdAt: Date
    let updatedAt: Date

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case timeFormat = "time_format"
        case measurementSystem =
            "measurement_system"
        case weekStartsOn =
            "week_starts_on"
        case defaultRecipeTab =
            "default_recipe_tab"
        case suppressNonSevereWarnings =
            "suppress_non_severe_warnings"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
}

nonisolated struct AccountProfileUpsert: Encodable {
    let userID: UUID
    let displayName: String
    let avatarURL: String?
    let bio: String?
    let publicProfileEnabled: Bool
    let showAvatarPublicly: Bool

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case displayName = "display_name"
        case avatarURL = "avatar_url"
        case bio
        case publicProfileEnabled =
            "public_profile_enabled"
        case showAvatarPublicly =
            "show_avatar_publicly"
    }
}

nonisolated struct AccountPreferencesUpsert: Encodable {
    let userID: UUID
    let timeFormat: String
    let measurementSystem: String
    let weekStartsOn: String
    let defaultRecipeTab: String
    let suppressNonSevereWarnings: Bool

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case timeFormat = "time_format"
        case measurementSystem =
            "measurement_system"
        case weekStartsOn =
            "week_starts_on"
        case defaultRecipeTab =
            "default_recipe_tab"
        case suppressNonSevereWarnings =
            "suppress_non_severe_warnings"
    }
}
