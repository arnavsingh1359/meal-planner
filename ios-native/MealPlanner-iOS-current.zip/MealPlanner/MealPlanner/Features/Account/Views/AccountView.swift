import SwiftUI

struct AccountView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    @State private var store = AccountStore()

    @State private var showEmailEditor = false
    @State private var showPasswordEditor = false
    @State private var showDeleteAccount = false
    @State private var showSignOutConfirmation = false

    @State private var emailDraft = ""
    @State private var newPassword = ""
    @State private var passwordConfirmation = ""
    @State private var deleteConfirmation = ""

    @State private var isSigningOut = false

    @AppStorage(AppTheme.appearanceStorageKey)
    private var appearanceRawValue =
        AppAppearancePreference.dark.rawValue

    var body: some View {
        Group {
            if store.isLoading
                && store.profile == nil {
                ProgressView("Loading account…")
            } else {
                accountContent
            }
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(
                placement: .confirmationAction
            ) {
                Button {
                    Task {
                        await store.saveChanges()
                    }
                } label: {
                    if store.isSaving {
                        ProgressView()
                    } else {
                        Text("Save")
                    }
                }
                .disabled(!store.canSave)
            }
        }
        .task {
            await store.load()
        }
        .refreshable {
            await store.load()
        }
        .sheet(
            isPresented: $showEmailEditor
        ) {
            emailEditor
        }
        .sheet(
            isPresented: $showPasswordEditor
        ) {
            passwordEditor
        }
        .sheet(
            isPresented: $showDeleteAccount
        ) {
            deleteAccountEditor
        }
        .confirmationDialog(
            "Sign out?",
            isPresented:
                $showSignOutConfirmation,
            titleVisibility: .visible
        ) {
            Button(
                "Sign out",
                role: .destructive
            ) {
                Task {
                    await signOut()
                }
            }

            Button(
                "Cancel",
                role: .cancel
            ) {}
        } message: {
            Text(
                "You will need to sign in again to use the app."
            )
        }
    }

    private var accountContent: some View {
        ScrollView {
            VStack(spacing: 16) {
                AppScreenHeader(
                    title: "Account",
                    subtitle: "Profile and sign-in settings"
                )

                profileSummary

                if let validation =
                    store.validationMessage {
                    messageCard(
                        validation,
                        color: .red,
                        icon:
                            "exclamationmark.triangle.fill"
                    )
                } else if let message =
                    store.errorMessage {
                    messageCard(
                        message,
                        color: .red,
                        icon:
                            "exclamationmark.triangle.fill"
                    )
                } else if let message =
                    store.successMessage {
                    messageCard(
                        message,
                        color: .green,
                        icon:
                            "checkmark.circle.fill"
                    )
                }

                publicProfileCard
                appExperienceCard
                signInAndSecurityCard
                sessionCard
                dangerZoneCard
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
        }
        .background(
            Color(.systemGroupedBackground)
        )
        .scrollDismissesKeyboard(
            .interactively
        )
    }

    private var profileSummary: some View {
        VStack(spacing: 10) {
            avatarView

            Text(
                store.displayName.isEmpty
                    ? AppBrand.defaultUserName
                    : store.displayName
            )
            .font(.title2.bold())

            Text(store.email)
                .font(.subheadline)
                .foregroundStyle(.secondary)

            Text(
                "Member since "
                    + store.memberSinceText
            )
            .font(.caption)
            .foregroundStyle(.secondary)

            if store.publicProfileEnabled {
                Text("Public profile enabled")
                    .font(
                        .caption2.weight(.semibold)
                    )
                    .foregroundStyle(.green)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(
                        Color.green.opacity(0.12),
                        in: Capsule()
                    )
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
    }

    @ViewBuilder
    private var avatarView: some View {
        if let url = URL(
            string:
                store.avatarURL.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
        ),
           !store.avatarURL.isEmpty {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFill()

                default:
                    initialsAvatar
                }
            }
            .frame(width: 84, height: 84)
            .clipShape(Circle())
        } else {
            initialsAvatar
        }
    }

    private var initialsAvatar: some View {
        ZStack {
            Circle()
                .fill(
                    Color.green.opacity(0.14)
                )

            Text(initials)
                .font(.title.bold())
                .foregroundStyle(.green)
        }
        .frame(width: 84, height: 84)
    }

    private var publicProfileCard: some View {
        accountCard(
            title: "Public profile",
            subtitle:
                "Control how your recipes identify you."
        ) {
            editorRow(
                title: "Display name"
            ) {
                TextField(
                    "Display name",
                    text: $store.displayName
                )
                .multilineTextAlignment(
                    .trailing
                )
                .textInputAutocapitalization(
                    .words
                )
            }

            Divider()

            VStack(
                alignment: .leading,
                spacing: 8
            ) {
                Text("Avatar image URL")
                    .font(
                        .subheadline
                            .weight(.semibold)
                    )

                TextField(
                    "https://…",
                    text: $store.avatarURL
                )
                .keyboardType(.URL)
                .textInputAutocapitalization(
                    .never
                )
                .autocorrectionDisabled()
                .padding(10)
                .background(
                    Color(
                        .tertiarySystemGroupedBackground
                    ),
                    in: RoundedRectangle(
                        cornerRadius: 10,
                        style: .continuous
                    )
                )
            }

            Divider()

            VStack(
                alignment: .leading,
                spacing: 8
            ) {
                HStack {
                    Text("Creator bio")
                        .font(
                            .subheadline
                                .weight(.semibold)
                        )

                    Spacer()

                    Text(
                        "\(store.bio.count)/300"
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }

                TextField(
                    "A short introduction shown with your public recipes.",
                    text: $store.bio,
                    axis: .vertical
                )
                .lineLimit(3...6)
                .padding(10)
                .background(
                    Color(
                        .tertiarySystemGroupedBackground
                    ),
                    in: RoundedRectangle(
                        cornerRadius: 10,
                        style: .continuous
                    )
                )
            }

            Divider()

            Toggle(
                "Enable public creator profile",
                isOn:
                    $store.publicProfileEnabled
            )

            Text(
                "Your public recipes remain visible even when this profile is disabled."
            )
            .font(.caption)
            .foregroundStyle(.secondary)

            Divider()

            Toggle(
                "Show avatar publicly",
                isOn:
                    $store.showAvatarPublicly
            )
            .disabled(
                !store.publicProfileEnabled
            )

            Text(
                "Your email address is never displayed publicly."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private var appExperienceCard: some View {
        accountCard(
            title: "App experience",
            subtitle:
                "Choose how the app displays time, units, and navigation."
        ) {
            VStack(
                alignment: .leading,
                spacing: 8
            ) {
                HStack {
                    Text("Appearance")
                        .font(.subheadline.weight(.semibold))

                    Spacer()

                    Picker(
                        "Appearance",
                        selection: Binding(
                            get: {
                                AppTheme
                                    .preference(
                                        from: appearanceRawValue
                                    )
                            },
                            set: { newValue in
                                appearanceRawValue =
                                    newValue.rawValue
                                AppTheme
                                    .configureGlobalAppearance(
                                        for: newValue
                                    )
                            }
                        )
                    ) {
                        ForEach(
                            AppAppearancePreference.allCases
                        ) { preference in
                            Text(preference.displayName)
                                .tag(preference)
                        }
                    }
                    .pickerStyle(.segmented)
                    .frame(maxWidth: 260)
                }

                Text(
                    "Choose System to follow your iPhone, or force Light/Dark for PrepFlow."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            Divider()

            pickerRow(
                title: "Time format",
                selection:
                    $store.timeFormat,
                options:
                    store.timeFormatOptions
            )

            Divider()

            pickerRow(
                title: "Measurement system",
                selection:
                    $store.measurementSystem,
                options:
                    store.measurementOptions
            )

            Divider()

            pickerRow(
                title: "Week starts on",
                selection:
                    $store.weekStartsOn,
                options:
                    store.weekStartOptions
            )

            Divider()

            pickerRow(
                title: "Default Recipes tab",
                selection:
                    $store.defaultRecipeTab,
                options:
                    store.recipeTabOptions
            )

            Divider()

            Toggle(
                "Only show severe schedule warnings",
                isOn:
                    $store.suppressNonSevereWarnings
            )

            Text(
                "Hides advisory task-window warnings. Cooking-disabled, overlapping-task, and active-cooking-limit warnings remain visible."
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private var signInAndSecurityCard:
        some View {
        accountCard(
            title: "Sign-in & security",
            subtitle:
                "Manage your email address and password."
        ) {
            Button {
                emailDraft = store.email
                store.clearMessages()
                showEmailEditor = true
            } label: {
                navigationRow(
                    title: "Email address",
                    subtitle: store.email,
                    icon: "envelope"
                )
            }
            .buttonStyle(.plain)

            Divider()

            Button {
                newPassword = ""
                passwordConfirmation = ""
                store.clearMessages()
                showPasswordEditor = true
            } label: {
                navigationRow(
                    title: "Change password",
                    subtitle:
                        "Use at least 8 characters",
                    icon: "key"
                )
            }
            .buttonStyle(.plain)
        }
    }

    private var sessionCard: some View {
        accountCard(
            title: "Session",
            subtitle:
                "You are signed in on this device."
        ) {
            Button {
                showSignOutConfirmation = true
            } label: {
                navigationRow(
                    title: "Sign out",
                    subtitle: store.email,
                    icon:
                        "rectangle.portrait.and.arrow.right",
                    color: .orange
                )
            }
            .buttonStyle(.plain)
            .disabled(isSigningOut)
        }
    }

    private var dangerZoneCard: some View {
        accountCard(
            title: "Danger zone",
            subtitle:
                "These actions cannot be undone."
        ) {
            Button {
                deleteConfirmation = ""
                store.clearMessages()
                showDeleteAccount = true
            } label: {
                navigationRow(
                    title: "Delete account",
                    subtitle:
                        "Permanently delete your data",
                    icon: "trash",
                    color: .red
                )
            }
            .buttonStyle(.plain)
        }
    }

    private var emailEditor: some View {
        NavigationStack {
            Form {
                Section {
                    TextField(
                        "Email address",
                        text: $emailDraft
                    )
                    .keyboardType(
                        .emailAddress
                    )
                    .textInputAutocapitalization(
                        .never
                    )
                    .autocorrectionDisabled()
                } footer: {
                    Text(
                        "Supabase may send confirmation messages to both your old and new addresses."
                    )
                }

                if let error = store.errorMessage {
                    Section {
                        Text(error)
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle("Change email")
            .navigationBarTitleDisplayMode(
                .inline
            )
            .toolbar {
                ToolbarItem(
                    placement:
                        .cancellationAction
                ) {
                    Button("Cancel") {
                        showEmailEditor = false
                    }
                }

                ToolbarItem(
                    placement:
                        .confirmationAction
                ) {
                    Button("Change") {
                        Task {
                            let didUpdate =
                                await store
                                    .changeEmail(
                                        newEmail:
                                            emailDraft
                                    )

                            if didUpdate {
                                showEmailEditor =
                                    false
                            }
                        }
                    }
                    .disabled(
                        store.isChangingEmail
                            || emailDraft
                                .trimmingCharacters(
                                    in:
                                        .whitespacesAndNewlines
                                )
                                .isEmpty
                    )
                }
            }
        }
    }

    private var passwordEditor: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(
                        "New password",
                        text: $newPassword
                    )
                    .textContentType(
                        .newPassword
                    )

                    SecureField(
                        "Confirm new password",
                        text:
                            $passwordConfirmation
                    )
                    .textContentType(
                        .newPassword
                    )
                } footer: {
                    Text(
                        "Use at least 8 characters."
                    )
                }

                if let error = store.errorMessage {
                    Section {
                        Text(error)
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle("Change password")
            .navigationBarTitleDisplayMode(
                .inline
            )
            .toolbar {
                ToolbarItem(
                    placement:
                        .cancellationAction
                ) {
                    Button("Cancel") {
                        showPasswordEditor = false
                    }
                }

                ToolbarItem(
                    placement:
                        .confirmationAction
                ) {
                    Button("Update") {
                        Task {
                            let didUpdate =
                                await store
                                    .changePassword(
                                        newPassword:
                                            newPassword,
                                        confirmation:
                                            passwordConfirmation
                                    )

                            if didUpdate {
                                showPasswordEditor =
                                    false
                            }
                        }
                    }
                    .disabled(
                        store.isChangingPassword
                            || newPassword.isEmpty
                            || passwordConfirmation
                                .isEmpty
                    )
                }
            }
        }
    }

    private var deleteAccountEditor:
        some View {
        NavigationStack {
            Form {
                Section {
                    Text(
                        "Deleting your account permanently removes your profile and app data. This cannot be undone."
                    )
                    .foregroundStyle(.red)

                    TextField(
                        "Type DELETE",
                        text: $deleteConfirmation
                    )
                    .textInputAutocapitalization(
                        .characters
                    )
                    .autocorrectionDisabled()
                }

                if let error = store.errorMessage {
                    Section {
                        Text(error)
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle("Delete account")
            .navigationBarTitleDisplayMode(
                .inline
            )
            .toolbar {
                ToolbarItem(
                    placement:
                        .cancellationAction
                ) {
                    Button("Cancel") {
                        showDeleteAccount = false
                    }
                }

                ToolbarItem(
                    placement:
                        .confirmationAction
                ) {
                    Button(
                        "Delete",
                        role: .destructive
                    ) {
                        Task {
                            let didDelete =
                                await store
                                    .deleteAccount(
                                        confirmationText:
                                            deleteConfirmation
                                    )

                            if didDelete {
                                showDeleteAccount =
                                    false

                                await signOut()
                            }
                        }
                    }
                    .disabled(
                        store.isDeletingAccount
                            || deleteConfirmation
                                != "DELETE"
                    )
                }
            }
        }
    }

    private func accountCard<Content: View>(
        title: String,
        subtitle: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(
            alignment: .leading,
            spacing: 12
        ) {
            Text(title)
                .font(.headline)

            Text(subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)

            content()
        }
        .padding(16)
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .background(
            Color(
                .secondarySystemGroupedBackground
            ),
            in: RoundedRectangle(
                cornerRadius: 18,
                style: .continuous
            )
        )
    }

    private func editorRow<Content: View>(
        title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        HStack(spacing: 12) {
            Text(title)
                .font(
                    .subheadline
                        .weight(.semibold)
                )

            Spacer()

            content()
        }
    }

    private func pickerRow(
        title: String,
        selection: Binding<String>,
        options: [(String, String)]
    ) -> some View {
        HStack(spacing: 12) {
            Text(title)
                .font(
                    .subheadline
                        .weight(.semibold)
                )

            Spacer()

            Picker(
                title,
                selection: selection
            ) {
                ForEach(
                    options,
                    id: \.0
                ) { value, label in
                    Text(label)
                        .tag(value)
                }
            }
            .labelsHidden()
            .pickerStyle(.menu)
        }
    }

    private func navigationRow(
        title: String,
        subtitle: String,
        icon: String,
        color: Color = .green
    ) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .frame(width: 24)
                .foregroundStyle(color)

            VStack(
                alignment: .leading,
                spacing: 3
            ) {
                Text(title)
                    .font(
                        .body.weight(.medium)
                    )
                    .foregroundStyle(
                        color == .red
                            ? Color.red
                            : Color.primary
                    )

                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.caption.bold())
                .foregroundStyle(.tertiary)
        }
        .contentShape(Rectangle())
    }

    private func messageCard(
        _ message: String,
        color: Color,
        icon: String
    ) -> some View {
        Label(message, systemImage: icon)
            .font(.footnote)
            .foregroundStyle(color)
            .padding(12)
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
            .background(
                color.opacity(0.09),
                in: RoundedRectangle(
                    cornerRadius: 12,
                    style: .continuous
                )
            )
    }

    private var initials: String {
        let source = store.displayName.isEmpty
            ? store.email
            : store.displayName

        let parts = source
            .split(separator: " ")
            .prefix(2)

        let letters = parts.compactMap(
            \.first
        )

        if letters.isEmpty {
            return "MP"
        }

        return String(letters).uppercased()
    }

    @MainActor
    private func signOut() async {
        guard !isSigningOut else {
            return
        }

        isSigningOut = true
        store.clearMessages()

        defer {
            isSigningOut = false
        }

        do {
            try await sessionStore.signOut()
        } catch {
            store.errorMessage =
                error.localizedDescription
        }
    }
}
