import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class AccountStore {
    private(set) var profile: AccountProfile?
    private(set) var preferences: AccountPreferences?
    private(set) var email = ""

    private(set) var isLoading = false
    private(set) var isSaving = false
    private(set) var isChangingEmail = false
    private(set) var isChangingPassword = false
    private(set) var isDeletingAccount = false

    var displayName = ""
    var avatarURL = ""
    var bio = ""
    var publicProfileEnabled = true
    var showAvatarPublicly = true

    var timeFormat = "12h"
    var measurementSystem = "metric"
    var weekStartsOn = "monday"
    var defaultRecipeTab = "discover"
    var suppressNonSevereWarnings = false

    var errorMessage: String?
    var successMessage: String?

    private var savedProfileState:
        AccountProfileDraft?

    private var savedPreferenceState:
        AccountPreferenceDraft?

    let timeFormatOptions = [
        ("12h", "12-hour"),
        ("24h", "24-hour")
    ]

    let measurementOptions = [
        ("metric", "Metric"),
        ("us", "US customary")
    ]

    let weekStartOptions = [
        ("monday", "Monday"),
        ("sunday", "Sunday")
    ]

    let recipeTabOptions = [
        ("discover", "Discover"),
        ("favorites", "Favorites"),
        ("mine", "My Recipes")
    ]

    var memberSinceText: String {
        guard let createdAt = profile?.createdAt else {
            return "Not available"
        }

        return createdAt.formatted(
            date: .abbreviated,
            time: .omitted
        )
    }

    var hasUnsavedChanges: Bool {
        guard let savedProfileState,
              let savedPreferenceState else {
            return false
        }

        return currentProfileDraft
            != savedProfileState
            || currentPreferenceDraft
            != savedPreferenceState
    }

    var canSave: Bool {
        !isLoading
            && !isSaving
            && validationMessage == nil
            && hasUnsavedChanges
    }

    var validationMessage: String? {
        let cleanedName = displayName
            .trimmingCharacters(
                in: .whitespacesAndNewlines
            )

        if cleanedName.isEmpty {
            return "Display name cannot be empty."
        }

        if cleanedName.count > 80 {
            return "Display name must be 80 characters or fewer."
        }

        if bio.count > 300 {
            return "Creator bio must be 300 characters or fewer."
        }

        let cleanedAvatarURL = avatarURL
            .trimmingCharacters(
                in: .whitespacesAndNewlines
            )

        if !cleanedAvatarURL.isEmpty,
           URL(string: cleanedAvatarURL) == nil {
            return "Enter a valid avatar image URL."
        }

        return nil
    }

    func load() async {
        guard !isLoading else {
            return
        }

        isLoading = true
        errorMessage = nil

        defer {
            isLoading = false
        }

        do {
            let session = try await AppSupabase
                .client
                .auth
                .session

            email = session.user.email ?? ""

            async let profileRequest:
                AccountProfile = try await AppSupabase
                    .client
                    .from("profiles")
                    .select(
                        """
                        user_id,
                        display_name,
                        avatar_url,
                        bio,
                        public_profile_enabled,
                        show_avatar_publicly,
                        created_at,
                        updated_at
                        """
                    )
                    .eq(
                        "user_id",
                        value: session.user.id.uuidString
                    )
                    .single()
                    .execute()
                    .value

            async let preferencesRequest:
                AccountPreferences = try await AppSupabase
                    .client
                    .from("account_preferences")
                    .select(
                        """
                        user_id,
                        time_format,
                        measurement_system,
                        week_starts_on,
                        default_recipe_tab,
                        suppress_non_severe_warnings,
                        created_at,
                        updated_at
                        """
                    )
                    .eq(
                        "user_id",
                        value: session.user.id.uuidString
                    )
                    .single()
                    .execute()
                    .value

            profile = try await profileRequest
            preferences =
                try await preferencesRequest

            applyLoadedValues()
        } catch {
            guard !isCancellation(error) else {
                return
            }

            errorMessage = error.localizedDescription
        }
    }

    func saveChanges() async -> Bool {
        guard let validationMessage = validationMessage else {
            return await persistChanges()
        }

        errorMessage = validationMessage
        return false
    }

    private func persistChanges() async -> Bool {
        guard !isSaving else {
            return false
        }

        isSaving = true
        errorMessage = nil
        successMessage = nil

        defer {
            isSaving = false
        }

        do {
            let session = try await AppSupabase
                .client
                .auth
                .session

            let cleanedDisplayName =
                displayName.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )

            let cleanedAvatarURL =
                avatarURL.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )

            let cleanedBio =
                bio.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )

            let profilePayload =
                AccountProfileUpsert(
                    userID: session.user.id,
                    displayName:
                        cleanedDisplayName,
                    avatarURL:
                        cleanedAvatarURL.isEmpty
                        ? nil
                        : cleanedAvatarURL,
                    bio:
                        cleanedBio.isEmpty
                        ? nil
                        : cleanedBio,
                    publicProfileEnabled:
                        publicProfileEnabled,
                    showAvatarPublicly:
                        showAvatarPublicly
                )

            let preferencePayload =
                AccountPreferencesUpsert(
                    userID: session.user.id,
                    timeFormat: timeFormat,
                    measurementSystem:
                        measurementSystem,
                    weekStartsOn: weekStartsOn,
                    defaultRecipeTab:
                        defaultRecipeTab,
                    suppressNonSevereWarnings:
                        suppressNonSevereWarnings
                )

            async let updatedProfileRequest:
                AccountProfile = try await AppSupabase
                    .client
                    .from("profiles")
                    .upsert(
                        profilePayload,
                        onConflict: "user_id"
                    )
                    .select(
                        """
                        user_id,
                        display_name,
                        avatar_url,
                        bio,
                        public_profile_enabled,
                        show_avatar_publicly,
                        created_at,
                        updated_at
                        """
                    )
                    .single()
                    .execute()
                    .value

            async let updatedPreferencesRequest:
                AccountPreferences =
                try await AppSupabase
                    .client
                    .from("account_preferences")
                    .upsert(
                        preferencePayload,
                        onConflict: "user_id"
                    )
                    .select(
                        """
                        user_id,
                        time_format,
                        measurement_system,
                        week_starts_on,
                        default_recipe_tab,
                        suppress_non_severe_warnings,
                        created_at,
                        updated_at
                        """
                    )
                    .single()
                    .execute()
                    .value

            profile =
                try await updatedProfileRequest

            preferences =
                try await updatedPreferencesRequest

            applyLoadedValues()

            NotificationCenter.default.post(
                name: .accountPreferencesDidChange,
                object: nil,
                userInfo: [
                    AccountPreferenceNotificationKey.defaultRecipeTab:
                        defaultRecipeTab
                ]
            )

            successMessage = "Account settings saved."
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func changeEmail(
        newEmail: String
    ) async -> Bool {
        let cleanedEmail = newEmail
            .trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            .lowercased()

        guard cleanedEmail.contains("@"),
              cleanedEmail.contains(".") else {
            errorMessage =
                "Enter a valid email address."
            return false
        }

        guard cleanedEmail != email.lowercased() else {
            errorMessage =
                "That is already your email address."
            return false
        }

        guard !isChangingEmail else {
            return false
        }

        isChangingEmail = true
        errorMessage = nil
        successMessage = nil

        defer {
            isChangingEmail = false
        }

        do {
            try await AppSupabase
                .client
                .auth
                .update(
                    user: UserAttributes(
                        email: cleanedEmail
                    )
                )

            successMessage =
                "Check your email to confirm the address change."

            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func changePassword(
        newPassword: String,
        confirmation: String
    ) async -> Bool {
        guard newPassword.count >= 8 else {
            errorMessage =
                "Password must contain at least 8 characters."
            return false
        }

        guard newPassword == confirmation else {
            errorMessage =
                "The password confirmation does not match."
            return false
        }

        guard !isChangingPassword else {
            return false
        }

        isChangingPassword = true
        errorMessage = nil
        successMessage = nil

        defer {
            isChangingPassword = false
        }

        do {
            try await AppSupabase
                .client
                .auth
                .update(
                    user: UserAttributes(
                        password: newPassword
                    )
                )

            successMessage =
                "Password changed successfully."

            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func deleteAccount(
        confirmationText: String
    ) async -> Bool {
        guard confirmationText == "DELETE" else {
            errorMessage =
                "Type DELETE exactly to confirm account deletion."
            return false
        }

        guard !isDeletingAccount else {
            return false
        }

        isDeletingAccount = true
        errorMessage = nil
        successMessage = nil

        defer {
            isDeletingAccount = false
        }

        do {
            try await AppSupabase
                .client
                .rpc("delete_current_user")
                .execute()

            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func clearMessages() {
        errorMessage = nil
        successMessage = nil
    }

    private func applyLoadedValues() {
        guard let profile,
              let preferences else {
            return
        }

        displayName = profile.displayName
        avatarURL = profile.avatarURL ?? ""
        bio = profile.bio ?? ""
        publicProfileEnabled =
            profile.publicProfileEnabled
        showAvatarPublicly =
            profile.showAvatarPublicly

        timeFormat = preferences.timeFormat
        measurementSystem =
            preferences.measurementSystem
        weekStartsOn =
            preferences.weekStartsOn
        defaultRecipeTab =
            preferences.defaultRecipeTab
        suppressNonSevereWarnings =
            preferences.suppressNonSevereWarnings

        savedProfileState =
            currentProfileDraft

        savedPreferenceState =
            currentPreferenceDraft
    }

    private var currentProfileDraft:
        AccountProfileDraft {
        AccountProfileDraft(
            displayName:
                displayName.trimmingCharacters(
                    in: .whitespacesAndNewlines
                ),
            avatarURL:
                avatarURL.trimmingCharacters(
                    in: .whitespacesAndNewlines
                ),
            bio:
                bio.trimmingCharacters(
                    in: .whitespacesAndNewlines
                ),
            publicProfileEnabled:
                publicProfileEnabled,
            showAvatarPublicly:
                showAvatarPublicly
        )
    }

    private var currentPreferenceDraft:
        AccountPreferenceDraft {
        AccountPreferenceDraft(
            timeFormat: timeFormat,
            measurementSystem:
                measurementSystem,
            weekStartsOn: weekStartsOn,
            defaultRecipeTab:
                defaultRecipeTab,
            suppressNonSevereWarnings:
                suppressNonSevereWarnings
        )
    }

    private func isCancellation(
        _ error: Error
    ) -> Bool {
        if error is CancellationError {
            return true
        }

        let nsError = error as NSError

        return nsError.domain
            == NSURLErrorDomain
            && nsError.code
            == NSURLErrorCancelled
    }
}

private struct AccountProfileDraft:
    Equatable {

    let displayName: String
    let avatarURL: String
    let bio: String
    let publicProfileEnabled: Bool
    let showAvatarPublicly: Bool
}

private struct AccountPreferenceDraft:
    Equatable {

    let timeFormat: String
    let measurementSystem: String
    let weekStartsOn: String
    let defaultRecipeTab: String
    let suppressNonSevereWarnings: Bool
}


extension Notification.Name {
    static let accountPreferencesDidChange =
        Notification.Name(
            "accountPreferencesDidChange"
        )
}

enum AccountPreferenceNotificationKey {
    static let defaultRecipeTab =
        "defaultRecipeTab"
}
