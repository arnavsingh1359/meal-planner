import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class PantryStore {
    private(set) var items: [PantryStockItem] = []
    private(set) var catalogItems: [PantryCatalogItem] = []
    private(set) var isLoading = false
    private(set) var hasLoaded = false
    var errorMessage: String?

    private var currentUserID: UUID?

    var trackedCount: Int { items.count }

    var lowOrOutCount: Int {
        items.filter { item in
            let status = item.normalizedStockStatus
            return status == .low || status == .out
        }.count
    }

    var catalogOnlyCount: Int {
        catalogItems.filter { !$0.isTracked }.count
    }

    var groupedItems: [(category: String, items: [PantryStockItem])] {
        let groups = Dictionary(
            grouping: items,
            by: { item in
                let category = item.category?
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                return category?.isEmpty == false ? category! : "Pantry"
            }
        )

        return groups
            .map { ($0.key, $0.value.sorted { lhs, rhs in
                lhs.name.localizedCaseInsensitiveCompare(rhs.name)
                    == .orderedAscending
            }) }
            .sorted { lhs, rhs in
                lhs.category.localizedCaseInsensitiveCompare(rhs.category)
                    == .orderedAscending
            }
    }

    var catalogOnlyItems: [PantryCatalogItem] {
        catalogItems
            .filter { !$0.isTracked }
            .sorted { lhs, rhs in
                lhs.name.localizedCaseInsensitiveCompare(rhs.name)
                    == .orderedAscending
            }
    }

    func filteredTrackedItems(
        searchText: String,
        statusFilter: PantryStockStatus?
    ) -> [(category: String, items: [PantryStockItem])] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        let filtered = items.filter { item in
            let matchesSearch = query.isEmpty
                || item.name.localizedCaseInsensitiveContains(query)
                || (item.category ?? "").localizedCaseInsensitiveContains(query)
                || (item.notes ?? "").localizedCaseInsensitiveContains(query)

            let matchesStatus = statusFilter == nil
                || item.normalizedStockStatus == statusFilter

            return matchesSearch && matchesStatus
        }

        let groups = Dictionary(
            grouping: filtered,
            by: { item in
                let category = item.category?
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                return category?.isEmpty == false ? category! : "Pantry"
            }
        )

        return groups
            .map { ($0.key, $0.value.sorted { lhs, rhs in
                lhs.name.localizedCaseInsensitiveCompare(rhs.name)
                    == .orderedAscending
            }) }
            .sorted { lhs, rhs in
                lhs.category.localizedCaseInsensitiveCompare(rhs.category)
                    == .orderedAscending
            }
    }

    func filteredCatalogItems(searchText: String) -> [(category: String, items: [PantryCatalogItem])] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        let filtered = catalogOnlyItems.filter { item in
            query.isEmpty
                || item.name.localizedCaseInsensitiveContains(query)
                || item.category.localizedCaseInsensitiveContains(query)
        }

        let groups = Dictionary(grouping: filtered, by: \.category)
        return groups
            .map { ($0.key, $0.value.sorted { lhs, rhs in
                lhs.name.localizedCaseInsensitiveCompare(rhs.name)
                    == .orderedAscending
            }) }
            .sorted { lhs, rhs in
                lhs.category.localizedCaseInsensitiveCompare(rhs.category)
                    == .orderedAscending
            }
    }

    func load() async {
        guard !isLoading else { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            let session = try await AppSupabase.client.auth.session
            currentUserID = session.user.id
            try await reloadAll(userID: session.user.id)
            hasLoaded = true
        } catch {
            if !(error is CancellationError) {
                errorMessage = error.localizedDescription
            }
        }
    }

    func refresh() async {
        await load()
    }

    func addCatalogItemToPantry(_ catalogItem: PantryCatalogItem) async -> Bool {
        await addStockItem(
            ingredientID: catalogItem.id,
            name: catalogItem.name,
            trackingMode: .approximate,
            quantity: nil,
            unit: catalogItem.defaultUnit,
            stockStatus: .enough,
            category: catalogItem.category,
            expiryDate: nil,
            notes: ""
        )
    }

    func addCustomItem(
        name: String,
        trackingMode: PantryTrackingMode,
        quantity: Double?,
        unit: String,
        stockStatus: PantryStockStatus,
        category: String,
        expiryDate: String?,
        notes: String
    ) async -> Bool {
        guard let currentUserID else {
            errorMessage = "Please log in before editing pantry stock."
            return false
        }

        let cleanedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanedCategory = category.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanedUnit = unit.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !cleanedName.isEmpty else {
            errorMessage = "Enter an ingredient name."
            return false
        }

        guard validateQuantity(trackingMode: trackingMode, quantity: quantity) else {
            return false
        }

        do {
            let ingredient = try await ingredientForPantryItem(
                name: cleanedName,
                category: cleanedCategory.isEmpty
                    ? ShoppingIngredientNormalizer.category(
                        for: ShoppingIngredientNormalizer.normalize(
                            name: cleanedName,
                            unit: cleanedUnit
                        ).canonicalName
                    )
                    : cleanedCategory,
                defaultUnit: cleanedUnit,
                userID: currentUserID
            )

            return await addStockItem(
                ingredientID: ingredient.id,
                name: ingredient.name,
                trackingMode: trackingMode,
                quantity: quantity,
                unit: cleanedUnit.isEmpty ? ingredient.defaultUnit : cleanedUnit,
                stockStatus: stockStatus,
                category: ingredient.category,
                expiryDate: expiryDate,
                notes: notes
            )
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func update(
        _ item: PantryStockItem,
        trackingMode: PantryTrackingMode,
        quantity: Double?,
        unit: String,
        stockStatus: PantryStockStatus,
        expiryDate: String?,
        notes: String
    ) async -> Bool {
        guard currentUserID != nil else {
            errorMessage = "Please log in before editing pantry stock."
            return false
        }

        guard validateQuantity(trackingMode: trackingMode, quantity: quantity) else {
            return false
        }

        let cleanedUnit = unit.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanedNotes = notes.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanedExpiry = expiryDate?
            .trimmingCharacters(in: .whitespacesAndNewlines)

        do {
            let updated: PantryItemDatabaseRow = try await AppSupabase.client
                .from("pantry_items")
                .update(
                    PantryStockItemUpdate(
                        trackingMode: trackingMode.rawValue,
                        quantity: trackingMode == .exact ? quantity : nil,
                        unit: cleanedUnit.isEmpty ? nil : cleanedUnit,
                        stockStatus: stockStatus.rawValue,
                        expiryDate: cleanedExpiry?.isEmpty == false ? cleanedExpiry : nil,
                        notes: cleanedNotes
                    )
                )
                .eq("id", value: item.id.uuidString)
                .select("*")
                .single()
                .execute()
                .value

            let ingredient = catalogItems.first { $0.id == item.ingredientID }
                .map { PantryIngredientDatabaseRow(catalogItem: $0) }

            replace(updated.stockItem(using: ingredient))
            errorMessage = nil
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func quickUpdateStatus(
        _ item: PantryStockItem,
        stockStatus: PantryStockStatus
    ) async {
        _ = await update(
            item,
            trackingMode: item.normalizedTrackingMode,
            quantity: item.quantity,
            unit: item.resolvedUnit,
            stockStatus: stockStatus,
            expiryDate: item.expiryDate,
            notes: item.notes ?? ""
        )
    }

    func delete(_ item: PantryStockItem) async {
        do {
            try await AppSupabase.client
                .from("pantry_items")
                .delete()
                .eq("id", value: item.id.uuidString)
                .execute()

            items.removeAll { $0.id == item.id }
            markCatalogTracking()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func addStockItem(
        ingredientID: UUID,
        name: String,
        trackingMode: PantryTrackingMode,
        quantity: Double?,
        unit: String,
        stockStatus: PantryStockStatus,
        category: String,
        expiryDate: String?,
        notes: String
    ) async -> Bool {
        guard let currentUserID else {
            errorMessage = "Please log in before editing pantry stock."
            return false
        }

        guard validateQuantity(trackingMode: trackingMode, quantity: quantity) else {
            return false
        }

        if items.contains(where: { $0.ingredientID == ingredientID }) {
            errorMessage = "This ingredient is already in your pantry. Edit the existing row instead."
            return false
        }

        let cleanedUnit = unit.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanedNotes = notes.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanedExpiry = expiryDate?
            .trimmingCharacters(in: .whitespacesAndNewlines)

        do {
            let inserted: PantryItemDatabaseRow = try await AppSupabase.client
                .from("pantry_items")
                .insert(
                    PantryStockItemInsert(
                        userID: currentUserID,
                        ingredientID: ingredientID,
                        trackingMode: trackingMode.rawValue,
                        quantity: trackingMode == .exact ? quantity : nil,
                        unit: cleanedUnit.isEmpty ? nil : cleanedUnit,
                        stockStatus: stockStatus.rawValue,
                        expiryDate: cleanedExpiry?.isEmpty == false ? cleanedExpiry : nil,
                        notes: cleanedNotes
                    )
                )
                .select("*")
                .single()
                .execute()
                .value

            let ingredient = catalogItems.first { $0.id == ingredientID }
                .map { PantryIngredientDatabaseRow(catalogItem: $0) }
                ?? PantryIngredientDatabaseRow(
                    id: ingredientID,
                    userID: currentUserID,
                    name: name,
                    category: category,
                    defaultUnit: cleanedUnit,
                    approximateAllowed: true
                )

            items.append(inserted.stockItem(using: ingredient))
            sortItems()
            markCatalogTracking()
            errorMessage = nil
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    private func validateQuantity(
        trackingMode: PantryTrackingMode,
        quantity: Double?
    ) -> Bool {
        if trackingMode == .exact {
            guard let quantity, quantity > 0 else {
                errorMessage = "Exact pantry tracking needs a quantity greater than zero."
                return false
            }
        }

        return true
    }

    private func replace(_ item: PantryStockItem) {
        if let index = items.firstIndex(where: { $0.id == item.id }) {
            items[index] = item
        } else {
            items.append(item)
        }

        sortItems()
        markCatalogTracking()
    }

    private func sortItems() {
        items.sort { lhs, rhs in
            lhs.name.localizedCaseInsensitiveCompare(rhs.name)
                == .orderedAscending
        }
    }

    private func reloadAll(userID: UUID) async throws {
        let ingredients = try await loadIngredientCatalog(userID: userID)
        let pantryRows: [PantryItemDatabaseRow] = try await AppSupabase.client
            .from("pantry_items")
            .select("*")
            .eq("user_id", value: userID.uuidString)
            .order("updated_at", ascending: false)
            .execute()
            .value

        let ingredientByID = Dictionary(uniqueKeysWithValues: ingredients.map { ($0.id, $0) })
        items = pantryRows
            .map { row in row.stockItem(using: ingredientByID[row.ingredientID]) }
            .sorted { lhs, rhs in
                lhs.name.localizedCaseInsensitiveCompare(rhs.name)
                    == .orderedAscending
            }

        let trackedIngredientIDs = Set(pantryRows.map(\.ingredientID))
        catalogItems = ingredients
            .map { PantryCatalogItem(row: $0, isTracked: trackedIngredientIDs.contains($0.id)) }
            .sorted { lhs, rhs in
                lhs.name.localizedCaseInsensitiveCompare(rhs.name)
                    == .orderedAscending
            }
    }

    private func loadIngredientCatalog(userID: UUID) async throws -> [PantryIngredientDatabaseRow] {
        try await AppSupabase.client
            .from("ingredients")
            .select("id,user_id,name,category,default_unit,approximate_allowed")
            .eq("user_id", value: userID.uuidString)
            .order("name", ascending: true)
            .execute()
            .value
    }

    private func ingredientForPantryItem(
        name: String,
        category: String,
        defaultUnit: String,
        userID: UUID
    ) async throws -> PantryIngredientDatabaseRow {
        let normalizedTarget = ShoppingIngredientNormalizer.normalize(
            name: name,
            unit: defaultUnit
        ).canonicalName

        if let match = catalogItems.first(where: { ingredient in
            ShoppingIngredientNormalizer.normalize(
                name: ingredient.name,
                unit: ingredient.defaultUnit
            ).canonicalName == normalizedTarget
        }) {
            return PantryIngredientDatabaseRow(catalogItem: match)
        }

        let inserted: PantryIngredientDatabaseRow = try await AppSupabase.client
            .from("ingredients")
            .insert(
                PantryIngredientInsert(
                    userID: userID,
                    name: name,
                    category: category.isEmpty ? "Other" : category,
                    defaultUnit: defaultUnit,
                    approximateAllowed: true
                )
            )
            .select("id,user_id,name,category,default_unit,approximate_allowed")
            .single()
            .execute()
            .value

        catalogItems.append(PantryCatalogItem(row: inserted, isTracked: false))
        catalogItems.sort { lhs, rhs in
            lhs.name.localizedCaseInsensitiveCompare(rhs.name)
                == .orderedAscending
        }
        return inserted
    }

    private func markCatalogTracking() {
        let trackedIngredientIDs = Set(items.compactMap(\.ingredientID))
        catalogItems = catalogItems.map { item in
            var copy = item
            copy.isTracked = trackedIngredientIDs.contains(item.id)
            return copy
        }
    }
}

private extension PantryIngredientDatabaseRow {
    init(catalogItem: PantryCatalogItem) {
        self.init(
            id: catalogItem.id,
            userID: catalogItem.userID,
            name: catalogItem.name,
            category: catalogItem.category,
            defaultUnit: catalogItem.defaultUnit,
            approximateAllowed: catalogItem.approximateAllowed
        )
    }
}
