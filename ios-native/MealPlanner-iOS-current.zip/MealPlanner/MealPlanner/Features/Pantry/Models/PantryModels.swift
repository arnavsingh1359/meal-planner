import Foundation

nonisolated enum PantryTrackingMode: String, Codable, CaseIterable, Identifiable, Hashable {
    case exact
    case approximate

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .exact:
            return "Exact"
        case .approximate:
            return "Approximate"
        }
    }
}

nonisolated enum PantryStockStatus: String, Codable, CaseIterable, Identifiable, Hashable {
    case plenty
    case enough
    case low
    case out

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .plenty:
            return "Plenty"
        case .enough:
            return "Enough"
        case .low:
            return "Low"
        case .out:
            return "Out"
        }
    }

    var systemImage: String {
        switch self {
        case .plenty:
            return "checkmark.circle.fill"
        case .enough:
            return "checkmark.circle"
        case .low:
            return "exclamationmark.triangle"
        case .out:
            return "xmark.circle"
        }
    }

    var contributesToShoppingSubtraction: Bool {
        switch self {
        case .plenty, .enough:
            return true
        case .low, .out:
            return false
        }
    }
}

nonisolated struct PantryStockItem: Codable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID?
    var ingredientID: UUID?
    var trackingMode: String
    var name: String
    var quantity: Double
    var unit: String
    var stockStatus: String
    var category: String?
    var defaultUnit: String?
    var approximateAllowed: Bool
    var expiryDate: String?
    var notes: String?
    var updatedAt: Date?

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case ingredientID = "ingredient_id"
        case trackingMode = "tracking_mode"
        case name
        case quantity
        case unit
        case stockStatus = "stock_status"
        case category
        case defaultUnit = "default_unit"
        case approximateAllowed = "approximate_allowed"
        case expiryDate = "expiry_date"
        case notes
        case updatedAt = "updated_at"
    }

    init(
        id: UUID,
        userID: UUID?,
        ingredientID: UUID? = nil,
        trackingMode: String = "exact",
        name: String,
        quantity: Double = 0,
        unit: String = "",
        stockStatus: String = "enough",
        category: String? = nil,
        defaultUnit: String? = nil,
        approximateAllowed: Bool = true,
        expiryDate: String? = nil,
        notes: String? = nil,
        updatedAt: Date? = nil
    ) {
        self.id = id
        self.userID = userID
        self.ingredientID = ingredientID
        self.trackingMode = trackingMode
        self.name = name
        self.quantity = quantity
        self.unit = unit
        self.stockStatus = stockStatus
        self.category = category
        self.defaultUnit = defaultUnit
        self.approximateAllowed = approximateAllowed
        self.expiryDate = expiryDate
        self.notes = notes
        self.updatedAt = updatedAt
    }

    var normalizedTrackingMode: PantryTrackingMode {
        PantryTrackingMode(rawValue: trackingMode.lowercased()) ?? .exact
    }

    var normalizedStockStatus: PantryStockStatus {
        PantryStockStatus(rawValue: stockStatus.lowercased()) ?? .enough
    }

    var resolvedUnit: String {
        let explicit = unit.trimmingCharacters(in: .whitespacesAndNewlines)
        if !explicit.isEmpty { return explicit }
        return defaultUnit?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    }

    var quantityText: String {
        switch normalizedTrackingMode {
        case .exact:
            return ShoppingQuantityFormatter.quantityText(
                quantity,
                unit: resolvedUnit
            )
        case .approximate:
            return normalizedStockStatus.displayName
        }
    }

    var canSubtractFromShopping: Bool {
        normalizedStockStatus.contributesToShoppingSubtraction
    }
}

nonisolated struct PantryCatalogItem: Codable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID?
    var name: String
    var category: String
    var defaultUnit: String
    var approximateAllowed: Bool
    var isTracked: Bool

    init(
        id: UUID,
        userID: UUID?,
        name: String,
        category: String,
        defaultUnit: String,
        approximateAllowed: Bool,
        isTracked: Bool = false
    ) {
        self.id = id
        self.userID = userID
        self.name = name
        self.category = category
        self.defaultUnit = defaultUnit
        self.approximateAllowed = approximateAllowed
        self.isTracked = isTracked
    }

    init(row: PantryIngredientDatabaseRow, isTracked: Bool) {
        self.init(
            id: row.id,
            userID: row.userID,
            name: row.name,
            category: row.category,
            defaultUnit: row.defaultUnit,
            approximateAllowed: row.approximateAllowed,
            isTracked: isTracked
        )
    }
}

nonisolated struct PantryItemDatabaseRow: Decodable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID
    let ingredientID: UUID
    let trackingMode: String
    let quantity: Double?
    let unit: String?
    let stockStatus: String
    let expiryDate: String?
    let notes: String
    let updatedAt: Date?

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case ingredientID = "ingredient_id"
        case trackingMode = "tracking_mode"
        case quantity
        case unit
        case stockStatus = "stock_status"
        case expiryDate = "expiry_date"
        case notes
        case updatedAt = "updated_at"
    }

    func stockItem(using ingredient: PantryIngredientDatabaseRow?) -> PantryStockItem {
        let resolvedName = ingredient?.name.trimmingCharacters(in: .whitespacesAndNewlines)
        let displayName = resolvedName?.isEmpty == false
            ? resolvedName!
            : "Unknown ingredient"

        let resolvedCategory = ingredient?.category.trimmingCharacters(in: .whitespacesAndNewlines)
        let category = resolvedCategory?.isEmpty == false
            ? resolvedCategory
            : ShoppingIngredientNormalizer.category(
                for: ShoppingIngredientNormalizer.normalize(
                    name: displayName,
                    unit: unit ?? ingredient?.defaultUnit ?? ""
                ).canonicalName
            )

        return PantryStockItem(
            id: id,
            userID: userID,
            ingredientID: ingredientID,
            trackingMode: trackingMode,
            name: displayName,
            quantity: quantity ?? 0,
            unit: unit ?? ingredient?.defaultUnit ?? "",
            stockStatus: stockStatus,
            category: category,
            defaultUnit: ingredient?.defaultUnit,
            approximateAllowed: ingredient?.approximateAllowed ?? true,
            expiryDate: expiryDate,
            notes: notes.isEmpty ? nil : notes,
            updatedAt: updatedAt
        )
    }
}

nonisolated struct PantryIngredientDatabaseRow: Codable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID?
    let name: String
    let category: String
    let defaultUnit: String
    let approximateAllowed: Bool

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case name
        case category
        case defaultUnit = "default_unit"
        case approximateAllowed = "approximate_allowed"
    }
}

nonisolated struct PantryStockItemInsert: Encodable {
    let userID: UUID
    let ingredientID: UUID
    let trackingMode: String
    let quantity: Double?
    let unit: String?
    let stockStatus: String
    let expiryDate: String?
    let notes: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case ingredientID = "ingredient_id"
        case trackingMode = "tracking_mode"
        case quantity
        case unit
        case stockStatus = "stock_status"
        case expiryDate = "expiry_date"
        case notes
    }
}

nonisolated struct PantryStockItemUpdate: Encodable {
    let trackingMode: String
    let quantity: Double?
    let unit: String?
    let stockStatus: String
    let expiryDate: String?
    let notes: String

    enum CodingKeys: String, CodingKey {
        case trackingMode = "tracking_mode"
        case quantity
        case unit
        case stockStatus = "stock_status"
        case expiryDate = "expiry_date"
        case notes
    }
}

nonisolated struct PantryIngredientInsert: Encodable {
    let userID: UUID
    let name: String
    let category: String
    let defaultUnit: String
    let approximateAllowed: Bool

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name
        case category
        case defaultUnit = "default_unit"
        case approximateAllowed = "approximate_allowed"
    }
}
