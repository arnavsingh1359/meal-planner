import SwiftUI

struct PantryView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    @State private var store = PantryStore()
    @State private var searchText = ""
    @State private var selectedMode: PantryMode = .tracked
    @State private var statusFilter: PantryStockStatus?
    @State private var showingAddSheet = false
    @State private var editingItem: PantryStockItem?

    var body: some View {
        Group {
            if sessionStore.isAuthenticated {
                content
            } else {
                ContentUnavailableView(
                    "Please log in",
                    systemImage: "person.crop.circle.badge.exclamationmark",
                    description: Text(
                        "Your pantry stock is saved to your account after you sign in."
                    )
                )
            }
        }
        .navigationTitle("Pantry")
        .task {
            if sessionStore.isAuthenticated, !store.hasLoaded {
                await store.load()
            }
        }
        .refreshable {
            await store.refresh()
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showingAddSheet = true
                } label: {
                    Image(systemName: "plus")
                }
                .disabled(!sessionStore.isAuthenticated)
            }
        }
        .sheet(isPresented: $showingAddSheet) {
            PantryItemEditorSheet(
                title: "Add Pantry Item",
                initialItem: nil
            ) { draft in
                await store.addCustomItem(
                    name: draft.name,
                    trackingMode: draft.trackingMode,
                    quantity: draft.quantity,
                    unit: draft.unit,
                    stockStatus: draft.stockStatus,
                    category: draft.category,
                    expiryDate: draft.expiryDate,
                    notes: draft.notes
                )
            }
        }
        .sheet(item: $editingItem) { item in
            PantryItemEditorSheet(
                title: "Edit Pantry Item",
                initialItem: item
            ) { draft in
                await store.update(
                    item,
                    trackingMode: draft.trackingMode,
                    quantity: draft.quantity,
                    unit: draft.unit,
                    stockStatus: draft.stockStatus,
                    expiryDate: draft.expiryDate,
                    notes: draft.notes
                )
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        if store.isLoading, !store.hasLoaded {
            ProgressView("Loading pantry…")
        } else if let errorMessage = store.errorMessage, !store.hasLoaded {
            ContentUnavailableView(
                "Could not load pantry",
                systemImage: "exclamationmark.triangle",
                description: Text(errorMessage)
            )
        } else {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    summaryCards
                    modePicker
                    searchAndFilter

                    if let errorMessage = store.errorMessage {
                        warningBanner(errorMessage)
                    }

                    switch selectedMode {
                    case .tracked:
                        trackedSection
                    case .catalogue:
                        catalogueSection
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 32)
            }
            .background(Color(.systemGroupedBackground))
        }
    }

    private var summaryCards: some View {
        HStack(spacing: 10) {
            PantrySummaryCard(
                title: "Tracked",
                value: "\(store.trackedCount)",
                subtitle: "currently stocked"
            )
            PantrySummaryCard(
                title: "Low / out",
                value: "\(store.lowOrOutCount)",
                subtitle: "may need buying"
            )
            PantrySummaryCard(
                title: "Catalogue",
                value: "\(store.catalogOnlyCount)",
                subtitle: "not in pantry"
            )
        }
    }

    private var modePicker: some View {
        Picker("Pantry mode", selection: $selectedMode) {
            ForEach(PantryMode.allCases) { mode in
                Text(mode.title).tag(mode)
            }
        }
        .pickerStyle(.segmented)
    }

    private var searchAndFilter: some View {
        VStack(spacing: 10) {
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.secondary)
                TextField(
                    selectedMode == .tracked
                        ? "Search pantry items"
                        : "Search ingredient catalogue",
                    text: $searchText
                )
                .textInputAutocapitalization(.never)
            }
            .padding(12)
            .background(.background)
            .clipShape(RoundedRectangle(cornerRadius: 14))

            if selectedMode == .tracked {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        StatusFilterChip(
                            title: "All",
                            isSelected: statusFilter == nil
                        ) {
                            statusFilter = nil
                        }

                        ForEach(PantryStockStatus.allCases) { status in
                            StatusFilterChip(
                                title: status.displayName,
                                isSelected: statusFilter == status
                            ) {
                                statusFilter = status
                            }
                        }
                    }
                }
            }
        }
    }

    private var trackedSection: some View {
        let groups = store.filteredTrackedItems(
            searchText: searchText,
            statusFilter: statusFilter
        )

        return VStack(alignment: .leading, spacing: 14) {
            if groups.isEmpty {
                ContentUnavailableView(
                    "No pantry items",
                    systemImage: "cabinet",
                    description: Text(
                        "Add ingredients from the catalogue or create a custom item. The shopping list will subtract pantry stock from your weekly menu."
                    )
                )
                .frame(maxWidth: .infinity)
                .padding(.top, 40)
            } else {
                ForEach(groups, id: \.category) { group in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(group.category.uppercased())
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.secondary)
                            .padding(.horizontal, 4)

                        VStack(spacing: 10) {
                            ForEach(group.items) { item in
                                PantryItemCard(
                                    item: item,
                                    onEdit: { editingItem = item },
                                    onDelete: { Task { await store.delete(item) } },
                                    onStatusChange: { status in
                                        Task {
                                            await store.quickUpdateStatus(
                                                item,
                                                stockStatus: status
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private var catalogueSection: some View {
        let groups = store.filteredCatalogItems(searchText: searchText)

        return VStack(alignment: .leading, spacing: 14) {
            if groups.isEmpty {
                ContentUnavailableView(
                    "Catalogue is empty",
                    systemImage: "list.bullet.rectangle",
                    description: Text(
                        "Ingredients you create from recipes or pantry edits will appear here."
                    )
                )
                .frame(maxWidth: .infinity)
                .padding(.top, 40)
            } else {
                ForEach(groups, id: \.category) { group in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(group.category.uppercased())
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.secondary)
                            .padding(.horizontal, 4)

                        LazyVGrid(
                            columns: [GridItem(.adaptive(minimum: 150), spacing: 10)],
                            spacing: 10
                        ) {
                            ForEach(group.items) { item in
                                CatalogueItemCard(item: item) {
                                    Task {
                                        await store.addCatalogItemToPantry(item)
                                        selectedMode = .tracked
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private func warningBanner(_ message: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "exclamationmark.triangle.fill")
            Text(message)
                .font(.footnote)
        }
        .foregroundStyle(.orange)
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.orange.opacity(0.12))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

private enum PantryMode: String, CaseIterable, Identifiable {
    case tracked
    case catalogue

    var id: String { rawValue }

    var title: String {
        switch self {
        case .tracked:
            return "Pantry"
        case .catalogue:
            return "Catalogue"
        }
    }
}

private struct PantrySummaryCard: View {
    let title: String
    let value: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            Text(value)
                .font(.title3.weight(.bold))
            Text(subtitle)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(2)
                .minimumScaleFactor(0.8)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

private struct StatusFilterChip: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 12)
                .padding(.vertical, 7)
                .background(isSelected ? Color.green.opacity(0.2) : Color(.secondarySystemGroupedBackground))
                .foregroundStyle(isSelected ? .green : .primary)
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}

private struct PantryItemCard: View {
    let item: PantryStockItem
    let onEdit: () -> Void
    let onDelete: () -> Void
    let onStatusChange: (PantryStockStatus) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(item.name)
                        .font(.headline)
                    Text(item.quantityText)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Menu {
                    ForEach(PantryStockStatus.allCases) { status in
                        Button {
                            onStatusChange(status)
                        } label: {
                            Label(status.displayName, systemImage: status.systemImage)
                        }
                    }
                } label: {
                    Label(
                        item.normalizedStockStatus.displayName,
                        systemImage: item.normalizedStockStatus.systemImage
                    )
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.green.opacity(0.12))
                    .clipShape(Capsule())
                }
            }

            if let expiryDate = item.expiryDate, !expiryDate.isEmpty {
                Label("Expires \(expiryDate)", systemImage: "calendar")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            if let notes = item.notes, !notes.isEmpty {
                Text(notes)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }

            HStack {
                Button("Edit") { onEdit() }
                    .font(.caption.weight(.semibold))

                Spacer()

                Button(role: .destructive) {
                    onDelete()
                } label: {
                    Text("Remove")
                        .font(.caption.weight(.semibold))
                }
            }
        }
        .padding(14)
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

private struct CatalogueItemCard: View {
    let item: PantryCatalogItem
    let onAdd: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(item.category.uppercased())
                .font(.caption2.weight(.bold))
                .foregroundStyle(.secondary)

            Text(item.name)
                .font(.subheadline.weight(.bold))
                .lineLimit(2)

            Text("Default unit: \(item.defaultUnit.isEmpty ? "—" : item.defaultUnit)")
                .font(.caption2)
                .foregroundStyle(.secondary)

            Button {
                onAdd()
            } label: {
                Text("Add to pantry")
                    .font(.caption.weight(.bold))
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .controlSize(.small)
        }
        .padding(12)
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

private struct PantryItemEditorSheet: View {
    let title: String
    let initialItem: PantryStockItem?
    let onSave: (PantryEditorDraft) async -> Bool

    @Environment(\.dismiss)
    private var dismiss

    @State private var name: String
    @State private var trackingMode: PantryTrackingMode
    @State private var quantity: String
    @State private var unit: String
    @State private var stockStatus: PantryStockStatus
    @State private var category: String
    @State private var expiryDate: String
    @State private var notes: String
    @State private var errorMessage: String?
    @State private var isSaving = false

    init(
        title: String,
        initialItem: PantryStockItem?,
        onSave: @escaping (PantryEditorDraft) async -> Bool
    ) {
        self.title = title
        self.initialItem = initialItem
        self.onSave = onSave
        _name = State(initialValue: initialItem?.name ?? "")
        _trackingMode = State(initialValue: initialItem?.normalizedTrackingMode ?? .exact)
        _quantity = State(
            initialValue: initialItem?.quantity.formatted(
                .number.precision(.fractionLength(0...2))
            ) ?? ""
        )
        _unit = State(initialValue: initialItem?.resolvedUnit ?? "")
        _stockStatus = State(initialValue: initialItem?.normalizedStockStatus ?? .enough)
        _category = State(initialValue: initialItem?.category ?? "")
        _expiryDate = State(initialValue: initialItem?.expiryDate ?? "")
        _notes = State(initialValue: initialItem?.notes ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Ingredient") {
                    TextField("Name", text: $name)
                        .disabled(initialItem != nil)
                        .textInputAutocapitalization(.words)

                    TextField("Category", text: $category)
                        .disabled(initialItem != nil)
                        .textInputAutocapitalization(.words)
                }

                Section("Stock") {
                    Picker("Tracking", selection: $trackingMode) {
                        ForEach(PantryTrackingMode.allCases) { mode in
                            Text(mode.displayName).tag(mode)
                        }
                    }

                    if trackingMode == .exact {
                        TextField("Quantity", text: $quantity)
                            .keyboardType(.decimalPad)
                    }

                    TextField("Unit", text: $unit)
                        .textInputAutocapitalization(.never)

                    Picker("Status", selection: $stockStatus) {
                        ForEach(PantryStockStatus.allCases) { status in
                            Text(status.displayName).tag(status)
                        }
                    }
                }

                Section("Optional") {
                    TextField("Expiry date, YYYY-MM-DD", text: $expiryDate)
                        .textInputAutocapitalization(.never)
                    TextField("Notes", text: $notes, axis: .vertical)
                        .lineLimit(2...4)
                }

                if let errorMessage {
                    Section {
                        Text(errorMessage)
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        Task { await save() }
                    }
                    .disabled(isSaving)
                }
            }
        }
    }

    private func save() async {
        let parsedQuantity: Double?
        if trackingMode == .exact {
            guard let value = Double(quantity), value > 0 else {
                errorMessage = "Enter a valid quantity greater than zero."
                return
            }
            parsedQuantity = value
        } else {
            parsedQuantity = nil
        }

        let cleanedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanedName.isEmpty else {
            errorMessage = "Enter an ingredient name."
            return
        }

        isSaving = true
        defer { isSaving = false }

        let saved = await onSave(
            PantryEditorDraft(
                name: cleanedName,
                trackingMode: trackingMode,
                quantity: parsedQuantity,
                unit: unit,
                stockStatus: stockStatus,
                category: category,
                expiryDate: expiryDate.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : expiryDate,
                notes: notes
            )
        )

        if saved {
            dismiss()
        } else {
            errorMessage = "Could not save pantry item."
        }
    }
}

private struct PantryEditorDraft: Hashable {
    let name: String
    let trackingMode: PantryTrackingMode
    let quantity: Double?
    let unit: String
    let stockStatus: PantryStockStatus
    let category: String
    let expiryDate: String?
    let notes: String
}
