import SwiftUI

struct PantryView: View {
    @Environment(SessionStore.self)
    private var sessionStore

    @Environment(AppRefreshCoordinator.self)
    private var refreshCoordinator

    @State private var store = PantryStore()
    @State private var searchText = ""
    @State private var selectedMode: PantryMode = .tracked
    @State private var statusFilter: PantryStockStatus?
    @State private var showingAddSheet = false
    @State private var editingItem: PantryStockItem?
    @State private var lastSeenRefreshVersion = -1

    var body: some View {
        Group {
            if sessionStore.isAuthenticated {
                content
            } else {
                ContentUnavailableView(
                    "Please log in",
                    systemImage: "person.crop.circle.badge.exclamationmark",
                    description: Text(
                        "Your pantry stock is saved to your account after you sign in."
                    )
                )
            }
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            if sessionStore.isAuthenticated {
                await refreshIfNeeded(force: !store.hasLoaded)
            }
        }
        .onAppear {
            guard sessionStore.isAuthenticated else { return }
            Task {
                await refreshIfNeeded(force: false)
            }
        }
        .onChange(of: refreshCoordinator.pantryVersion) { _, _ in
            guard sessionStore.isAuthenticated else { return }
            Task {
                await refreshIfNeeded(force: false)
            }
        }
        .refreshable {
            await store.refresh()
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showingAddSheet = true
                } label: {
                    Image(systemName: "plus")
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.green)
                        .frame(width: 44, height: 44)
                        .background(Color.white.opacity(0.08))
                        .clipShape(Circle())
                }
                .disabled(!sessionStore.isAuthenticated)
            }
        }
        .sheet(isPresented: $showingAddSheet) {
            PantryItemEditorSheet(
                title: "Add Pantry Item",
                initialItem: nil
            ) { draft in
                let changed = await store.addCustomItem(
                    name: draft.name,
                    trackingMode: draft.trackingMode,
                    quantity: draft.quantity,
                    unit: draft.unit,
                    stockStatus: draft.stockStatus,
                    category: draft.category,
                    expiryDate: draft.expiryDate,
                    notes: draft.notes
                )
                if changed {
                    refreshCoordinator.pantryChanged()
                }
                return changed
            }
            .presentationDetents([.large])
        }
        .sheet(item: $editingItem) { item in
            PantryItemEditorSheet(
                title: "Edit Pantry Item",
                initialItem: item
            ) { draft in
                let changed = await store.update(
                    item,
                    trackingMode: draft.trackingMode,
                    quantity: draft.quantity,
                    unit: draft.unit,
                    stockStatus: draft.stockStatus,
                    expiryDate: draft.expiryDate,
                    notes: draft.notes
                )
                if changed {
                    refreshCoordinator.pantryChanged()
                }
                return changed
            }
            .presentationDetents([.large])
        }
    }

    private func refreshIfNeeded(force: Bool) async {
        let version = refreshCoordinator.pantryVersion

        guard force || version != lastSeenRefreshVersion else {
            return
        }

        lastSeenRefreshVersion = version
        await store.refresh()
    }

    @ViewBuilder
    private var content: some View {
        if store.isLoading, !store.hasLoaded {
            ProgressView("Loading pantry…")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black)
        } else if let errorMessage = store.errorMessage, !store.hasLoaded {
            ContentUnavailableView(
                "Could not load pantry",
                systemImage: "exclamationmark.triangle",
                description: Text(errorMessage)
            )
            .background(Color.black)
        } else {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    AppScreenHeader(
                        title: "Pantry",
                        subtitle: "Track stock and browse ingredients"
                    )

                    summaryStrip
                    modePicker
                    searchAndFilter

                    if let errorMessage = store.errorMessage {
                        warningBanner(errorMessage)
                    }

                    switch selectedMode {
                    case .tracked:
                        trackedSection
                    case .catalogue:
                        catalogueSection
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 14)
                .padding(.bottom, 112)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(Color.black.ignoresSafeArea())
        }
    }

    private var summaryStrip: some View {
        HStack(spacing: 10) {
            PantrySummaryCard(
                title: "Tracked",
                value: "\(store.trackedCount)",
                subtitle: "stocked",
                systemImage: "cabinet.fill"
            )
            PantrySummaryCard(
                title: "Low / out",
                value: "\(store.lowOrOutCount)",
                subtitle: "needs attention",
                systemImage: "exclamationmark.triangle.fill"
            )
            PantrySummaryCard(
                title: "Catalogue",
                value: "\(store.catalogOnlyCount)",
                subtitle: "available",
                systemImage: "list.bullet.rectangle.fill"
            )
        }
    }

    private var modePicker: some View {
        Picker("Pantry mode", selection: $selectedMode) {
            ForEach(PantryMode.allCases) { mode in
                Text(mode.title).tag(mode)
            }
        }
        .pickerStyle(.segmented)
        .padding(4)
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private var searchAndFilter: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.secondary)
                TextField(
                    selectedMode == .tracked
                        ? "Search stocked pantry"
                        : "Search ingredient catalogue",
                    text: $searchText
                )
                .textInputAutocapitalization(.never)

                if !searchText.isEmpty {
                    Button {
                        searchText = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 13)
            .background(Color.white.opacity(0.08))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.white.opacity(0.08), lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

            if selectedMode == .tracked {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        StatusFilterChip(
                            title: "All",
                            isSelected: statusFilter == nil
                        ) {
                            statusFilter = nil
                        }

                        ForEach(PantryStockStatus.allCases) { status in
                            StatusFilterChip(
                                title: status.displayName,
                                isSelected: statusFilter == status
                            ) {
                                statusFilter = status
                            }
                        }
                    }
                }
            }
        }
    }

    private var trackedSection: some View {
        let groups = store.filteredTrackedItems(
            searchText: searchText,
            statusFilter: statusFilter
        )

        return VStack(alignment: .leading, spacing: 18) {
            if groups.isEmpty {
                PantryEmptyState(
                    title: "No stocked items",
                    systemImage: "cabinet",
                    message: "Add ingredients from the catalogue or create a custom item. Shopping will subtract what you already have."
                )
            } else {
                ForEach(groups, id: \.category) { group in
                    PantryGroupedSection(title: group.category) {
                        VStack(spacing: 10) {
                            ForEach(group.items) { item in
                                PantryItemCard(
                                    item: item,
                                    onEdit: { editingItem = item },
                                    onDelete: {
                                        Task {
                                            await store.delete(item)
                                            refreshCoordinator.pantryChanged()
                                        }
                                    },
                                    onStatusChange: { status in
                                        Task {
                                            await store.quickUpdateStatus(
                                                item,
                                                stockStatus: status
                                            )
                                            refreshCoordinator.pantryChanged()
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private var catalogueSection: some View {
        let groups = store.filteredCatalogItems(searchText: searchText)

        return VStack(alignment: .leading, spacing: 18) {
            if groups.isEmpty {
                PantryEmptyState(
                    title: "No matching ingredients",
                    systemImage: "magnifyingglass",
                    message: "Try a different search, or tap + to add a custom pantry item."
                )
            } else {
                ForEach(groups, id: \.category) { group in
                    PantryGroupedSection(title: group.category) {
                        VStack(spacing: 10) {
                            ForEach(group.items) { item in
                                CatalogueItemCard(item: item) {
                                    Task {
                                        let changed = await store.addCatalogItemToPantry(item)
                                        if changed {
                                            refreshCoordinator.pantryChanged()
                                            selectedMode = .tracked
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private func warningBanner(_ message: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
            Text(message)
                .font(.footnote.weight(.medium))
        }
        .foregroundStyle(.orange)
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.orange.opacity(0.14))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private enum PantryMode: String, CaseIterable, Identifiable {
    case tracked
    case catalogue

    var id: String { rawValue }

    var title: String {
        switch self {
        case .tracked:
            return "Pantry"
        case .catalogue:
            return "Catalogue"
        }
    }
}

private struct PantrySummaryCard: View {
    let title: String
    let value: String
    let subtitle: String
    let systemImage: String

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Image(systemName: systemImage)
                .font(.caption.weight(.bold))
                .foregroundStyle(.green)

            Text(value)
                .font(.title2.weight(.black))
                .foregroundStyle(.primary)

            VStack(alignment: .leading, spacing: 1) {
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.primary)
                Text(subtitle)
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Color.white.opacity(0.07))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

private struct StatusFilterChip: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.caption.weight(.bold))
                .padding(.horizontal, 13)
                .padding(.vertical, 8)
                .background(isSelected ? Color.green.opacity(0.25) : Color.white.opacity(0.08))
                .foregroundStyle(isSelected ? .green : .primary)
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}

private struct PantryGroupedSection<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title.uppercased())
                .font(.caption.weight(.black))
                .tracking(1.1)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 4)

            content
        }
    }
}

private struct PantryItemCard: View {
    let item: PantryStockItem
    let onEdit: () -> Void
    let onDelete: () -> Void
    let onStatusChange: (PantryStockStatus) -> Void

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            VStack(alignment: .leading, spacing: 7) {
                Text(item.name)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)

                HStack(spacing: 8) {
                    Text(item.quantityText)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.secondary)

                    if item.normalizedTrackingMode == .approximate {
                        Text("Approx")
                            .font(.caption2.weight(.bold))
                            .padding(.horizontal, 7)
                            .padding(.vertical, 3)
                            .foregroundStyle(.secondary)
                            .background(Color.white.opacity(0.08))
                            .clipShape(Capsule())
                    }
                }

                if let expiryDate = item.expiryDate, !expiryDate.isEmpty {
                    Label("Expires \(expiryDate)", systemImage: "calendar")
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)
                }

                if let notes = item.notes, !notes.isEmpty {
                    Text(notes)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }

                HStack(spacing: 16) {
                    Button("Edit") { onEdit() }
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.green)

                    Button(role: .destructive) {
                        onDelete()
                    } label: {
                        Text("Remove")
                            .font(.caption.weight(.bold))
                    }
                }
                .padding(.top, 2)
            }

            Spacer(minLength: 8)

            Menu {
                ForEach(PantryStockStatus.allCases) { status in
                    Button {
                        onStatusChange(status)
                    } label: {
                        Label(status.displayName, systemImage: status.systemImage)
                    }
                }
            } label: {
                StockStatusPill(status: item.normalizedStockStatus)
            }
        }
        .padding(15)
        .background(Color.white.opacity(0.075))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button(role: .destructive) {
                onDelete()
            } label: {
                Label("Remove", systemImage: "trash")
            }
        }
        .swipeActions(edge: .leading, allowsFullSwipe: false) {
            Button {
                onEdit()
            } label: {
                Label("Edit", systemImage: "pencil")
            }
            .tint(.green)
        }
    }
}

private struct StockStatusPill: View {
    let status: PantryStockStatus

    var color: Color {
        switch status {
        case .plenty, .enough:
            return .green
        case .low:
            return .orange
        case .out:
            return .red
        }
    }

    var body: some View {
        Label(status.displayName, systemImage: status.systemImage)
            .font(.caption.weight(.black))
            .lineLimit(1)
            .foregroundStyle(color)
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(color.opacity(0.14))
            .clipShape(Capsule())
    }
}

private struct CatalogueItemCard: View {
    let item: PantryCatalogItem
    let onAdd: () -> Void

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            VStack(alignment: .leading, spacing: 5) {
                Text(item.name)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)

                HStack(spacing: 6) {
                    Text(item.category)
                    Text("•")
                    Text(item.defaultUnit.isEmpty ? "No default unit" : item.defaultUnit)
                }
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            }

            Spacer(minLength: 8)

            Button {
                onAdd()
            } label: {
                Text("Add")
                    .font(.caption.weight(.black))
                    .foregroundStyle(.black)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    .background(Color.green)
                    .clipShape(Capsule())
            }
            .buttonStyle(.plain)
        }
        .padding(15)
        .background(Color.white.opacity(0.075))
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

private struct PantryEmptyState: View {
    let title: String
    let systemImage: String
    let message: String

    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: systemImage)
                .font(.title2.weight(.bold))
                .foregroundStyle(.secondary)
            Text(title)
                .font(.headline.weight(.bold))
            Text(message)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .lineLimit(3)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

private struct PantryItemEditorSheet: View {
    let title: String
    let initialItem: PantryStockItem?
    let onSave: (PantryEditorDraft) async -> Bool

    @Environment(\.dismiss)
    private var dismiss

    @State private var name: String
    @State private var trackingMode: PantryTrackingMode
    @State private var quantity: String
    @State private var unit: String
    @State private var stockStatus: PantryStockStatus
    @State private var category: String
    @State private var expiryDate: String
    @State private var notes: String
    @State private var errorMessage: String?
    @State private var isSaving = false

    init(
        title: String,
        initialItem: PantryStockItem?,
        onSave: @escaping (PantryEditorDraft) async -> Bool
    ) {
        self.title = title
        self.initialItem = initialItem
        self.onSave = onSave
        _name = State(initialValue: initialItem?.name ?? "")
        _trackingMode = State(initialValue: initialItem?.normalizedTrackingMode ?? .exact)
        _quantity = State(
            initialValue: initialItem?.quantity.formatted(
                .number.precision(.fractionLength(0...2))
            ) ?? ""
        )
        _unit = State(initialValue: initialItem?.resolvedUnit ?? "")
        _stockStatus = State(initialValue: initialItem?.normalizedStockStatus ?? .enough)
        _category = State(initialValue: initialItem?.category ?? "")
        _expiryDate = State(initialValue: initialItem?.expiryDate ?? "")
        _notes = State(initialValue: initialItem?.notes ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Ingredient") {
                    TextField("Name", text: $name)
                        .disabled(initialItem != nil)
                        .textInputAutocapitalization(.words)

                    TextField("Category", text: $category)
                        .disabled(initialItem != nil)
                        .textInputAutocapitalization(.words)
                }

                Section("Stock") {
                    Picker("Tracking", selection: $trackingMode) {
                        ForEach(PantryTrackingMode.allCases) { mode in
                            Text(mode.displayName).tag(mode)
                        }
                    }

                    if trackingMode == .exact {
                        TextField("Quantity", text: $quantity)
                            .keyboardType(.decimalPad)
                    }

                    TextField("Unit", text: $unit)
                        .textInputAutocapitalization(.never)

                    Picker("Status", selection: $stockStatus) {
                        ForEach(PantryStockStatus.allCases) { status in
                            Text(status.displayName).tag(status)
                        }
                    }
                }

                Section("Optional") {
                    TextField("Expiry date, YYYY-MM-DD", text: $expiryDate)
                        .textInputAutocapitalization(.never)
                    TextField("Notes", text: $notes, axis: .vertical)
                        .lineLimit(2...4)
                }

                if let errorMessage {
                    Section {
                        Text(errorMessage)
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        Task { await save() }
                    }
                    .disabled(isSaving)
                }
            }
        }
    }

    private func save() async {
        let parsedQuantity: Double?
        if trackingMode == .exact {
            guard let value = Double(quantity), value > 0 else {
                errorMessage = "Enter a valid quantity greater than zero."
                return
            }
            parsedQuantity = value
        } else {
            parsedQuantity = nil
        }

        let cleanedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanedName.isEmpty else {
            errorMessage = "Enter an ingredient name."
            return
        }

        isSaving = true
        defer { isSaving = false }

        let saved = await onSave(
            PantryEditorDraft(
                name: cleanedName,
                trackingMode: trackingMode,
                quantity: parsedQuantity,
                unit: unit,
                stockStatus: stockStatus,
                category: category,
                expiryDate: expiryDate.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : expiryDate,
                notes: notes
            )
        )

        if saved {
            dismiss()
        } else {
            errorMessage = "Could not save pantry item."
        }
    }
}

private struct PantryEditorDraft: Hashable {
    let name: String
    let trackingMode: PantryTrackingMode
    let quantity: Double?
    let unit: String
    let stockStatus: PantryStockStatus
    let category: String
    let expiryDate: String?
    let notes: String
}
