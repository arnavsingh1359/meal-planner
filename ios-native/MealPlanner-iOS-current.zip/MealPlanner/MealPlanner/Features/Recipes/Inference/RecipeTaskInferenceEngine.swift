import Foundation

nonisolated enum RecipeTaskInferenceEngine {
    static func inferTasks(
        from steps: [RecipeStepDraft],
        ingredients: [RecipeIngredientDraft]
    ) -> [RecipeTaskDraft] {
        let ingredientNames = ingredients
            .map {
                $0.name.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
            }
            .filter {
                !$0.isEmpty
            }

        var seenKeys = Set<String>()

        return steps.enumerated().compactMap {
            position,
            step in

            let instruction =
                step.instruction
                    .trimmingCharacters(
                        in: .whitespacesAndNewlines
                    )

            guard !instruction.isEmpty else {
                return nil
            }

            let lower =
                instruction.lowercased()

            let enteredMinutes =
                Int(step.durationMinutes)
                ?? 0

            let totalMinutes =
                inferredMinutes(
                    instruction: lower,
                    explicitMinutes:
                        enteredMinutes
                )

            let classification =
                classify(
                    instruction: lower,
                    totalMinutes:
                        totalMinutes
                )

            let title =
                summarizedTitle(
                    instruction: instruction,
                    lowerInstruction: lower,
                    ingredients:
                        ingredientNames
                )

            let dedupeKey =
                [
                    String(position),
                    title.lowercased(),
                    classification.taskType
                ]
                .joined(separator: "|")

            guard seenKeys.insert(
                dedupeKey
            ).inserted else {
                return nil
            }

            var task =
                RecipeTaskDraft()

            task.title = title
            task.instructions =
                instruction
            task.taskType =
                classification.taskType
            task.activeMinutes =
                String(
                    classification
                        .activeMinutes
                )
            task.passiveMinutes =
                String(
                    classification
                        .passiveMinutes
                )
            task.dayOffset =
                String(
                    classification.dayOffset
                )
            task.startBeforeMealMinutes =
                String(
                    classification
                        .startBeforeMealMinutes
                )
            task.canBatch =
                classification.canBatch
            task.batchKey =
                classification.canBatch
                ? makeBatchKey(
                    taskType:
                        classification.taskType,
                    ingredient:
                        matchingIngredient(
                            in: lower,
                            ingredients:
                                ingredientNames
                        )
                )
                : ""
            task.unattended =
                classification.unattended
            task.blocksActiveWork =
                classification
                    .blocksActiveWork
            task.sourceStepPositions = [
                position
            ]
            task.inferenceSource =
                "rules"
            task.inferenceVersion =
                "rules-v3"
            task.confidence =
                classification.confidence
            task.manuallyEdited = false
            task.canMakeAhead =
                classification.canMakeAhead
            task.maximumMakeAheadHours =
                classification
                    .maximumMakeAheadHours
            task.storageMethod =
                classification.storageMethod

            return task
        }
    }

    private static func classify(
        instruction: String,
        totalMinutes: Int
    ) -> Classification {
        if containsAny(
            instruction,
            ["marinate", "marinade"]
        ) {
            let total =
                totalMinutes > 0
                ? totalMinutes
                : 60

            let active =
                min(5, total)

            return Classification(
                taskType: "marinating",
                activeMinutes: active,
                passiveMinutes:
                    max(0, total - active),
                dayOffset:
                    total >= 480 ? 1 : 0,
                startBeforeMealMinutes:
                    total + 30,
                canBatch: true,
                unattended: true,
                blocksActiveWork: false,
                canMakeAhead: true,
                maximumMakeAheadHours:
                    max(
                        24,
                        total / 60 + 12
                    ),
                storageMethod:
                    "refrigerated",
                confidence: 0.94
            )
        }

        if containsAny(
            instruction,
            ["soak", "rehydrate"]
        ) {
            let total =
                totalMinutes > 0
                ? totalMinutes
                : 30

            let active =
                min(5, total)

            return Classification(
                taskType: "soaking",
                activeMinutes: active,
                passiveMinutes:
                    max(0, total - active),
                dayOffset:
                    total >= 480 ? 1 : 0,
                startBeforeMealMinutes:
                    total + 20,
                canBatch: true,
                unattended: true,
                blocksActiveWork: false,
                canMakeAhead: true,
                maximumMakeAheadHours: 24,
                storageMethod:
                    "refrigerated",
                confidence: 0.91
            )
        }

        if containsAny(
            instruction,
            ["thaw", "defrost"]
        ) {
            let total =
                totalMinutes > 0
                ? totalMinutes
                : 240

            return Classification(
                taskType: "thawing",
                activeMinutes: 0,
                passiveMinutes: total,
                dayOffset:
                    total >= 480 ? 1 : 0,
                startBeforeMealMinutes:
                    total + 30,
                canBatch: false,
                unattended: true,
                blocksActiveWork: false,
                canMakeAhead: true,
                maximumMakeAheadHours: 24,
                storageMethod:
                    "refrigerated",
                confidence: 0.95
            )
        }

        if containsAny(
            instruction,
            [
                "chop",
                "dice",
                "mince",
                "slice",
                "peel",
                "grate",
                "wash",
                "rinse",
                "trim",
                "whisk",
                "mix",
                "stir",
                "combine",
                "fold"
            ]
        ) {
            let total =
                totalMinutes > 0
                ? totalMinutes
                : 10

            return Classification(
                taskType: "preparation",
                activeMinutes: total,
                passiveMinutes: 0,
                dayOffset: 0,
                startBeforeMealMinutes:
                    max(45, total + 25),
                canBatch: true,
                unattended: false,
                blocksActiveWork: true,
                canMakeAhead: true,
                maximumMakeAheadHours: 72,
                storageMethod:
                    "refrigerated",
                confidence: 0.94
            )
        }

        if containsAny(
            instruction,
            [
                "chill",
                "refrigerate",
                "cool",
                "rest",
                "set aside"
            ]
        ) {
            let total =
                totalMinutes > 0
                ? totalMinutes
                : 15

            return Classification(
                taskType:
                    instruction.contains("cool")
                    ? "cooling"
                    : "resting",
                activeMinutes: 0,
                passiveMinutes: total,
                dayOffset:
                    total >= 480 ? 1 : 0,
                startBeforeMealMinutes:
                    total + 20,
                canBatch: false,
                unattended: true,
                blocksActiveWork: false,
                canMakeAhead: true,
                maximumMakeAheadHours: 48,
                storageMethod:
                    instruction.contains(
                        "refrigerate"
                    )
                    || instruction.contains(
                        "chill"
                    )
                    ? "refrigerated"
                    : "room_temperature",
                confidence: 0.89
            )
        }

        if containsAny(
            instruction,
            ["bake", "roast"]
        ) {
            let total =
                totalMinutes > 0
                ? totalMinutes
                : 20

            let active =
                min(5, total)

            return Classification(
                taskType: "cooking",
                activeMinutes: active,
                passiveMinutes:
                    max(0, total - active),
                dayOffset: 0,
                startBeforeMealMinutes:
                    total + 15,
                canBatch: true,
                unattended: true,
                blocksActiveWork: false,
                canMakeAhead: false,
                maximumMakeAheadHours: 0,
                storageMethod: "none",
                confidence: 0.93
            )
        }

        if containsAny(
            instruction,
            ["simmer", "steam"]
        ) {
            let total =
                totalMinutes > 0
                ? totalMinutes
                : 10

            let active =
                min(5, total)

            return Classification(
                taskType: "cooking",
                activeMinutes: active,
                passiveMinutes:
                    max(0, total - active),
                dayOffset: 0,
                startBeforeMealMinutes:
                    total + 10,
                canBatch: true,
                unattended: true,
                blocksActiveWork: false,
                canMakeAhead: false,
                maximumMakeAheadHours: 0,
                storageMethod: "none",
                confidence: 0.91
            )
        }

        if containsAny(
            instruction,
            [
                "boil",
                "fry",
                "sauté",
                "saute",
                "sear",
                "stir-fry",
                "cook",
                "melt",
                "flip"
            ]
        ) {
            let total =
                totalMinutes > 0
                ? totalMinutes
                : 10

            return Classification(
                taskType: "cooking",
                activeMinutes: total,
                passiveMinutes: 0,
                dayOffset: 0,
                startBeforeMealMinutes:
                    total + 15,
                canBatch: true,
                unattended: false,
                blocksActiveWork: true,
                canMakeAhead: false,
                maximumMakeAheadHours: 0,
                storageMethod: "none",
                confidence: 0.91
            )
        }

        if containsAny(
            instruction,
            [
                "serve",
                "garnish",
                "plate",
                "portion"
            ]
        ) {
            let total =
                totalMinutes > 0
                ? totalMinutes
                : 5

            return Classification(
                taskType:
                    instruction.contains(
                        "portion"
                    )
                    ? "portioning"
                    : "serving",
                activeMinutes: total,
                passiveMinutes: 0,
                dayOffset: 0,
                startBeforeMealMinutes:
                    total,
                canBatch:
                    instruction.contains(
                        "portion"
                    ),
                unattended: false,
                blocksActiveWork: true,
                canMakeAhead:
                    instruction.contains(
                        "portion"
                    ),
                maximumMakeAheadHours:
                    instruction.contains(
                        "portion"
                    )
                    ? 24
                    : 0,
                storageMethod:
                    instruction.contains(
                        "portion"
                    )
                    ? "refrigerated"
                    : "none",
                confidence: 0.85
            )
        }

        let total =
            totalMinutes > 0
            ? totalMinutes
            : 10

        return Classification(
            taskType: "preparation",
            activeMinutes: total,
            passiveMinutes: 0,
            dayOffset: 0,
            startBeforeMealMinutes:
                total + 30,
            canBatch: false,
            unattended: false,
            blocksActiveWork: true,
            canMakeAhead: false,
            maximumMakeAheadHours: 0,
            storageMethod: "none",
            confidence: 0.6
        )
    }

    private static func summarizedTitle(
        instruction: String,
        lowerInstruction: String,
        ingredients: [String]
    ) -> String {
        if lowerInstruction.contains(
            "wet ingredients"
        )
            && lowerInstruction.contains(
                "dry ingredients"
            ) {
            return "Combine wet and dry ingredients"
        }

        if lowerInstruction.contains("whisk")
            && containsAny(
                lowerInstruction,
                [
                    "flour",
                    "baking powder",
                    "sugar",
                    "dry ingredients"
                ]
            ) {
            return "Whisk dry ingredients"
        }

        if lowerInstruction.contains("whisk")
            && containsAny(
                lowerInstruction,
                [
                    "egg",
                    "buttermilk",
                    "milk",
                    "vanilla",
                    "wet ingredients"
                ]
            ) {
            return "Whisk wet ingredients"
        }

        if lowerInstruction.contains("melt")
            && lowerInstruction.contains(
                "butter"
            ) {
            return "Melt butter"
        }

        if containsAny(
            lowerInstruction,
            ["scoop", "pour"]
        )
            && containsAny(
                lowerInstruction,
                ["batter", "pancake"]
            ) {
            return "Cook pancakes"
        }

        if lowerInstruction.contains("flip")
            && lowerInstruction.contains(
                "pancake"
            ) {
            return "Flip and finish pancakes"
        }

        let actions:
            [(terms: [String], title: String)] = [
            (["chop"], "Chop"),
            (["dice"], "Dice"),
            (["mince"], "Mince"),
            (["slice"], "Slice"),
            (["peel"], "Peel"),
            (["grate"], "Grate"),
            (["wash", "rinse"], "Wash"),
            (["marinate"], "Marinate"),
            (["soak"], "Soak"),
            (["bake"], "Bake"),
            (["roast"], "Roast"),
            (["simmer"], "Simmer"),
            (["boil"], "Boil"),
            (["refrigerate", "chill"], "Refrigerate"),
            (["cool"], "Cool"),
            (["mix"], "Mix"),
            (["stir"], "Stir"),
            (["combine"], "Combine"),
            (["cook"], "Cook"),
            (["serve"], "Serve")
        ]

        for action in actions
        where containsAny(
            lowerInstruction,
            action.terms
        ) {
            if let ingredient =
                matchingIngredient(
                    in: lowerInstruction,
                    ingredients:
                        ingredients
                ) {
                return "\(action.title) \(ingredient.lowercased())"
            }

            if let object =
                shortObjectPhrase(
                    after: action.terms,
                    in: instruction
                ) {
                return "\(action.title) \(object)"
            }

            return action.title
        }

        let words =
            instruction
                .replacingOccurrences(
                    of: #"\s+"#,
                    with: " ",
                    options:
                        .regularExpression
                )
                .split(separator: " ")
                .prefix(5)
                .map(String.init)

        guard !words.isEmpty else {
            return "Prepare recipe step"
        }

        let result =
            words.joined(
                separator: " "
            )

        return result.prefix(1)
            .uppercased()
            + result.dropFirst()
    }

    private static func shortObjectPhrase(
        after terms: [String],
        in instruction: String
    ) -> String? {
        let lower =
            instruction.lowercased()

        guard let matchedTerm =
            terms.first(
                where: {
                    lower.contains($0)
                }
            ),
              let range =
            lower.range(of: matchedTerm)
        else {
            return nil
        }

        let remaining =
            instruction[
                range.upperBound...
            ]
            .trimmingCharacters(
                in:
                    .whitespacesAndNewlines
            )

        let cleaned =
            remaining
                .replacingOccurrences(
                    of: #"^(the|a|an)\s+"#,
                    with: "",
                    options:
                        .regularExpression
                )

        let phrase =
            cleaned
                .split(
                    whereSeparator: {
                        ",.;".contains($0)
                    }
                )
                .first
                .map(String.init)
                ?? cleaned

        let words =
            phrase
                .split(separator: " ")
                .prefix(4)
                .map(String.init)

        guard !words.isEmpty else {
            return nil
        }

        return words.joined(
            separator: " "
        )
    }

    private static func inferredMinutes(
        instruction: String,
        explicitMinutes: Int
    ) -> Int {
        if explicitMinutes > 0 {
            return explicitMinutes
        }

        let patterns:
            [(String, Int)] = [
            (
                #"(\d+)\s*(?:hours|hour|hrs|hr)"#,
                60
            ),
            (
                #"(\d+)\s*(?:minutes|minute|mins|min)"#,
                1
            )
        ]

        for (
            pattern,
            multiplier
        ) in patterns {
            guard let regex =
                try? NSRegularExpression(
                    pattern: pattern
                ),
                  let match =
                regex.firstMatch(
                    in: instruction,
                    range: NSRange(
                        instruction.startIndex...,
                        in: instruction
                    )
                ),
                  let range =
                Range(
                    match.range(at: 1),
                    in: instruction
                ),
                  let value =
                Int(instruction[range])
            else {
                continue
            }

            return value * multiplier
        }

        if instruction.contains(
            "overnight"
        ) {
            return 720
        }

        return 0
    }

    private static func matchingIngredient(
        in instruction: String,
        ingredients: [String]
    ) -> String? {
        ingredients
            .sorted {
                $0.count > $1.count
            }
            .first {
                instruction.contains(
                    $0.lowercased()
                )
            }
    }

    private static func makeBatchKey(
        taskType: String,
        ingredient: String?
    ) -> String {
        let raw =
            [
                taskType,
                ingredient ?? "shared"
            ]
            .joined(separator: "_")
            .lowercased()

        return raw
            .replacingOccurrences(
                of: #"[^a-z0-9]+"#,
                with: "_",
                options:
                    .regularExpression
            )
            .trimmingCharacters(
                in:
                    CharacterSet(
                        charactersIn: "_"
                    )
            )
    }

    private static func containsAny(
        _ text: String,
        _ terms: [String]
    ) -> Bool {
        terms.contains {
            text.contains($0)
        }
    }
}

nonisolated private struct Classification {
    let taskType: String
    let activeMinutes: Int
    let passiveMinutes: Int
    let dayOffset: Int
    let startBeforeMealMinutes: Int
    let canBatch: Bool
    let unattended: Bool
    let blocksActiveWork: Bool
    let canMakeAhead: Bool
    let maximumMakeAheadHours: Int
    let storageMethod: String
    let confidence: Double
}
