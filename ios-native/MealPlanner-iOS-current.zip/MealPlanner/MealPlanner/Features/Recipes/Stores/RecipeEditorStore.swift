import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class RecipeEditorStore {
    private(set) var isLoading = false
    private(set) var isSaving = false
    private(set) var recipeID: UUID?

    var draft = RecipeEditorDraft()
    var errorMessage: String?

    private var savedDraft = RecipeEditorDraft()
    private(set) var hasLoaded = false

    let availableMealTypes = ["breakfast", "lunch", "dinner", "snack"]
    let availableStepTypes = ["active", "passive"]
    let availableTaskTypes = ["preparation", "marinating", "soaking", "thawing", "cooking", "resting", "cooling", "portioning", "storage", "cleanup", "serving", "other"]
    let availableIngredientUnits = ["g", "kg", "ml", "L", "tsp", "tbsp", "cup", "fl oz", "oz", "lb", "pinch", "piece", "clove", "can", "package", "unit"]

    var hasUnsavedChanges: Bool {
        draft.normalized != savedDraft.normalized
    }

    var validationMessage: String? {
        let value = draft.normalized

        if value.name.isEmpty { return "Recipe name is required." }
        if value.mealTypes.isEmpty { return "Select at least one meal type." }
        if let message = validatePositiveDecimal(value.defaultServings, field: "Default servings") { return message }
        if let message = validatePositiveDecimal(value.minimumBatchServings, field: "Minimum batch servings") { return message }
        if let message = validatePositiveDecimal(value.maximumBatchServings, field: "Maximum batch servings") { return message }

        if let minimum = Double(value.minimumBatchServings),
           let maximum = Double(value.maximumBatchServings),
           minimum > maximum {
            return "Maximum batch servings cannot be smaller than minimum batch servings."
        }

        for (text, field) in [
            (value.preparationMinutes, "Preparation time"),
            (value.cookingMinutes, "Cooking time"),
            (value.cleanupMinutes, "Cleanup time"),
            (value.refrigeratorLifeDays, "Refrigerator life")
        ] {
            if let message = validateNonnegativeInteger(text, field: field) { return message }
        }

        if value.freezerAllowed,
           let message = validateNonnegativeInteger(value.freezerLifeDays, field: "Freezer life") {
            return message
        }

        if value.ingredients.isEmpty {
            return "Add at least one ingredient."
        }

        for (index, ingredient) in value.ingredients.enumerated() {
            if ingredient.name.isEmpty { return "Ingredient \(index + 1) needs a name." }
            guard let quantity = Double(ingredient.quantity), quantity > 0 else {
                return "Ingredient \(index + 1) needs a quantity greater than zero."
            }
            if ingredient.unit.isEmpty { return "Ingredient \(index + 1) needs a unit." }
        }

        if !value.steps.contains(where: { !$0.instruction.isEmpty }) {
            return "Add at least one cooking step."
        }

        for (index, step) in value.steps.enumerated() {
            if step.instruction.isEmpty { return "Instruction \(index + 1) cannot be empty." }
            if let message = validateNonnegativeInteger(step.durationMinutes, field: "Instruction \(index + 1) duration") { return message }
        }

        for (index, task) in value.tasks.enumerated() {
            if task.title.isEmpty { return "Schedule task \(index + 1) needs a title." }
            for (text, field) in [
                (task.activeMinutes, "Task \(index + 1) active time"),
                (task.passiveMinutes, "Task \(index + 1) passive time"),
                (task.startBeforeMealMinutes, "Task \(index + 1) start-before-meal time")
            ] {
                if let message = validateNonnegativeInteger(text, field: field) { return message }
            }

            guard let dayOffset = Int(task.dayOffset), (-14...14).contains(dayOffset) else {
                return "Task \(index + 1) day offset must be a whole number from -14 to 14."
            }

            if task.canBatch && task.batchKey.isEmpty {
                return "Task \(index + 1) needs a batch key, or batching must be turned off."
            }
        }

        return nil
    }

    var canSave: Bool {
        !isLoading && !isSaving && hasUnsavedChanges && validationMessage == nil
    }

    var complianceReport:
        RecipeComplianceReport {
        RecipeComplianceEngine.analyze(
            draft: draft
        )
    }

    var calculatedPreparationMinutes: Int {
        calculatedTimes.preparation
    }

    var calculatedCookingMinutes: Int {
        calculatedTimes.cooking
    }

    var calculatedCleanupMinutes: Int {
        calculatedTimes.cleanup
    }

    var calculatedTotalMinutes: Int {
        roundedToNearestFive(
            calculatedTimes.total
        )
    }

    private var calculatedTimes:
        (
            preparation: Int,
            cooking: Int,
            cleanup: Int,
            total: Int
        ) {
        let inferred =
            RecipeTaskInferenceEngine
                .inferTasks(
                    from: draft.steps,
                    ingredients:
                        draft.ingredients
                )

        var preparation = 0
        var cooking = 0
        var cleanup = 0

        for task in inferred {
            let activeDuration =
                Int(task.activeMinutes)
                ?? 0

            switch task.taskType {
            case "cooking":
                cooking += activeDuration

            case "cleanup":
                cleanup += activeDuration

            default:
                preparation += activeDuration
            }
        }

        return (
            preparation,
            cooking,
            cleanup,
            preparation
                + cooking
                + cleanup
        )
    }

    private func synchronizeCalculatedTimes() {
        draft.preparationMinutes =
            String(
                calculatedPreparationMinutes
            )

        draft.cookingMinutes =
            String(
                calculatedCookingMinutes
            )

        draft.cleanupMinutes =
            String(
                calculatedCleanupMinutes
            )
    }

    private func roundedToNearestFive(
        _ minutes: Int
    ) -> Int {
        guard minutes > 0 else {
            return 0
        }

        return max(
            5,
            Int(
                (
                    Double(minutes)
                    / 5.0
                ).rounded()
            ) * 5
        )
    }

    func load(recipeID: UUID?) async {
        guard !isLoading, !hasLoaded else { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            _ = try await AppSupabase.client.auth.session

            guard let recipeID else {
                self.recipeID = nil
                draft = RecipeEditorDraft()
                savedDraft = draft
                hasLoaded = true
                return
            }

            let session = try await AppSupabase.client.auth.session

            let recipe: RecipeDetail = try await AppSupabase.client
                .from("recipes")
                .select(
                    """
                    id,
                    user_id,
                    name,
                    description,
                    meal_types,
                    default_servings,
                    minimum_batch_servings,
                    maximum_batch_servings,
                    preparation_minutes,
                    cooking_minutes,
                    cleanup_minutes,
                    refrigerator_life_days,
                    freezer_allowed,
                    freezer_life_days,
                    is_public,
                    parent_recipe_id,
                    creator_name,
                    analysis_status,
                    compliance_score,
                    created_at
                    """
                )
                .eq("id", value: recipeID.uuidString)
                .single()
                .execute()
                .value

            guard recipe.userID == session.user.id else {
                throw RecipeEditorError.notOwner
            }

            let ingredients: [RecipeDetailIngredient] = try await AppSupabase.client
                .from("recipe_ingredients")
                .select("id,ingredient_id,name,quantity,unit,preparation_note,is_optional,scaling_behavior,shopping_included,preparation_state,position")
                .eq("recipe_id", value: recipeID.uuidString)
                .order("position", ascending: true)
                .execute()
                .value

            let steps: [RecipeDetailStep] = try await AppSupabase.client
                .from("recipe_steps")
                .select("id,instruction,duration_minutes,step_type,position")
                .eq("recipe_id", value: recipeID.uuidString)
                .order("position", ascending: true)
                .execute()
                .value

            let tasks: [RecipeDetailTask] = try await AppSupabase.client
                .from("recipe_tasks")
                .select("id,title,instructions,task_type,active_minutes,passive_minutes,day_offset,start_before_meal_minutes,can_batch,batch_key,unattended,blocks_active_work,source_step_positions,inference_source,inference_version,confidence,manually_edited,can_make_ahead,maximum_make_ahead_hours,storage_method,position")
                .eq("recipe_id", value: recipeID.uuidString)
                .order("position", ascending: true)
                .execute()
                .value

            self.recipeID = recipeID
            draft = RecipeEditorDraft(recipe: recipe, ingredients: ingredients, steps: steps, tasks: tasks)
            savedDraft = draft
            hasLoaded = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func toggleMealType(_ mealType: String) {
        if draft.mealTypes.contains(mealType) {
            draft.mealTypes.remove(mealType)
        } else {
            draft.mealTypes.insert(mealType)
        }
    }

    func addIngredient() { draft.ingredients.append(RecipeIngredientDraft()) }
    func addStep() { draft.steps.append(RecipeStepDraft()) }
    func addTask() {
        var task = RecipeTaskDraft()
        task.manuallyEdited = true
        task.inferenceSource = "manual"
        draft.tasks.append(task)
    }

    func generateTasksFromSteps() {
        draft.tasks =
            deduplicatedTasks(
                RecipeTaskInferenceEngine
                    .inferTasks(
                        from: draft.steps,
                        ingredients:
                            draft.ingredients
                    )
            )

        synchronizeCalculatedTimes()
    }

    func deleteIngredient(id: UUID) { draft.ingredients.removeAll { $0.id == id } }
    func deleteStep(id: UUID) { draft.steps.removeAll { $0.id == id } }
    func deleteTask(id: UUID) { draft.tasks.removeAll { $0.id == id } }

    func moveIngredient(id: UUID, by offset: Int) { move(id: id, by: offset, in: &draft.ingredients) }
    func moveStep(id: UUID, by offset: Int) { move(id: id, by: offset, in: &draft.steps) }
    func moveTask(id: UUID, by offset: Int) { move(id: id, by: offset, in: &draft.tasks) }

    func save() async -> Bool {
        if draft.tasks.isEmpty {
            generateTasksFromSteps()
        } else {
            draft.tasks =
                deduplicatedTasks(
                    draft.tasks
                )
            synchronizeCalculatedTimes()
        }

        guard let parameters =
            makeSaveParameters(
                recipeID: recipeID
            )
        else {
            return false
        }
        isSaving = true
        errorMessage = nil
        defer { isSaving = false }

        do {
            let returnedID: String = try await AppSupabase.client
                .rpc("save_recipe_full", params: parameters)
                .execute()
                .value

            guard let savedRecipeID = UUID(uuidString: returnedID) else {
                throw RecipeEditorError.invalidSavedRecipeID
            }

            recipeID = savedRecipeID

            try await persistCompliance(
                recipeID:
                    savedRecipeID
            )

            savedDraft = draft.normalized
            draft = savedDraft
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    private func persistCompliance(
        recipeID: UUID
    ) async throws {
        let session =
            try await AppSupabase
                .client
                .auth
                .session

        let report =
            RecipeComplianceEngine
                .analyze(
                    draft: draft
                )

        try await AppSupabase.client
            .from(
                "recipe_prep_operations"
            )
            .delete()
            .eq(
                "recipe_id",
                value:
                    recipeID.uuidString
            )
            .execute()

        try await AppSupabase.client
            .from(
                "recipe_compliance_issues"
            )
            .delete()
            .eq(
                "recipe_id",
                value:
                    recipeID.uuidString
            )
            .execute()

        if !report.operations.isEmpty {
            let rows =
                report.operations
                    .enumerated()
                    .map {
                        index,
                        operation in

                        RecipePrepOperationInsert(
                            recipeID:
                                recipeID,
                            userID:
                                session.user.id,
                            ingredientPosition:
                                operation
                                    .ingredientPosition,
                            sourceStepPositions:
                                operation
                                    .sourceStepPositions,
                            canonicalIngredientName:
                                operation
                                    .canonicalIngredientName,
                            displayIngredientName:
                                operation
                                    .displayIngredientName,
                            action:
                                operation.action,
                            preparationState:
                                operation
                                    .preparationState,
                            quantity:
                                operation.quantity,
                            unit:
                                operation.unit,
                            canMakeAhead:
                                operation
                                    .canMakeAhead,
                            maximumMakeAheadHours:
                                operation
                                    .maximumMakeAheadHours,
                            storageMethod:
                                operation
                                    .storageMethod,
                            batchKey:
                                operation.batchKey,
                            confidence:
                                operation.confidence,
                            manuallyEdited:
                                false,
                            analysisVersion:
                                RecipeComplianceEngine
                                    .analysisVersion,
                            position: index
                        )
                    }

            try await AppSupabase.client
                .from(
                    "recipe_prep_operations"
                )
                .insert(rows)
                .execute()
        }

        if !report.issues.isEmpty {
            let rows =
                report.issues.map {
                    issue in

                    RecipeComplianceIssueInsert(
                        recipeID:
                            recipeID,
                        userID:
                            session.user.id,
                        code:
                            issue.code,
                        severity:
                            issue.severity.rawValue,
                        title:
                            issue.title,
                        message:
                            issue.message,
                        ingredientPosition:
                            issue
                                .ingredientPosition,
                        stepPosition:
                            issue.stepPosition
                    )
                }

            try await AppSupabase.client
                .from(
                    "recipe_compliance_issues"
                )
                .insert(rows)
                .execute()
        }

        try await AppSupabase.client
            .from("recipes")
            .update(
                RecipeAnalysisUpdate(
                    analysisStatus:
                        report.status,
                    analysisVersion:
                        RecipeComplianceEngine
                            .analysisVersion,
                    complianceScore:
                        report.score,
                    lastAnalyzedAt:
                        Date()
                )
            )
            .eq(
                "id",
                value:
                    recipeID.uuidString
            )
            .execute()
    }

    private func makeSaveParameters(recipeID: UUID?) -> SaveRecipeParameters? {
        guard validationMessage == nil else { return nil }
        let value = draft.normalized

        let metadata = RecipeSaveMetadata(
            name: value.name,
            description: value.description.isEmpty ? nil : value.description,
            mealTypes: value.mealTypes.sorted(),
            defaultServings: Double(value.defaultServings),
            minimumBatchServings: Double(value.minimumBatchServings),
            maximumBatchServings: Double(value.maximumBatchServings),
            preparationMinutes: Int(value.preparationMinutes),
            cookingMinutes: Int(value.cookingMinutes),
            cleanupMinutes: Int(value.cleanupMinutes),
            refrigeratorLifeDays: Int(value.refrigeratorLifeDays),
            freezerAllowed: value.freezerAllowed,
            freezerLifeDays: value.freezerAllowed ? Int(value.freezerLifeDays) : nil,
            isPublic: value.isPublic
        )

        let ingredients = value.ingredients.enumerated().map { index, ingredient in
            RecipeIngredientSaveItem(
                name: ingredient.name,
                quantity: Double(ingredient.quantity) ?? 0,
                unit: ingredient.unit,
                preparationNote: ingredient.preparationNote.isEmpty ? nil : ingredient.preparationNote,
                isOptional: ingredient.isOptional,
                position: index
            )
        }

        let steps = value.steps.enumerated().map { index, step in
            RecipeStepSaveItem(
                instruction: step.instruction,
                durationMinutes: Int(step.durationMinutes) ?? 0,
                stepType: step.stepType,
                position: index
            )
        }

        let tasks = value.tasks.enumerated().map { index, task in
            RecipeTaskSaveItem(
                title: task.title,
                instructions: task.instructions.isEmpty ? nil : task.instructions,
                taskType: task.taskType,
                activeMinutes: Int(task.activeMinutes) ?? 0,
                passiveMinutes: Int(task.passiveMinutes) ?? 0,
                dayOffset: Int(task.dayOffset) ?? 0,
                startBeforeMealMinutes: Int(task.startBeforeMealMinutes) ?? 0,
                canBatch: task.canBatch,
                batchKey: task.canBatch && !task.batchKey.isEmpty ? task.batchKey : nil,
                unattended: task.unattended,
                blocksActiveWork: task.blocksActiveWork,
                sourceStepPositions: task.sourceStepPositions,
                inferenceSource: task.inferenceSource,
                inferenceVersion: task.inferenceVersion,
                confidence: task.confidence,
                manuallyEdited: task.manuallyEdited,
                canMakeAhead: task.canMakeAhead,
                maximumMakeAheadHours: task.maximumMakeAheadHours,
                storageMethod: task.storageMethod,
                position: index
            )
        }

        return SaveRecipeParameters(
            recipeID: recipeID,
            recipe: metadata,
            ingredients: ingredients,
            steps: steps,
            tasks: tasks
        )
    }

    private func deduplicatedTasks(
        _ tasks: [RecipeTaskDraft]
    ) -> [RecipeTaskDraft] {
        var seen = Set<String>()

        return tasks.filter { task in
            let source =
                task.sourceStepPositions
                    .map(String.init)
                    .joined(separator: ",")

            let key =
                [
                    source,
                    task.title
                        .trimmingCharacters(
                            in:
                                .whitespacesAndNewlines
                        )
                        .lowercased(),
                    task.taskType
                        .lowercased()
                ]
                .joined(separator: "|")

            return seen.insert(key).inserted
        }
    }

    private func validatePositiveDecimal(_ text: String, field: String) -> String? {
        guard !text.isEmpty else { return nil }
        guard let value = Double(text), value > 0 else { return "\(field) must be greater than zero." }
        return nil
    }

    private func validateNonnegativeInteger(_ text: String, field: String) -> String? {
        guard !text.isEmpty else { return nil }
        guard let value = Int(text), value >= 0 else { return "\(field) must be a whole number of zero or more." }
        return nil
    }

    private func move<T: Identifiable>(id: UUID, by offset: Int, in array: inout [T]) where T.ID == UUID {
        guard let source = array.firstIndex(where: { $0.id == id }) else { return }
        let destination = source + offset
        guard array.indices.contains(destination) else { return }
        array.swapAt(source, destination)
    }
}

private enum RecipeEditorError: LocalizedError {
    case notOwner
    case invalidSavedRecipeID

    var errorDescription: String? {
        switch self {
        case .notOwner: return "You can only edit recipes that you own."
        case .invalidSavedRecipeID: return "The recipe saved, but its identifier could not be read."
        }
    }
}
