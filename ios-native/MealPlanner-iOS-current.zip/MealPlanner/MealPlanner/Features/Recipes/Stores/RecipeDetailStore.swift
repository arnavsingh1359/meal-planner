import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class RecipeDetailStore {
    private(set) var recipe: RecipeDetail?
    private(set) var ingredients: [RecipeDetailIngredient] = []
    private(set) var steps: [RecipeDetailStep] = []
    private(set) var tasks: [RecipeDetailTask] = []
    private(set) var complianceIssues:
        [RecipeDetailComplianceIssue] = []
    private(set) var isLoading = false
    private(set) var isUpdatingFavorite = false
    private(set) var isCustomizing = false
    private(set) var isDeleting = false
    private(set) var isFavorite = false
    private(set) var isOwnedByCurrentUser = false

    var errorMessage: String?
    var operationErrorMessage: String?

    private var currentUserID: UUID?

    func load(recipeID: UUID) async {
        guard !isLoading else { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            let session = try await AppSupabase.client.auth.session
            currentUserID = session.user.id

            let loadedRecipe: RecipeDetail = try await AppSupabase.client
                .from("recipes")
                .select(
                    """
                    id,
                    user_id,
                    name,
                    description,
                    meal_types,
                    default_servings,
                    minimum_batch_servings,
                    maximum_batch_servings,
                    preparation_minutes,
                    cooking_minutes,
                    cleanup_minutes,
                    refrigerator_life_days,
                    freezer_allowed,
                    freezer_life_days,
                    is_public,
                    parent_recipe_id,
                    creator_name,
                    analysis_status,
                    compliance_score,
                    created_at
                    """
                )
                .eq("id", value: recipeID.uuidString)
                .single()
                .execute()
                .value

            let loadedIngredients: [RecipeDetailIngredient] = try await AppSupabase.client
                .from("recipe_ingredients")
                .select(
                    """
                    id,
                    ingredient_id,
                    name,
                    quantity,
                    unit,
                    preparation_note,
                    is_optional,
                    scaling_behavior,
                    shopping_included,
                    preparation_state,
                    position
                    """
                )
                .eq("recipe_id", value: recipeID.uuidString)
                .order("position", ascending: true)
                .execute()
                .value

            let loadedSteps: [RecipeDetailStep] = try await AppSupabase.client
                .from("recipe_steps")
                .select("id,instruction,duration_minutes,step_type,position")
                .eq("recipe_id", value: recipeID.uuidString)
                .order("position", ascending: true)
                .execute()
                .value

            let loadedTasks: [RecipeDetailTask] = try await AppSupabase.client
                .from("recipe_tasks")
                .select(
                    """
                    id,
                    title,
                    instructions,
                    task_type,
                    active_minutes,
                    passive_minutes,
                    day_offset,
                    start_before_meal_minutes,
                    can_batch,
                    batch_key,
                    unattended,
                    blocks_active_work,
                    source_step_positions,
                    inference_source,
                    inference_version,
                    confidence,
                    manually_edited,
                    can_make_ahead,
                    maximum_make_ahead_hours,
                    storage_method,
                    position
                    """
                )
                .eq("recipe_id", value: recipeID.uuidString)
                .order("position", ascending: true)
                .execute()
                .value

            let loadedIssues:
                [RecipeDetailComplianceIssue]

            if loadedRecipe.userID
                == session.user.id {
                loadedIssues =
                    try await AppSupabase.client
                        .from(
                            "recipe_compliance_issues"
                        )
                        .select(
                            """
                            id,
                            code,
                            severity,
                            title,
                            message,
                            ingredient_position,
                            step_position
                            """
                        )
                        .eq(
                            "recipe_id",
                            value:
                                recipeID.uuidString
                        )
                        .order(
                            "created_at",
                            ascending: true
                        )
                        .execute()
                        .value
            } else {
                loadedIssues = []
            }

            recipe = loadedRecipe
            ingredients = loadedIngredients
            steps = loadedSteps
            tasks = loadedTasks
            complianceIssues = loadedIssues
            isOwnedByCurrentUser = loadedRecipe.userID == session.user.id
            isFavorite = isOwnedByCurrentUser
                ? true
                : try await favoriteExists(recipeID: recipeID, userID: session.user.id)
        } catch {
            guard !isCancellation(error) else {
                return
            }

            if recipe == nil {
                ingredients = []
                steps = []
                tasks = []
                complianceIssues = []
                errorMessage =
                    error.localizedDescription
            } else {
                // Preserve the currently displayed recipe when a refresh
                // request fails or the connection briefly drops.
                errorMessage = nil
                operationErrorMessage =
                    "Could not refresh this recipe. Pull down to try again."
            }
        }
    }

    func toggleFavorite() async {
        guard let recipe, let currentUserID, !isOwnedByCurrentUser, !isUpdatingFavorite else { return }
        isUpdatingFavorite = true
        operationErrorMessage = nil
        defer { isUpdatingFavorite = false }

        do {
            if isFavorite {
                try await AppSupabase.client
                    .from("user_recipe_favorites")
                    .delete()
                    .eq("user_id", value: currentUserID.uuidString)
                    .eq("recipe_id", value: recipe.id.uuidString)
                    .execute()
                isFavorite = false
            } else {
                try await AppSupabase.client
                    .from("user_recipe_favorites")
                    .insert(RecipeFavorite(userID: currentUserID, recipeID: recipe.id))
                    .execute()
                isFavorite = true
            }
        } catch {
            operationErrorMessage = error.localizedDescription
        }
    }

    func customize() async -> UUID? {
        guard let recipe else { return nil }
        guard !isOwnedByCurrentUser, recipe.isPublic, !isCustomizing else { return nil }
        isCustomizing = true
        operationErrorMessage = nil
        defer { isCustomizing = false }

        do {
            let returnedID: String = try await AppSupabase.client
                .rpc("fork_public_recipe", params: ForkRecipeParameters(sourceRecipeID: recipe.id))
                .execute()
                .value

            guard let id = UUID(uuidString: returnedID) else {
                throw RecipeDetailStoreError.invalidRecipeID
            }
            return id
        } catch {
            operationErrorMessage = error.localizedDescription
            return nil
        }
    }

    func deleteOwnedRecipe() async -> Bool {
        guard let recipe, isOwnedByCurrentUser, !isDeleting else { return false }
        isDeleting = true
        operationErrorMessage = nil
        defer { isDeleting = false }

        do {
            return try await AppSupabase.client
                .rpc("delete_owned_recipe", params: RecipeIDParameters(recipeID: recipe.id))
                .execute()
                .value
        } catch {
            operationErrorMessage = error.localizedDescription
            return false
        }
    }

    func clearOperationError() {
        operationErrorMessage = nil
    }

    private func isCancellation(
        _ error: Error
    ) -> Bool {
        if error is CancellationError {
            return true
        }

        let nsError = error as NSError

        return nsError.domain == NSURLErrorDomain
            && nsError.code == NSURLErrorCancelled
    }

    private func favoriteExists(recipeID: UUID, userID: UUID) async throws -> Bool {
        let response = try await AppSupabase.client
            .from("user_recipe_favorites")
            .select("recipe_id", head: true, count: .exact)
            .eq("user_id", value: userID.uuidString)
            .eq("recipe_id", value: recipeID.uuidString)
            .execute()

        return (response.count ?? 0) > 0
    }
}

private enum RecipeDetailStoreError: LocalizedError {
    case invalidRecipeID

    var errorDescription: String? {
        "The customized recipe was created, but its identifier could not be read."
    }
}
