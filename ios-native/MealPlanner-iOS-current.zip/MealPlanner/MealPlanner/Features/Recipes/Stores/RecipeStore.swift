import Foundation
import Observation
import Supabase

enum RecipeTab: String, CaseIterable, Identifiable {
    case discover = "Discover"
    case favorites = "Favorites"
    case mine = "My Recipes"

    var id: String {
        rawValue
    }

    var databaseValue: String {
        switch self {
        case .discover:
            return "discover"

        case .favorites:
            return "favorites"

        case .mine:
            return "mine"
        }
    }

    init?(databaseValue: String) {
        switch databaseValue.lowercased() {
        case "discover":
            self = .discover

        case "favorites":
            self = .favorites

        case "mine":
            self = .mine

        default:
            return nil
        }
    }
}

enum RecipeMealTypeFilter:
    String,
    CaseIterable,
    Identifiable {

    case all = "All"
    case breakfast = "Breakfast"
    case lunch = "Lunch"
    case dinner = "Dinner"
    case snack = "Snack"

    var id: String {
        rawValue
    }

    var databaseValue: String? {
        self == .all
            ? nil
            : rawValue.lowercased()
    }
}

private struct RecipeDefaultTabPreference:
    Decodable {

    let defaultRecipeTab: String

    enum CodingKeys: String, CodingKey {
        case defaultRecipeTab =
            "default_recipe_tab"
    }
}

@MainActor
@Observable
final class RecipeStore {
    static let pageSize = 50

    private(set) var recipes: [Recipe] = []
    private(set) var isLoading = false
    private(set) var hasLoadedInitialPreference = false

    private(set) var currentPage = 1
    private(set) var totalCount = 0

    private(set) var discoverCount = 0
    private(set) var favoritesCount = 0
    private(set) var myRecipesCount = 0

    var selectedTab: RecipeTab = .discover
    var selectedMealType:
        RecipeMealTypeFilter = .all

    var searchText = ""
    var errorMessage: String?

    private var currentUserID: UUID?

    var totalPages: Int {
        max(
            1,
            Int(
                ceil(
                    Double(totalCount)
                    / Double(Self.pageSize)
                )
            )
        )
    }

    var hasPreviousPage: Bool {
        currentPage > 1
    }

    var hasNextPage: Bool {
        currentPage < totalPages
    }

    var pageSummary: String {
        guard totalCount > 0 else {
            return "0 recipes"
        }

        let first =
            ((currentPage - 1)
             * Self.pageSize) + 1

        let last = min(
            currentPage * Self.pageSize,
            totalCount
        )

        return "\(first)–\(last) of \(totalCount)"
    }

    var queryIdentifier: String {
        [
            selectedTab.databaseValue,
            selectedMealType.databaseValue
                ?? "all",
            searchText
                .trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
                .lowercased()
        ]
        .joined(separator: "|")
    }

    func prepareInitialLoad() async {
        guard !hasLoadedInitialPreference else {
            return
        }

        await loadDefaultRecipeTabPreference()

        hasLoadedInitialPreference = true

        await loadFirstPage()
    }

    func applyDefaultTab(
        databaseValue: String
    ) async {
        guard let tab = RecipeTab(
            databaseValue: databaseValue
        ) else {
            return
        }

        selectedTab = tab
        currentPage = 1

        await loadFirstPage()
    }

    func loadFirstPage() async {
        await loadPage(1)
    }

    func reloadCurrentPage() async {
        await loadPage(currentPage)
    }

    func loadNextPage() async {
        guard hasNextPage else {
            return
        }

        await loadPage(currentPage + 1)
    }

    func loadPreviousPage() async {
        guard hasPreviousPage else {
            return
        }

        await loadPage(currentPage - 1)
    }

    func loadPage(
        _ requestedPage: Int
    ) async {
        guard !isLoading else {
            return
        }

        isLoading = true
        errorMessage = nil

        defer {
            isLoading = false
        }

        do {
            let session = try await AppSupabase
                .client
                .auth
                .session

            currentUserID = session.user.id

            let cleanedSearch = searchText
                .trimmingCharacters(
                    in: .whitespacesAndNewlines
                )

            let parameters =
                RecipePageParameters(
                    tab:
                        selectedTab.databaseValue,
                    search:
                        cleanedSearch.isEmpty
                        ? nil
                        : cleanedSearch,
                    mealType:
                        selectedMealType
                            .databaseValue,
                    page:
                        max(1, requestedPage),
                    pageSize:
                        Self.pageSize
                )

            let pageResponse:
                RecipePageResponse =
                try await AppSupabase
                    .client
                    .rpc(
                        "get_recipe_page",
                        params: parameters
                    )
                    .execute()
                    .value

            let countResponse:
                RecipeLibraryCounts =
                try await AppSupabase
                    .client
                    .rpc(
                        "get_recipe_library_counts"
                    )
                    .execute()
                    .value

            recipes = pageResponse.items
            totalCount =
                pageResponse.totalCount
            currentPage =
                pageResponse.page

            discoverCount =
                countResponse.discoverCount

            favoritesCount =
                countResponse.favoritesCount

            myRecipesCount =
                countResponse.myRecipesCount
        } catch {
            guard !isCancellation(error) else {
                return
            }

            if recipes.isEmpty {
                totalCount = 0
                errorMessage =
                    error.localizedDescription
            } else {
                errorMessage = nil
            }
        }
    }

    func isOwnedByCurrentUser(
        _ recipe: Recipe
    ) -> Bool {
        recipe.userID == currentUserID
    }

    func isFavorite(
        _ recipe: Recipe
    ) -> Bool {
        recipe.userID == currentUserID
            || recipe.isFavorite
    }

    func toggleFavorite(
        _ recipe: Recipe
    ) async {
        guard let currentUserID,
              recipe.userID != currentUserID else {
            return
        }

        errorMessage = nil

        do {
            let exists =
                try await favoriteExists(
                    recipeID: recipe.id,
                    userID: currentUserID
                )

            if exists {
                try await AppSupabase
                    .client
                    .from(
                        "user_recipe_favorites"
                    )
                    .delete()
                    .eq(
                        "user_id",
                        value:
                            currentUserID.uuidString
                    )
                    .eq(
                        "recipe_id",
                        value:
                            recipe.id.uuidString
                    )
                    .execute()
            } else {
                try await AppSupabase
                    .client
                    .from(
                        "user_recipe_favorites"
                    )
                    .insert(
                        RecipeFavorite(
                            userID:
                                currentUserID,
                            recipeID:
                                recipe.id
                        )
                    )
                    .execute()
            }

            await reloadCurrentPage()
        } catch {
            errorMessage =
                error.localizedDescription
        }
    }

    func removeFromFavorites(
        _ recipe: Recipe
    ) async {
        guard let currentUserID else {
            return
        }

        errorMessage = nil

        do {
            try await AppSupabase
                .client
                .from(
                    "user_recipe_favorites"
                )
                .delete()
                .eq(
                    "user_id",
                    value:
                        currentUserID.uuidString
                )
                .eq(
                    "recipe_id",
                    value:
                        recipe.id.uuidString
                )
                .execute()

            await loadPage(currentPage)
        } catch {
            errorMessage =
                error.localizedDescription
        }
    }

    func deleteOwnedRecipe(
        _ recipe: Recipe
    ) async -> Bool {
        guard isOwnedByCurrentUser(
            recipe
        ) else {
            return false
        }

        errorMessage = nil

        do {
            let deleted: Bool =
                try await AppSupabase
                    .client
                    .rpc(
                        "delete_owned_recipe",
                        params:
                            RecipeIDParameters(
                                recipeID:
                                    recipe.id
                            )
                    )
                    .execute()
                    .value

            if deleted {
                await loadPage(currentPage)
            }

            return deleted
        } catch {
            errorMessage =
                error.localizedDescription
            return false
        }
    }

    private func loadDefaultRecipeTabPreference()
        async {

        do {
            let session = try await AppSupabase
                .client
                .auth
                .session

            let preference:
                RecipeDefaultTabPreference =
                try await AppSupabase
                    .client
                    .from(
                        "account_preferences"
                    )
                    .select(
                        "default_recipe_tab"
                    )
                    .eq(
                        "user_id",
                        value:
                            session.user.id
                                .uuidString
                    )
                    .single()
                    .execute()
                    .value

            if let preferredTab =
                RecipeTab(
                    databaseValue:
                        preference
                            .defaultRecipeTab
                ) {
                selectedTab = preferredTab
            }
        } catch {
            guard !isCancellation(error) else {
                return
            }

            // A missing preference should not block Recipes.
            selectedTab = .discover
        }
    }

    private func isCancellation(
        _ error: Error
    ) -> Bool {
        if error is CancellationError {
            return true
        }

        let nsError = error as NSError

        return nsError.domain
            == NSURLErrorDomain
            && nsError.code
            == NSURLErrorCancelled
    }

    private func favoriteExists(
        recipeID: UUID,
        userID: UUID
    ) async throws -> Bool {
        let response =
            try await AppSupabase
                .client
                .from(
                    "user_recipe_favorites"
                )
                .select(
                    "recipe_id",
                    head: true,
                    count: .exact
                )
                .eq(
                    "user_id",
                    value:
                        userID.uuidString
                )
                .eq(
                    "recipe_id",
                    value:
                        recipeID.uuidString
                )
                .execute()

        return (response.count ?? 0) > 0
    }
}
