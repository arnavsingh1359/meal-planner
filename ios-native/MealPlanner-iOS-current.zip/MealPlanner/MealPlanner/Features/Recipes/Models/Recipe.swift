import Foundation

nonisolated struct Recipe: Codable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID
    let name: String
    let description: String?
    let mealTypes: [String]
    let defaultServings: Double?
    let preparationMinutes: Int?
    let cookingMinutes: Int?
    let isPublic: Bool
    let isFavorite: Bool
    let parentRecipeID: UUID?
    let creatorName: String
    let analysisStatus: String
    let complianceScore: Double
    let createdAt: Date?

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case name
        case description
        case mealTypes = "meal_types"
        case defaultServings = "default_servings"
        case preparationMinutes = "preparation_minutes"
        case cookingMinutes = "cooking_minutes"
        case isPublic = "is_public"
        case isFavorite = "is_favorite"
        case parentRecipeID = "parent_recipe_id"
        case creatorName = "creator_name"
        case analysisStatus =
            "analysis_status"
        case complianceScore =
            "compliance_score"
        case createdAt = "created_at"
    }

    var hasSmartPrepIssues: Bool {
        analysisStatus
            == "needs_review"
            || analysisStatus
            == "failed"
    }

    var mealTypeText: String {
        guard !mealTypes.isEmpty else {
            return "Uncategorized"
        }

        return mealTypes
            .map { $0.capitalized }
            .joined(separator: " • ")
    }
}

nonisolated struct RecipeFavorite: Codable, Hashable {
    let userID: UUID
    let recipeID: UUID

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case recipeID = "recipe_id"
    }
}

nonisolated struct RecipePageResponse: Decodable {
    let items: [Recipe]
    let totalCount: Int
    let page: Int
    let pageSize: Int

    enum CodingKeys: String, CodingKey {
        case items
        case totalCount = "total_count"
        case page
        case pageSize = "page_size"
    }
}

nonisolated struct RecipeLibraryCounts: Decodable {
    let discoverCount: Int
    let favoritesCount: Int
    let myRecipesCount: Int

    enum CodingKeys: String, CodingKey {
        case discoverCount = "discover_count"
        case favoritesCount = "favorites_count"
        case myRecipesCount = "my_recipes_count"
    }
}

nonisolated struct RecipePageParameters: Encodable {
    let tab: String
    let search: String?
    let mealType: String?
    let page: Int
    let pageSize: Int

    enum CodingKeys: String, CodingKey {
        case tab = "p_tab"
        case search = "p_search"
        case mealType = "p_meal_type"
        case page = "p_page"
        case pageSize = "p_page_size"
    }
}

nonisolated struct RecipeIDParameters: Encodable {
    let recipeID: UUID

    enum CodingKeys: String, CodingKey {
        case recipeID = "p_recipe_id"
    }
}
