import Foundation

nonisolated struct ForkRecipeParameters: Encodable {
    let sourceRecipeID: UUID

    enum CodingKeys: String, CodingKey {
        case sourceRecipeID = "p_source_recipe_id"
    }
}

nonisolated struct RecipeEditorDraft: Equatable {
    var name = ""
    var description = ""
    var mealTypes: Set<String> = []
    var defaultServings = "1"
    var minimumBatchServings = "1"
    var maximumBatchServings = "10"
    var preparationMinutes = "0"
    var cookingMinutes = "0"
    var cleanupMinutes = "0"
    var refrigeratorLifeDays = "3"
    var freezerAllowed = false
    var freezerLifeDays = "30"
    var isPublic = true
    var ingredients: [RecipeIngredientDraft] = [RecipeIngredientDraft()]
    var steps: [RecipeStepDraft] = [RecipeStepDraft()]
    var tasks: [RecipeTaskDraft] = []

    init() {}

    init(
        recipe: RecipeDetail,
        ingredients: [RecipeDetailIngredient],
        steps: [RecipeDetailStep],
        tasks: [RecipeDetailTask]
    ) {
        name = recipe.name
        description = recipe.description ?? ""
        mealTypes = Set(
            recipe.mealTypes.map {
                $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            }
        )
        defaultServings = Self.decimalText(recipe.defaultServings)
        minimumBatchServings = Self.decimalText(recipe.minimumBatchServings)
        maximumBatchServings = Self.decimalText(recipe.maximumBatchServings)
        preparationMinutes = Self.integerText(recipe.preparationMinutes)
        cookingMinutes = Self.integerText(recipe.cookingMinutes)
        cleanupMinutes = Self.integerText(recipe.cleanupMinutes)
        refrigeratorLifeDays = Self.integerText(recipe.refrigeratorLifeDays)
        freezerAllowed = recipe.freezerAllowed
        freezerLifeDays = Self.integerText(recipe.freezerLifeDays)
        isPublic = recipe.isPublic
        self.ingredients = ingredients.map(RecipeIngredientDraft.init)
        self.steps = steps.map(RecipeStepDraft.init)
        self.tasks = tasks.map(RecipeTaskDraft.init)
    }

    var normalized: RecipeEditorDraft {
        var result = self
        result.name = clean(name)
        result.description = clean(description)
        result.mealTypes = Set(mealTypes.map { clean($0).lowercased() })
        result.defaultServings = normalizeDecimal(defaultServings)
        result.minimumBatchServings = normalizeDecimal(minimumBatchServings)
        result.maximumBatchServings = normalizeDecimal(maximumBatchServings)
        result.preparationMinutes = normalizeInteger(preparationMinutes)
        result.cookingMinutes = normalizeInteger(cookingMinutes)
        result.cleanupMinutes = normalizeInteger(cleanupMinutes)
        result.refrigeratorLifeDays = normalizeInteger(refrigeratorLifeDays)
        result.freezerLifeDays = freezerAllowed ? normalizeInteger(freezerLifeDays) : ""
        result.ingredients = ingredients.map { $0.normalized }
        result.steps = steps.map { $0.normalized }
        result.tasks = tasks.map { $0.normalized }
        return result
    }

    private static func decimalText(_ value: Double?) -> String {
        guard let value else { return "" }
        return value.formatted(.number.precision(.fractionLength(0...2)))
    }

    private static func integerText(_ value: Int?) -> String {
        value.map(String.init) ?? ""
    }
}

nonisolated struct RecipeIngredientDraft: Identifiable, Equatable {
    var id = UUID()
    var name = ""
    var quantity = ""
    var unit = "g"
    var preparationNote = ""
    var isOptional = false

    init() {}

    init(_ ingredient: RecipeDetailIngredient) {
        id = ingredient.id
        name = ingredient.name
        quantity = ingredient.quantity.formatted(
            .number.precision(.fractionLength(0...2))
        )
        unit = ingredient.unit
        preparationNote = ingredient.preparationNote ?? ""
        isOptional = ingredient.isOptional
    }

    var normalized: RecipeIngredientDraft {
        var result = self
        result.name = clean(name)
        result.quantity = normalizeDecimal(quantity)
        result.unit = clean(unit)
        result.preparationNote = clean(preparationNote)
        return result
    }
}

nonisolated struct RecipeStepDraft: Identifiable, Equatable {
    var id = UUID()
    var instruction = ""
    var durationMinutes = ""
    var stepType = "active"

    init() {}

    init(_ step: RecipeDetailStep) {
        id = step.id
        instruction = step.instruction
        durationMinutes = String(step.durationMinutes)
        stepType = step.stepType
    }

    var normalized: RecipeStepDraft {
        var result = self
        result.instruction = clean(instruction)
        result.durationMinutes = normalizeInteger(durationMinutes)
        result.stepType = clean(stepType).lowercased()
        return result
    }
}

nonisolated struct RecipeTaskDraft: Identifiable, Equatable {
    var id = UUID()
    var title = ""
    var instructions = ""
    var taskType = "preparation"
    var activeMinutes = "0"
    var passiveMinutes = "0"
    var dayOffset = "0"
    var startBeforeMealMinutes = "60"
    var canBatch = false
    var batchKey = ""
    var unattended = false
    var blocksActiveWork = true
    var sourceStepPositions: [Int] = []
    var inferenceSource = "manual"
    var inferenceVersion = ""
    var confidence = 1.0
    var manuallyEdited = true
    var canMakeAhead = false
    var maximumMakeAheadHours = 0
    var storageMethod = "none"

    init() {}

    init(_ task: RecipeDetailTask) {
        id = task.id
        title = task.title
        instructions = task.instructions ?? ""
        taskType = task.taskType
        activeMinutes = String(task.activeMinutes)
        passiveMinutes = String(task.passiveMinutes)
        dayOffset = String(task.dayOffset)
        startBeforeMealMinutes = String(task.startBeforeMealMinutes)
        canBatch = task.canBatch
        batchKey = task.batchKey ?? ""
        unattended = task.unattended
        blocksActiveWork = task.blocksActiveWork
        sourceStepPositions = task.sourceStepPositions
        inferenceSource = task.inferenceSource
        inferenceVersion = task.inferenceVersion
        confidence = task.confidence
        manuallyEdited = task.manuallyEdited
        canMakeAhead = task.canMakeAhead
        maximumMakeAheadHours = task.maximumMakeAheadHours
        storageMethod = task.storageMethod
    }

    var normalized: RecipeTaskDraft {
        var result = self
        result.title = clean(title)
        result.instructions = clean(instructions)
        result.taskType = clean(taskType).lowercased()
        result.activeMinutes = normalizeInteger(activeMinutes)
        result.passiveMinutes = normalizeInteger(passiveMinutes)
        result.dayOffset = normalizeInteger(dayOffset)
        result.startBeforeMealMinutes = normalizeInteger(startBeforeMealMinutes)
        result.batchKey = canBatch ? clean(batchKey) : ""
        result.inferenceSource = clean(inferenceSource)
        result.inferenceVersion = clean(inferenceVersion)
        result.storageMethod = clean(storageMethod).lowercased()
        return result
    }
}

nonisolated struct SaveRecipeParameters: Encodable {
    let recipeID: UUID?
    let recipe: RecipeSaveMetadata
    let ingredients: [RecipeIngredientSaveItem]
    let steps: [RecipeStepSaveItem]
    let tasks: [RecipeTaskSaveItem]

    enum CodingKeys: String, CodingKey {
        case recipeID = "p_recipe_id"
        case recipe = "p_recipe"
        case ingredients = "p_ingredients"
        case steps = "p_steps"
        case tasks = "p_tasks"
    }
}

nonisolated struct RecipeSaveMetadata: Encodable {
    let name: String
    let description: String?
    let mealTypes: [String]
    let defaultServings: Double?
    let minimumBatchServings: Double?
    let maximumBatchServings: Double?
    let preparationMinutes: Int?
    let cookingMinutes: Int?
    let cleanupMinutes: Int?
    let refrigeratorLifeDays: Int?
    let freezerAllowed: Bool
    let freezerLifeDays: Int?
    let isPublic: Bool

    enum CodingKeys: String, CodingKey {
        case name
        case description
        case mealTypes = "meal_types"
        case defaultServings = "default_servings"
        case minimumBatchServings = "minimum_batch_servings"
        case maximumBatchServings = "maximum_batch_servings"
        case preparationMinutes = "preparation_minutes"
        case cookingMinutes = "cooking_minutes"
        case cleanupMinutes = "cleanup_minutes"
        case refrigeratorLifeDays = "refrigerator_life_days"
        case freezerAllowed = "freezer_allowed"
        case freezerLifeDays = "freezer_life_days"
        case isPublic = "is_public"
    }
}

nonisolated struct RecipeIngredientSaveItem: Encodable {
    let name: String
    let quantity: Double
    let unit: String
    let preparationNote: String?
    let isOptional: Bool
    let position: Int

    enum CodingKeys: String, CodingKey {
        case name
        case quantity
        case unit
        case preparationNote = "preparation_note"
        case isOptional = "is_optional"
        case position
    }
}

nonisolated struct RecipeStepSaveItem: Encodable {
    let instruction: String
    let durationMinutes: Int
    let stepType: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case instruction
        case durationMinutes = "duration_minutes"
        case stepType = "step_type"
        case position
    }
}

nonisolated struct RecipeTaskSaveItem: Encodable {
    let title: String
    let instructions: String?
    let taskType: String
    let activeMinutes: Int
    let passiveMinutes: Int
    let dayOffset: Int
    let startBeforeMealMinutes: Int
    let canBatch: Bool
    let batchKey: String?
    let unattended: Bool
    let blocksActiveWork: Bool
    let sourceStepPositions: [Int]
    let inferenceSource: String
    let inferenceVersion: String
    let confidence: Double
    let manuallyEdited: Bool
    let canMakeAhead: Bool
    let maximumMakeAheadHours: Int
    let storageMethod: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case title
        case instructions
        case taskType = "task_type"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case dayOffset = "day_offset"
        case startBeforeMealMinutes = "start_before_meal_minutes"
        case canBatch = "can_batch"
        case batchKey = "batch_key"
        case unattended
        case blocksActiveWork = "blocks_active_work"
        case sourceStepPositions = "source_step_positions"
        case inferenceSource = "inference_source"
        case inferenceVersion = "inference_version"
        case confidence
        case manuallyEdited = "manually_edited"
        case canMakeAhead = "can_make_ahead"
        case maximumMakeAheadHours = "maximum_make_ahead_hours"
        case storageMethod = "storage_method"
        case position
    }
}

nonisolated private func clean(_ value: String) -> String {
    value.trimmingCharacters(in: .whitespacesAndNewlines)
}

nonisolated private func normalizeDecimal(_ value: String) -> String {
    guard let number = Double(clean(value)) else { return "" }
    return number.formatted(.number.precision(.fractionLength(0...2)))
}

nonisolated private func normalizeInteger(_ value: String) -> String {
    guard let number = Int(clean(value)) else { return "" }
    return String(number)
}
