import Foundation

struct RecipeDetail: Codable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID
    let name: String
    let description: String?
    let mealTypes: [String]
    let defaultServings: Double?
    let minimumBatchServings: Double?
    let maximumBatchServings: Double?
    let preparationMinutes: Int?
    let cookingMinutes: Int?
    let cleanupMinutes: Int?
    let refrigeratorLifeDays: Int?
    let freezerAllowed: Bool
    let freezerLifeDays: Int?
    let isPublic: Bool
    let parentRecipeID: UUID?
    let creatorName: String
    let analysisStatus: String
    let complianceScore: Double
    let createdAt: Date?

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case name
        case description
        case mealTypes = "meal_types"
        case defaultServings = "default_servings"
        case minimumBatchServings = "minimum_batch_servings"
        case maximumBatchServings = "maximum_batch_servings"
        case preparationMinutes = "preparation_minutes"
        case cookingMinutes = "cooking_minutes"
        case cleanupMinutes = "cleanup_minutes"
        case refrigeratorLifeDays = "refrigerator_life_days"
        case freezerAllowed = "freezer_allowed"
        case freezerLifeDays = "freezer_life_days"
        case isPublic = "is_public"
        case parentRecipeID = "parent_recipe_id"
        case creatorName = "creator_name"
        case analysisStatus =
            "analysis_status"
        case complianceScore =
            "compliance_score"
        case createdAt = "created_at"
    }

    var hasSmartPrepIssues: Bool {
        analysisStatus
            == "needs_review"
            || analysisStatus
            == "failed"
    }

    var mealTypeText: String {
        guard !mealTypes.isEmpty else {
            return "Uncategorized"
        }

        return mealTypes
            .map { $0.capitalized }
            .joined(separator: " • ")
    }

    var totalMinutes: Int {
        let exactTotal =
            (preparationMinutes ?? 0)
            + (cookingMinutes ?? 0)
            + (cleanupMinutes ?? 0)

        guard exactTotal > 0 else {
            return 0
        }

        return max(
            5,
            Int(
                (
                    Double(exactTotal)
                    / 5.0
                ).rounded()
            ) * 5
        )
    }
}

struct RecipeDetailIngredient: Codable, Identifiable, Hashable {
    let id: UUID
    let ingredientID: UUID?
    let name: String
    let quantity: Double
    let unit: String
    let preparationNote: String?
    let isOptional: Bool
    let scalingBehavior: String
    let shoppingIncluded: Bool
    let preparationState: String?
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case ingredientID = "ingredient_id"
        case name
        case quantity
        case unit
        case preparationNote = "preparation_note"
        case isOptional = "is_optional"
        case scalingBehavior = "scaling_behavior"
        case shoppingIncluded = "shopping_included"
        case preparationState = "preparation_state"
        case position
    }

    func scaledQuantity(
        selectedServings: Double,
        baseServings: Double
    ) -> Double {
        guard baseServings > 0 else {
            return quantity
        }

        switch scalingBehavior {
        case "fixed", "to_taste":
            return quantity

        default:
            return quantity
                * selectedServings
                / baseServings
        }
    }

    func quantityText(
        selectedServings: Double,
        baseServings: Double
    ) -> String {
        if scalingBehavior == "to_taste" {
            return "To taste"
        }

        return scaledQuantity(
            selectedServings: selectedServings,
            baseServings: baseServings
        )
        .formatted(
            .number.precision(
                .fractionLength(0...2)
            )
        )
    }
}

struct RecipeDetailStep: Codable, Identifiable, Hashable {
    let id: UUID
    let instruction: String
    let durationMinutes: Int
    let stepType: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case instruction
        case durationMinutes = "duration_minutes"
        case stepType = "step_type"
        case position
    }
}

struct RecipeDetailTask: Codable, Identifiable, Hashable {
    let id: UUID
    let title: String
    let instructions: String?
    let taskType: String
    let activeMinutes: Int
    let passiveMinutes: Int
    let dayOffset: Int
    let startBeforeMealMinutes: Int
    let canBatch: Bool
    let batchKey: String?
    let unattended: Bool
    let blocksActiveWork: Bool
    let sourceStepPositions: [Int]
    let inferenceSource: String
    let inferenceVersion: String
    let confidence: Double
    let manuallyEdited: Bool
    let canMakeAhead: Bool
    let maximumMakeAheadHours: Int
    let storageMethod: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case title
        case instructions
        case taskType = "task_type"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case dayOffset = "day_offset"
        case startBeforeMealMinutes = "start_before_meal_minutes"
        case canBatch = "can_batch"
        case batchKey = "batch_key"
        case unattended
        case blocksActiveWork = "blocks_active_work"
        case sourceStepPositions = "source_step_positions"
        case inferenceSource = "inference_source"
        case inferenceVersion = "inference_version"
        case confidence
        case manuallyEdited = "manually_edited"
        case canMakeAhead = "can_make_ahead"
        case maximumMakeAheadHours = "maximum_make_ahead_hours"
        case storageMethod = "storage_method"
        case position
    }
}


nonisolated struct RecipeDetailComplianceIssue:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let code: String
    let severity: String
    let title: String
    let message: String
    let ingredientPosition: Int?
    let stepPosition: Int?

    enum CodingKeys: String, CodingKey {
        case id
        case code
        case severity
        case title
        case message
        case ingredientPosition =
            "ingredient_position"
        case stepPosition =
            "step_position"
    }

    var requiresReview: Bool {
        severity == "review"
            || severity == "blocking"
    }
}
