import SwiftUI

struct RecipeEditorView: View {
    let recipeID: UUID?
    let onSaved: () -> Void

    @Environment(\.dismiss)
    private var dismiss

    @State private var store = RecipeEditorStore()
    @State private var showDiscardConfirmation = false
    @State private var showComplianceSaveWarning = false
    @State private var expandedIngredientIDs: Set<UUID> = []
    @State private var expandedStepIDs: Set<UUID> = []
    @State private var expandedTaskIDs: Set<UUID> = []
    @State private var expandedUnitPickerIDs: Set<UUID> = []

    var body: some View {
        NavigationStack {
            Group {
                if store.isLoading && store.recipeID == nil {
                    ProgressView("Loading recipe…")
                } else if let errorMessage = store.errorMessage,
                          !store.hasLoaded {
                    ContentUnavailableView {
                        Label("Could not load recipe", systemImage: "exclamationmark.triangle")
                    } description: {
                        Text(errorMessage)
                    } actions: {
                        Button("Try again") {
                            Task { await store.load(recipeID: recipeID) }
                        }
                    }
                } else {
                    editorContent
                }
            }
            .navigationTitle(recipeID == nil ? "Add recipe" : "Edit recipe")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        attemptDismiss()
                    }
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        if store.complianceReport
                            .reviewIssueCount > 0 {
                            showComplianceSaveWarning =
                                true
                        } else {
                            Task {
                                await saveAndDismiss()
                            }
                        }
                    } label: {
                        if store.isSaving {
                            ProgressView()
                        } else {
                            Text("Save")
                        }
                    }
                    .disabled(!store.canSave)
                }
            }
            .interactiveDismissDisabled(store.hasUnsavedChanges)
            .confirmationDialog(
                "Discard unsaved changes?",
                isPresented: $showDiscardConfirmation,
                titleVisibility: .visible
            ) {
                Button("Discard changes", role: .destructive) {
                    dismiss()
                }
                Button("Keep editing", role: .cancel) {}
            }
            .alert(
                "Recipe needs smart-prep review",
                isPresented:
                    $showComplianceSaveWarning
            ) {
                Button(
                    "Keep editing",
                    role: .cancel
                ) {}

                Button("OK, save anyway") {
                    Task {
                        await saveAndDismiss()
                    }
                }
            } message: {
                Text(
                    "This recipe can be saved, but it cannot be used by smart scheduling until all ingredient and preparation warnings are resolved. The Recipes tab will mark it as needing review."
                )
            }
            .task {
                await store.load(recipeID: recipeID)
            }
        }
    }

    private var editorContent: some View {
        ScrollView {
            VStack(spacing: 14) {
                if let message = store.validationMessage ?? store.errorMessage {
                    errorCard(message)
                }

                recipeCard
                mealTypesCard
                servingsCard
                timingCard
                storageAndVisibilityCard
                ingredientsCard
                instructionsCard
                complianceCard
                scheduleCard
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
        }
        .background(Color(.systemGroupedBackground))
        .scrollDismissesKeyboard(.interactively)
    }

    private var recipeCard: some View {
        compactCard(title: "Recipe") {
            VStack(spacing: 12) {
                editorRow(title: "Name") {
                    TextField("Recipe name", text: $store.draft.name)
                        .multilineTextAlignment(.trailing)
                }

                Divider()

                VStack(alignment: .leading, spacing: 8) {
                    Text("Description")
                        .font(.subheadline.weight(.semibold))

                    TextField(
                        "Add a description",
                        text: $store.draft.description,
                        axis: .vertical
                    )
                    .lineLimit(2...5)
                    .padding(10)
                    .background(
                        Color(.tertiarySystemGroupedBackground),
                        in: RoundedRectangle(cornerRadius: 10, style: .continuous)
                    )
                }
            }
        }
    }

    private var mealTypesCard: some View {
        compactCard(title: "Meal types") {
            HStack(spacing: 8) {
                ForEach(store.availableMealTypes, id: \.self) { mealType in
                    let selected = store.draft.mealTypes.contains(mealType)

                    Button {
                        store.toggleMealType(mealType)
                    } label: {
                        Text(mealType.capitalized)
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(selected ? Color.white : Color.primary)
                            .padding(.horizontal, 11)
                            .frame(height: 34)
                            .background(
                                selected ? Color.green : Color(.tertiarySystemGroupedBackground),
                                in: Capsule()
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var servingsCard: some View {
        compactCard(title: "Servings") {
            HStack(spacing: 10) {
                valueField(
                    title: "Default",
                    text: $store.draft.defaultServings,
                    keyboard: .decimalPad
                )

                valueField(
                    title: "Min",
                    text: $store.draft.minimumBatchServings,
                    keyboard: .decimalPad
                )

                valueField(
                    title: "Max",
                    text: $store.draft.maximumBatchServings,
                    keyboard: .decimalPad
                )
            }
        }
    }

    private var timingCard: some View {
        compactCard(title: "Calculated time") {
            VStack(spacing: 12) {
                HStack(spacing: 10) {
                    calculatedTimeMetric(
                        title: "Prep",
                        minutes:
                            store
                                .calculatedPreparationMinutes
                    )

                    calculatedTimeMetric(
                        title: "Cook",
                        minutes:
                            store
                                .calculatedCookingMinutes
                    )

                    calculatedTimeMetric(
                        title: "Cleanup",
                        minutes:
                            store
                                .calculatedCleanupMinutes
                    )
                }

                Divider()

                LabeledContent(
                    "Total recipe time",
                    value:
                        "\(store.calculatedTotalMinutes) min"
                )
                .font(
                    .subheadline
                        .weight(.semibold)
                )

                Text(
                    "Calculated automatically from the instruction durations and rounded to the nearest 5 minutes."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
    }

    private func calculatedTimeMetric(
        title: String,
        minutes: Int
    ) -> some View {
        VStack(spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)

            Text("\(minutes) min")
                .font(
                    .subheadline
                        .weight(.semibold)
                )
                .monospacedDigit()
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(
            Color(
                .tertiarySystemGroupedBackground
            ),
            in: RoundedRectangle(
                cornerRadius: 10,
                style: .continuous
            )
        )
    }

    private var storageAndVisibilityCard: some View {
        compactCard(title: "Storage & visibility") {
            VStack(spacing: 12) {
                editorRow(title: "Refrigerator") {
                    highlightedInlineValue(
                        text: $store.draft.refrigeratorLifeDays,
                        suffix: "days"
                    )
                }

                Divider()

                Toggle("Freezer friendly", isOn: $store.draft.freezerAllowed)

                if store.draft.freezerAllowed {
                    Divider()

                    editorRow(title: "Freezer") {
                        highlightedInlineValue(
                            text: $store.draft.freezerLifeDays,
                            suffix: "days"
                        )
                    }
                }

                Divider()

                Toggle("Public recipe", isOn: $store.draft.isPublic)

                Text(
                    store.draft.isPublic
                        ? "Visible to other signed-in users."
                        : "Visible only to you."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var ingredientsCard: some View {
        compactCard(title: "Ingredients") {
            VStack(spacing: 10) {
                if store.draft.ingredients.isEmpty {
                    emptyEditorMessage("No ingredients yet.")
                }

                ForEach($store.draft.ingredients) { $ingredient in
                    let ingredientID =
                        ingredient.id

                    let ingredientPosition =
                        store.draft.ingredients
                            .firstIndex {
                                $0.id
                                    == ingredientID
                            }
                        ?? 0

                    DisclosureGroup(
                        isExpanded:
                            ingredientExpansionBinding(
                                for:
                                    ingredient.id
                            )
                    ) {
                        VStack(spacing: 10) {
                            TextField("Ingredient name", text: $ingredient.name)
                                .textFieldStyle(.roundedBorder)

                            labeledField(
                                "Quantity",
                                text: $ingredient.quantity,
                                keyboard: .decimalPad
                            )

                            VStack(alignment: .leading, spacing: 7) {
                                HStack {
                                    Text("Unit")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)

                                    Spacer()

                                    Text(
                                        unitDisplayName(
                                            ingredient.unit
                                        )
                                    )
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(.green)
                                }

                                unitPicker(
                                    ingredientID: ingredient.id,
                                    selection: $ingredient.unit
                                )
                            }

                            TextField(
                                "Preparation note",
                                text: $ingredient.preparationNote,
                                axis: .vertical
                            )
                            .lineLimit(1...3)
                            .textFieldStyle(.roundedBorder)

                            ingredientComplianceMessage(
                                position:
                                    ingredientPosition
                            )

                            Toggle(
                                "Optional",
                                isOn:
                                    $ingredient.isOptional
                            )

                            itemActions(
                                id: ingredient.id,
                                canMoveUp: ingredient.id != store.draft.ingredients.first?.id,
                                canMoveDown: ingredient.id != store.draft.ingredients.last?.id,
                                moveUp: { store.moveIngredient(id: ingredient.id, by: -1) },
                                moveDown: { store.moveIngredient(id: ingredient.id, by: 1) },
                                delete: {
                                    expandedIngredientIDs.remove(
                                        ingredient.id
                                    )
                                    expandedUnitPickerIDs.remove(
                                        ingredient.id
                                    )
                                    Task {
                                        await Task.yield()
                                        store.deleteIngredient(
                                            id:
                                                ingredient.id
                                        )
                                    }
                                }
                            )
                        }
                        .padding(.top, 10)
                    } label: {
                        HStack(spacing: 8) {
                            complianceStatusIcon(
                                forIngredientAt:
                                    ingredientPosition
                            )

                            Text(
                                ingredient.name
                                    .isEmpty
                                ? "New ingredient"
                                : ingredient.name
                            )
                            .font(
                                .subheadline
                                    .weight(.semibold)
                            )

                            Spacer()

                            if !ingredient.quantity
                                .isEmpty {
                                Text(
                                    "\(ingredient.quantity) \(ingredient.unit)"
                                )
                                .font(.caption)
                                .foregroundStyle(
                                    .secondary
                                )
                            }
                        }
                    }
                    .padding(12)
                    .background(
                        Color(.tertiarySystemGroupedBackground),
                        in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                    )
                }

                addButton(
                    "Add ingredient",
                    systemImage: "plus"
                ) {
                    expandedIngredientIDs
                        .removeAll()

                    expandedUnitPickerIDs
                        .removeAll()

                    store.addIngredient()

                    if let id =
                        store.draft
                            .ingredients
                            .last?
                            .id {
                        expandedIngredientIDs = [
                            id
                        ]
                    }
                }
            }
        }
    }

    private var instructionsCard: some View {
        compactCard(title: "Instructions") {
            VStack(spacing: 10) {
                if store.draft.steps.isEmpty {
                    emptyEditorMessage("No instructions yet.")
                }

                ForEach($store.draft.steps) { $step in
                    let stepID = step.id
                    let index = store.draft.steps.firstIndex {
                        $0.id == stepID
                    } ?? 0

                    DisclosureGroup(
                        isExpanded: expansionBinding(
                            for: stepID,
                            in: $expandedStepIDs
                        )
                    ) {
                        VStack(spacing: 10) {
                            TextField(
                                "Instruction",
                                text: $step.instruction,
                                axis: .vertical
                            )
                            .lineLimit(2...6)
                            .textFieldStyle(.roundedBorder)

                            stepComplianceMessage(
                                position: index
                            )

                            HStack(spacing: 10) {
                                labeledField(
                                    "Duration (min)",
                                    text: $step.durationMinutes,
                                    keyboard: .numberPad
                                )

                                VStack(alignment: .leading, spacing: 5) {
                                    Text("Type")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)

                                    Picker(
                                        "Type",
                                        selection: $step.stepType
                                    ) {
                                        ForEach(
                                            store.availableStepTypes,
                                            id: \.self
                                        ) { type in
                                            Text(type.capitalized)
                                                .tag(type)
                                        }
                                    }
                                    .pickerStyle(.segmented)
                                }
                            }

                            itemActions(
                                id: stepID,
                                canMoveUp: index > 0,
                                canMoveDown:
                                    index
                                    < store.draft.steps.count - 1,
                                moveUp: {
                                    store.moveStep(
                                        id: stepID,
                                        by: -1
                                    )
                                },
                                moveDown: {
                                    store.moveStep(
                                        id: stepID,
                                        by: 1
                                    )
                                },
                                delete: {
                                    expandedStepIDs.remove(stepID)
                                    store.deleteStep(id: stepID)
                                }
                            )
                        }
                        .padding(.top, 10)
                    } label: {
                        HStack(spacing: 8) {
                            complianceStatusIcon(
                                forStepAt: index
                            )

                            Text(
                                "\(index + 1). "
                                + (
                                    step.instruction.isEmpty
                                    ? "New instruction"
                                    : step.instruction
                                )
                            )
                            .font(
                                .subheadline
                                    .weight(.semibold)
                            )
                            .lineLimit(1)

                            Spacer()

                            Text(
                                step.stepType
                                    .capitalized
                            )
                            .font(.caption)
                            .foregroundStyle(
                                .secondary
                            )
                        }
                    }
                    .padding(12)
                    .background(
                        Color(.tertiarySystemGroupedBackground),
                        in: RoundedRectangle(
                            cornerRadius: 12,
                            style: .continuous
                        )
                    )
                }

                addButton("Add instruction", systemImage: "plus") {
                    store.addStep()

                    if let id = store.draft.steps.last?.id {
                        expandedStepIDs.insert(id)
                    }
                }
            }
        }
    }

    private var complianceCard:
        some View {
        let report =
            store.complianceReport

        return compactCard(
            title: "Smart-prep readiness"
        ) {
            HStack(spacing: 10) {
                Image(
                    systemName:
                        complianceIcon(
                            status:
                                report.status
                        )
                )
                .foregroundStyle(
                    complianceColor(
                        status:
                            report.status
                    )
                )

                VStack(
                    alignment: .leading,
                    spacing: 2
                ) {
                    Text(
                        complianceTitle(
                            status:
                                report.status
                        )
                    )
                    .font(
                        .subheadline
                            .weight(.semibold)
                    )

                    Text(
                        "\(report.operations.count) reusable prep operations • \(report.reviewIssueCount) items need review"
                    )
                    .font(.caption)
                    .foregroundStyle(
                        .secondary
                    )
                }

                Spacer()

                Text(
                    report.score.formatted(
                        .percent.precision(
                            .fractionLength(0)
                        )
                    )
                )
                .font(
                    .caption
                        .weight(.semibold)
                )
                .foregroundStyle(
                    .secondary
                )
            }
        }
    }


    @ViewBuilder
    private func complianceStatusIcon(
        forIngredientAt position: Int
    ) -> some View {
        let report =
            store.complianceReport

        if report.issues.contains(
            where: {
                $0.ingredientPosition
                    == position
                && $0.severity
                    != .advisory
            }
        ) {
            Image(
                systemName:
                    "exclamationmark.triangle.fill"
            )
            .foregroundStyle(.orange)
            .accessibilityLabel(
                "Needs review"
            )
        } else if report.operations.contains(
            where: {
                $0.ingredientPosition
                    == position
            }
        ) {
            Image(
                systemName:
                    "checkmark.circle.fill"
            )
            .foregroundStyle(.green)
            .accessibilityLabel(
                "Compliant"
            )
        } else {
            Image(
                systemName:
                    "circle.dashed"
            )
            .foregroundStyle(
                .secondary
            )
            .accessibilityLabel(
                "No preparation operation"
            )
        }
    }

    @ViewBuilder
    private func complianceStatusIcon(
        forStepAt position: Int
    ) -> some View {
        let report =
            store.complianceReport

        let analysis =
            report.instructionAnalyses
                .first {
                    $0.position
                        == position
                }

        if analysis?.role
            == .preparation {
            if analysis?.needsReview
                == true {
                Image(
                    systemName:
                        "exclamationmark.triangle.fill"
                )
                .foregroundStyle(.orange)
                .accessibilityLabel(
                    "Preparation needs review"
                )
            } else if (
                analysis?
                    .linkedOperationCount
                ?? 0
            ) > 0 {
                Image(
                    systemName:
                        "checkmark.circle.fill"
                )
                .foregroundStyle(.green)
                .accessibilityLabel(
                    "Structured preparation recognized"
                )
            } else {
                Image(
                    systemName:
                        "exclamationmark.triangle.fill"
                )
                .foregroundStyle(.orange)
                .accessibilityLabel(
                    "Preparation needs review"
                )
            }
        }
    }

    @ViewBuilder
    private func ingredientComplianceMessage(
        position: Int
    ) -> some View {
        let report =
            store.complianceReport

        if let issue =
            report.issues.first(
                where: {
                    $0.ingredientPosition
                        == position
                    && $0.severity
                        != .advisory
                }
            ) {
            Label(
                issue.message,
                systemImage:
                    "exclamationmark.triangle.fill"
            )
            .font(.caption)
            .foregroundStyle(.orange)
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
        } else if let operation =
            report.operations.first(
                where: {
                    $0.ingredientPosition
                        == position
                }
            ) {
            Label(
                "\(operation.action.capitalized) \(operation.canonicalIngredientName)",
                systemImage:
                    "checkmark.circle.fill"
            )
            .font(.caption)
            .foregroundStyle(.green)
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
        }
    }

    @ViewBuilder
    private func stepComplianceMessage(
        position: Int
    ) -> some View {
        let report =
            store.complianceReport

        if let issue =
            report.issues.first(
                where: {
                    $0.stepPosition
                        == position
                    && $0.severity
                        != .advisory
                }
            ) {
            VStack(
                alignment: .leading,
                spacing: 4
            ) {
                Label(
                    issue.title,
                    systemImage:
                        "exclamationmark.triangle.fill"
                )
                .font(
                    .caption
                        .weight(.semibold)
                )
                .foregroundStyle(.orange)

                Text(issue.message)
                    .font(.caption)
                    .foregroundStyle(
                        .secondary
                    )
            }
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
            .padding(10)
            .background(
                Color.orange.opacity(0.08),
                in: RoundedRectangle(
                    cornerRadius: 10,
                    style: .continuous
                )
            )
        } else if let analysis =
            report.instructionAnalyses
                .first(
                    where: {
                        $0.position
                            == position
                    }
                ),
                  analysis.role
                    == .preparation,
                  analysis.linkedOperationCount
                    > 0 {
            Label(
                "\(analysis.linkedOperationCount) reusable preparation operation\(analysis.linkedOperationCount == 1 ? "" : "s") recognized.",
                systemImage:
                    "checkmark.circle.fill"
            )
            .font(.caption)
            .foregroundStyle(.green)
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
        }
    }

    private func saveAndDismiss() async {
        if await store.save() {
            onSaved()
            dismiss()
        }
    }

    private func complianceTitle(
        status: String
    ) -> String {
        switch status {
        case "compliant":
            return "Reusable prep is ready"
        case "needs_review":
            return "Prep details need review"
        default:
            return "Prep analysis is incomplete"
        }
    }

    private func complianceIcon(
        status: String
    ) -> String {
        switch status {
        case "compliant":
            return "checkmark.seal.fill"
        case "needs_review":
            return "exclamationmark.triangle.fill"
        default:
            return "xmark.octagon.fill"
        }
    }

    private func complianceColor(
        status: String
    ) -> Color {
        switch status {
        case "compliant":
            return .green
        case "needs_review":
            return .orange
        default:
            return .red
        }
    }

    private var scheduleCard: some View {
        compactCard(title: "Preparation schedule") {
            VStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(
                        "Scheduling tasks are inferred from the recipe instructions. Review and edit the generated result only when needed."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                    Button {
                        store.generateTasksFromSteps()
                        expandedTaskIDs = Set(
                            store.draft.tasks.map(\.id)
                        )
                    } label: {
                        Label(
                            store.draft.tasks.isEmpty
                            ? "Generate tasks from instructions"
                            : "Regenerate tasks from instructions",
                            systemImage: "wand.and.stars"
                        )
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                }

                if store.draft.tasks.isEmpty {
                    emptyEditorMessage(
                        "Tasks will be generated automatically when the recipe is saved."
                    )
                }

                ForEach($store.draft.tasks) { $task in
                    let taskID = task.id
                    let index = store.draft.tasks.firstIndex {
                        $0.id == taskID
                    } ?? 0

                    DisclosureGroup(
                        isExpanded: expansionBinding(
                            for: taskID,
                            in: $expandedTaskIDs
                        )
                    ) {
                        VStack(spacing: 10) {
                            TextField(
                                "Task title",
                                text: $task.title
                            )
                            .textFieldStyle(.roundedBorder)

                            TextField(
                                "Task instructions",
                                text: $task.instructions,
                                axis: .vertical
                            )
                            .lineLimit(1...4)
                            .textFieldStyle(.roundedBorder)

                            Picker(
                                "Task type",
                                selection: $task.taskType
                            ) {
                                ForEach(
                                    store.availableTaskTypes,
                                    id: \.self
                                ) { type in
                                    Text(type.capitalized)
                                        .tag(type)
                                }
                            }
                            .pickerStyle(.menu)

                            HStack(spacing: 10) {
                                labeledField(
                                    "Active min",
                                    text: $task.activeMinutes,
                                    keyboard: .numberPad
                                )

                                labeledField(
                                    "Passive min",
                                    text: $task.passiveMinutes,
                                    keyboard: .numberPad
                                )
                            }

                            HStack(spacing: 10) {
                                labeledField(
                                    "Day offset",
                                    text: $task.dayOffset,
                                    keyboard:
                                        .numbersAndPunctuation
                                )

                                labeledField(
                                    "Before meal min",
                                    text:
                                        $task
                                            .startBeforeMealMinutes,
                                    keyboard: .numberPad
                                )
                            }

                            Toggle(
                                "Can batch",
                                isOn: $task.canBatch
                            )

                            if task.canBatch {
                                TextField(
                                    "Batch key",
                                    text: $task.batchKey
                                )
                                .textFieldStyle(.roundedBorder)
                            }

                            Toggle(
                                "Unattended",
                                isOn: $task.unattended
                            )

                            Toggle(
                                "Blocks active work",
                                isOn:
                                    $task.blocksActiveWork
                            )

                            itemActions(
                                id: taskID,
                                canMoveUp: index > 0,
                                canMoveDown:
                                    index
                                    < store.draft.tasks.count - 1,
                                moveUp: {
                                    store.moveTask(
                                        id: taskID,
                                        by: -1
                                    )
                                },
                                moveDown: {
                                    store.moveTask(
                                        id: taskID,
                                        by: 1
                                    )
                                },
                                delete: {
                                    expandedTaskIDs.remove(taskID)
                                    store.deleteTask(id: taskID)
                                }
                            )
                        }
                        .padding(.top, 10)
                    } label: {
                        HStack {
                            Text(
                                task.title.isEmpty
                                ? "New task"
                                : task.title
                            )
                            .font(.subheadline.weight(.semibold))

                            Spacer()

                            Text(task.taskType.capitalized)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(12)
                    .background(
                        Color(.tertiarySystemGroupedBackground),
                        in: RoundedRectangle(
                            cornerRadius: 12,
                            style: .continuous
                        )
                    )
                }

                addButton("Add schedule task", systemImage: "plus") {
                    store.addTask()

                    if let id = store.draft.tasks.last?.id {
                        expandedTaskIDs.insert(id)
                    }
                }
            }
        }
    }


    private func ingredientExpansionBinding(
        for id: UUID
    ) -> Binding<Bool> {
        Binding(
            get: {
                expandedIngredientIDs
                    .contains(id)
            },
            set: { isExpanded in
                if isExpanded {
                    expandedIngredientIDs = [
                        id
                    ]

                    expandedUnitPickerIDs =
                        expandedUnitPickerIDs
                            .intersection([id])
                } else {
                    expandedIngredientIDs
                        .remove(id)

                    expandedUnitPickerIDs
                        .remove(id)
                }
            }
        )
    }

    private func expansionBinding(
        for id: UUID,
        in set: Binding<Set<UUID>>
    ) -> Binding<Bool> {
        Binding(
            get: {
                set.wrappedValue.contains(id)
            },
            set: { isExpanded in
                if isExpanded {
                    set.wrappedValue.insert(id)
                } else {
                    set.wrappedValue.remove(id)
                }
            }
        )
    }


    private func unitPicker(
        ingredientID: UUID,
        selection: Binding<String>
    ) -> some View {
        let isExpanded = expandedUnitPickerIDs.contains(
            ingredientID
        )

        return VStack(spacing: 0) {
            Button {
                dismissKeyboard()

                _ = withAnimation(.easeInOut(duration: 0.18)) {
                    if isExpanded {
                        expandedUnitPickerIDs.remove(
                            ingredientID
                        )
                    } else {
                        expandedUnitPickerIDs.insert(
                            ingredientID
                        )
                    }
                }
            } label: {
                HStack(spacing: 10) {
                    VStack(
                        alignment: .leading,
                        spacing: 2
                    ) {
                        Text("Selected unit")
                            .font(.caption2)
                            .foregroundStyle(.secondary)

                        Text(
                            unitDisplayName(
                                selection.wrappedValue
                            )
                        )
                        .font(
                            .subheadline
                                .weight(.semibold)
                        )
                        .foregroundStyle(.primary)
                    }

                    Spacer()

                    Image(
                        systemName:
                            isExpanded
                            ? "chevron.up"
                            : "chevron.down"
                    )
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.green)
                }
                .padding(.horizontal, 12)
                .frame(height: 48)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if isExpanded {
                Divider()

                VStack(spacing: 0) {
                    ForEach(
                        unitOptions(
                            including:
                                selection.wrappedValue
                        ),
                        id: \.self
                    ) { unit in
                        Button {
                            selection.wrappedValue = unit

                            _ = withAnimation(
                                .easeInOut(duration: 0.18)
                            ) {
                                expandedUnitPickerIDs.remove(
                                    ingredientID
                                )
                            }
                        } label: {
                            HStack(spacing: 10) {
                                Text(
                                    unitDisplayName(unit)
                                )
                                .font(.subheadline)
                                .foregroundStyle(.primary)

                                Spacer()

                                if selection.wrappedValue
                                    == unit {
                                    Image(
                                        systemName:
                                            "checkmark.circle.fill"
                                    )
                                    .foregroundStyle(.green)
                                }
                            }
                            .padding(.horizontal, 12)
                            .frame(minHeight: 44)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)

                        if unit
                            != unitOptions(
                                including:
                                    selection.wrappedValue
                            ).last {
                            Divider()
                                .padding(.leading, 12)
                        }
                    }
                }
                .transition(
                    .opacity.combined(
                        with: .move(edge: .top)
                    )
                )
            }
        }
        .background(
            Color.green.opacity(0.10),
            in: RoundedRectangle(
                cornerRadius: 12,
                style: .continuous
            )
        )
        .overlay {
            RoundedRectangle(
                cornerRadius: 12,
                style: .continuous
            )
            .stroke(
                Color.green.opacity(0.30),
                lineWidth: 1
            )
        }
        .clipShape(
            RoundedRectangle(
                cornerRadius: 12,
                style: .continuous
            )
        )
    }

    private func unitOptions(
        including currentUnit: String
    ) -> [String] {
        let cleaned = currentUnit.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        if cleaned.isEmpty
            || store.availableIngredientUnits
                .contains(cleaned) {
            return store.availableIngredientUnits
        }

        return [cleaned]
            + store.availableIngredientUnits
    }

    private func unitDisplayName(
        _ unit: String
    ) -> String {
        switch unit {
        case "g":
            return "g — grams"
        case "kg":
            return "kg — kilograms"
        case "ml":
            return "ml — millilitres"
        case "L":
            return "L — litres"
        case "tsp":
            return "tsp — teaspoon"
        case "tbsp":
            return "tbsp — tablespoon"
        case "cup":
            return "cup"
        case "fl oz":
            return "fl oz — fluid ounce"
        case "oz":
            return "oz — ounce"
        case "lb":
            return "lb — pound"
        case "pinch":
            return "pinch"
        case "piece":
            return "piece"
        case "clove":
            return "clove"
        case "can":
            return "can"
        case "package":
            return "package"
        case "unit":
            return "unit"
        default:
            return unit
        }
    }

    private func compactCard<Content: View>(
        title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.headline)

            content()
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            Color(.secondarySystemGroupedBackground),
            in: RoundedRectangle(cornerRadius: 16, style: .continuous)
        )
    }

    private func editorRow<Content: View>(
        title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        HStack(spacing: 12) {
            Text(title)
                .font(.subheadline.weight(.semibold))

            Spacer()
            content()
        }
    }

    private func valueField(
        title: String,
        text: Binding<String>,
        suffix: String? = nil,
        keyboard: UIKeyboardType
    ) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)

            HStack(spacing: 4) {
                TextField("—", text: text)
                    .keyboardType(keyboard)
                    .multilineTextAlignment(.center)
                    .font(.headline)

                if let suffix {
                    Text(suffix)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 8)
            .frame(height: 40)
            .background(
                Color.green.opacity(0.12),
                in: RoundedRectangle(cornerRadius: 10, style: .continuous)
            )
            .overlay {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .stroke(Color.green.opacity(0.35), lineWidth: 1)
            }
        }
        .frame(maxWidth: .infinity)
    }

    private func highlightedInlineValue(
        text: Binding<String>,
        suffix: String
    ) -> some View {
        HStack(spacing: 6) {
            TextField("—", text: text)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.trailing)
                .font(.body.weight(.semibold))
                .frame(width: 48)

            Text(suffix)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 10)
        .frame(height: 36)
        .background(Color.green.opacity(0.12), in: Capsule())
        .overlay {
            Capsule().stroke(Color.green.opacity(0.35), lineWidth: 1)
        }
    }

    private func labeledField(
        _ title: String,
        text: Binding<String>,
        keyboard: UIKeyboardType
    ) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)

            TextField(title, text: text)
                .keyboardType(keyboard)
                .textFieldStyle(.roundedBorder)
        }
        .frame(maxWidth: .infinity)
    }

    private func itemActions(
        id: UUID,
        canMoveUp: Bool,
        canMoveDown: Bool,
        moveUp: @escaping () -> Void,
        moveDown: @escaping () -> Void,
        delete: @escaping () -> Void
    ) -> some View {
        HStack {
            Button(action: moveUp) {
                Label("Up", systemImage: "arrow.up")
            }
            .disabled(!canMoveUp)

            Button(action: moveDown) {
                Label("Down", systemImage: "arrow.down")
            }
            .disabled(!canMoveDown)

            Spacer()

            Button(role: .destructive, action: delete) {
                Label("Delete", systemImage: "trash")
            }
        }
        .font(.caption)
    }

    private func addButton(
        _ title: String,
        systemImage: String,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Label(title, systemImage: systemImage)
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(Color.green.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
        .foregroundStyle(.green)
    }

    private func emptyEditorMessage(_ text: String) -> some View {
        Text(text)
            .font(.subheadline)
            .foregroundStyle(.secondary)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func errorCard(_ message: String) -> some View {
        Label(message, systemImage: "exclamationmark.triangle.fill")
            .font(.footnote)
            .foregroundStyle(.red)
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                Color.red.opacity(0.08),
                in: RoundedRectangle(cornerRadius: 12, style: .continuous)
            )
    }

    private func dismissKeyboard() {
        UIApplication.shared.sendAction(
            #selector(UIResponder.resignFirstResponder),
            to: nil,
            from: nil,
            for: nil
        )
    }

    private func attemptDismiss() {
        if store.hasUnsavedChanges {
            showDiscardConfirmation = true
        } else {
            dismiss()
        }
    }
}
