import SwiftUI

struct RecipeDetailView: View {
    let recipeID: UUID

    @Environment(\.dismiss)
    private var dismiss

    @State private var store = RecipeDetailStore()
    @State private var editorRoute: RecipeEditorRoute?
    @State private var detailRoute: RecipeDetailRoute?
    @State private var showDeleteConfirmation = false
    @State private var selectedServings = 1.0

    var body: some View {
        Group {
            if store.isLoading && store.recipe == nil {
                ProgressView("Loading recipe…")
            } else if let errorMessage = store.errorMessage,
                      store.recipe == nil {
                errorView(message: errorMessage)
            } else if let recipe = store.recipe {
                recipeContent(recipe)
            } else {
                ContentUnavailableView(
                    "Recipe unavailable",
                    systemImage: "fork.knife.circle",
                    description: Text("This recipe could not be found.")
                )
            }
        }
        .navigationTitle(store.recipe?.name ?? "Recipe")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                favoriteButton
                actionsMenu
            }
        }
        .sheet(item: $editorRoute) { route in
            RecipeEditorView(recipeID: route.recipeID) {
                Task {
                    await store.load(recipeID: recipeID)
                }
            }
        }
        .navigationDestination(item: $detailRoute) { route in
            RecipeDetailView(recipeID: route.recipeID)
        }
        .alert(
            "Delete recipe?",
            isPresented: $showDeleteConfirmation
        ) {
            Button("Cancel", role: .cancel) {}

            Button("Delete", role: .destructive) {
                Task {
                    if await store.deleteOwnedRecipe() {
                        dismiss()
                    }
                }
            }
        } message: {
            Text("This permanently deletes the recipe, its ingredients, instructions, and preparation tasks.")
        }
        .alert(
            "Could not complete action",
            isPresented: Binding(
                get: { store.operationErrorMessage != nil },
                set: { if !$0 { store.clearOperationError() } }
            )
        ) {
            Button("OK", role: .cancel) {
                store.clearOperationError()
            }
        } message: {
            Text(store.operationErrorMessage ?? "Unknown error")
        }
        .task {
            await store.load(recipeID: recipeID)

            if let baseServings = store.recipe?.defaultServings,
               baseServings > 0 {
                selectedServings = baseServings
            }
        }
        .onChange(of: store.recipe?.id) {
            guard let baseServings = store.recipe?.defaultServings,
                  baseServings > 0 else {
                return
            }

            selectedServings = baseServings
        }
    }

    private var favoriteButton: some View {
        Button {
            Task {
                await store.toggleFavorite()
            }
        } label: {
            if store.isUpdatingFavorite {
                ProgressView()
            } else {
                Image(systemName: store.isFavorite ? "heart.fill" : "heart")
                    .foregroundStyle(store.isFavorite ? Color.red : Color.primary)
            }
        }
        .disabled(
            store.isOwnedByCurrentUser
                || store.isUpdatingFavorite
                || store.recipe == nil
        )
        .accessibilityLabel(
            store.isOwnedByCurrentUser
                ? "Your recipes are always favorites"
                : store.isFavorite
                    ? "Remove from favorites"
                    : "Add to favorites"
        )
    }

    @ViewBuilder
    private var actionsMenu: some View {
        if let recipe = store.recipe {
            Menu {
                if store.isOwnedByCurrentUser {
                    Button {
                        editorRoute = RecipeEditorRoute(recipeID: recipe.id)
                    } label: {
                        Label("Edit recipe", systemImage: "pencil")
                    }

                    Button(role: .destructive) {
                        showDeleteConfirmation = true
                    } label: {
                        Label("Delete recipe", systemImage: "trash")
                    }
                } else {
                    Button {
                        Task {
                            await store.toggleFavorite()
                        }
                    } label: {
                        Label(
                            store.isFavorite ? "Remove from favorites" : "Add to favorites",
                            systemImage: store.isFavorite ? "heart.slash" : "heart"
                        )
                    }

                    if recipe.isPublic {
                        Button {
                            Task {
                                guard let newRecipeID = await store.customize() else {
                                    return
                                }
                                detailRoute = RecipeDetailRoute(recipeID: newRecipeID)
                            }
                        } label: {
                            Label("Customize", systemImage: "doc.on.doc")
                        }
                        .disabled(store.isCustomizing)
                    }
                }
            } label: {
                if store.isCustomizing || store.isDeleting {
                    ProgressView()
                } else {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
    }

    private func recipeContent(_ recipe: RecipeDetail) -> some View {
        List {
            summarySection(recipe)

            if recipe.hasSmartPrepIssues {
                prepReviewSection(recipe)
            }

            ingredientsSection
            stepsSection

            if !store.tasks.isEmpty {
                tasksSection
            }

            storageSection(recipe)
        }
        .listStyle(.insetGrouped)
        .refreshable {
            await store.load(recipeID: recipeID)
        }
    }

    private func summarySection(_ recipe: RecipeDetail) -> some View {
        Section {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 7) {
                        HStack(spacing: 7) {
                            Text(recipe.name)
                                .font(.title2.bold())

                            if store.isFavorite {
                                Image(systemName: "heart.fill")
                                    .font(.caption)
                                    .foregroundStyle(.red)
                            }
                        }

                        badgeRow(recipe)

                        Text(recipe.mealTypeText)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()
                }

                Text("Created by \(recipe.creatorName)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                if let description = recipe.description,
                   !description.isEmpty {
                    Text(description)
                        .font(.body)
                }

                Divider()
                servingSelector(recipe)
                Divider()
                timingGrid(recipe)
            }
            .padding(.vertical, 5)
        }
    }

    private func badgeRow(_ recipe: RecipeDetail) -> some View {
        HStack(spacing: 6) {
            if store.isOwnedByCurrentUser {
                badge("Your recipe", color: .green)
            }

            if recipe.parentRecipeID != nil {
                badge(
                    "Customized",
                    color: .orange
                )
            }

            if recipe.hasSmartPrepIssues {
                badge(
                    "Prep review",
                    color: .orange
                )
            }

            complianceBadge(
                score:
                    recipe.complianceScore,
                status:
                    recipe.analysisStatus
            )

            badge(
                recipe.isPublic
                ? "Public"
                : "Private",
                color:
                    recipe.isPublic
                    ? .blue
                    : .secondary
            )
        }
    }

    private func complianceBadge(
        score: Double,
        status: String
    ) -> some View {
        let percentage =
            Int(
                (
                    max(
                        0,
                        min(1, score)
                    ) * 100
                ).rounded()
            )

        let color: Color

        switch status {
        case "compliant":
            color = .green

        case "needs_review",
             "analyzing",
             "pending":
            color = .orange

        case "failed":
            color = .red

        default:
            color = .secondary
        }

        return Label(
            "Prep \(percentage)%",
            systemImage:
                status == "compliant"
                ? "checkmark.seal.fill"
                : "exclamationmark.triangle.fill"
        )
        .font(
            .caption2
                .weight(.semibold)
        )
        .foregroundStyle(color)
        .padding(
            .horizontal,
            7
        )
        .padding(
            .vertical,
            3
        )
        .background(
            color.opacity(0.12),
            in: Capsule()
        )
        .accessibilityLabel(
            "Smart prep compliance \(percentage) percent"
        )
    }

    private func badge(_ text: String, color: Color) -> some View {
        Text(text)
            .font(.caption2.weight(.semibold))
            .foregroundStyle(color)
            .padding(.horizontal, 7)
            .padding(.vertical, 3)
            .background(color.opacity(0.12), in: Capsule())
    }

    private func timingGrid(_ recipe: RecipeDetail) -> some View {
        Grid(alignment: .leading, horizontalSpacing: 20, verticalSpacing: 12) {
            GridRow {
                detailMetric(
                    title: "Selected",
                    value: selectedServings.formatted(
                        .number.precision(
                            .fractionLength(0...1)
                        )
                    ),
                    icon: "person.2"
                )

                detailMetric(
                    title: "Total",
                    value: durationText(recipe.totalMinutes),
                    icon: "clock"
                )
            }

            GridRow {
                detailMetric(
                    title: "Prep",
                    value: optionalDurationText(recipe.preparationMinutes),
                    icon: "fork.knife"
                )

                detailMetric(
                    title: "Cook",
                    value: optionalDurationText(recipe.cookingMinutes),
                    icon: "flame"
                )
            }
        }
    }

    private func servingSelector(
        _ recipe: RecipeDetail
    ) -> some View {
        HStack(spacing: 12) {
            VStack(
                alignment: .leading,
                spacing: 3
            ) {
                Text("Ingredient servings")
                    .font(
                        .subheadline
                            .weight(.semibold)
                    )

                Text(
                    "Ingredients scale from the recipe's base yield of \(servingsText(recipe))."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            Spacer()

            HStack(spacing: 0) {
                Button {
                    selectedServings =
                        max(
                            0.5,
                            selectedServings
                                - 0.5
                        )
                } label: {
                    Image(
                        systemName: "minus"
                    )
                    .frame(
                        width: 44,
                        height: 36
                    )
                }
                .buttonStyle(.plain)
                .disabled(
                    selectedServings <= 0.5
                )

                Divider()
                    .frame(height: 24)

                Text(
                    selectedServings
                        .formatted(
                            .number
                                .precision(
                                    .fractionLength(
                                        0...1
                                    )
                                )
                        )
                )
                .font(
                    .headline
                        .monospacedDigit()
                )
                .frame(
                    minWidth: 52,
                    minHeight: 36
                )

                Divider()
                    .frame(height: 24)

                Button {
                    selectedServings =
                        min(
                            10,
                            selectedServings
                                + 0.5
                        )
                } label: {
                    Image(
                        systemName: "plus"
                    )
                    .frame(
                        width: 44,
                        height: 36
                    )
                }
                .buttonStyle(.plain)
                .disabled(
                    selectedServings >= 10
                )
            }
            .background(
                Color(
                    .tertiarySystemGroupedBackground
                ),
                in: Capsule()
            )
        }
    }

    private var recipeBaseServings: Double {
        store.recipe?.defaultServings ?? 1
    }

    private func detailMetric(
        title: String,
        value: String,
        icon: String
    ) -> some View {
        Label {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Text(value)
                    .font(.subheadline.weight(.semibold))
            }
        } icon: {
            Image(systemName: icon)
                .foregroundStyle(.green)
        }
    }

    private func prepReviewSection(
        _ recipe: RecipeDetail
    ) -> some View {
        Section {
            VStack(
                alignment: .leading,
                spacing: 12
            ) {
                HStack(
                    alignment: .top,
                    spacing: 10
                ) {
                    Image(
                        systemName:
                            "exclamationmark.triangle.fill"
                    )
                    .foregroundStyle(.orange)

                    VStack(
                        alignment: .leading,
                        spacing: 4
                    ) {
                        Text(
                            "Smart-prep review needed"
                        )
                        .font(
                            .headline
                        )

                        Text(
                            "This recipe is saved, but smart scheduling will not use its reusable preparation data until the issues below are resolved."
                        )
                        .font(.subheadline)
                        .foregroundStyle(
                            .secondary
                        )
                    }
                }

                if store.complianceIssues
                    .isEmpty {
                    prepReviewFallback
                } else {
                    ForEach(
                        store.complianceIssues
                            .filter(
                                \.requiresReview
                            )
                    ) {
                        issue in

                        VStack(
                            alignment: .leading,
                            spacing: 4
                        ) {
                            Text(issue.title)
                                .font(
                                    .subheadline
                                        .weight(
                                            .semibold
                                        )
                                )

                            Text(issue.message)
                                .font(.subheadline)
                                .foregroundStyle(
                                    .secondary
                                )

                            if issue.stepPosition
                                != nil {
                                Text(
                                    "Rewrite the affected step with explicit ingredient actions—for example: “Dice the onion, mince the garlic, and slice the bell pepper.”"
                                )
                                .font(.caption)
                                .foregroundStyle(
                                    .orange
                                )
                            }
                        }
                        .padding(10)
                        .frame(
                            maxWidth: .infinity,
                            alignment: .leading
                        )
                        .background(
                            Color.orange
                                .opacity(0.08),
                            in:
                                RoundedRectangle(
                                    cornerRadius: 10,
                                    style:
                                        .continuous
                                )
                        )
                    }
                }

                if store.isOwnedByCurrentUser {
                    Button {
                        editorRoute =
                            RecipeEditorRoute(
                                recipeID:
                                    recipe.id
                            )
                    } label: {
                        Label(
                            "Review recipe",
                            systemImage:
                                "pencil"
                        )
                    }
                    .buttonStyle(
                        .borderedProminent
                    )
                    .tint(.orange)
                }
            }
            .padding(.vertical, 4)
        } header: {
            Text("Smart-prep readiness")
        }
    }

    private var prepReviewFallback:
        some View {
        VStack(
            alignment: .leading,
            spacing: 5
        ) {
            Text(
                "The preparation instructions are too broad."
            )
            .font(
                .subheadline
                    .weight(.semibold)
            )

            Text(
                "Ingredient preparation notes help, but the recipe steps should also state which action applies to each ingredient. Replace directions such as “Cut all vegetables” with explicit steps such as “Dice the onion, mince the garlic, and slice the bell pepper.”"
            )
            .font(.subheadline)
            .foregroundStyle(
                .secondary
            )
        }
        .padding(10)
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .background(
            Color.orange.opacity(0.08),
            in: RoundedRectangle(
                cornerRadius: 10,
                style: .continuous
            )
        )
    }

    private var ingredientsSection: some View {
        Section("Ingredients") {
            if store.ingredients.isEmpty {
                Text("No ingredients have been added.")
                    .foregroundStyle(.secondary)
            } else {
                ForEach(store.ingredients) { ingredient in
                    HStack(alignment: .firstTextBaseline) {
                        VStack(alignment: .leading, spacing: 3) {
                            HStack(spacing: 5) {
                                Text(ingredient.name)

                                if ingredient.isOptional {
                                    Text("Optional")
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                            }

                            if let note = ingredient.preparationNote,
                               !note.isEmpty {
                                Text(note)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }

                        Spacer()

                        let baseServings = max(
                            recipeBaseServings,
                            0.5
                        )

                        let quantityText = ingredient.quantityText(
                            selectedServings: selectedServings,
                            baseServings: baseServings
                        )

                        Text(
                            ingredient.scalingBehavior == "to_taste"
                            ? quantityText
                            : "\(quantityText) \(ingredient.unit)"
                        )
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }

    private var stepsSection: some View {
        Section("Instructions") {
            if store.steps.isEmpty {
                Text("No instructions have been added.")
                    .foregroundStyle(.secondary)
            } else {
                ForEach(Array(store.steps.enumerated()), id: \.element.id) { index, step in
                    HStack(alignment: .top, spacing: 12) {
                        Text(String(index + 1))
                            .font(.caption.bold())
                            .foregroundStyle(.white)
                            .frame(width: 25, height: 25)
                            .background(Color.green, in: Circle())

                        VStack(alignment: .leading, spacing: 5) {
                            Text(step.instruction)

                            if step.durationMinutes > 0 {
                                Label(
                                    durationText(step.durationMinutes),
                                    systemImage: "clock"
                                )
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .padding(.vertical, 3)
                }
            }
        }
    }

    private var tasksSection: some View {
        Section("Preparation schedule") {
            ForEach(store.tasks) { task in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(task.title)
                            .font(.subheadline.weight(.semibold))

                        Spacer()

                        Text(task.taskType.replacingOccurrences(of: "_", with: " ").capitalized)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    if let instructions = task.instructions,
                       !instructions.isEmpty {
                        Text(instructions)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }

                    HStack(spacing: 12) {
                        if task.activeMinutes > 0 {
                            Label(
                                "\(durationText(task.activeMinutes)) active",
                                systemImage: "figure.walk"
                            )
                        }

                        if task.passiveMinutes > 0 {
                            Label(
                                "\(durationText(task.passiveMinutes)) passive",
                                systemImage: "hourglass"
                            )
                        }
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
                .padding(.vertical, 3)
            }
        }
    }

    private func storageSection(_ recipe: RecipeDetail) -> some View {
        Section("Storage") {
            LabeledContent(
                "Refrigerator",
                value: dayText(recipe.refrigeratorLifeDays)
            )

            LabeledContent(
                "Freezer",
                value: recipe.freezerAllowed
                    ? dayText(recipe.freezerLifeDays)
                    : "Not recommended"
            )
        }
    }

    private func errorView(message: String) -> some View {
        ContentUnavailableView {
            Label("Could not load recipe", systemImage: "exclamationmark.triangle")
        } description: {
            Text(message)
        } actions: {
            Button("Try again") {
                Task {
                    await store.load(recipeID: recipeID)
                }
            }
        }
    }

    private func durationText(
        _ totalMinutes: Int
    ) -> String {
        AppDurationFormatter.string(
            minutes: totalMinutes
        )
    }

    private func optionalDurationText(
        _ minutes: Int?
    ) -> String {
        AppDurationFormatter.optionalString(
            minutes: minutes
        )
    }

    private func servingsText(_ recipe: RecipeDetail) -> String {
        guard let servings = recipe.defaultServings else { return "—" }
        return servings.formatted(.number.precision(.fractionLength(0...1)))
    }

    private func dayText(_ days: Int?) -> String {
        guard let days, days > 0 else { return "Not specified" }
        return days == 1 ? "1 day" : "\(days) days"
    }
}

private struct RecipeEditorRoute: Identifiable {
    let recipeID: UUID
    var id: UUID { recipeID }
}

private struct RecipeDetailRoute: Identifiable, Hashable {
    let recipeID: UUID
    var id: UUID { recipeID }
}
