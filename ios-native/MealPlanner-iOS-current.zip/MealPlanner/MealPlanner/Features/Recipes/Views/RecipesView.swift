import SwiftUI

struct RecipesView: View {
    @State private var store = RecipeStore()
    @State private var recipePendingDeletion: Recipe?
    @State private var editorRoute: RecipeListEditorRoute?

    var body: some View {
        VStack(spacing: 0) {
            AppScreenHeader(
                title: "Recipes",
                subtitle: "Browse, save, and edit meals"
            )
            .padding(.horizontal, 20)
            .padding(.top, 54)
            .padding(.bottom, 18)

            tabPicker
                .padding(.horizontal)
                .padding(.top, 0)

            mealTypeFilters
                .padding(.top, 10)

            content
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    editorRoute = RecipeListEditorRoute(recipeID: nil)
                } label: {
                    Image(systemName: "plus")
                }
                .accessibilityLabel("Add recipe")
            }
        }
        .sheet(item: $editorRoute) { route in
            RecipeEditorView(recipeID: route.recipeID) {
                Task {
                    await store.loadFirstPage()
                }
            }
        }
        .searchable(
            text: $store.searchText,
            prompt: "Search recipes or creators"
        )
        .task {
            await store.prepareInitialLoad()
        }
        .task(id: store.queryIdentifier) {
            guard store.hasLoadedInitialPreference else {
                return
            }

            do {
                try await Task.sleep(
                    for: .milliseconds(350)
                )
            } catch {
                return
            }

            guard !Task.isCancelled else {
                return
            }

            await store.loadFirstPage()
        }
        .onReceive(
            NotificationCenter.default.publisher(
                for: .accountPreferencesDidChange
            )
        ) { notification in
            guard let defaultTab =
                notification.userInfo?[
                    AccountPreferenceNotificationKey
                        .defaultRecipeTab
                ] as? String
            else {
                return
            }

            Task {
                await store.applyDefaultTab(
                    databaseValue: defaultTab
                )
            }
        }
        .alert(
            "Delete recipe?",
            isPresented: Binding(
                get: { recipePendingDeletion != nil },
                set: { if !$0 { recipePendingDeletion = nil } }
            )
        ) {
            Button("Cancel", role: .cancel) {
                recipePendingDeletion = nil
            }

            Button("Delete", role: .destructive) {
                guard let recipe = recipePendingDeletion else { return }
                recipePendingDeletion = nil

                Task {
                    _ = await store.deleteOwnedRecipe(recipe)
                }
            }
        } message: {
            Text("This permanently deletes the recipe, its ingredients, instructions, and preparation tasks.")
        }
        .alert(
            "Could not complete action",
            isPresented: Binding(
                get: { store.errorMessage != nil && !store.recipes.isEmpty },
                set: { if !$0 { store.errorMessage = nil } }
            )
        ) {
            Button("OK", role: .cancel) {
                store.errorMessage = nil
            }
        } message: {
            Text(store.errorMessage ?? "Unknown error")
        }
    }

    @ViewBuilder
    private var content: some View {
        if store.isLoading && store.recipes.isEmpty {
            Spacer()
            ProgressView("Loading recipes…")
            Spacer()
        } else if let errorMessage = store.errorMessage,
                  store.recipes.isEmpty {
            ContentUnavailableView {
                Label("Could not load recipes", systemImage: "exclamationmark.triangle")
            } description: {
                Text(errorMessage)
            } actions: {
                Button("Try again") {
                    Task { await store.loadFirstPage() }
                }
            }
        } else if store.recipes.isEmpty {
            ContentUnavailableView.search(text: store.searchText)
        } else {
            recipeList
        }
    }

    private var recipeList: some View {
        List {
            ForEach(store.recipes) { recipe in
                NavigationLink {
                    RecipeDetailView(recipeID: recipe.id)
                } label: {
                    RecipeRow(
                        recipe: recipe,
                        isFavorite: store.isFavorite(recipe),
                        isOwnedByCurrentUser: store.isOwnedByCurrentUser(recipe)
                    )
                }
                .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                    if store.selectedTab == .mine && store.isOwnedByCurrentUser(recipe) {
                        Button(role: .destructive) {
                            recipePendingDeletion = recipe
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    } else if store.selectedTab == .favorites {
                        if store.isOwnedByCurrentUser(recipe) {
                            Button(role: .destructive) {
                                recipePendingDeletion = recipe
                            } label: {
                                Label("Delete recipe", systemImage: "trash")
                            }
                        } else {
                            Button {
                                Task { await store.removeFromFavorites(recipe) }
                            } label: {
                                Label("Remove favorite", systemImage: "heart.slash")
                            }
                            .tint(.gray)
                        }
                    } else if !store.isOwnedByCurrentUser(recipe) {
                        Button {
                            Task { await store.toggleFavorite(recipe) }
                        } label: {
                            Label(
                                store.isFavorite(recipe) ? "Unfavorite" : "Favorite",
                                systemImage: store.isFavorite(recipe) ? "heart.slash" : "heart"
                            )
                        }
                        .tint(store.isFavorite(recipe) ? .gray : .red)
                    }
                }
            }

            if store.totalPages > 1 {
                Section {
                    paginationControls
                }
                .listRowSeparator(.hidden)
            }
        }
        .listStyle(.plain)
        .refreshable {
            await store.reloadCurrentPage()
        }
    }

    private var mealTypeFilters: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(RecipeMealTypeFilter.allCases) { filter in
                    Button {
                        store.selectedMealType = filter
                    } label: {
                        Text(filter.rawValue)
                            .font(.subheadline.weight(.medium))
                            .padding(.horizontal, 13)
                            .padding(.vertical, 8)
                            .foregroundStyle(store.selectedMealType == filter ? Color.white : Color.primary)
                            .background(
                                store.selectedMealType == filter
                                    ? Color.green
                                    : Color(.secondarySystemBackground),
                                in: Capsule()
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal)
        }
    }

    private var paginationControls: some View {
        VStack(spacing: 10) {
            Text(store.pageSummary)
                .font(.footnote)
                .foregroundStyle(.secondary)

            HStack {
                Button {
                    Task { await store.loadPreviousPage() }
                } label: {
                    Label("Previous", systemImage: "chevron.left")
                }
                .disabled(!store.hasPreviousPage || store.isLoading)

                Spacer()

                Text("Page \(store.currentPage) of \(store.totalPages)")
                    .font(.subheadline.weight(.medium))

                Spacer()

                Button {
                    Task { await store.loadNextPage() }
                } label: {
                    HStack {
                        Text("Next")
                        Image(systemName: "chevron.right")
                    }
                }
                .disabled(!store.hasNextPage || store.isLoading)
            }
        }
        .padding(.vertical, 8)
    }

    private var tabPicker: some View {
        Picker("Recipe collection", selection: $store.selectedTab) {
            Text("Discover \(store.discoverCount)").tag(RecipeTab.discover)
            Text("Favorites \(store.favoritesCount)").tag(RecipeTab.favorites)
            Text("My Recipes \(store.myRecipesCount)").tag(RecipeTab.mine)
        }
        .pickerStyle(.segmented)
    }
}

private struct RecipeRow: View {
    let recipe: Recipe
    let isFavorite: Bool
    let isOwnedByCurrentUser: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 7) {
                Text(recipe.name)
                    .font(.headline)

                if isFavorite {
                    Image(systemName: "heart.fill")
                        .font(.caption)
                        .foregroundStyle(.red)
                }
            }

            HStack(spacing: 6) {
                if isOwnedByCurrentUser {
                    badge("Your recipe", color: .green)
                }

                if recipe.parentRecipeID != nil {
                    badge(
                        "Customized",
                        color: .orange
                    )
                }

                if recipe.hasSmartPrepIssues {
                    badge(
                        "Prep review",
                        color: .orange
                    )
                }

                complianceBadge(
                    score:
                        recipe.complianceScore,
                    status:
                        recipe.analysisStatus
                )

                badge(
                    recipe.isPublic
                    ? "Public"
                    : "Private",
                    color:
                        recipe.isPublic
                        ? .blue
                        : .secondary
                )
            }

            Text(recipe.mealTypeText)
                .font(.subheadline)
                .foregroundStyle(.secondary)

            if recipe.isPublic {
                Text("Created by \(recipe.creatorName)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            if let description = recipe.description, !description.isEmpty {
                Text(description)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }

            HStack(spacing: 12) {
                if let minutes = recipe.preparationMinutes {
                    Label(durationText(minutes), systemImage: "fork.knife")
                }

                if let minutes = recipe.cookingMinutes {
                    Label(durationText(minutes), systemImage: "flame")
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 6)
    }

    private func complianceBadge(
        score: Double,
        status: String
    ) -> some View {
        let percentage =
            Int(
                (
                    max(
                        0,
                        min(1, score)
                    ) * 100
                ).rounded()
            )

        let color: Color

        switch status {
        case "compliant":
            color = .green

        case "needs_review",
             "analyzing",
             "pending":
            color = .orange

        case "failed":
            color = .red

        default:
            color = .secondary
        }

        return Label(
            "Prep \(percentage)%",
            systemImage:
                status == "compliant"
                ? "checkmark.seal.fill"
                : "exclamationmark.triangle.fill"
        )
        .font(
            .caption2
                .weight(.semibold)
        )
        .foregroundStyle(color)
        .padding(
            .horizontal,
            7
        )
        .padding(
            .vertical,
            3
        )
        .background(
            color.opacity(0.12),
            in: Capsule()
        )
        .accessibilityLabel(
            "Smart prep compliance \(percentage) percent"
        )
    }

    private func badge(_ text: String, color: Color) -> some View {
        Text(text)
            .font(.caption2.weight(.semibold))
            .foregroundStyle(color)
            .padding(.horizontal, 7)
            .padding(.vertical, 3)
            .background(color.opacity(0.12), in: Capsule())
    }

    private func durationText(
        _ minutes: Int
    ) -> String {
        AppDurationFormatter.string(
            minutes: minutes
        )
    }
}

private struct RecipeListEditorRoute: Identifiable {
    let id = UUID()
    let recipeID: UUID?
}
