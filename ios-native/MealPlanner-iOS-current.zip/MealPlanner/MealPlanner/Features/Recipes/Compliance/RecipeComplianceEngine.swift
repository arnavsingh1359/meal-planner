import Foundation

nonisolated enum RecipeInstructionRole:
    String,
    Codable,
    Hashable {

    case preparation
    case setup
    case cooking
    case passive
    case finishing
    case general
}

nonisolated struct RecipeInstructionAnalysis:
    Identifiable,
    Codable,
    Hashable {

    let id: UUID
    let position: Int
    let role: RecipeInstructionRole
    let linkedOperationCount: Int
    let needsReview: Bool

    var isPreparation: Bool {
        role == .preparation
    }
}

nonisolated enum RecipeComplianceSeverity:
    String,
    Codable,
    Hashable {

    case advisory
    case review
    case blocking
}

nonisolated struct RecipeComplianceIssue:
    Identifiable,
    Codable,
    Hashable {

    let id: UUID
    let code: String
    let severity: RecipeComplianceSeverity
    let title: String
    let message: String
    let ingredientPosition: Int?
    let stepPosition: Int?
}

nonisolated struct RecipePrepOperation:
    Identifiable,
    Codable,
    Hashable {

    let id: UUID
    let ingredientPosition: Int
    let sourceStepPositions: [Int]
    let canonicalIngredientName: String
    let displayIngredientName: String
    let action: String
    let preparationState: String
    let quantity: Double
    let unit: String
    let canMakeAhead: Bool
    let maximumMakeAheadHours: Int
    let storageMethod: String
    let batchKey: String
    let confidence: Double
}

nonisolated struct RecipeComplianceReport:
    Hashable {

    let operations: [RecipePrepOperation]
    let issues: [RecipeComplianceIssue]
    let instructionAnalyses:
        [RecipeInstructionAnalysis]

    var status: String {
        if issues.contains(
            where: {
                $0.severity == .blocking
            }
        ) {
            return "failed"
        }

        if issues.contains(
            where: {
                $0.severity == .review
            }
        ) {
            return "needs_review"
        }

        return "compliant"
    }

    var score: Double {
        let penalty =
            issues.reduce(0.0) {
                partial,
                issue in

                switch issue.severity {
                case .advisory:
                    return partial + 0.05
                case .review:
                    return partial + 0.18
                case .blocking:
                    return partial + 0.45
                }
            }

        return max(
            0,
            min(1, 1 - penalty)
        )
    }

    var reviewIssueCount: Int {
        issues.filter {
            $0.severity == .review
                || $0.severity == .blocking
        }.count
    }
}

nonisolated struct RecipePrepOperationInsert:
    Encodable {

    let recipeID: UUID
    let userID: UUID
    let ingredientPosition: Int
    let sourceStepPositions: [Int]
    let canonicalIngredientName: String
    let displayIngredientName: String
    let action: String
    let preparationState: String
    let quantity: Double
    let unit: String
    let canMakeAhead: Bool
    let maximumMakeAheadHours: Int
    let storageMethod: String
    let batchKey: String
    let confidence: Double
    let manuallyEdited: Bool
    let analysisVersion: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case recipeID = "recipe_id"
        case userID = "user_id"
        case ingredientPosition =
            "ingredient_position"
        case sourceStepPositions =
            "source_step_positions"
        case canonicalIngredientName =
            "canonical_ingredient_name"
        case displayIngredientName =
            "display_ingredient_name"
        case action
        case preparationState =
            "preparation_state"
        case quantity
        case unit
        case canMakeAhead =
            "can_make_ahead"
        case maximumMakeAheadHours =
            "maximum_make_ahead_hours"
        case storageMethod =
            "storage_method"
        case batchKey = "batch_key"
        case confidence
        case manuallyEdited =
            "manually_edited"
        case analysisVersion =
            "analysis_version"
        case position
    }
}

nonisolated struct RecipeComplianceIssueInsert:
    Encodable {

    let recipeID: UUID
    let userID: UUID
    let code: String
    let severity: String
    let title: String
    let message: String
    let ingredientPosition: Int?
    let stepPosition: Int?

    enum CodingKeys: String, CodingKey {
        case recipeID = "recipe_id"
        case userID = "user_id"
        case code
        case severity
        case title
        case message
        case ingredientPosition =
            "ingredient_position"
        case stepPosition =
            "step_position"
    }
}

nonisolated struct RecipeAnalysisUpdate:
    Encodable {

    let analysisStatus: String
    let analysisVersion: String
    let complianceScore: Double
    let lastAnalyzedAt: Date

    enum CodingKeys: String, CodingKey {
        case analysisStatus =
            "analysis_status"
        case analysisVersion =
            "analysis_version"
        case complianceScore =
            "compliance_score"
        case lastAnalyzedAt =
            "last_analyzed_at"
    }
}

nonisolated enum RecipeComplianceEngine {
    static let analysisVersion =
        "prep-compliance-v2-indian-kitchen"

    static func analyze(
        draft: RecipeEditorDraft
    ) -> RecipeComplianceReport {
        let value = draft.normalized

        var operations:
            [RecipePrepOperation] = []

        var issues:
            [RecipeComplianceIssue] = []

        let normalizedSteps =
            value.steps.enumerated().map {
                index,
                step in

                (
                    position: index,
                    text:
                        normalizeText(
                            step.instruction
                        ),
                    role:
                        classifyInstruction(
                            normalizeText(
                                step.instruction
                            )
                        )
                )
            }

        let collectivePrepSteps =
            normalizedSteps.filter {
                step in

                step.role == .preparation
                && containsAny(
                    step.text,
                    [
                        "aromatics",
                        "vegetables",
                        "ingredients",
                        "toppings",
                        "produce"
                    ]
                )
            }

        for (
            ingredientPosition,
            ingredient
        ) in value.ingredients.enumerated() {
            let canonicalIngredient =
                canonicalIngredientName(
                    ingredient.name
                )

            let normalizedIngredientName =
                normalizeText(
                    ingredient.name
                )

            let preparationNote =
                normalizeText(
                    ingredient.preparationNote
                )

            let matchingPreparationSteps =
                normalizedSteps.filter {
                    step in

                    step.role == .preparation
                    && (
                        step.text.contains(
                            canonicalIngredient
                        )
                        || step.text.contains(
                            normalizedIngredientName
                        )
                    )
                }

            let noteAction =
                inferAction(
                    from:
                        preparationNote
                )

            let explicitStepAction =
                matchingPreparationSteps
                    .compactMap {
                        explicitAction(
                            for:
                                canonicalIngredient,
                            in: $0.text
                        )
                    }
                    .first

            let inferredAction =
                noteAction
                ?? explicitStepAction

            guard let action =
                inferredAction
            else {
                let relatedCollectiveStep =
                    collectivePrepSteps.first

                let shouldRequireResolution =
                    requiresPreparationResolution(
                        canonicalIngredient:
                            canonicalIngredient,
                        preparationNote:
                            preparationNote,
                        matchingPreparationSteps:
                            matchingPreparationSteps.map(
                                \.text
                            ),
                        hasCollectivePrepStep:
                            relatedCollectiveStep
                            != nil
                    )

                if shouldRequireResolution {
                    issues.append(
                        RecipeComplianceIssue(
                            id: UUID(),
                            code:
                                "confirm_ingredient_preparation",
                            severity: .review,
                            title:
                                "Confirm \(ingredient.name) preparation",
                            message:
                                preparationGuidance(
                                    for:
                                        canonicalIngredient
                                ),
                            ingredientPosition:
                                ingredientPosition,
                            stepPosition:
                                matchingPreparationSteps
                                    .first?
                                    .position
                                ?? relatedCollectiveStep?
                                    .position
                        )
                    )
                }

                continue
            }

            let sourcePositions =
                matchingPreparationSteps
                    .map(\.position)

            let policy =
                makeAheadPolicy(
                    action: action,
                    canonicalIngredient:
                        canonicalIngredient
                )

            let confidence: Double =
                noteAction != nil
                ? 0.96
                : 0.86

            operations.append(
                RecipePrepOperation(
                    id: UUID(),
                    ingredientPosition:
                        ingredientPosition,
                    sourceStepPositions:
                        sourcePositions,
                    canonicalIngredientName:
                        canonicalIngredient,
                    displayIngredientName:
                        ingredient.name,
                    action: action,
                    preparationState:
                        preparationState(
                            for: action
                        ),
                    quantity:
                        Double(
                            ingredient.quantity
                        ) ?? 0,
                    unit:
                        ingredient.unit,
                    canMakeAhead:
                        policy.allowed,
                    maximumMakeAheadHours:
                        policy.hours,
                    storageMethod:
                        policy.storage,
                    batchKey:
                        "prep:\(action):\(slug(canonicalIngredient))",
                    confidence:
                        confidence
                )
            )
        }

        let prepSteps =
            normalizedSteps.filter {
                $0.role == .preparation
            }

        for step in prepSteps {
            let linkedOperations =
                operations.filter {
                    $0.sourceStepPositions
                        .contains(
                            step.position
                        )
                }

            let isCollectiveStep =
                collectivePrepSteps.contains {
                    $0.position
                        == step.position
                }

            let unresolvedIngredientIssues =
                issues.contains {
                    $0.ingredientPosition
                        != nil
                    && $0.severity
                        != .advisory
                }

            let collectiveIngredientsResolved =
                isCollectiveStep
                && !operations.isEmpty
                && !unresolvedIngredientIssues

            if linkedOperations.isEmpty
                && !collectiveIngredientsResolved {
                issues.append(
                    RecipeComplianceIssue(
                        id: UUID(),
                        code:
                            "opaque_preparation_step",
                        severity: .review,
                        title:
                            "Preparation step needs detail",
                        message:
                            "This is a preparation instruction, but the app cannot determine which reusable ingredient operations it represents. Name the ingredients and actions in the instruction, or add preparation notes such as diced, minced, sliced, washed, or peeled to the affected ingredients.",
                        ingredientPosition:
                            nil,
                        stepPosition:
                            step.position
                    )
                )
            }
        }

        let cleanOperations =
            deduplicatedOperations(
                operations
            )

        let cleanIssues =
            deduplicatedIssues(
                issues
            )

        let instructionAnalyses =
            normalizedSteps.map {
                step in

                let linkedCount =
                    cleanOperations.filter {
                        $0.sourceStepPositions
                            .contains(
                                step.position
                            )
                    }
                    .count

                let needsReview =
                    cleanIssues.contains {
                        $0.stepPosition
                            == step.position
                        && $0.severity
                            != .advisory
                    }

                return RecipeInstructionAnalysis(
                    id: UUID(),
                    position:
                        step.position,
                    role:
                        step.role,
                    linkedOperationCount:
                        linkedCount,
                    needsReview:
                        needsReview
                )
            }

        return RecipeComplianceReport(
            operations:
                cleanOperations,
            issues:
                cleanIssues,
            instructionAnalyses:
                instructionAnalyses
        )
    }

    private static func classifyInstruction(
        _ text: String
    ) -> RecipeInstructionRole {
        guard !text.isEmpty else {
            return .general
        }

        if containsAny(
            text,
            [
                "serve",
                "plate",
                "garnish",
                "season to taste",
                "finish with",
                "top with"
            ]
        ) {
            return .finishing
        }

        if containsAny(
            text,
            [
                "rest",
                "cool",
                "chill",
                "refrigerate",
                "freeze",
                "thaw",
                "marinate",
                "soak",
                "proof",
                "rise"
            ]
        ) {
            return .passive
        }

        if containsAny(
            text,
            [
                "preheat",
                "heat oil",
                "heat a pan",
                "heat the pan",
                "grease",
                "line a tray",
                "line the tray",
                "prepare a pan"
            ]
        ) {
            return .setup
        }

        if containsAny(
            text,
            [
                "cook",
                "bake",
                "roast",
                "fry",
                "saute",
                "sauté",
                "simmer",
                "boil",
                "steam",
                "sear",
                "toast",
                "reduce",
                "until heated",
                "until softened",
                "until browned",
                "until cooked"
            ]
        ) {
            return .cooking
        }

        if containsAny(
            text,
            [
                "prepare",
                "prep",
                "aromatic",
                "vegetable",
                "chop",
                "dice",
                "mince",
                "slice",
                "peel",
                "grate",
                "wash",
                "rinse",
                "trim",
                "julienne",
                "shred",
                "cut"
            ]
        ) {
            return .preparation
        }

        return .general
    }

    private static func explicitAction(
        for ingredient: String,
        in text: String
    ) -> String? {
        let escapedIngredient =
            NSRegularExpression
                .escapedPattern(
                    for: ingredient
                )

        let actionTerms:
            [
                (
                    action: String,
                    terms: [String]
                )
            ] = actionVocabulary


        for entry in actionTerms {
            for term in entry.terms {
                let escapedTerm =
                    NSRegularExpression
                        .escapedPattern(
                            for: term
                        )

                let patterns = [
                    "\\b\(escapedTerm)\\b.{0,30}\\b\(escapedIngredient)\\b",
                    "\\b\(escapedIngredient)\\b.{0,30}\\b\(escapedTerm)\\b"
                ]

                if patterns.contains(
                    where: {
                        text.range(
                            of: $0,
                            options:
                                .regularExpression
                        ) != nil
                    }
                ) {
                    return entry.action
                }
            }
        }

        return nil
    }

    private static func inferAction(
        from text: String
    ) -> String? {
        let vocabulary = actionVocabulary

        return vocabulary.first {
            containsAny(
                text,
                $0.terms
            )
        }?.action
    }

    private static func canonicalIngredientName(
        _ value: String
    ) -> String {
        var text = normalizeText(value)

        for word in [
            "fresh", "large", "medium", "small", "whole",
            "organic", "boneless", "skinless", "raw", "ripe",
            "dried", "finely", "roughly"
        ] {
            text = text.replacingOccurrences(
                of: "\\b\(word)\\b",
                with: "",
                options: .regularExpression
            )
        }

        let aliases: [String: String] = [
            "onions": "onion", "red onion": "onion",
            "yellow onion": "onion", "white onion": "onion",
            "spring onions": "spring onion", "green onions": "spring onion",
            "scallions": "spring onion", "tomatoes": "tomato",
            "cherry tomatoes": "cherry tomato", "bell peppers": "bell pepper",
            "capsicum": "bell pepper", "capsicums": "bell pepper",
            "green chilli": "green chili", "green chillies": "green chili",
            "green chilies": "green chili", "red chilli": "red chili",
            "red chillies": "red chili", "red chilies": "red chili",
            "chillies": "chili", "chilies": "chili",
            "garlic cloves": "garlic", "cloves of garlic": "garlic",
            "ginger root": "ginger", "potatoes": "potato",
            "carrots": "carrot", "aubergine": "eggplant",
            "brinjal": "eggplant", "brinjals": "eggplant",
            "lady finger": "okra", "ladies finger": "okra",
            "cauliflower florets": "cauliflower",
            "coriander leaves": "cilantro", "fresh coriander": "cilantro",
            "coriander": "cilantro", "mint leaves": "mint",
            "fenugreek leaves": "methi", "methi leaves": "methi",
            "spinach leaves": "spinach", "curry leaves": "curry leaf",
            "mustard seeds": "mustard seed", "cumin seeds": "cumin seed",
            "jeera": "cumin seed", "dhania": "coriander seed",
            "turmeric powder": "turmeric", "haldi": "turmeric",
            "red chilli powder": "red chili powder",
            "chili powder": "red chili powder",
            "garam masala powder": "garam masala",
            "atta": "whole wheat flour", "maida": "all purpose flour",
            "besan": "gram flour", "chana dal": "split chickpea",
            "toor dal": "pigeon pea", "tuvar dal": "pigeon pea",
            "arhar dal": "pigeon pea", "moong dal": "mung dal",
            "urad dal": "black gram", "masoor dal": "red lentil",
            "rajma": "kidney bean", "chole": "chickpea",
            "kabuli chana": "chickpea", "kala chana": "black chickpea",
            "paneer cubes": "paneer", "basmati rice": "rice",
            "vegetable broth": "vegetable stock",
            "chicken broth": "chicken stock"
        ]

        if let exact = aliases[text] { text = exact }

        return text
            .replacingOccurrences(
                of: #"\s+"#,
                with: " ",
                options: .regularExpression
            )
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }


    private static func preparationState(
        for action: String
    ) -> String {
        [
            "dice": "diced", "mince": "minced", "slice": "sliced",
            "grate": "grated", "peel": "peeled", "wash": "washed",
            "rinse": "rinsed", "drain": "drained", "soak": "soaked",
            "chop": "chopped", "halve": "halved", "quarter": "quartered",
            "cube": "cubed", "julienne": "julienned", "shred": "shredded",
            "crush": "crushed", "pound": "pounded", "grind": "ground",
            "roast": "roasted", "toast": "toasted", "temper": "tempered",
            "blanch": "blanched", "boil": "boiled", "steam": "steamed",
            "cook": "cooked", "marinate": "marinated", "slit": "slit",
            "deseed": "deseeded", "juice": "juiced", "zest": "zested",
            "mash": "mashed", "puree": "pureed", "whisk": "whisked",
            "knead": "kneaded", "ferment": "fermented",
            "sprout": "sprouted", "trim": "trimmed"
        ][action] ?? action
    }


    private static func makeAheadPolicy(
        action: String,
        canonicalIngredient: String
    ) -> (allowed: Bool, hours: Int, storage: String) {
        switch action {
        case "wash", "rinse", "drain":
            return (true, containsAny(canonicalIngredient, ["spinach", "methi", "cilantro", "mint"]) ? 24 : 48, "refrigerated")
        case "peel", "chop", "dice", "slice", "halve", "quarter",
             "cube", "julienne", "shred", "grate", "mince", "trim",
             "slit", "deseed", "crush", "pound", "zest":
            return (true, makeAheadHours(for: canonicalIngredient), "refrigerated")
        case "marinate":
            return (true, canonicalIngredient.contains("fish") ? 8 : 24, "refrigerated")
        case "soak": return (true, 24, "refrigerated")
        case "sprout", "ferment": return (true, 48, "refrigerated")
        case "cook", "boil", "steam", "roast", "blanch", "toast",
             "temper", "grind", "puree", "mash":
            return (true, 72, "refrigerated")
        case "juice": return (true, 24, "refrigerated")
        default: return (false, 0, "none")
        }
    }


    private static let actionVocabulary: [(action: String, terms: [String])] = [
        ("mince", ["mince", "minced"]),
        ("dice", ["dice", "diced", "small cubes", "small pieces"]),
        ("julienne", ["julienne", "matchsticks"]),
        ("slice", ["slice", "sliced", "thinly sliced", "rings"]),
        ("halve", ["halve", "halved", "cut in half"]),
        ("quarter", ["quarter", "quartered"]),
        ("cube", ["cube", "cubed"]),
        ("shred", ["shred", "shredded"]),
        ("grate", ["grate", "grated"]),
        ("peel", ["peel", "peeled"]),
        ("rinse", ["rinse", "rinsed"]),
        ("wash", ["wash", "washed", "cleaned"]),
        ("drain", ["drain", "drained"]),
        ("trim", ["trim", "trimmed"]),
        ("deseed", ["deseed", "deseeded", "remove seeds"]),
        ("slit", ["slit", "slitted"]),
        ("crush", ["crush", "crushed"]),
        ("pound", ["pound", "pounded"]),
        ("grind", ["grind", "ground", "make a paste", "paste"]),
        ("chop", ["chop", "chopped", "roughly chopped", "finely chopped", "cut"]),
        ("soak", ["soak", "soaked"]),
        ("sprout", ["sprout", "sprouted"]),
        ("marinate", ["marinate", "marinated"]),
        ("juice", ["juice", "juiced", "squeeze", "squeezed"]),
        ("zest", ["zest", "zested"]),
        ("mash", ["mash", "mashed"]),
        ("puree", ["puree", "purée", "pureed", "blended"]),
        ("whisk", ["whisk", "whisked", "beat", "beaten"]),
        ("knead", ["knead", "kneaded"]),
        ("ferment", ["ferment", "fermented"]),
        ("temper", ["temper", "tempered", "tadka", "chaunk"]),
        ("toast", ["toast", "toasted", "dry roast"]),
        ("roast", ["roast", "roasted"]),
        ("blanch", ["blanch", "blanched"]),
        ("boil", ["boil", "boiled"]),
        ("steam", ["steam", "steamed"]),
        ("cook", ["cook", "cooked"])
    ]

    private static let noPrepIngredientTerms = [
        "salt", "sugar", "jaggery", "oil", "ghee", "butter", "water",
        "stock", "broth", "sauce", "vinegar", "milk", "cream", "yogurt",
        "curd", "coconut milk", "flour", "starch", "powder", "masala",
        "turmeric", "paprika", "cumin seed", "mustard seed", "coriander seed",
        "cardamom", "clove", "cinnamon", "bay leaf", "asafoetida", "hing",
        "kasuri methi", "extract", "paste", "ketchup", "honey", "syrup", "pickle"
    ]

    private static let likelyRawPrepIngredientTerms = [
        "onion", "garlic", "ginger", "tomato", "potato", "carrot",
        "bell pepper", "chili", "eggplant", "okra", "cauliflower", "cabbage",
        "spinach", "methi", "cilantro", "mint", "curry leaf", "beans", "peas",
        "zucchini", "cucumber", "radish", "beet", "turnip", "pumpkin",
        "gourd", "drumstick", "mushroom", "paneer", "tofu", "chicken", "fish",
        "meat", "prawn", "shrimp", "lentil", "dal", "chickpea", "kidney bean", "rice"
    ]

    private static func requiresPreparationResolution(
        canonicalIngredient: String,
        preparationNote: String,
        matchingPreparationSteps: [String],
        hasCollectivePrepStep: Bool
    ) -> Bool {
        if containsAny(canonicalIngredient, noPrepIngredientTerms) { return false }
        if !preparationNote.isEmpty { return true }
        if !matchingPreparationSteps.isEmpty { return true }
        return hasCollectivePrepStep
            && containsAny(canonicalIngredient, likelyRawPrepIngredientTerms)
    }

    private static func preparationGuidance(for ingredient: String) -> String {
        if ingredient.contains("rice") {
            return "Specify whether the rice is rinsed, soaked, cooked, or left unchanged for this recipe."
        }
        if containsAny(ingredient, ["lentil", "dal", "chickpea", "bean", "rajma"]) {
            return "Specify whether \(ingredient) should be rinsed, soaked, drained, sprouted, or cooked."
        }
        if containsAny(ingredient, ["chili", "pepper"]) {
            return "Specify whether \(ingredient) should be sliced, diced, chopped, slit, or deseeded."
        }
        if containsAny(ingredient, ["ginger", "garlic"]) {
            return "Specify whether \(ingredient) should be minced, grated, crushed, chopped, or ground into a paste."
        }
        if containsAny(ingredient, ["chicken", "fish", "meat", "paneer", "tofu"]) {
            return "Specify whether \(ingredient) should be cubed, sliced, drained, pressed, marinated, or otherwise prepared."
        }
        return "Specify the preparation only when needed—for example chopped, diced, sliced, grated, washed, rinsed, soaked, crushed, or cooked."
    }

    private static func makeAheadHours(for ingredient: String) -> Int {
        if containsAny(ingredient, ["potato", "eggplant", "spinach", "methi", "cilantro", "mint", "curry leaf", "tomato", "cucumber"]) { return 24 }
        if containsAny(ingredient, ["onion", "garlic", "ginger", "carrot", "bell pepper", "celery", "cabbage", "cauliflower"]) { return 72 }
        return 48
    }

    private static func slug(
        _ value: String
    ) -> String {
        value.lowercased()
            .replacingOccurrences(
                of: #"[^a-z0-9]+"#,
                with: "_",
                options:
                    .regularExpression
            )
            .trimmingCharacters(
                in:
                    CharacterSet(
                        charactersIn: "_"
                    )
            )
    }

    private static func normalizeText(
        _ value: String
    ) -> String {
        value.lowercased()
            .replacingOccurrences(
                of: #"[^a-z0-9\s]+"#,
                with: " ",
                options:
                    .regularExpression
            )
            .replacingOccurrences(
                of: #"\s+"#,
                with: " ",
                options:
                    .regularExpression
            )
            .trimmingCharacters(
                in:
                    .whitespacesAndNewlines
            )
    }

    private static func containsAny(
        _ text: String,
        _ terms: [String]
    ) -> Bool {
        terms.contains {
            text.contains($0)
        }
    }

    private static func deduplicatedOperations(
        _ operations:
            [RecipePrepOperation]
    ) -> [RecipePrepOperation] {
        var seen = Set<String>()

        return operations.filter {
            operation in

            seen.insert(
                "\(operation.ingredientPosition)|\(operation.batchKey)"
            ).inserted
        }
    }

    private static func deduplicatedIssues(
        _ issues:
            [RecipeComplianceIssue]
    ) -> [RecipeComplianceIssue] {
        var seen = Set<String>()

        return issues.filter {
            issue in

            seen.insert(
                "\(issue.code)|\(issue.ingredientPosition ?? -1)|\(issue.stepPosition ?? -1)"
            ).inserted
        }
    }
}
