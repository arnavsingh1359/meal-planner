import Foundation

nonisolated enum WeeklyPlanningStep: String, Codable, CaseIterable, Hashable, Identifiable {
    case menuSelected = "menu_selected"
    case servingsConfirmed = "servings_confirmed"
    case pantryReviewed = "pantry_reviewed"
    case shoppingGenerated = "shopping_generated"
    case scheduleGenerated = "schedule_generated"
    case complete

    var id: String { rawValue }

    var title: String {
        switch self {
        case .menuSelected:
            return "Choose next week’s menu"
        case .servingsConfirmed:
            return "Confirm servings"
        case .pantryReviewed:
            return "Check and adjust pantry"
        case .shoppingGenerated:
            return "Generate shopping list"
        case .scheduleGenerated:
            return "Generate cooking schedule"
        case .complete:
            return "Planning complete"
        }
    }

    var shortTitle: String {
        switch self {
        case .menuSelected:
            return "Menu"
        case .servingsConfirmed:
            return "Servings"
        case .pantryReviewed:
            return "Pantry"
        case .shoppingGenerated:
            return "Shopping"
        case .scheduleGenerated:
            return "Schedule"
        case .complete:
            return "Complete"
        }
    }

    var description: String {
        switch self {
        case .menuSelected:
            return "Pick meals for the upcoming week or copy a previous week."
        case .servingsConfirmed:
            return "Verify each planned meal uses the intended number of servings."
        case .pantryReviewed:
            return "Physically check what you have, then update pantry quantities and stock status."
        case .shoppingGenerated:
            return "Review the shopping checklist generated from next week’s menu minus pantry stock."
        case .scheduleGenerated:
            return "Generate prep and cooking tasks so Sunday batch cooking is ready."
        case .complete:
            return "Meal plan, pantry check, shopping list, and schedule are ready."
        }
    }

    var systemImage: String {
        switch self {
        case .menuSelected:
            return "calendar.badge.plus"
        case .servingsConfirmed:
            return "person.2"
        case .pantryReviewed:
            return "cabinet"
        case .shoppingGenerated:
            return "cart"
        case .scheduleGenerated:
            return "clock"
        case .complete:
            return "checkmark.seal.fill"
        }
    }
}

nonisolated enum WeeklyPlanningStatus: String, Codable, Hashable {
    case notStarted = "not_started"
    case menuSelected = "menu_selected"
    case servingsConfirmed = "servings_confirmed"
    case pantryReviewed = "pantry_reviewed"
    case shoppingGenerated = "shopping_generated"
    case scheduleGenerated = "schedule_generated"
    case complete

    var title: String {
        switch self {
        case .notStarted:
            return "Not started"
        case .menuSelected:
            return "Menu selected"
        case .servingsConfirmed:
            return "Servings confirmed"
        case .pantryReviewed:
            return "Pantry reviewed"
        case .shoppingGenerated:
            return "Shopping generated"
        case .scheduleGenerated:
            return "Schedule generated"
        case .complete:
            return "Complete"
        }
    }

    var isComplete: Bool {
        self == .complete
    }

    var progressFraction: Double {
        switch self {
        case .notStarted:
            return 0
        case .menuSelected:
            return 1.0 / 6.0
        case .servingsConfirmed:
            return 2.0 / 6.0
        case .pantryReviewed:
            return 3.0 / 6.0
        case .shoppingGenerated:
            return 4.0 / 6.0
        case .scheduleGenerated:
            return 5.0 / 6.0
        case .complete:
            return 1
        }
    }
}

nonisolated struct WeeklyPlanningProgress: Identifiable, Hashable {
    let id: UUID
    let userID: UUID?
    let weekStart: String
    var status: WeeklyPlanningStatus
    var menuSelectedAt: String?
    var servingsConfirmedAt: String?
    var pantryReviewedAt: String?
    var shoppingGeneratedAt: String?
    var scheduleGeneratedAt: String?
    var completedAt: String?

    init(
        id: UUID = UUID(),
        userID: UUID? = nil,
        weekStart: String,
        status: WeeklyPlanningStatus = .notStarted,
        menuSelectedAt: String? = nil,
        servingsConfirmedAt: String? = nil,
        pantryReviewedAt: String? = nil,
        shoppingGeneratedAt: String? = nil,
        scheduleGeneratedAt: String? = nil,
        completedAt: String? = nil
    ) {
        self.id = id
        self.userID = userID
        self.weekStart = weekStart
        self.status = status
        self.menuSelectedAt = menuSelectedAt
        self.servingsConfirmedAt = servingsConfirmedAt
        self.pantryReviewedAt = pantryReviewedAt
        self.shoppingGeneratedAt = shoppingGeneratedAt
        self.scheduleGeneratedAt = scheduleGeneratedAt
        self.completedAt = completedAt
    }

    var completedSteps: Set<WeeklyPlanningStep> {
        var steps = Set<WeeklyPlanningStep>()

        if menuSelectedAt != nil || statusProgressOrder >= WeeklyPlanningStatus.menuSelected.progressOrder {
            steps.insert(.menuSelected)
        }

        if servingsConfirmedAt != nil || statusProgressOrder >= WeeklyPlanningStatus.servingsConfirmed.progressOrder {
            steps.insert(.servingsConfirmed)
        }

        if pantryReviewedAt != nil || statusProgressOrder >= WeeklyPlanningStatus.pantryReviewed.progressOrder {
            steps.insert(.pantryReviewed)
        }

        if shoppingGeneratedAt != nil || statusProgressOrder >= WeeklyPlanningStatus.shoppingGenerated.progressOrder {
            steps.insert(.shoppingGenerated)
        }

        if scheduleGeneratedAt != nil || statusProgressOrder >= WeeklyPlanningStatus.scheduleGenerated.progressOrder {
            steps.insert(.scheduleGenerated)
        }

        if completedAt != nil || status == .complete {
            steps.insert(.complete)
        }

        return steps
    }

    var remainingStepCount: Int {
        WeeklyPlanningStep.allCases.count - completedSteps.count
    }

    var nextIncompleteStep: WeeklyPlanningStep? {
        WeeklyPlanningStep.allCases.first { !isComplete($0) }
    }

    var callToActionTitle: String {
        switch nextIncompleteStep {
        case .none:
            return "Planning complete"
        case .some(.menuSelected):
            return "Start planning next week"
        case .some(.servingsConfirmed):
            return "Confirm servings"
        case .some(.pantryReviewed):
            return "Check pantry"
        case .some(.shoppingGenerated):
            return "Generate shopping list"
        case .some(.scheduleGenerated):
            return "Generate schedule"
        case .some(.complete):
            return "Mark planning complete"
        }
    }

    var summaryText: String {
        if status == .complete {
            return "Next week is ready."
        }

        guard let next = nextIncompleteStep else {
            return "Next week is ready."
        }

        return "Next: \(next.shortTitle) • \(remainingStepCount) step\(remainingStepCount == 1 ? "" : "s") left"
    }

    func isComplete(_ step: WeeklyPlanningStep) -> Bool {
        completedSteps.contains(step)
    }

    mutating func mark(
        _ step: WeeklyPlanningStep,
        timestamp: String
    ) {
        switch step {
        case .menuSelected:
            menuSelectedAt = menuSelectedAt ?? timestamp
            status = maxStatus(status, .menuSelected)
        case .servingsConfirmed:
            menuSelectedAt = menuSelectedAt ?? timestamp
            servingsConfirmedAt = servingsConfirmedAt ?? timestamp
            status = maxStatus(status, .servingsConfirmed)
        case .pantryReviewed:
            menuSelectedAt = menuSelectedAt ?? timestamp
            servingsConfirmedAt = servingsConfirmedAt ?? timestamp
            pantryReviewedAt = pantryReviewedAt ?? timestamp
            status = maxStatus(status, .pantryReviewed)
        case .shoppingGenerated:
            menuSelectedAt = menuSelectedAt ?? timestamp
            servingsConfirmedAt = servingsConfirmedAt ?? timestamp
            pantryReviewedAt = pantryReviewedAt ?? timestamp
            shoppingGeneratedAt = shoppingGeneratedAt ?? timestamp
            status = maxStatus(status, .shoppingGenerated)
        case .scheduleGenerated:
            menuSelectedAt = menuSelectedAt ?? timestamp
            servingsConfirmedAt = servingsConfirmedAt ?? timestamp
            pantryReviewedAt = pantryReviewedAt ?? timestamp
            shoppingGeneratedAt = shoppingGeneratedAt ?? timestamp
            scheduleGeneratedAt = scheduleGeneratedAt ?? timestamp
            status = maxStatus(status, .scheduleGenerated)
        case .complete:
            menuSelectedAt = menuSelectedAt ?? timestamp
            servingsConfirmedAt = servingsConfirmedAt ?? timestamp
            pantryReviewedAt = pantryReviewedAt ?? timestamp
            shoppingGeneratedAt = shoppingGeneratedAt ?? timestamp
            scheduleGeneratedAt = scheduleGeneratedAt ?? timestamp
            completedAt = completedAt ?? timestamp
            status = .complete
        }
    }

    private var statusProgressOrder: Int {
        status.progressOrder
    }
}

nonisolated extension WeeklyPlanningStatus {
    var progressOrder: Int {
        switch self {
        case .notStarted:
            return 0
        case .menuSelected:
            return 1
        case .servingsConfirmed:
            return 2
        case .pantryReviewed:
            return 3
        case .shoppingGenerated:
            return 4
        case .scheduleGenerated:
            return 5
        case .complete:
            return 6
        }
    }
}

nonisolated func maxStatus(
    _ lhs: WeeklyPlanningStatus,
    _ rhs: WeeklyPlanningStatus
) -> WeeklyPlanningStatus {
    lhs.progressOrder >= rhs.progressOrder ? lhs : rhs
}

nonisolated enum WeeklyPlanningReminderPolicy {
    static func shouldShowPlanningPrompt(
        progress: WeeklyPlanningProgress,
        date: Date,
        calendar: Calendar = .current
    ) -> Bool {
        guard !progress.status.isComplete else {
            return false
        }

        let weekday = calendar.component(
            .weekday,
            from: date
        )

        let isSaturday = weekday == 7
        let isSunday = weekday == 1

        return isSaturday || isSunday || progress.status != .notStarted
    }

    static func urgencyText(
        progress: WeeklyPlanningProgress,
        date: Date,
        calendar: Calendar = .current
    ) -> String {
        guard !progress.status.isComplete else {
            return "Next week is ready."
        }

        let weekday = calendar.component(
            .weekday,
            from: date
        )
        let hour = calendar.component(
            .hour,
            from: date
        )

        if weekday == 7 && hour >= 18 {
            return "Finish this tonight so Sunday shopping is ready."
        }

        if weekday == 1 {
            return "Finish this now so shopping and batch cooking can happen today."
        }

        return "Plan next week before Sunday shopping and batch cooking."
    }
}

nonisolated struct WeeklyPlanningProgressRow: Codable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID
    let weekStart: String
    let status: String
    let menuSelectedAt: String?
    let servingsConfirmedAt: String?
    let pantryReviewedAt: String?
    let shoppingGeneratedAt: String?
    let scheduleGeneratedAt: String?
    let completedAt: String?

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case weekStart = "week_start"
        case status
        case menuSelectedAt = "menu_selected_at"
        case servingsConfirmedAt = "servings_confirmed_at"
        case pantryReviewedAt = "pantry_reviewed_at"
        case shoppingGeneratedAt = "shopping_generated_at"
        case scheduleGeneratedAt = "schedule_generated_at"
        case completedAt = "completed_at"
    }

    static let selectColumns = "id,user_id,week_start,status,menu_selected_at,servings_confirmed_at,pantry_reviewed_at,shopping_generated_at,schedule_generated_at,completed_at"

    var progress: WeeklyPlanningProgress {
        WeeklyPlanningProgress(
            id: id,
            userID: userID,
            weekStart: weekStart,
            status: WeeklyPlanningStatus(rawValue: status) ?? .notStarted,
            menuSelectedAt: menuSelectedAt,
            servingsConfirmedAt: servingsConfirmedAt,
            pantryReviewedAt: pantryReviewedAt,
            shoppingGeneratedAt: shoppingGeneratedAt,
            scheduleGeneratedAt: scheduleGeneratedAt,
            completedAt: completedAt
        )
    }
}

nonisolated struct WeeklyPlanningProgressUpsert: Encodable {
    let userID: UUID
    let weekStart: String
    let status: String
    let menuSelectedAt: String?
    let servingsConfirmedAt: String?
    let pantryReviewedAt: String?
    let shoppingGeneratedAt: String?
    let scheduleGeneratedAt: String?
    let completedAt: String?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case weekStart = "week_start"
        case status
        case menuSelectedAt = "menu_selected_at"
        case servingsConfirmedAt = "servings_confirmed_at"
        case pantryReviewedAt = "pantry_reviewed_at"
        case shoppingGeneratedAt = "shopping_generated_at"
        case scheduleGeneratedAt = "schedule_generated_at"
        case completedAt = "completed_at"
    }
}
