import SwiftUI

struct WeeklyPlanningView: View {
    let store: WeeklyPlanningStore
    let onNavigate: (TodayNavigationDestination) -> Void

    @Environment(\.dismiss)
    private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header

                    if let error = store.errorMessage {
                        errorBanner(error)
                    }

                    workflowSteps
                    completionSection
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)
                .padding(.bottom, 40)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Weekly planning")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Close") {
                        dismiss()
                    }
                }

                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Task {
                            await store.refresh()
                        }
                    } label: {
                        if store.isLoading {
                            ProgressView()
                        } else {
                            Image(systemName: "arrow.clockwise")
                        }
                    }
                    .accessibilityLabel("Refresh weekly planning")
                }
            }
            .task {
                await store.load()
            }
            .refreshable {
                await store.refresh()
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: "calendar.badge.clock")
                    .font(.largeTitle)
                    .foregroundStyle(.green)

                VStack(alignment: .leading, spacing: 4) {
                    Text("Plan next week")
                        .font(.title.weight(.bold))

                    Text(store.weekTitle)
                        .font(.headline)
                        .foregroundStyle(.secondary)

                    Text(store.urgencyText)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            ProgressView(
                value: store.progress.status.progressFraction
            )
            .tint(.green)

            Text(store.progress.summaryText)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
        }
        .padding(18)
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 24))
    }

    private var workflowSteps: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Saturday workflow")
                .font(.title2.weight(.bold))

            Text("Work through these in order. Pantry review updates what you actually have; it does not deduct ingredients for planned meals yet.")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            VStack(spacing: 10) {
                PlanningStepCard(
                    step: .menuSelected,
                    isComplete: store.progress.isComplete(.menuSelected),
                    primaryActionTitle: "Choose meals",
                    secondaryActionTitle: "Mark menu done"
                ) {
                    Task {
                        await store.mark(.menuSelected)
                        dismiss()
                        onNavigate(.week)
                    }
                } secondaryAction: {
                    Task {
                        await store.mark(.menuSelected)
                    }
                }

                PlanningStepCard(
                    step: .servingsConfirmed,
                    isComplete: store.progress.isComplete(.servingsConfirmed),
                    primaryActionTitle: "Review servings",
                    secondaryActionTitle: "Mark servings done"
                ) {
                    Task {
                        await store.mark(.servingsConfirmed)
                        dismiss()
                        onNavigate(.week)
                    }
                } secondaryAction: {
                    Task {
                        await store.mark(.servingsConfirmed)
                    }
                }

                PlanningStepCard(
                    step: .pantryReviewed,
                    isComplete: store.progress.isComplete(.pantryReviewed),
                    primaryActionTitle: "Adjust pantry",
                    secondaryActionTitle: "Mark pantry reviewed"
                ) {
                    Task {
                        await store.mark(.pantryReviewed)
                        dismiss()
                        onNavigate(.pantry)
                    }
                } secondaryAction: {
                    Task {
                        await store.mark(.pantryReviewed)
                    }
                }

                PlanningStepCard(
                    step: .shoppingGenerated,
                    isComplete: store.progress.isComplete(.shoppingGenerated),
                    primaryActionTitle: "Review shopping",
                    secondaryActionTitle: "Mark shopping ready"
                ) {
                    Task {
                        await store.mark(.shoppingGenerated)
                        dismiss()
                        onNavigate(.shopping)
                    }
                } secondaryAction: {
                    Task {
                        await store.mark(.shoppingGenerated)
                    }
                }

                PlanningStepCard(
                    step: .scheduleGenerated,
                    isComplete: store.progress.isComplete(.scheduleGenerated),
                    primaryActionTitle: "Review schedule",
                    secondaryActionTitle: "Mark schedule ready"
                ) {
                    Task {
                        await store.mark(.scheduleGenerated)
                        dismiss()
                        onNavigate(.schedule)
                    }
                } secondaryAction: {
                    Task {
                        await store.mark(.scheduleGenerated)
                    }
                }
            }
        }
    }

    private var completionSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Button {
                Task {
                    await store.mark(.complete)
                }
            } label: {
                Label(
                    store.progress.status == .complete
                        ? "Planning is complete"
                        : "Mark next week ready",
                    systemImage: store.progress.status == .complete
                        ? "checkmark.seal.fill"
                        : "checkmark.seal"
                )
                .font(.headline.weight(.bold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
            .tint(.green)
            .disabled(store.progress.status == .complete)

            Button(role: .destructive) {
                Task {
                    await store.resetForCurrentPlanningWeek()
                }
            } label: {
                Label("Reset this planning checklist", systemImage: "arrow.counterclockwise")
                    .font(.subheadline.weight(.semibold))
            }
            .buttonStyle(.plain)
        }
        .padding(.top, 4)
    }

    private func errorBanner(_ message: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.orange)

            Text(message)
                .font(.footnote)
                .foregroundStyle(.primary)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.orange.opacity(0.12))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

private struct PlanningStepCard: View {
    let step: WeeklyPlanningStep
    let isComplete: Bool
    let primaryActionTitle: String
    let secondaryActionTitle: String
    let primaryAction: () -> Void
    let secondaryAction: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: isComplete ? "checkmark.circle.fill" : step.systemImage)
                    .font(.title3)
                    .foregroundStyle(isComplete ? .green : .secondary)
                    .frame(width: 28)

                VStack(alignment: .leading, spacing: 4) {
                    Text(step.title)
                        .font(.headline.weight(.bold))

                    Text(step.description)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                if isComplete {
                    Text("Done")
                        .font(.caption.weight(.bold))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 5)
                        .background(.green.opacity(0.14), in: Capsule())
                        .foregroundStyle(.green)
                }
            }

            HStack(spacing: 10) {
                Button(primaryActionTitle, action: primaryAction)
                    .buttonStyle(.borderedProminent)
                    .tint(.green)

                Button(secondaryActionTitle, action: secondaryAction)
                    .buttonStyle(.bordered)
            }
            .font(.subheadline.weight(.semibold))
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(step.title), \(isComplete ? "complete" : "not complete")")
    }
}
