import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class WeeklyPlanningStore {
    private(set) var isLoading = false
    private(set) var hasLoaded = false
    private(set) var progress = WeeklyPlanningProgress(
        weekStart: ""
    )

    var errorMessage: String?

    private var calendar = Calendar.current
    private var mondayStart = true
    private var currentUserID: UUID?

    var weekTitle: String {
        guard let weekStartDate = date(from: progress.weekStart),
              let end = calendar.date(
                byAdding: .day,
                value: 6,
                to: weekStartDate
              )
        else {
            return "Next week"
        }

        return "\(weekStartDate.formatted(.dateTime.month(.abbreviated).day())) – \(end.formatted(.dateTime.month(.abbreviated).day().year()))"
    }

    var shouldShowPrompt: Bool {
        WeeklyPlanningReminderPolicy.shouldShowPlanningPrompt(
            progress: progress,
            date: Date(),
            calendar: calendar
        )
    }

    var urgencyText: String {
        WeeklyPlanningReminderPolicy.urgencyText(
            progress: progress,
            date: Date(),
            calendar: calendar
        )
    }

    func load() async {
        guard !isLoading else {
            return
        }

        isLoading = true
        errorMessage = nil

        defer {
            isLoading = false
        }

        do {
            let session = try await AppSupabase
                .client
                .auth
                .session

            currentUserID = session.user.id
            try await loadPreference(userID: session.user.id)

            let weekStart = nextPlanningWeekStart()
            let weekStartKey = dateString(weekStart)

            do {
                let row: WeeklyPlanningProgressRow =
                    try await AppSupabase
                        .client
                        .from("weekly_planning_statuses")
                        .select(WeeklyPlanningProgressRow.selectColumns)
                        .eq("user_id", value: session.user.id.uuidString)
                        .eq("week_start", value: weekStartKey)
                        .single()
                        .execute()
                        .value

                progress = row.progress
            } catch {
                progress = WeeklyPlanningProgress(
                    userID: session.user.id,
                    weekStart: weekStartKey
                )
            }

            hasLoaded = true
        } catch {
            if !(error is CancellationError) {
                errorMessage = friendlyError(error)
            }
        }
    }

    func refresh() async {
        await load()
    }

    func mark(_ step: WeeklyPlanningStep) async {
        guard let userID = currentUserID else {
            await load()
            guard currentUserID != nil else {
                return
            }
            await mark(step)
            return
        }

        var updated = progress
        updated.mark(
            step,
            timestamp: timestampString(Date())
        )

        await save(updated, userID: userID)
    }

    func resetForCurrentPlanningWeek() async {
        guard let userID = currentUserID else {
            return
        }

        let reset = WeeklyPlanningProgress(
            userID: userID,
            weekStart: progress.weekStart
        )

        await save(reset, userID: userID)
    }

    private func save(
        _ updated: WeeklyPlanningProgress,
        userID: UUID
    ) async {
        do {
            let payload = WeeklyPlanningProgressUpsert(
                userID: userID,
                weekStart: updated.weekStart,
                status: updated.status.rawValue,
                menuSelectedAt: updated.menuSelectedAt,
                servingsConfirmedAt: updated.servingsConfirmedAt,
                pantryReviewedAt: updated.pantryReviewedAt,
                shoppingGeneratedAt: updated.shoppingGeneratedAt,
                scheduleGeneratedAt: updated.scheduleGeneratedAt,
                completedAt: updated.completedAt
            )

            let row: WeeklyPlanningProgressRow =
                try await AppSupabase
                    .client
                    .from("weekly_planning_statuses")
                    .upsert(
                        payload,
                        onConflict: "user_id,week_start"
                    )
                    .select(WeeklyPlanningProgressRow.selectColumns)
                    .single()
                    .execute()
                    .value

            progress = row.progress
            errorMessage = nil
        } catch {
            progress = updated
            errorMessage = friendlyError(error)
        }
    }

    private func loadPreference(userID: UUID) async throws {
        do {
            let preference: WeekStartPreference =
                try await AppSupabase
                    .client
                    .from("account_preferences")
                    .select("week_starts_on")
                    .eq("user_id", value: userID.uuidString)
                    .single()
                    .execute()
                    .value

            mondayStart = preference.weekStartsOn.lowercased() != "sunday"
        } catch {
            mondayStart = true
        }
    }

    private func nextPlanningWeekStart() -> Date {
        let today = Date()
        let thisWeek = startOfWeek(containing: today)

        return calendar.date(
            byAdding: .day,
            value: 7,
            to: thisWeek
        ) ?? thisWeek
    }

    private func startOfWeek(containing date: Date) -> Date {
        var calendar = calendar
        calendar.firstWeekday = mondayStart ? 2 : 1

        let components = calendar.dateComponents(
            [.yearForWeekOfYear, .weekOfYear],
            from: date
        )

        return calendar.date(from: components)
            ?? calendar.startOfDay(for: date)
    }

    private func dateString(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = calendar
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    private func date(from string: String) -> Date? {
        let formatter = DateFormatter()
        formatter.calendar = calendar
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: string)
    }

    private func timestampString(_ date: Date) -> String {
        ISO8601DateFormatter().string(from: date)
    }

    private func friendlyError(_ error: Error) -> String {
        let message = error.localizedDescription

        if message.contains("weekly_planning_statuses") {
            return "Weekly planning table is missing. Run weekly_planning_workflow.sql in Supabase."
        }

        return message
    }
}
