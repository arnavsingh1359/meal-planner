import Foundation

nonisolated struct WeekMealSlot: Codable, Identifiable, Hashable {
    let id: UUID
    let dayOfWeek: Int
    let position: Int
    let name: String
    let recipeCategory: String
    let eatTime: String
    let readyTime: String
    let preparationMode: String

    enum CodingKeys: String, CodingKey {
        case id
        case dayOfWeek = "day_of_week"
        case position
        case name
        case recipeCategory = "recipe_category"
        case eatTime = "eat_time"
        case readyTime = "ready_time"
        case preparationMode = "preparation_mode"
    }
}

nonisolated struct WeekRecipeSummary: Codable, Identifiable, Hashable {
    let id: UUID
    let name: String
    let mealTypes: [String]
    let defaultServings: Double?
    let preparationMinutes: Int?
    let cookingMinutes: Int?
    let cleanupMinutes: Int?
    let creatorName: String
    let analysisStatus: String
    let complianceScore: Double

    enum CodingKeys: String, CodingKey {
        case id, name
        case mealTypes = "meal_types"
        case defaultServings =
            "default_servings"
        case preparationMinutes =
            "preparation_minutes"
        case cookingMinutes =
            "cooking_minutes"
        case cleanupMinutes =
            "cleanup_minutes"
        case creatorName =
            "creator_name"
        case analysisStatus =
            "analysis_status"
        case complianceScore =
            "compliance_score"
    }

    var isSmartSchedulingReady: Bool {
        analysisStatus == "compliant"
    }

    var smartPrepStatusText: String {
        switch analysisStatus {
        case "compliant":
            return "Ready"
        case "needs_review":
            return "Prep review required"
        case "failed":
            return "Prep analysis failed"
        case "analyzing":
            return "Analyzing"
        default:
            return "Prep analysis pending"
        }
    }

    var totalMinutes: Int {
        let exactTotal =
            (preparationMinutes ?? 0)
            + (cookingMinutes ?? 0)
            + (cleanupMinutes ?? 0)

        guard exactTotal > 0 else {
            return 0
        }

        return max(
            5,
            Int(
                (
                    Double(exactTotal)
                    / 5.0
                ).rounded()
            ) * 5
        )
    }

    var totalTimeText: String {
        totalMinutes > 0
            ? "\(totalMinutes) min"
            : "Time unavailable"
    }

    var subtitle: String {
        let types = mealTypes.isEmpty
            ? "Uncategorized"
            : mealTypes
                .map(\.capitalized)
                .joined(separator: " • ")

        return "\(types) • \(totalTimeText) • \(creatorName)"
    }
}

nonisolated struct WeekPlanEntry: Codable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID
    let weekStart: String
    let mealDate: String
    let mealSlotID: UUID
    let recipeID: UUID
    var servings: Double
    var notes: String
    var position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case weekStart = "week_start"
        case mealDate = "meal_date"
        case mealSlotID = "meal_slot_id"
        case recipeID = "recipe_id"
        case servings, notes, position
    }
}

nonisolated struct WeekPlanEntryInsert: Encodable {
    let userID: UUID
    let weekStart: String
    let mealDate: String
    let mealSlotID: UUID
    let recipeID: UUID
    let servings: Double
    let notes: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case weekStart = "week_start"
        case mealDate = "meal_date"
        case mealSlotID = "meal_slot_id"
        case recipeID = "recipe_id"
        case servings, notes, position
    }
}

nonisolated struct WeekPlanEntryUpdate: Encodable {
    let servings: Double
    let notes: String
    let position: Int
}

nonisolated struct WeekStartPreference: Decodable {
    let weekStartsOn: String
    enum CodingKeys: String, CodingKey {
        case weekStartsOn = "week_starts_on"
    }
}

nonisolated struct PlannedRecipeItem: Identifiable {
    let entry: WeekPlanEntry
    let recipe: WeekRecipeSummary
    var id: UUID { entry.id }
}
