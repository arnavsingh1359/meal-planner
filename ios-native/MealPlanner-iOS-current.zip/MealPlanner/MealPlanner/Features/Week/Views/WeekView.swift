import SwiftUI

struct WeekView: View {
    let targetDate: Date?

    init(targetDate: Date? = nil) {
        self.targetDate = targetDate
    }

    @Environment(AppRefreshCoordinator.self)
    private var refreshCoordinator

    @State private var store = WeekStore()
    @State private var lastSeenRefreshVersion = -1
    @State private var pickerContext: PickerContext?
    @State private var editingItem: PlannedRecipeItem?
    @State private var clearSlotContext: ClearSlotContext?
    @State private var showClearSlotConfirmation = false
    @State private var showClearDay = false
    @State private var showCopyDaySheet = false
    @State private var appliedTargetDate: Date?

    var body: some View {
        Group {
            if store.isLoading && !store.hasLoaded {
                ProgressView("Loading week…")
            } else {
                content
            }
        }
        .navigationTitle("Week")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button {
                        showCopyDaySheet = true
                    } label: {
                        Label(
                            "Copy meals of day",
                            systemImage: "doc.on.doc"
                        )
                    }

                    Button(role: .destructive) {
                        showClearDay = true
                    } label: {
                        Label("Clear day", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .task {
            await refreshIfNeeded(force: !store.hasLoaded)
            await applyTargetDateIfNeeded()
        }
        .onAppear {
            Task {
                await refreshIfNeeded(force: false)
                await applyTargetDateIfNeeded()
            }
        }
        .onChange(of: targetDate) { _, _ in
            Task {
                await applyTargetDateIfNeeded()
            }
        }
        .onChange(of: refreshCoordinator.weekVersion) { _, _ in
            Task {
                await refreshIfNeeded(force: false)
            }
        }
        .sheet(item: $pickerContext) { context in
            RecipePickerView(
                recipes: store.recipes,
                slot: context.slot
            ) { recipe in
                Task {
                    let changed = await store.add(recipe, to: context.slot, on: context.date)
                    if changed {
                        refreshCoordinator.weekPlanChanged()
                    }
                }
            }
        }
        .sheet(item: $editingItem) { item in
            WeekMealEditorView(
                item: item,
                slots: store.selectedDaySlots
            ) { servings, notes in
                let changed = await store.update(item.entry, servings: servings, notes: notes)
                if changed {
                    refreshCoordinator.weekPlanChanged()
                }
                return changed
            } onMove: { slot in
                let changed = await store.move(item.entry, to: slot)
                if changed {
                    refreshCoordinator.weekPlanChanged()
                }
                return changed
            }
        }
        .sheet(
            isPresented: $showCopyDaySheet
        ) {
            CopyWeekDayView(
                sourceDate:
                    store.selectedDate,
                weekDates:
                    store.weekDates
            ) { destinationDate in
                Task {
                    let changed = await store.copyDay(
                        from:
                            store.selectedDate,
                        to:
                            destinationDate
                    )
                    if changed {
                        refreshCoordinator.weekPlanChanged()
                    }
                }
            }
        }
        .confirmationDialog(
            "Clear this meal slot?",
            isPresented: $showClearSlotConfirmation,
            titleVisibility: .visible
        ) {
            Button(
                "Clear slot",
                role: .destructive
            ) {
                guard let context =
                    clearSlotContext
                else {
                    return
                }

                Task {
                    await store.clear(
                        slot: context.slot,
                        on: context.date
                    )
                    refreshCoordinator.weekPlanChanged()
                    clearSlotContext = nil
                }
            }

            Button(
                "Cancel",
                role: .cancel
            ) {
                clearSlotContext = nil
            }
        }
        .confirmationDialog(
            "Clear all meals for this day?",
            isPresented: $showClearDay,
            titleVisibility: .visible
        ) {
            Button("Clear day", role: .destructive) {
                Task {
                    await store.clearDay(store.selectedDate)
                    refreshCoordinator.weekPlanChanged()
                }
            }
            Button("Cancel", role: .cancel) {}
        }
    }



    private func applyTargetDateIfNeeded() async {
        guard let targetDate, targetDate != appliedTargetDate else {
            return
        }

        appliedTargetDate = targetDate
        await store.goToWeek(containing: targetDate)
    }

    private func refreshIfNeeded(force: Bool) async {
        let version = refreshCoordinator.weekVersion

        guard force || version != lastSeenRefreshVersion else {
            return
        }

        lastSeenRefreshVersion = version
        await store.refresh()
    }

    private var content: some View {
        ScrollView {
            VStack(spacing: 14) {
                weekNavigation
                daySelector

                if let error = store.errorMessage {
                    Label(error, systemImage: "exclamationmark.triangle.fill")
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                }

                if store.selectedDaySlots.isEmpty {
                    ContentUnavailableView(
                        "No meal slots",
                        systemImage: "calendar.badge.exclamationmark",
                        description: Text("Add meal slots for this day in Settings.")
                    )
                } else {
                    ForEach(store.selectedDaySlots) { slot in
                        slotCard(slot)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
        }
        .background(Color(.systemGroupedBackground))
        .refreshable { await store.refresh() }
    }

    private var weekNavigation: some View {
        HStack {
            Button {
                Task { await store.moveWeek(-1) }
            } label: {
                Image(systemName: "chevron.left")
            }
            .buttonStyle(.bordered)

            VStack(spacing: 2) {
                Text(store.weekTitle).font(.headline)
                Button("Today") {
                    Task { await store.goToToday() }
                }
                .font(.caption)
            }
            .frame(maxWidth: .infinity)

            Button {
                Task { await store.moveWeek(1) }
            } label: {
                Image(systemName: "chevron.right")
            }
            .buttonStyle(.bordered)
        }
    }

    private var daySelector: some View {
        GeometryReader { geometry in
            let spacing: CGFloat = 6
            let width = (geometry.size.width - spacing * 6) / 7

            HStack(spacing: spacing) {
                ForEach(store.weekDates, id: \.self) { date in
                    let selected = Calendar.current.isDate(
                        date,
                        inSameDayAs: store.selectedDate
                    )

                    Button {
                        store.selectDate(date)
                    } label: {
                        VStack(spacing: 3) {
                            Text(date.formatted(.dateTime.weekday(.narrow)))
                                .font(.caption2)
                            Text(date.formatted(.dateTime.day()))
                                .font(.subheadline.weight(.semibold))
                        }
                        .foregroundStyle(selected ? .white : .primary)
                        .frame(width: width, height: 48)
                        .background(
                            selected ? Color.green : Color(.secondarySystemGroupedBackground),
                            in: RoundedRectangle(cornerRadius: 12)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .frame(height: 48)
    }

    private func slotCard(_ slot: WeekMealSlot) -> some View {
        let items = store.items(for: slot, on: store.selectedDate)

        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(slot.name).font(.headline)
                    Text(slot.eatTime.prefix(5))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Menu {
                    Button {
                        pickerContext = PickerContext(slot: slot, date: store.selectedDate)
                    } label: {
                        Label("Add recipe", systemImage: "plus")
                    }

                    if !items.isEmpty {
                        Button(role: .destructive) {
                            clearSlotContext =
                                ClearSlotContext(
                                    slot: slot,
                                    date:
                                        store.selectedDate
                                )
                            showClearSlotConfirmation =
                                true
                        } label: {
                            Label("Clear slot", systemImage: "trash")
                        }
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }

            if items.isEmpty {
                Button {
                    pickerContext = PickerContext(slot: slot, date: store.selectedDate)
                } label: {
                    Label("Add recipe", systemImage: "plus.circle")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .tint(.green)
            } else {
                ForEach(items) { item in
                    Button {
                        editingItem = item
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.recipe.name)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                HStack(spacing: 6) {
                                    Text(
                                        "\(servingsText(item.entry.servings)) servings"
                                    )

                                    Text("•")

                                    Label(
                                        item.recipe
                                            .totalTimeText,
                                        systemImage:
                                            "clock"
                                    )
                                }
                                .font(.caption)
                                .foregroundStyle(
                                    .secondary
                                )
                                if !item.entry.notes.isEmpty {
                                    Text(item.entry.notes)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(2)
                                }
                            }

                            Spacer()

                            Button(role: .destructive) {
                                Task {
                                    await store.remove(item.entry)
                                    refreshCoordinator.weekPlanChanged()
                                }
                            } label: {
                                Image(systemName: "trash")
                            }
                            .buttonStyle(.borderless)
                        }
                    }
                    .buttonStyle(.plain)

                    if item.id != items.last?.id {
                        Divider()
                    }
                }
            }
        }
        .padding(16)
        .background(
            Color(.secondarySystemGroupedBackground),
            in: RoundedRectangle(cornerRadius: 18)
        )
    }

    private func servingsText(_ value: Double) -> String {
        value.rounded() == value
            ? String(Int(value))
            : value.formatted(.number.precision(.fractionLength(0...1)))
    }
}

private struct PickerContext: Identifiable {
    let slot: WeekMealSlot
    let date: Date
    var id: String { slot.id.uuidString + date.timeIntervalSince1970.description }
}

private struct ClearSlotContext: Identifiable {
    let slot: WeekMealSlot
    let date: Date
    var id: String { slot.id.uuidString + date.timeIntervalSince1970.description }
}

private struct WeekMealEditorView: View {
    let item: PlannedRecipeItem
    let slots: [WeekMealSlot]
    let onSave: (Double, String) async -> Bool
    let onMove: (WeekMealSlot) async -> Bool

    @Environment(\.dismiss) private var dismiss
    @State private var servings: Double
    @State private var notes: String
    @State private var targetSlotID: UUID

    init(
        item: PlannedRecipeItem,
        slots: [WeekMealSlot],
        onSave: @escaping (Double, String) async -> Bool,
        onMove: @escaping (WeekMealSlot) async -> Bool
    ) {
        self.item = item
        self.slots = slots
        self.onSave = onSave
        self.onMove = onMove
        _servings = State(initialValue: item.entry.servings)
        _notes = State(initialValue: item.entry.notes)
        _targetSlotID = State(initialValue: item.entry.mealSlotID)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Meal") {
                    LabeledContent("Recipe", value: item.recipe.name)

                    Stepper(value: $servings, in: 0.5...100, step: 0.5) {
                        LabeledContent(
                            "Servings",
                            value: servings.formatted(.number.precision(.fractionLength(0...1)))
                        )
                    }

                    TextField("Notes", text: $notes, axis: .vertical)
                        .lineLimit(2...5)
                }

                Section("Move") {
                    Picker("Meal slot", selection: $targetSlotID) {
                        ForEach(slots) { slot in
                            Text(slot.name).tag(slot.id)
                        }
                    }
                }
            }
            .navigationTitle("Edit meal")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        Task {
                            let saved = await onSave(servings, notes)
                            var moved = true

                            if targetSlotID != item.entry.mealSlotID,
                               let target = slots.first(where: { $0.id == targetSlotID }) {
                                moved = await onMove(target)
                            }

                            if saved && moved { dismiss() }
                        }
                    }
                }
            }
        }
    }
}


private struct CopyWeekDayView: View {
    let sourceDate: Date
    let weekDates: [Date]
    let onCopy: (Date) -> Void

    @Environment(\.dismiss)
    private var dismiss

    var body: some View {
        NavigationStack {
            List(
                weekDates.filter {
                    !Calendar.current.isDate(
                        $0,
                        inSameDayAs:
                            sourceDate
                    )
                },
                id: \.self
            ) { date in
                Button {
                    onCopy(date)
                    dismiss()
                } label: {
                    HStack {
                        VStack(
                            alignment: .leading,
                            spacing: 3
                        ) {
                            Text(
                                date.formatted(
                                    .dateTime
                                        .weekday(.wide)
                                )
                            )
                            .foregroundStyle(
                                .primary
                            )

                            Text(
                                date.formatted(
                                    .dateTime
                                        .month(
                                            .abbreviated
                                        )
                                        .day()
                                )
                            )
                            .font(.caption)
                            .foregroundStyle(
                                .secondary
                            )
                        }

                        Spacer()

                        Image(
                            systemName:
                                "doc.on.doc"
                        )
                        .foregroundStyle(
                            .green
                        )
                    }
                }
                .buttonStyle(.plain)
            }
            .navigationTitle(
                "Copy meals to"
            )
            .navigationBarTitleDisplayMode(
                .inline
            )
            .toolbar {
                ToolbarItem(
                    placement:
                        .cancellationAction
                ) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }
}
