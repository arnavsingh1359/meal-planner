import SwiftUI

struct RecipePickerView: View {
    let recipes: [WeekRecipeSummary]
    let slot: WeekMealSlot
    let onSelect:
        (WeekRecipeSummary) -> Void

    @Environment(\.dismiss)
    private var dismiss

    @State private var searchText = ""
    @State private var selectedMealType: String

    init(
        recipes: [WeekRecipeSummary],
        slot: WeekMealSlot,
        onSelect:
            @escaping (WeekRecipeSummary) -> Void
    ) {
        self.recipes = recipes
        self.slot = slot
        self.onSelect = onSelect

        let preferredType =
            slot.recipeCategory.lowercased()

        _selectedMealType = State(
            initialValue:
                preferredType == "any"
                ? "all"
                : preferredType
        )
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker(
                        "Meal type",
                        selection: $selectedMealType
                    ) {
                        Text("All")
                            .tag("all")

                        ForEach(
                            availableMealTypes,
                            id: \.self
                        ) { mealType in
                            Text(
                                mealType.capitalized
                            )
                            .tag(mealType)
                        }
                    }
                    .pickerStyle(.menu)
                }

                ForEach(
                    groupedReadyRecipes,
                    id: \.mealType
                ) { group in
                    Section(
                        group.mealType.capitalized
                    ) {
                        ForEach(
                            group.recipes
                        ) { recipe in
                            Button {
                                onSelect(recipe)
                                dismiss()
                            } label: {
                                recipeRow(
                                    recipe,
                                    enabled: true
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                if !reviewRecipes.isEmpty {
                    Section {
                        ForEach(
                            reviewRecipes
                        ) { recipe in
                            recipeRow(
                                recipe,
                                enabled: false
                            )
                            .opacity(0.75)
                        }
                    } header: {
                        Label(
                            "Needs prep review",
                            systemImage:
                                "exclamationmark.triangle.fill"
                        )
                        .foregroundStyle(.orange)
                    } footer: {
                        Text(
                            "These recipes cannot be added to the Week plan. Open each recipe, resolve its ingredient and preparation warnings, and save it again."
                        )
                    }
                }
            }
            .navigationTitle(
                "Choose for \(slot.name)"
            )
            .navigationBarTitleDisplayMode(
                .inline
            )
            .searchable(
                text: $searchText,
                prompt:
                    "Search recipes or creators"
            )
            .toolbar {
                ToolbarItem(
                    placement:
                        .cancellationAction
                ) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .overlay {
                if visibleRecipes.isEmpty {
                    ContentUnavailableView(
                        "No matching recipes",
                        systemImage:
                            "magnifyingglass",
                        description: Text(
                            "Try another meal type or search."
                        )
                    )
                } else if readyRecipes.isEmpty
                    && reviewRecipes.isEmpty {
                    ContentUnavailableView(
                        "No schedule-ready recipes",
                        systemImage:
                            "exclamationmark.triangle",
                        description: Text(
                            "Review and save a recipe before adding it to the Week plan."
                        )
                    )
                }
            }
        }
    }

    @ViewBuilder
    private func recipeRow(
        _ recipe: WeekRecipeSummary,
        enabled: Bool
    ) -> some View {
        HStack(
            alignment: .top,
            spacing: 10
        ) {
            VStack(
                alignment: .leading,
                spacing: 4
            ) {
                Text(recipe.name)
                    .font(.headline)
                    .foregroundStyle(
                        enabled
                        ? Color.primary
                        : Color.secondary
                    )

                Text(recipe.subtitle)
                    .font(.caption)
                    .foregroundStyle(
                        .secondary
                    )
            }

            Spacer()

            if enabled {
                Image(
                    systemName:
                        "checkmark.circle.fill"
                )
                .foregroundStyle(.green)
                .accessibilityLabel(
                    "Ready for smart scheduling"
                )
            } else {
                VStack(
                    alignment: .trailing,
                    spacing: 3
                ) {
                    Image(
                        systemName:
                            "exclamationmark.triangle.fill"
                    )
                    .foregroundStyle(.orange)

                    Text(
                        recipe.smartPrepStatusText
                    )
                    .font(.caption2)
                    .foregroundStyle(
                        .orange
                    )
                    .multilineTextAlignment(
                        .trailing
                    )
                }
            }
        }
        .padding(.vertical, 4)
    }

    private var visibleRecipes:
        [WeekRecipeSummary] {
        let cleanedSearch =
            searchText.trimmingCharacters(
                in:
                    .whitespacesAndNewlines
            )
            .lowercased()

        return recipes.filter { recipe in
            let matchesMealType =
                selectedMealType == "all"
                || recipe.mealTypes.contains {
                    $0.caseInsensitiveCompare(
                        selectedMealType
                    ) == .orderedSame
                }

            guard matchesMealType else {
                return false
            }

            guard !cleanedSearch.isEmpty else {
                return true
            }

            return recipe.name
                .lowercased()
                .contains(cleanedSearch)
                || recipe.creatorName
                    .lowercased()
                    .contains(cleanedSearch)
                || recipe.mealTypes
                    .joined(separator: " ")
                    .lowercased()
                    .contains(cleanedSearch)
        }
    }

    private var readyRecipes:
        [WeekRecipeSummary] {
        visibleRecipes.filter(
            \.isSmartSchedulingReady
        )
    }

    private var reviewRecipes:
        [WeekRecipeSummary] {
        visibleRecipes
            .filter {
                !$0.isSmartSchedulingReady
            }
            .sorted {
                $0.name
                    .localizedCaseInsensitiveCompare(
                        $1.name
                    )
                    == .orderedAscending
            }
    }

    private var availableMealTypes:
        [String] {
        let discovered = Set(
            recipes.flatMap {
                $0.mealTypes.map {
                    $0.lowercased()
                }
            }
        )

        let preferred =
            slot.recipeCategory.lowercased()

        return discovered.sorted {
            if $0 == preferred {
                return true
            }

            if $1 == preferred {
                return false
            }

            return mealTypeRank($0)
                < mealTypeRank($1)
        }
    }

    private var groupedReadyRecipes:
        [RecipeMealTypeGroup] {
        let preferred =
            slot.recipeCategory.lowercased()

        let grouped = Dictionary(
            grouping: readyRecipes
        ) { recipe in
            primaryMealType(
                for: recipe,
                preferred: preferred
            )
        }

        return grouped
            .map {
                RecipeMealTypeGroup(
                    mealType: $0.key,
                    recipes:
                        $0.value.sorted {
                            $0.name
                                .localizedCaseInsensitiveCompare(
                                    $1.name
                                )
                                == .orderedAscending
                        }
                )
            }
            .sorted {
                if $0.mealType
                    == preferred {
                    return true
                }

                if $1.mealType
                    == preferred {
                    return false
                }

                return mealTypeRank(
                    $0.mealType
                ) < mealTypeRank(
                    $1.mealType
                )
            }
    }

    private func primaryMealType(
        for recipe: WeekRecipeSummary,
        preferred: String
    ) -> String {
        if recipe.mealTypes.contains(
            where: {
                $0.caseInsensitiveCompare(
                    preferred
                ) == .orderedSame
            }
        ) {
            return preferred
        }

        return recipe.mealTypes
            .map {
                $0.lowercased()
            }
            .sorted {
                mealTypeRank($0)
                    < mealTypeRank($1)
            }
            .first
            ?? "uncategorized"
    }

    private func mealTypeRank(
        _ value: String
    ) -> Int {
        switch value.lowercased() {
        case "breakfast":
            return 0
        case "lunch":
            return 1
        case "snack":
            return 2
        case "dinner":
            return 3
        default:
            return 4
        }
    }
}

private struct RecipeMealTypeGroup {
    let mealType: String
    let recipes: [WeekRecipeSummary]
}
