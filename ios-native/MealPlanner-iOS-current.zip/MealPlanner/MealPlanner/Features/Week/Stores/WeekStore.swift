import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class WeekStore {
    private(set) var isLoading = false
    private(set) var hasLoaded = false
    private(set) var slots: [WeekMealSlot] = []
    private(set) var recipes: [WeekRecipeSummary] = []
    private(set) var entries: [WeekPlanEntry] = []

    var selectedDate = Date()
    var weekStartDate = Date()
    var errorMessage: String?

    private var currentUserID: UUID?
    private var mondayStart = true
    private var calendar = Calendar.current

    var weekDates: [Date] {
        (0..<7).compactMap {
            calendar.date(byAdding: .day, value: $0, to: weekStartDate)
        }
    }

    var weekTitle: String {
        guard let end = weekDates.last else { return "" }
        return "\(weekStartDate.formatted(.dateTime.month(.abbreviated).day())) – \(end.formatted(.dateTime.month(.abbreviated).day().year()))"
    }

    var selectedDaySlots: [WeekMealSlot] {
        let day = schedulerDay(for: selectedDate)
        return slots.filter { $0.dayOfWeek == day }
            .sorted { $0.position < $1.position }
    }

    func load() async {
        guard !isLoading else { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            let session = try await AppSupabase.client.auth.session
            currentUserID = session.user.id

            let preference: WeekStartPreference = try await AppSupabase.client
                .from("account_preferences")
                .select("week_starts_on")
                .eq("user_id", value: session.user.id.uuidString)
                .single()
                .execute()
                .value

            mondayStart = preference.weekStartsOn.lowercased() != "sunday"
            weekStartDate = startOfWeek(containing: selectedDate)

            async let slotRequest: [WeekMealSlot] = AppSupabase.client
                .from("meal_slot_preferences")
                .select("id,day_of_week,position,name,recipe_category,eat_time,ready_time,preparation_mode")
                .eq("user_id", value: session.user.id.uuidString)
                .order("day_of_week", ascending: true)
                .order("position", ascending: true)
                .execute()
                .value

            async let recipeRequest: [WeekRecipeSummary] = AppSupabase.client
                .from("recipes")
                .select(
                    """
                    id,
                    name,
                    meal_types,
                    default_servings,
                    preparation_minutes,
                    cooking_minutes,
                    cleanup_minutes,
                    creator_name,
                    analysis_status,
                    compliance_score
                    """
                )
                .order("name", ascending: true)
                .execute()
                .value

            slots = try await slotRequest
            recipes = try await recipeRequest
            try await loadEntries()
            hasLoaded = true
        } catch {
            if !(error is CancellationError) {
                errorMessage = error.localizedDescription
            }
        }
    }

    func refresh() async { await load() }

    func selectDate(_ date: Date) {
        selectedDate = date
    }

    func moveWeek(_ offset: Int) async {
        guard let date = calendar.date(byAdding: .day, value: offset * 7, to: weekStartDate) else { return }
        weekStartDate = date
        selectedDate = date
        await reloadEntries()
    }

    func goToToday() async {
        selectedDate = Date()
        weekStartDate = startOfWeek(containing: selectedDate)
        await reloadEntries()
    }

    func goToWeek(containing date: Date) async {
        selectedDate = date
        weekStartDate = startOfWeek(containing: date)

        if hasLoaded {
            await reloadEntries()
        } else {
            await load()
            selectedDate = date
            weekStartDate = startOfWeek(containing: date)
            await reloadEntries()
        }
    }

    func items(for slot: WeekMealSlot, on date: Date) -> [PlannedRecipeItem] {
        let key = dateString(date)
        return entries
            .filter { $0.mealDate == key && $0.mealSlotID == slot.id }
            .sorted { $0.position < $1.position }
            .compactMap { entry in
                guard let recipe = recipes.first(where: { $0.id == entry.recipeID }) else { return nil }
                return PlannedRecipeItem(entry: entry, recipe: recipe)
            }
    }

    func add(
        _ recipe: WeekRecipeSummary,
        to slot: WeekMealSlot,
        on date: Date
    ) async -> Bool {
        guard let currentUserID else {
            return false
        }

        guard recipe.isSmartSchedulingReady else {
            errorMessage =
                "“\(recipe.name)” cannot be added to the Week plan because its smart-prep review is incomplete. Open the recipe, resolve every ingredient and preparation warning, then save it again."
            return false
        }

        do {
            let payload = WeekPlanEntryInsert(
                userID: currentUserID,
                weekStart: dateString(weekStartDate),
                mealDate: dateString(date),
                mealSlotID: slot.id,
                recipeID: recipe.id,
                servings: recipe.defaultPlannedServings,
                notes: "",
                position: items(for: slot, on: date).count
            )

            let entry: WeekPlanEntry = try await AppSupabase.client
                .from("week_plan_entries")
                .insert(payload)
                .select()
                .single()
                .execute()
                .value

            entries.append(entry)
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func update(_ entry: WeekPlanEntry, servings: Double, notes: String) async -> Bool {
        guard servings > 0 else {
            errorMessage = "Servings must be greater than zero."
            return false
        }

        do {
            let updated: WeekPlanEntry = try await AppSupabase.client
                .from("week_plan_entries")
                .update(
                    WeekPlanEntryUpdate(
                        servings: servings,
                        notes: notes.trimmingCharacters(in: .whitespacesAndNewlines),
                        position: entry.position
                    )
                )
                .eq("id", value: entry.id.uuidString)
                .select()
                .single()
                .execute()
                .value

            replace(updated)
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func remove(_ entry: WeekPlanEntry) async {
        do {
            try await AppSupabase.client
                .from("week_plan_entries")
                .delete()
                .eq("id", value: entry.id.uuidString)
                .execute()

            entries.removeAll { $0.id == entry.id }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func clear(slot: WeekMealSlot, on date: Date) async {
        for item in items(for: slot, on: date) {
            await remove(item.entry)
        }
    }

    func clearDay(_ date: Date) async {
        let key = dateString(date)
        for entry in entries.filter({ $0.mealDate == key }) {
            await remove(entry)
        }
    }

    func move(_ entry: WeekPlanEntry, to slot: WeekMealSlot) async -> Bool {
        struct Payload: Encodable {
            let mealSlotID: UUID
            let position: Int
            enum CodingKeys: String, CodingKey {
                case mealSlotID = "meal_slot_id"
                case position
            }
        }

        do {
            let updated: WeekPlanEntry = try await AppSupabase.client
                .from("week_plan_entries")
                .update(
                    Payload(
                        mealSlotID: slot.id,
                        position: items(for: slot, on: selectedDate).count
                    )
                )
                .eq("id", value: entry.id.uuidString)
                .select()
                .single()
                .execute()
                .value

            replace(updated)
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }


    func copyDay(
        from sourceDate: Date,
        to destinationDate: Date
    ) async -> Bool {
        let sourceKey =
            dateString(sourceDate)

        let sourceEntries =
            entries.filter {
                $0.mealDate == sourceKey
            }
            .sorted {
                if $0.mealSlotID
                    == $1.mealSlotID {
                    return $0.position
                        < $1.position
                }

                return $0.mealSlotID
                    .uuidString
                    < $1.mealSlotID
                        .uuidString
            }

        guard !sourceEntries.isEmpty else {
            errorMessage =
                "There are no meals to copy."
            return false
        }

        let sourceDay =
            schedulerDay(for: sourceDate)

        let destinationDay =
            schedulerDay(
                for: destinationDate
            )

        let sourceSlots =
            slots.filter {
                $0.dayOfWeek == sourceDay
            }

        let destinationSlots =
            slots.filter {
                $0.dayOfWeek
                    == destinationDay
            }

        var copiedAny = false

        for entry in sourceEntries {
            guard let recipe =
                recipes.first(
                    where: {
                        $0.id
                            == entry.recipeID
                    }
                ),
                  recipe.isSmartSchedulingReady,
                  let sourceSlot =
                sourceSlots.first(
                    where: {
                        $0.id
                            == entry.mealSlotID
                    }
                ),
                  let targetSlot =
                destinationSlots.first(
                    where: {
                        $0.position
                            == sourceSlot.position
                    }
                )
                ?? destinationSlots.first(
                    where: {
                        $0.recipeCategory
                            == sourceSlot
                                .recipeCategory
                    }
                )
            else {
                continue
            }

            let added = await add(
                recipe,
                to: targetSlot,
                on: destinationDate
            )

            if added {
                copiedAny = true

                guard let newestIndex =
                    entries.indices.last
                else {
                    continue
                }

                var newest =
                    entries[newestIndex]

                let updated = await update(
                    newest,
                    servings:
                        entry.servings,
                    notes:
                        entry.notes
                )

                if updated {
                    newest.servings =
                        entry.servings
                    newest.notes =
                        entry.notes
                }
            }
        }

        if copiedAny {
            errorMessage = nil
        }

        return copiedAny
    }

    private func reloadEntries() async {
        do { try await loadEntries() }
        catch { errorMessage = error.localizedDescription }
    }

    private func loadEntries() async throws {
        guard let end = calendar.date(byAdding: .day, value: 6, to: weekStartDate) else {
            entries = []
            return
        }

        entries = try await AppSupabase.client
            .from("week_plan_entries")
            .select()
            .gte("meal_date", value: dateString(weekStartDate))
            .lte("meal_date", value: dateString(end))
            .order("meal_date", ascending: true)
            .order("position", ascending: true)
            .execute()
            .value
    }

    private func replace(_ entry: WeekPlanEntry) {
        if let index = entries.firstIndex(where: { $0.id == entry.id }) {
            entries[index] = entry
        } else {
            entries.append(entry)
        }
    }

    private func startOfWeek(containing date: Date) -> Date {
        let startWeekday = mondayStart ? 2 : 1
        let weekday = calendar.component(.weekday, from: date)
        let offset = (weekday - startWeekday + 7) % 7
        let start = calendar.date(byAdding: .day, value: -offset, to: date) ?? date
        return calendar.startOfDay(for: start)
    }

    private func schedulerDay(for date: Date) -> Int {
        let weekday = calendar.component(.weekday, from: date)
        return weekday == 1 ? 7 : weekday - 1
    }

    private func dateString(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = calendar
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }
}
