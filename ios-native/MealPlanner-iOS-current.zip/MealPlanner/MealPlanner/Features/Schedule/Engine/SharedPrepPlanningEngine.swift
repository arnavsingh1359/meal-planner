import Foundation

nonisolated struct SharedPrepOperationCandidate:
    Identifiable,
    Hashable {

    let id: String
    let batch: RecipeProductionBatch
    let operation: ScheduleRecipePrepOperation
    let recipeName: String
    let recipeBaseServings: Double
    let matchedTask: ScheduleRecipeTask?

    var scaledQuantity: Double {
        guard recipeBaseServings > 0 else {
            return operation.quantity
        }

        return operation.quantity
            * batch.totalServings
            / recipeBaseServings
    }

    var matchedTaskID: UUID? {
        matchedTask?.id
    }
}

nonisolated struct SharedPrepOperationGroup:
    Identifiable,
    Hashable {

    let id: UUID
    let key: String
    let title: String
    let preparationDate: Date
    let activeMinutes: Int
    let passiveMinutes: Int
    let totalQuantity: Double
    let unit: String
    let candidates:
        [SharedPrepOperationCandidate]
    let explanation: String

    var primaryCandidate:
        SharedPrepOperationCandidate {
        candidates[0]
    }

    var recipeIDs: [UUID] {
        Array(
            Set(
                candidates.map {
                    $0.batch.recipeID
                }
            )
        )
    }

    var recipeNames: [String] {
        Array(
            Set(
                candidates.map(
                    \.recipeName
                )
            )
        )
        .sorted()
    }

    var coveredEntryIDs: [UUID] {
        Array(
            Set(
                candidates.flatMap {
                    $0.batch
                        .coveredEntryIDs
                }
            )
        )
    }

    var matchedTaskIDs: [UUID] {
        Array(
            Set(
                candidates.compactMap(
                    \.matchedTaskID
                )
            )
        )
    }

    var candidateIDs: Set<String> {
        Set(
            candidates.map(\.id)
        )
    }
}

nonisolated enum SharedPrepPlanningEngine {
    static func makeGroups(
        candidates:
            [SharedPrepOperationCandidate],
        preferredBatchDays: [String],
        weekDates: [Date],
        calendar: Calendar = .current
    ) -> [SharedPrepOperationGroup] {
        let eligible =
            candidates.filter {
                candidate in

                let operation =
                    candidate.operation

                return operation.canMakeAhead
                    && operation
                        .maximumMakeAheadHours
                    > 0
                    && operation.confidence
                    >= 0.75
                    && !operation.batchKey
                        .trimmingCharacters(
                            in:
                                .whitespacesAndNewlines
                        )
                        .isEmpty
                    && operation.storageMethod
                        != "none"
                    && candidate.scaledQuantity
                        > 0
            }

        let grouped =
            Dictionary(
                grouping: eligible
            ) {
                candidate in

                [
                    candidate.operation
                        .batchKey
                        .lowercased(),
                    normalizedUnit(
                        candidate.operation
                            .unit
                    ),
                    candidate.operation
                        .storageMethod
                        .lowercased()
                ]
                .joined(separator: "|")
            }

        return grouped.compactMap {
            _,
            members in

            let distinctRecipes =
                Set(
                    members.map {
                        $0.batch.recipeID
                    }
                )

            guard members.count > 1,
                  distinctRecipes.count > 1
            else {
                return nil
            }

            let ordered =
                members.sorted {
                    lhs,
                    rhs in

                    if lhs.batch
                        .preparationDate
                        == rhs.batch
                            .preparationDate {
                        return lhs.recipeName
                            < rhs.recipeName
                    }

                    return lhs.batch
                        .preparationDate
                        < rhs.batch
                            .preparationDate
                }

            guard let earliestUse =
                ordered.first?
                    .batch
                    .preparationDate
            else {
                return nil
            }

            let maximumMakeAheadHours =
                ordered.map {
                    $0.operation
                        .maximumMakeAheadHours
                }
                .min()
                ?? 0

            guard maximumMakeAheadHours
                    > 0
            else {
                return nil
            }

            let earliestSafeDate =
                calendar.date(
                    byAdding: .hour,
                    value:
                        -maximumMakeAheadHours,
                    to: earliestUse
                )
                ?? earliestUse

            let preparationDate =
                choosePreparationDate(
                    earliestSafeDate:
                        earliestSafeDate,
                    latestDate:
                        earliestUse,
                    preferredBatchDays:
                        preferredBatchDays,
                    weekDates:
                        weekDates,
                    calendar:
                        calendar
                )

            let activeValues =
                ordered.map(
                    estimatedActiveMinutes
                )

            let largestActive =
                activeValues.max()
                ?? 1

            let remainingActive =
                max(
                    0,
                    activeValues.reduce(
                        0,
                        +
                    )
                    - largestActive
                )

            let combinedActive =
                largestActive
                + Int(
                    ceil(
                        Double(
                            remainingActive
                        ) * 0.45
                    )
                )

            let combinedPassive =
                ordered.compactMap {
                    $0.matchedTask?
                        .passiveMinutes
                }
                .max()
                ?? 0

            let totalQuantity =
                ordered.reduce(0) {
                    $0
                    + $1.scaledQuantity
                }

            let operation =
                ordered[0].operation

            let recipeNames =
                Array(
                    distinctRecipes.compactMap {
                        recipeID in

                        ordered.first {
                            $0.batch.recipeID
                                == recipeID
                        }?
                        .recipeName
                    }
                )
                .sorted()

            let quantityText =
                formattedQuantity(
                    totalQuantity,
                    unit:
                        operation.unit
                )

            let explanation =
                """
                Prepare \(quantityText) of \(operation.canonicalIngredientName) as \(operation.preparationState). This single task covers \(ordered.count) planned recipe batches across \(recipeNames.count) recipes: \(recipeNames.joined(separator: ", ")). It is scheduled on \(preparationDate.formatted(.dateTime.weekday(.wide).month(.abbreviated).day())) inside the shortest \(maximumMakeAheadHours)-hour refrigerated storage window.
                """

            return SharedPrepOperationGroup(
                id: UUID(),
                key:
                    operation.batchKey,
                title:
                    sharedTitle(
                        action:
                            operation.action,
                        ingredient:
                            operation
                                .canonicalIngredientName
                    ),
                preparationDate:
                    calendar.startOfDay(
                        for:
                            preparationDate
                    ),
                activeMinutes:
                    max(
                        1,
                        combinedActive
                    ),
                passiveMinutes:
                    combinedPassive,
                totalQuantity:
                    totalQuantity,
                unit:
                    operation.unit,
                candidates:
                    ordered,
                explanation:
                    explanation
            )
        }
        .sorted {
            lhs,
            rhs in

            if lhs.preparationDate
                == rhs.preparationDate {
                return lhs.title
                    < rhs.title
            }

            return lhs.preparationDate
                < rhs.preparationDate
        }
    }

    private static func estimatedActiveMinutes(
        _ candidate:
            SharedPrepOperationCandidate
    ) -> Int {
        if let task =
            candidate.matchedTask,
           task.activeMinutes > 0 {
            let ratio =
                max(
                    1,
                    candidate.batch
                        .totalServings
                    / max(
                        0.5,
                        candidate
                            .recipeBaseServings
                    )
                )

            let multiplier =
                1
                + 0.35
                * (
                    ratio - 1
                )

            return max(
                task.activeMinutes,
                Int(
                    ceil(
                        Double(
                            task.activeMinutes
                        )
                        * multiplier
                    )
                )
            )
        }

        switch candidate
            .operation
            .action
            .lowercased() {
        case "wash",
             "rinse",
             "drain",
             "trim":
            return 2

        case "mince",
             "grate",
             "crush":
            return 3

        case "dice",
             "slice",
             "chop",
             "cube",
             "julienne",
             "shred":
            return 5

        case "soak",
             "marinate":
            return 5

        case "cook",
             "boil",
             "steam",
             "roast":
            return 8

        default:
            return 4
        }
    }

    private static func choosePreparationDate(
        earliestSafeDate: Date,
        latestDate: Date,
        preferredBatchDays: [String],
        weekDates: [Date],
        calendar: Calendar
    ) -> Date {
        let preferred =
            Set(
                preferredBatchDays.map {
                    $0.lowercased()
                }
            )

        let validDates =
            weekDates.filter {
                date in

                let start =
                    calendar.startOfDay(
                        for: date
                    )

                return start
                    >= calendar.startOfDay(
                        for:
                            earliestSafeDate
                    )
                    && start
                    <= calendar.startOfDay(
                        for:
                            latestDate
                    )
            }

        let preferredDates =
            validDates.filter {
                date in

                let day =
                    date.formatted(
                        .dateTime
                            .weekday(.wide)
                    )
                    .lowercased()

                return preferred
                    .contains(day)
            }

        if let preferredDate =
            preferredDates.max() {
            return preferredDate
        }

        if let dayBefore =
            calendar.date(
                byAdding: .day,
                value: -1,
                to: latestDate
            ),
           dayBefore
            >= earliestSafeDate {
            return dayBefore
        }

        return validDates.max()
            ?? latestDate
    }

    private static func normalizedUnit(
        _ unit: String
    ) -> String {
        switch unit
            .trimmingCharacters(
                in:
                    .whitespacesAndNewlines
            )
            .lowercased() {
        case "unit",
             "count",
             "piece",
             "pieces":
            return "unit"

        case "clove",
             "cloves":
            return "clove"

        case "g",
             "gram",
             "grams":
            return "g"

        case "kg",
             "kilogram",
             "kilograms":
            return "kg"

        case "ml",
             "milliliter",
             "milliliters":
            return "ml"

        case "l",
             "liter",
             "liters":
            return "l"

        case "tsp",
             "teaspoon",
             "teaspoons":
            return "tsp"

        case "tbsp",
             "tablespoon",
             "tablespoons":
            return "tbsp"

        default:
            return unit
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )
                .lowercased()
        }
    }

    private static func formattedQuantity(
        _ quantity: Double,
        unit: String
    ) -> String {
        let amount =
            quantity.formatted(
                .number.precision(
                    .fractionLength(0...2)
                )
            )

        let cleanedUnit =
            unit.trimmingCharacters(
                in:
                    .whitespacesAndNewlines
            )

        return cleanedUnit.isEmpty
            ? amount
            : "\(amount) \(cleanedUnit)"
    }

    private static func sharedTitle(
        action: String,
        ingredient: String
    ) -> String {
        "Shared prep: \(action.capitalized) \(ingredient)"
    }
}
