import Foundation

nonisolated struct BatchMealDemand: Identifiable, Hashable {
    let id: UUID
    let entry: WeekPlanEntry
    let mealDate: Date

    var servings: Double {
        entry.servings
    }
}

nonisolated struct BatchRecipePolicy: Hashable {
    let recipeID: UUID
    let recipeName: String
    let baseServings: Double
    let minimumBatchServings: Double
    let maximumBatchServings: Double
    let refrigeratorLifeDays: Int
    let allowsBatching: Bool
}

nonisolated struct RecipeProductionBatch: Identifiable, Hashable {
    let id: UUID
    let recipeID: UUID
    let recipeName: String
    let demands: [BatchMealDemand]
    let totalServings: Double
    let preparationDate: Date
    let isCombinedBatch: Bool
    let explanation: String

    var primaryEntry: WeekPlanEntry {
        demands[0].entry
    }

    var coveredEntryIDs: [UUID] {
        demands.map(\.entry.id)
    }

    var coveredMealCount: Int {
        demands.count
    }
}

nonisolated enum BatchPlanningEngine {
    static func makeBatches(
        demands: [BatchMealDemand],
        policies: [UUID: BatchRecipePolicy],
        calendar: Calendar = .current
    ) -> [RecipeProductionBatch] {
        let grouped = Dictionary(
            grouping: demands,
            by: { $0.entry.recipeID }
        )

        return grouped.flatMap { recipeID, recipeDemands in
            guard let policy = policies[recipeID] else {
                return recipeDemands.map {
                    singleBatch(
                        demand: $0,
                        recipeName: "Recipe"
                    )
                }
            }

            return makeRecipeBatches(
                demands: recipeDemands,
                policy: policy,
                calendar: calendar
            )
        }
        .sorted {
            if $0.preparationDate == $1.preparationDate {
                return $0.recipeName.localizedCaseInsensitiveCompare(
                    $1.recipeName
                ) == .orderedAscending
            }

            return $0.preparationDate < $1.preparationDate
        }
    }

    private static func makeRecipeBatches(
        demands: [BatchMealDemand],
        policy: BatchRecipePolicy,
        calendar: Calendar
    ) -> [RecipeProductionBatch] {
        let ordered = demands.sorted {
            if $0.mealDate == $1.mealDate {
                return $0.entry.position < $1.entry.position
            }

            return $0.mealDate < $1.mealDate
        }

        guard policy.allowsBatching,
              policy.refrigeratorLifeDays > 0,
              policy.maximumBatchServings > 1,
              ordered.count > 1
        else {
            return ordered.map {
                singleBatch(
                    demand: $0,
                    recipeName: policy.recipeName
                )
            }
        }

        var batches: [RecipeProductionBatch] = []
        var remaining = ordered

        while let first = remaining.first {
            remaining.removeFirst()

            var selected = [first]
            var servings = first.servings

            let latestSafeDate = calendar.date(
                byAdding: .day,
                value: policy.refrigeratorLifeDays,
                to: first.mealDate
            ) ?? first.mealDate

            var retained: [BatchMealDemand] = []

            for candidate in remaining {
                let insideStorageWindow =
                    candidate.mealDate <= latestSafeDate

                let fitsMaximum =
                    servings + candidate.servings
                    <= policy.maximumBatchServings + 0.0001

                if insideStorageWindow && fitsMaximum {
                    selected.append(candidate)
                    servings += candidate.servings
                } else {
                    retained.append(candidate)
                }
            }

            remaining = retained

            let combined =
                selected.count > 1
                && servings >= policy.minimumBatchServings

            if combined {
                batches.append(
                    RecipeProductionBatch(
                        id: UUID(),
                        recipeID: policy.recipeID,
                        recipeName: policy.recipeName,
                        demands: selected,
                        totalServings: servings,
                        preparationDate: first.mealDate,
                        isCombinedBatch: true,
                        explanation: batchExplanation(
                            recipeName: policy.recipeName,
                            selected: selected,
                            servings: servings,
                            refrigeratorLifeDays:
                                policy.refrigeratorLifeDays
                        )
                    )
                )
            } else {
                batches.append(
                    contentsOf: selected.map {
                        singleBatch(
                            demand: $0,
                            recipeName: policy.recipeName
                        )
                    }
                )
            }
        }

        return batches
    }

    private static func singleBatch(
        demand: BatchMealDemand,
        recipeName: String
    ) -> RecipeProductionBatch {
        RecipeProductionBatch(
            id: UUID(),
            recipeID: demand.entry.recipeID,
            recipeName: recipeName,
            demands: [demand],
            totalServings: demand.servings,
            preparationDate: demand.mealDate,
            isCombinedBatch: false,
            explanation:
                "Prepared separately for this meal."
        )
    }

    private static func batchExplanation(
        recipeName: String,
        selected: [BatchMealDemand],
        servings: Double,
        refrigeratorLifeDays: Int
    ) -> String {
        let meals = selected.map { demand in
            let date = demand.mealDate.formatted(
                .dateTime
                    .weekday(.abbreviated)
                    .month(.abbreviated)
                    .day()
            )

            let amount = demand.servings.formatted(
                .number.precision(
                    .fractionLength(0...1)
                )
            )

            return "\(date): \(amount)"
        }
        .joined(separator: ", ")

        let total = servings.formatted(
            .number.precision(
                .fractionLength(0...1)
            )
        )

        return "Combined \(selected.count) planned meals into one \(total)-serving batch of \(recipeName). Covered meals: \(meals). The meals fit within the \(refrigeratorLifeDays)-day refrigerated storage window."
    }
}
