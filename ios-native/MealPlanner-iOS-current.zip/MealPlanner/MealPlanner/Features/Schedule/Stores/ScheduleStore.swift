import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class ScheduleStore {
    private(set) var isLoading = false
    private(set) var isGenerating = false
    private(set) var hasLoaded = false

    private(set) var entries: [WeekPlanEntry] = []
    private(set) var recipes: [ScheduleRecipeSummary] = []
    private(set) var recipeTasks: [ScheduleRecipeTask] = []
    private(set) var recipePrepOperations:
        [ScheduleRecipePrepOperation] = []
    private(set) var recipeIngredients:
        [ScheduleRecipeIngredient] = []
    private(set) var recipeSteps:
        [ScheduleRecipeStep] = []
    private(set) var mealSlots: [ScheduleMealSlotRecord] = []
    private(set) var dayPreferences: [ScheduleDayPreferenceRecord] = []
    private(set) var globalPreferences: ScheduleGlobalPreferenceRecord?
    private(set) var generatedTasks: [ScheduleGeneratedTask] = []

    var selectedDate = Date()
    var weekStartDate = Date()
    var errorMessage: String?
    var successMessage: String?

    private var currentUserID: UUID?
    private var weekStartsOnMonday = true
    private(set) var suppressNonSevereWarnings = false
    private let calendar = Calendar.current

    var weekDates: [Date] {
        (0..<7).compactMap {
            calendar.date(
                byAdding: .day,
                value: $0,
                to: weekStartDate
            )
        }
    }

    var weekTitle: String {
        guard let endDate = weekDates.last else {
            return ""
        }

        return "\(weekStartDate.formatted(.dateTime.month(.abbreviated).day())) – \(endDate.formatted(.dateTime.month(.abbreviated).day().year()))"
    }

    var selectedDayTasks: [ScheduleGeneratedTask] {
        let key = databaseDate(selectedDate)

        return generatedTasks
            .filter {
                $0.taskDate == key
            }
            .sorted {
                if $0.scheduledStart
                    == $1.scheduledStart {
                    return $0.position
                        < $1.position
                }

                return $0.scheduledStart
                    < $1.scheduledStart
            }
    }

    var weekSummaries: [ScheduleDaySummary] {
        weekDates.map { date in
            let dateKey = databaseDate(date)

            let dayTasks =
                generatedTasks.filter {
                    $0.taskDate == dateKey
                }

            let dayEntries =
                entries.filter {
                    $0.mealDate == dateKey
                }

            let nextTask =
                dayTasks
                    .filter {
                        !$0.isCompleted
                    }
                    .sorted {
                        $0.scheduledStart
                            < $1.scheduledStart
                    }
                    .first?
                    .title

            return ScheduleDaySummary(
                date: date,
                mealCount:
                    dayEntries.count,
                taskCount:
                    dayTasks.count,
                completedCount:
                    dayTasks.filter(
                        \.isCompleted
                    ).count,
                warningCount:
                    dayTasks.filter {
                        shouldShowWarning(
                            for: $0
                        )
                    }.count,
                nextTaskTitle:
                    nextTask
            )
        }
    }

    func shouldShowWarning(
        for task: ScheduleGeneratedTask
    ) -> Bool {
        guard task.hasConflict
            || task.warningMessage != nil
        else {
            return false
        }

        guard suppressNonSevereWarnings else {
            return true
        }

        if task.hasConflict {
            return true
        }

        guard let warning =
            task.warningMessage
        else {
            return false
        }

        switch warning {
        case "Outside the configured task window.":
            return false

        case "Cooking is disabled for this day.",
             "Exceeds the active-cooking limit.":
            return true

        default:
            // New or unrecognized warnings remain visible so
            // important future warnings are not hidden silently.
            return true
        }
    }

    func sharedPrepRecipeNames(
        for task: ScheduleGeneratedTask
    ) -> [String] {
        task.sharedPrepRecipeNames
    }

    func recipeName(
        for task: ScheduleGeneratedTask
    ) -> String {
        recipes.first {
            $0.id == task.recipeID
        }?.name ?? "Recipe"
    }

    func ingredients(
        for task: ScheduleGeneratedTask
    ) -> [ScheduleRecipeIngredient] {
        recipeIngredients
            .filter {
                $0.recipeID == task.recipeID
            }
            .sorted {
                $0.position < $1.position
            }
    }

    func steps(
        for task: ScheduleGeneratedTask
    ) -> [ScheduleRecipeStep] {
        recipeSteps
            .filter {
                $0.recipeID == task.recipeID
            }
            .sorted {
                $0.position < $1.position
            }
    }

    func ingredientQuantityText(
        _ ingredient: ScheduleRecipeIngredient,
        for task: ScheduleGeneratedTask
    ) -> String {
        let baseServings =
            recipes.first {
                $0.id == task.recipeID
            }?.defaultServings ?? 1

        return ingredient.quantityText(
            selectedServings:
                max(
                    0.5,
                    task.batchServings
                ),
            baseServings:
                max(
                    0.5,
                    baseServings
                )
        )
    }

    func load() async {
        guard !isLoading else {
            return
        }

        isLoading = true
        errorMessage = nil

        defer {
            isLoading = false
        }

        do {
            let session = try await AppSupabase
                .client
                .auth
                .session

            currentUserID =
                session.user.id

            struct WeekPreference:
                Decodable {
                let weekStartsOn: String
                let suppressNonSevereWarnings: Bool

                enum CodingKeys:
                    String,
                    CodingKey {
                    case weekStartsOn =
                        "week_starts_on"
                    case suppressNonSevereWarnings =
                        "suppress_non_severe_warnings"
                }
            }

            let weekPreference:
                WeekPreference =
                try await AppSupabase
                    .client
                    .from(
                        "account_preferences"
                    )
                    .select(
                        """
                        week_starts_on,
                        suppress_non_severe_warnings
                        """
                    )
                    .eq(
                        "user_id",
                        value:
                            session.user.id
                                .uuidString
                    )
                    .single()
                    .execute()
                    .value

            weekStartsOnMonday =
                weekPreference
                    .weekStartsOn
                    .lowercased()
                != "sunday"

            suppressNonSevereWarnings =
                weekPreference
                    .suppressNonSevereWarnings

            weekStartDate =
                startOfWeek(
                    containing:
                        selectedDate
                )

            try await loadWeekData()
            hasLoaded = true

            if needsAutomaticRegeneration {
                await regenerate(
                    onlyDate: nil
                )
            }
        } catch {
            guard !isCancellation(error) else {
                return
            }

            errorMessage =
                error.localizedDescription
        }
    }

    func refresh() async {
        await load()
    }

    func moveWeek(
        by amount: Int
    ) async {
        guard let newStart =
            calendar.date(
                byAdding: .day,
                value: amount * 7,
                to: weekStartDate
            )
        else {
            return
        }

        weekStartDate = newStart
        selectedDate = newStart
        await reloadWeekDataSafely()
    }

    func goToCurrentWeek() async {
        selectedDate = Date()
        weekStartDate =
            startOfWeek(
                containing:
                    selectedDate
            )

        await reloadWeekDataSafely()
    }

    func selectDate(
        _ date: Date
    ) {
        selectedDate = date
    }

    func regenerateDay() async {
        // Same-recipe batching is evaluated across the complete
        // week. Rebuilding only one day could split an existing
        // batch or leave stale tasks for its covered meals.
        await regenerate(
            onlyDate: nil
        )
    }

    func regenerateWeek() async {
        await regenerate(
            onlyDate: nil
        )
    }

    func toggleCompletion(
        _ task: ScheduleGeneratedTask
    ) async {
        do {
            let payload =
                ScheduleCompletionUpdate(
                    isCompleted:
                        !task.isCompleted
                )

            let updated:
                ScheduleGeneratedTask =
                try await AppSupabase
                    .client
                    .from("schedule_tasks")
                    .update(payload)
                    .eq(
                        "id",
                        value:
                            task.id.uuidString
                    )
                    .select()
                    .single()
                    .execute()
                    .value

            replaceTask(updated)
        } catch {
            errorMessage =
                error.localizedDescription
        }
    }

    private func regenerate(
        onlyDate: String?
    ) async {
        guard let currentUserID else {
            return
        }

        guard !isGenerating else {
            return
        }

        isGenerating = true
        errorMessage = nil
        successMessage = nil

        defer {
            isGenerating = false
        }

        do {
            let targetEntries =
                entries.filter {
                    onlyDate == nil
                    || $0.mealDate
                        == onlyDate
                }

            let newTasks =
                buildTasks(
                    entries:
                        targetEntries,
                    userID:
                        currentUserID
                )

            var deleteQuery =
                AppSupabase
                    .client
                    .from("schedule_tasks")
                    .delete()
                    .eq(
                        "user_id",
                        value:
                            currentUserID
                                .uuidString
                    )
                    .eq(
                        "week_start",
                        value:
                            databaseDate(
                                weekStartDate
                            )
                    )

            if let onlyDate {
                deleteQuery =
                    deleteQuery.eq(
                        "task_date",
                        value: onlyDate
                    )
            }

            try await deleteQuery.execute()

            if let onlyDate {
                generatedTasks.removeAll {
                    $0.taskDate == onlyDate
                }
            } else {
                generatedTasks.removeAll()
            }

            if !newTasks.isEmpty {
                let inserted:
                    [ScheduleGeneratedTask] =
                    try await AppSupabase
                        .client
                        .from("schedule_tasks")
                        .insert(newTasks)
                        .select()
                        .execute()
                        .value

                generatedTasks.append(
                    contentsOf: inserted
                )
            }

            successMessage =
                onlyDate == nil
                ? "Week regenerated."
                : "Day regenerated."
        } catch {
            errorMessage =
                error.localizedDescription
        }
    }

    private func buildTasks(
        entries: [WeekPlanEntry],
        userID: UUID
    ) -> [ScheduleTaskInsert] {
        let policies =
            Dictionary(
                uniqueKeysWithValues:
                    recipes.map {
                        recipe in

                        let taskTemplates =
                            recipeTasks.filter {
                                $0.recipeID
                                    == recipe.id
                            }

                        let allowsBatching =
                            taskTemplates.contains {
                                $0.canBatch
                            }

                        return (
                            recipe.id,
                            BatchRecipePolicy(
                                recipeID:
                                    recipe.id,
                                recipeName:
                                    recipe.name,
                                baseServings:
                                    max(
                                        0.5,
                                        recipe
                                            .defaultServings
                                    ),
                                minimumBatchServings:
                                    max(
                                        0.5,
                                        recipe
                                            .minimumBatchServings
                                    ),
                                maximumBatchServings:
                                    max(
                                        0.5,
                                        recipe
                                            .maximumBatchServings
                                    ),
                                refrigeratorLifeDays:
                                    max(
                                        0,
                                        recipe
                                            .refrigeratorLifeDays
                                    ),
                                allowsBatching:
                                    allowsBatching
                            )
                        )
                    }
            )

        let demands =
            entries.map {
                entry in

                BatchMealDemand(
                    id: entry.id,
                    entry: entry,
                    mealDate:
                        dateFromDatabase(
                            entry.mealDate
                        )
                )
            }

        let batches =
            BatchPlanningEngine
                .makeBatches(
                    demands: demands,
                    policies: policies,
                    calendar: calendar
                )

        let sharedCandidates =
            batches.flatMap {
                batch in

                let recipe =
                    recipes.first {
                        $0.id
                            == batch.recipeID
                    }

                let baseServings =
                    max(
                        0.5,
                        recipe?
                            .defaultServings
                        ?? 1
                    )

                return recipePrepOperations
                    .filter {
                        $0.recipeID
                            == batch.recipeID
                    }
                    .map {
                        operation in

                        let matchedTask =
                            recipeTasks.first {
                                task in

                                task.recipeID
                                    == operation
                                        .recipeID
                                && task.batchKey?
                                    .caseInsensitiveCompare(
                                        operation
                                            .batchKey
                                    )
                                    == .orderedSame
                            }

                        return SharedPrepOperationCandidate(
                            id:
                                "\(batch.id.uuidString)|\(operation.id.uuidString)",
                            batch:
                                batch,
                            operation:
                                operation,
                            recipeName:
                                recipe?.name
                                ?? "Recipe",
                            recipeBaseServings:
                                baseServings,
                            matchedTask:
                                matchedTask
                        )
                    }
            }

        let sharedGroups =
            SharedPrepPlanningEngine
                .makeGroups(
                    candidates:
                        sharedCandidates,
                    preferredBatchDays:
                        globalPreferences?
                            .preferredBatchDays
                        ?? [],
                    weekDates:
                        weekDates,
                    calendar:
                        calendar
                )

        let groupedTaskKeys: Set<String> =
            Set(
                sharedGroups.flatMap {
                    group -> [String] in

                    group.candidates
                        .compactMap {
                            candidate -> String? in

                            guard let taskID =
                                candidate
                                    .matchedTaskID
                            else {
                                return nil
                            }

                            return "\(candidate.batch.id.uuidString)|\(taskID.uuidString)"
                        }
                }
            )

        var result:
            [ScheduleTaskInsert] = []

        var generatedKeys =
            Set<String>()

        for batch in batches {
            let entry =
                batch.primaryEntry

            let matchingTasks =
                recipeTasks
                    .filter {
                        $0.recipeID
                            == entry.recipeID
                    }
                    .sorted {
                        $0.position
                            < $1.position
                    }

            var seenTaskIDs =
                Set<UUID>()

            let uniqueTasks =
                matchingTasks.filter {
                    seenTaskIDs.insert(
                        $0.id
                    ).inserted
                }

            let localTasks =
                uniqueTasks.filter {
                    task in

                    !groupedTaskKeys.contains(
                        "\(batch.id.uuidString)|\(task.id.uuidString)"
                    )
                }

            let taskTemplates =
                uniqueTasks.isEmpty
                ? fallbackTasks(
                    for: entry.recipeID
                )
                : localTasks

            let recipe =
                recipes.first {
                    $0.id
                        == entry.recipeID
                }

            let servingRatio =
                max(
                    1,
                    batch.totalServings
                        / max(
                            0.5,
                            recipe?
                                .defaultServings
                            ?? 1
                        )
                )

            let slot =
                mealSlots.first {
                    $0.id
                        == entry.mealSlotID
                }

            let mealTime =
                dateByApplyingTime(
                    slot?.readyTime
                        ?? slot?.eatTime
                        ?? "18:00",
                    to:
                        batch
                            .preparationDate
                )

            var dependencyCursor =
                mealTime

            var placements:
                [
                    (
                        index: Int,
                        template:
                            ScheduleRecipeTask,
                        start: Date,
                        end: Date,
                        active: Int,
                        passive: Int
                    )
                ] = []

            for (
                index,
                template
            ) in taskTemplates
                .enumerated()
                .reversed() {
                let scaledActive =
                    scaledActiveMinutes(
                        template
                            .activeMinutes,
                        servingRatio:
                            servingRatio,
                        isCombinedBatch:
                            batch
                                .isCombinedBatch
                    )

                let passive =
                    template
                        .passiveMinutes

                let duration =
                    max(
                        1,
                        scaledActive
                            + passive
                    )

                let offsetMealTime =
                    calendar.date(
                        byAdding: .day,
                        value:
                            -template.dayOffset,
                        to: mealTime
                    ) ?? mealTime

                let preferredStart =
                    calendar.date(
                        byAdding: .minute,
                        value:
                            -template
                                .startBeforeMealMinutes,
                        to: offsetMealTime
                    ) ?? offsetMealTime

                let preferredEnd =
                    calendar.date(
                        byAdding: .minute,
                        value: duration,
                        to: preferredStart
                    ) ?? preferredStart

                let end =
                    preferredEnd
                        < dependencyCursor
                    ? preferredEnd
                    : dependencyCursor

                let start =
                    calendar.date(
                        byAdding: .minute,
                        value: -duration,
                        to: end
                    ) ?? end

                placements.append(
                    (
                        index: index,
                        template:
                            template,
                        start: start,
                        end: end,
                        active:
                            scaledActive,
                        passive:
                            passive
                    )
                )

                dependencyCursor =
                    start
            }

            for placement in placements
                .sorted(
                    by: {
                        $0.index
                            < $1.index
                    }
                ) {
                let template =
                    placement.template

                let dayNumber =
                    schedulerDayNumber(
                        for:
                            placement.start
                    )

                let preference =
                    dayPreferences.first {
                        $0.dayOfWeek
                            == dayNumber
                    }

                let warning =
                    scheduleWarning(
                        start:
                            placement.start,
                        end:
                            placement.end,
                        activeMinutes:
                            placement.active,
                        preference:
                            preference
                    )

                let hasConflict =
                    result.contains {
                        intervalsOverlap(
                            placement.start,
                            placement.end,
                            $0.scheduledStart,
                            $0.scheduledEnd
                        )
                    }

                let generatedKey =
                    [
                        batch.id
                            .uuidString,
                        template.id
                            .uuidString,
                        String(
                            placement.index
                        )
                    ]
                    .joined(
                        separator: "|"
                    )

                guard generatedKeys.insert(
                    generatedKey
                ).inserted else {
                    continue
                }

                result.append(
                    ScheduleTaskInsert(
                        userID: userID,
                        weekStart:
                            databaseDate(
                                weekStartDate
                            ),
                        taskDate:
                            databaseDate(
                                placement.start
                            ),
                        weekPlanEntryID:
                            entry.id,
                        recipeID:
                            entry.recipeID,
                        recipeTaskID:
                            template.id,
                        title:
                            template.title,
                        instructions:
                            template.instructions,
                        scheduledStart:
                            placement.start,
                        scheduledEnd:
                            placement.end,
                        activeMinutes:
                            placement.active,
                        passiveMinutes:
                            placement.passive,
                        isCompleted: false,
                        isManuallyAdjusted:
                            false,
                        hasConflict:
                            hasConflict,
                        warningMessage:
                            warning,
                        batchID:
                            batch
                                .isCombinedBatch
                            ? batch.id
                            : nil,
                        batchServings:
                            batch
                                .totalServings,
                        batchMealCount:
                            batch
                                .coveredMealCount,
                        batchExplanation:
                            batch
                                .isCombinedBatch
                            ? batch
                                .explanation
                            : nil,
                        coveredWeekPlanEntryIDs:
                            batch
                                .coveredEntryIDs,
                        isSharedPrep: false,
                        sharedPrepKey: nil,
                        sharedPrepRecipeIDs: [],
                        sharedPrepRecipeNames: [],
                        sharedPrepTaskIDs: [],
                        sharedPrepExplanation: nil,
                        position:
                            placement.index
                    )
                )
            }
        }

        for (
            index,
            group
        ) in sharedGroups.enumerated() {
            let representative =
                group.primaryCandidate

            let start =
                sharedPrepStartTime(
                    on:
                        group.preparationDate
                )

            let duration =
                max(
                    1,
                    group.activeMinutes
                    + group.passiveMinutes
                )

            let end =
                calendar.date(
                    byAdding: .minute,
                    value: duration,
                    to: start
                )
                ?? start

            let preference =
                dayPreferences.first {
                    $0.dayOfWeek
                        == schedulerDayNumber(
                            for: start
                        )
                }

            let warning =
                scheduleWarning(
                    start: start,
                    end: end,
                    activeMinutes:
                        group.activeMinutes,
                    preference:
                        preference
                )

            let conflict =
                result.contains {
                    intervalsOverlap(
                        start,
                        end,
                        $0.scheduledStart,
                        $0.scheduledEnd
                    )
                }

            let quantityText =
                sharedPrepQuantityText(
                    quantity:
                        group.totalQuantity,
                    unit:
                        group.unit
                )

            result.append(
                ScheduleTaskInsert(
                    userID: userID,
                    weekStart:
                        databaseDate(
                            weekStartDate
                        ),
                    taskDate:
                        databaseDate(start),
                    weekPlanEntryID:
                        representative
                            .batch
                            .primaryEntry
                            .id,
                    recipeID:
                        representative
                            .batch
                            .recipeID,
                    recipeTaskID:
                        representative
                            .matchedTaskID,
                    title:
                        group.title,
                    instructions:
                        "\(quantityText). \(group.explanation)",
                    scheduledStart:
                        start,
                    scheduledEnd:
                        end,
                    activeMinutes:
                        group.activeMinutes,
                    passiveMinutes:
                        group.passiveMinutes,
                    isCompleted: false,
                    isManuallyAdjusted:
                        false,
                    hasConflict:
                        conflict,
                    warningMessage:
                        warning,
                    batchID: nil,
                    batchServings:
                        group.candidates
                            .reduce(0.0) {
                                partialResult,
                                candidate in

                                partialResult
                                + candidate.batch
                                    .totalServings
                            },
                    batchMealCount:
                        group.coveredEntryIDs
                            .count,
                    batchExplanation: nil,
                    coveredWeekPlanEntryIDs:
                        group.coveredEntryIDs,
                    isSharedPrep: true,
                    sharedPrepKey:
                        group.key,
                    sharedPrepRecipeIDs:
                        group.recipeIDs,
                    sharedPrepRecipeNames:
                        group.recipeNames,
                    sharedPrepTaskIDs:
                        group.matchedTaskIDs,
                    sharedPrepExplanation:
                        group.explanation,
                    position:
                        10_000 + index
                )
            )
        }

        return result
    }

    private func sharedPrepQuantityText(
        quantity: Double,
        unit: String
    ) -> String {
        let amount =
            quantity.formatted(
                .number.precision(
                    .fractionLength(
                        0...2
                    )
                )
            )

        let cleanedUnit =
            unit.trimmingCharacters(
                in:
                    .whitespacesAndNewlines
            )

        return cleanedUnit.isEmpty
            ? "Prepare \(amount)"
            : "Prepare \(amount) \(cleanedUnit)"
    }

    private func sharedPrepStartTime(
        on date: Date
    ) -> Date {
        let preference =
            dayPreferences.first {
                $0.dayOfWeek
                    == schedulerDayNumber(
                        for: date
                    )
            }

        return dateByApplyingTime(
            preference?.eveningPrepStart
            ?? "17:00",
            to: date
        )
    }

    private func scaledActiveMinutes(
        _ baseMinutes: Int,
        servingRatio: Double,
        isCombinedBatch: Bool
    ) -> Int {
        guard isCombinedBatch,
              baseMinutes > 0,
              servingRatio > 1
        else {
            return baseMinutes
        }

        let multiplier =
            1
            + 0.35
            * (
                servingRatio - 1
            )

        return max(
            baseMinutes,
            Int(
                ceil(
                    Double(baseMinutes)
                    * multiplier
                )
            )
        )
    }

    private func fallbackTasks(
        for recipeID: UUID
    ) -> [ScheduleRecipeTask] {
        let recipeName =
            recipes.first {
                $0.id == recipeID
            }?.name ?? "Prepare meal"

        return [
            ScheduleRecipeTask(
                id: UUID(),
                recipeID: recipeID,
                title:
                    "Prepare \(recipeName)",
                instructions: nil,
                taskType:
                    "preparation",
                activeMinutes: 30,
                passiveMinutes: 0,
                dayOffset: 0,
                startBeforeMealMinutes:
                    45,
                canBatch: false,
                batchKey: nil,
                canMakeAhead: false,
                maximumMakeAheadHours: 0,
                storageMethod: "none",
                unattended: false,
                blocksActiveWork:
                    true,
                position: 0
            )
        ]
    }

    private func scheduleWarning(
        start: Date,
        end: Date,
        activeMinutes: Int,
        preference:
            ScheduleDayPreferenceRecord?
    ) -> String? {
        guard let preference else {
            return nil
        }

        if !preference.cookingAllowed
            && activeMinutes > 0 {
            return "Cooking is disabled for this day."
        }

        let earliest =
            dateByApplyingTime(
                preference
                    .earliestTaskTime,
                to: start
            )

        let latest =
            dateByApplyingTime(
                preference
                    .latestTaskTime,
                to: start
            )

        if start < earliest
            || end > latest {
            return "Outside the configured task window."
        }

        if activeMinutes
            > preference
                .maxActiveCookingMinutes {
            return "Exceeds the active-cooking limit."
        }

        return nil
    }

    private func loadWeekData() async throws {
        guard let currentUserID else {
            return
        }

        let start =
            databaseDate(
                weekStartDate
            )

        let endDate =
            calendar.date(
                byAdding: .day,
                value: 6,
                to: weekStartDate
            ) ?? weekStartDate

        let end =
            databaseDate(endDate)

        async let entryRequest:
            [WeekPlanEntry] =
            AppSupabase.client
                .from(
                    "week_plan_entries"
                )
                .select()
                .eq(
                    "user_id",
                    value:
                        currentUserID
                            .uuidString
                )
                .gte(
                    "meal_date",
                    value: start
                )
                .lte(
                    "meal_date",
                    value: end
                )
                .execute()
                .value

        async let recipeRequest:
            [ScheduleRecipeSummary] =
            AppSupabase.client
                .from("recipes")
                .select(
                    """
                    id,
                    name,
                    default_servings,
                    minimum_batch_servings,
                    maximum_batch_servings,
                    refrigerator_life_days
                    """
                )
                .execute()
                .value

        async let taskRequest:
            [ScheduleRecipeTask] =
            AppSupabase.client
                .from(
                    "recipe_tasks"
                )
                .select(
                    """
                    id,
                    recipe_id,
                    title,
                    instructions,
                    task_type,
                    active_minutes,
                    passive_minutes,
                    day_offset,
                    start_before_meal_minutes,
                    can_batch,
                    batch_key,
                    can_make_ahead,
                    maximum_make_ahead_hours,
                    storage_method,
                    unattended,
                    blocks_active_work,
                    position
                    """
                )
                .execute()
                .value

        async let prepOperationRequest:
            [ScheduleRecipePrepOperation] =
            AppSupabase.client
                .from(
                    "recipe_prep_operations"
                )
                .select(
                    """
                    id,
                    recipe_id,
                    ingredient_position,
                    source_step_positions,
                    canonical_ingredient_name,
                    display_ingredient_name,
                    action,
                    preparation_state,
                    quantity,
                    unit,
                    can_make_ahead,
                    maximum_make_ahead_hours,
                    storage_method,
                    batch_key,
                    confidence,
                    manually_edited,
                    analysis_version,
                    position
                    """
                )
                .execute()
                .value

        async let ingredientRequest:
            [ScheduleRecipeIngredient] =
            AppSupabase.client
                .from(
                    "recipe_ingredients"
                )
                .select(
                    """
                    id,
                    recipe_id,
                    name,
                    quantity,
                    unit,
                    preparation_note,
                    is_optional,
                    scaling_behavior,
                    position
                    """
                )
                .execute()
                .value

        async let stepRequest:
            [ScheduleRecipeStep] =
            AppSupabase.client
                .from(
                    "recipe_steps"
                )
                .select(
                    """
                    id,
                    recipe_id,
                    instruction,
                    duration_minutes,
                    step_type,
                    position
                    """
                )
                .execute()
                .value

        async let slotRequest:
            [ScheduleMealSlotRecord] =
            AppSupabase.client
                .from(
                    "meal_slot_preferences"
                )
                .select(
                    """
                    id,
                    day_of_week,
                    position,
                    name,
                    eat_time,
                    ready_time
                    """
                )
                .eq(
                    "user_id",
                    value:
                        currentUserID
                            .uuidString
                )
                .execute()
                .value

        async let dayRequest:
            [ScheduleDayPreferenceRecord] =
            AppSupabase.client
                .from(
                    "day_schedule_preferences"
                )
                .select(
                    """
                    day_of_week,
                    earliest_task_time,
                    latest_task_time,
                    evening_prep_start,
                    evening_prep_end,
                    max_active_cooking_minutes,
                    cooking_allowed
                    """
                )
                .eq(
                    "user_id",
                    value:
                        currentUserID
                            .uuidString
                )
                .execute()
                .value

        async let globalRequest:
            [ScheduleGlobalPreferenceRecord] =
            AppSupabase.client
                .from(
                    "scheduler_preferences"
                )
                .select(
                    """
                    conflict_grouping_minutes,
                    preferred_batch_days,
                    preserve_manual_adjustments
                    """
                )
                .eq(
                    "user_id",
                    value:
                        currentUserID
                            .uuidString
                )
                .execute()
                .value

        async let generatedRequest:
            [ScheduleGeneratedTask] =
            AppSupabase.client
                .from(
                    "schedule_tasks"
                )
                .select()
                .eq(
                    "user_id",
                    value:
                        currentUserID
                            .uuidString
                )
                .gte(
                    "task_date",
                    value: start
                )
                .lte(
                    "task_date",
                    value: end
                )
                .order(
                    "scheduled_start",
                    ascending: true
                )
                .execute()
                .value

        entries = try await entryRequest
        recipes = try await recipeRequest
        recipeTasks =
            try await taskRequest
        recipePrepOperations =
            try await prepOperationRequest
        recipeIngredients =
            try await ingredientRequest
        recipeSteps =
            try await stepRequest
        mealSlots =
            try await slotRequest
        dayPreferences =
            try await dayRequest
        globalPreferences =
            try await globalRequest
                .first
        generatedTasks =
            try await generatedRequest
    }

    private func reloadWeekDataSafely()
        async {
        do {
            try await loadWeekData()

            if needsAutomaticRegeneration {
                await regenerate(
                    onlyDate: nil
                )
            }
        } catch {
            guard !isCancellation(error) else {
                return
            }

            errorMessage =
                error.localizedDescription
        }
    }

    private var needsAutomaticRegeneration: Bool {
        let plannedEntryIDs =
            Set(entries.map(\.id))

        let coveredEntryIDs =
            Set(
                generatedTasks.flatMap {
                    task in

                    task
                        .coveredWeekPlanEntryIDs
                        .isEmpty
                    ? [
                        task.weekPlanEntryID
                    ]
                    : task
                        .coveredWeekPlanEntryIDs
                }
            )

        return plannedEntryIDs
            != coveredEntryIDs
    }

    private func replaceTask(
        _ updated:
            ScheduleGeneratedTask
    ) {
        guard let index =
            generatedTasks.firstIndex(
                where: {
                    $0.id == updated.id
                }
            )
        else {
            generatedTasks.append(
                updated
            )
            return
        }

        generatedTasks[index] =
            updated
    }

    private func intervalsOverlap(
        _ firstStart: Date,
        _ firstEnd: Date,
        _ secondStart: Date,
        _ secondEnd: Date
    ) -> Bool {
        firstStart < secondEnd
            && secondStart < firstEnd
    }

    private func startOfWeek(
        containing date: Date
    ) -> Date {
        let targetWeekday =
            weekStartsOnMonday ? 2 : 1

        let weekday =
            calendar.component(
                .weekday,
                from: date
            )

        let offset =
            (weekday
             - targetWeekday
             + 7) % 7

        let start =
            calendar.date(
                byAdding: .day,
                value: -offset,
                to: date
            ) ?? date

        return calendar.startOfDay(
            for: start
        )
    }

    private func schedulerDayNumber(
        for date: Date
    ) -> Int {
        let weekday =
            calendar.component(
                .weekday,
                from: date
            )

        return weekday == 1
            ? 7
            : weekday - 1
    }

    private func dateByApplyingTime(
        _ value: String,
        to date: Date
    ) -> Date {
        let parts =
            value.split(separator: ":")

        let hour =
            parts.first.flatMap {
                Int($0)
            } ?? 0

        let minute =
            parts.dropFirst()
                .first.flatMap {
                    Int($0)
                } ?? 0

        return calendar.date(
            bySettingHour: hour,
            minute: minute,
            second: 0,
            of: date
        ) ?? date
    }

    private func databaseDate(
        _ date: Date
    ) -> String {
        let formatter =
            DateFormatter()

        formatter.calendar =
            calendar
        formatter.locale =
            Locale(
                identifier:
                    "en_US_POSIX"
            )
        formatter.dateFormat =
            "yyyy-MM-dd"

        return formatter.string(
            from: date
        )
    }

    private func dateFromDatabase(
        _ value: String
    ) -> Date {
        let formatter =
            DateFormatter()

        formatter.calendar =
            calendar
        formatter.locale =
            Locale(
                identifier:
                    "en_US_POSIX"
            )
        formatter.dateFormat =
            "yyyy-MM-dd"

        return formatter.date(
            from: value
        ) ?? Date()
    }

    private func isCancellation(
        _ error: Error
    ) -> Bool {
        if error is CancellationError {
            return true
        }

        let nsError =
            error as NSError

        return nsError.domain
            == NSURLErrorDomain
            && nsError.code
            == NSURLErrorCancelled
    }
}
