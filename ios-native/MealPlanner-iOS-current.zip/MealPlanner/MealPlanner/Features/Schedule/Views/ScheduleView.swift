import SwiftUI

struct ScheduleView: View {
    @State private var store =
        ScheduleStore()

    @State private var selectedTask:
        ScheduleGeneratedTask?

    @State private var showRegenerateWeek =
        false

    @State private var showRegenerateDay =
        false

    var body: some View {
        Group {
            if store.isLoading
                && !store.hasLoaded {
                ProgressView(
                    "Loading schedule…"
                )
            } else {
                scheduleContent
            }
        }
        .navigationTitle("Schedule")
        .navigationBarTitleDisplayMode(
            .inline
        )
        .toolbar {
            ToolbarItem(
                placement:
                    .topBarTrailing
            ) {
                Menu {
                    Button {
                        showRegenerateDay =
                            true
                    } label: {
                        Label(
                            "Regenerate day",
                            systemImage:
                                "arrow.clockwise"
                        )
                    }

                    Button {
                        showRegenerateWeek =
                            true
                    } label: {
                        Label(
                            "Regenerate week",
                            systemImage:
                                "calendar.badge.clock"
                        )
                    }
                } label: {
                    Image(
                        systemName:
                            "ellipsis.circle"
                    )
                }
            }
        }
        .task {
            await store.load()
        }
        .sheet(
            item: $selectedTask
        ) { task in
            ScheduleTaskDetailView(
                task: task,
                recipeName:
                    store.recipeName(
                        for: task
                    ),
                ingredients:
                    store.ingredients(
                        for: task
                    ),
                steps:
                    store.steps(
                        for: task
                    ),
                ingredientQuantityText: {
                    ingredient in

                    store
                        .ingredientQuantityText(
                            ingredient,
                            for: task
                        )
                },
                sharedPrepRecipeNames:
                    store.sharedPrepRecipeNames(
                        for: task
                    ),
                showWarning:
                    store.shouldShowWarning(
                        for: task
                    )
            )
        }
        .confirmationDialog(
            "Regenerate this day?",
            isPresented:
                $showRegenerateDay,
            titleVisibility: .visible
        ) {
            Button("Regenerate") {
                Task {
                    await store
                        .regenerateDay()
                }
            }

            Button(
                "Cancel",
                role: .cancel
            ) {}
        } message: {
            Text(
                "This refreshes the weekly plan so batching and task order remain consistent."
            )
        }
        .confirmationDialog(
            "Regenerate the full week?",
            isPresented:
                $showRegenerateWeek,
            titleVisibility: .visible
        ) {
            Button("Regenerate") {
                Task {
                    await store
                        .regenerateWeek()
                }
            }

            Button(
                "Cancel",
                role: .cancel
            ) {}
        }
    }

    private var scheduleContent:
        some View {
        ScrollView {
            VStack(spacing: 12) {
                weekNavigation

                WeekCalendarSummaryView(
                    summaries:
                        store.weekSummaries,
                    selectedDate:
                        store.selectedDate
                ) { date in
                    store.selectDate(date)
                }

                if let error =
                    store.errorMessage {
                    compactMessage(
                        error,
                        color: .red,
                        icon:
                            "exclamationmark.triangle.fill"
                    )
                } else if let success =
                    store.successMessage {
                    compactMessage(
                        success,
                        color: .green,
                        icon:
                            "checkmark.circle.fill"
                    )
                }

                dayHeader

                if store.selectedDayTasks
                    .isEmpty {
                    ContentUnavailableView(
                        "No scheduled tasks",
                        systemImage:
                            "clock.badge.questionmark",
                        description: Text(
                            "Add meals in Week, then generate the schedule."
                        )
                    )
                } else {
                    LazyVStack(spacing: 8) {
                        ForEach(
                            store.selectedDayTasks
                        ) { task in
                            compactTaskCard(task)
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .background(
            Color(.systemGroupedBackground)
        )
        .refreshable {
            await store.refresh()
        }
    }

    private var weekNavigation:
        some View {
        HStack(spacing: 10) {
            Button {
                Task {
                    await store.moveWeek(
                        by: -1
                    )
                }
            } label: {
                Image(
                    systemName:
                        "chevron.left"
                )
                .frame(
                    width: 34,
                    height: 34
                )
            }
            .buttonStyle(.bordered)

            VStack(spacing: 1) {
                Text(store.weekTitle)
                    .font(.headline)

                Button("Today") {
                    Task {
                        await store
                            .goToCurrentWeek()
                    }
                }
                .font(.caption2)
            }
            .frame(maxWidth: .infinity)

            Button {
                Task {
                    await store.moveWeek(
                        by: 1
                    )
                }
            } label: {
                Image(
                    systemName:
                        "chevron.right"
                )
                .frame(
                    width: 34,
                    height: 34
                )
            }
            .buttonStyle(.bordered)
        }
    }

    private var dayHeader:
        some View {
        HStack {
            VStack(
                alignment: .leading,
                spacing: 1
            ) {
                Text(
                    store.selectedDate
                        .formatted(
                            .dateTime
                                .weekday(.wide)
                        )
                )
                .font(.title3.bold())

                let summary =
                    store.weekSummaries
                        .first {
                            Calendar.current
                                .isDate(
                                    $0.date,
                                    inSameDayAs:
                                        store.selectedDate
                                )
                        }

                Text(
                    "\(summary?.taskCount ?? 0) tasks"
                )
                .font(.caption)
                .foregroundStyle(
                    .secondary
                )
            }

            Spacer()

            Button {
                showRegenerateDay = true
            } label: {
                Image(
                    systemName:
                        "arrow.clockwise"
                )
                .frame(
                    width: 36,
                    height: 36
                )
            }
            .buttonStyle(
                .borderedProminent
            )
            .tint(.green)
            .disabled(
                store.isGenerating
            )
            .accessibilityLabel(
                "Generate schedule"
            )
        }
    }

    private func compactTaskCard(
        _ task:
            ScheduleGeneratedTask
    ) -> some View {
        Button {
            selectedTask = task
        } label: {
            HStack(spacing: 10) {
                Button {
                    Task {
                        await store
                            .toggleCompletion(
                                task
                            )
                    }
                } label: {
                    Image(
                        systemName:
                            task.isCompleted
                            ? "checkmark.circle.fill"
                            : "circle"
                    )
                    .font(.title3)
                    .foregroundStyle(
                        task.isCompleted
                        ? Color.green
                        : Color.secondary
                    )
                }
                .buttonStyle(.borderless)

                Image(
                    systemName:
                        taskIcon(task)
                )
                .font(.body)
                .foregroundStyle(
                    taskIconColor(task)
                )
                .frame(width: 22)

                VStack(
                    alignment: .leading,
                    spacing: 3
                ) {
                    Text(task.title)
                        .font(
                            .subheadline
                                .weight(.semibold)
                        )
                        .lineLimit(2)
                        .strikethrough(
                            task.isCompleted
                        )
                        .foregroundStyle(
                            .primary
                        )

                    HStack(spacing: 6) {
                        Label(
                            task.scheduledStart
                                .formatted(
                                    date: .omitted,
                                    time: .shortened
                                ),
                            systemImage:
                                "clock"
                        )

                        Text("•")

                        Text(
                            durationText(task)
                        )

                        if task.batchMealCount > 1 {
                            Text("•")

                            Label(
                                "\(task.batchMealCount)",
                                systemImage:
                                    "square.stack.3d.up"
                            )
                            .foregroundStyle(
                                .blue
                            )
                        }
                    }
                    .font(.caption2)
                    .foregroundStyle(
                        .secondary
                    )
                }

                Spacer(minLength: 4)

                if store.shouldShowWarning(
                    for: task
                ) {
                    Image(
                        systemName:
                            "exclamationmark.triangle.fill"
                    )
                    .font(.caption)
                    .foregroundStyle(
                        .orange
                    )
                    .accessibilityLabel(
                        "Scheduling warning"
                    )
                }

                Image(
                    systemName:
                        "chevron.right"
                )
                .font(.caption.bold())
                .foregroundStyle(
                    .tertiary
                )
            }
            .padding(
                .horizontal,
                12
            )
            .padding(
                .vertical,
                10
            )
            .background(
                Color(
                    .secondarySystemGroupedBackground
                ),
                in: RoundedRectangle(
                    cornerRadius: 14,
                    style: .continuous
                )
            )
        }
        .buttonStyle(.plain)
    }

    private func taskIcon(
        _ task:
            ScheduleGeneratedTask
    ) -> String {
        if task.isSharedPrep {
            return "square.3.layers.3d"
        }

        if task.passiveMinutes > 0
            && task.activeMinutes == 0 {
            return "hourglass"
        }

        if task.batchMealCount > 1 {
            return "square.stack.3d.up.fill"
        }

        if task.passiveMinutes > 0 {
            return "timer"
        }

        return "fork.knife"
    }

    private func taskIconColor(
        _ task:
            ScheduleGeneratedTask
    ) -> Color {
        if task.isSharedPrep
            || task.batchMealCount > 1 {
            return .blue
        }

        if task.passiveMinutes > 0 {
            return .orange
        }

        return .green
    }

    private func durationText(
        _ task:
            ScheduleGeneratedTask
    ) -> String {
        let total =
            task.activeMinutes
            + task.passiveMinutes

        return AppDurationFormatter.string(
            minutes: total
        )
    }

    private func compactMessage(
        _ text: String,
        color: Color,
        icon: String
    ) -> some View {
        Label(
            text,
            systemImage: icon
        )
        .font(.caption)
        .foregroundStyle(color)
        .padding(
            .horizontal,
            10
        )
        .padding(
            .vertical,
            8
        )
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .background(
            color.opacity(0.08),
            in: RoundedRectangle(
                cornerRadius: 10,
                style: .continuous
            )
        )
    }
}

private struct ScheduleTaskDetailView:
    View {

    let task:
        ScheduleGeneratedTask

    let recipeName: String

    let ingredients:
        [ScheduleRecipeIngredient]

    let steps:
        [ScheduleRecipeStep]

    let ingredientQuantityText:
        (ScheduleRecipeIngredient) -> String

    let sharedPrepRecipeNames: [String]

    let showWarning: Bool

    @Environment(\.dismiss)
    private var dismiss

    @State private var showIssues =
        false

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(
                    alignment: .leading,
                    spacing: 14
                ) {
                    summaryCard
                    ingredientsCard
                    methodCard

                    if task.isSharedPrep {
                        sharedPrepCard
                    } else if task.batchMealCount > 1 {
                        batchCard
                    }

                    if showWarning
                        && hasWarning {
                        issuesCard
                    }
                }
                .padding(16)
            }
            .background(
                Color(
                    .systemGroupedBackground
                )
            )
            .navigationTitle(
                recipeName
            )
            .navigationBarTitleDisplayMode(
                .inline
            )
            .toolbar {
                ToolbarItem(
                    placement:
                        .confirmationAction
                ) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }

    private var summaryCard:
        some View {
        VStack(
            alignment: .leading,
            spacing: 10
        ) {
            HStack {
                VStack(
                    alignment: .leading,
                    spacing: 3
                ) {
                    Text(task.title)
                        .font(
                            .title3
                                .weight(.semibold)
                        )

                    Text(
                        "\(task.scheduledStart.formatted(date: .abbreviated, time: .shortened)) – \(task.scheduledEnd.formatted(date: .omitted, time: .shortened))"
                    )
                    .font(.caption)
                    .foregroundStyle(
                        .secondary
                    )
                }

                Spacer()

                Image(
                    systemName:
                        task.batchMealCount > 1
                        ? "square.stack.3d.up.fill"
                        : "fork.knife"
                )
                .font(.title2)
                .foregroundStyle(
                    task.batchMealCount > 1
                    ? Color.blue
                    : Color.green
                )
            }

            HStack(spacing: 16) {
                metric(
                    icon: "person.2",
                    value:
                        servingsText(
                            task.batchServings
                        ),
                    label: "servings"
                )

                metric(
                    icon:
                        "figure.walk",
                    value:
                        AppDurationFormatter.string(
                            minutes:
                                task.activeMinutes
                        ),
                    label: "active"
                )

                metric(
                    icon: "hourglass",
                    value:
                        AppDurationFormatter.string(
                            minutes:
                                task.passiveMinutes
                        ),
                    label: "passive"
                )
            }

            if let instructions =
                task.instructions,
               !instructions
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )
                .isEmpty {
                Divider()

                Text("Current task")
                    .font(
                        .caption
                            .weight(.semibold)
                    )
                    .foregroundStyle(
                        .secondary
                    )

                Text(instructions)
                    .font(.subheadline)
            }
        }
        .compactCard()
    }

    private var ingredientsCard:
        some View {
        VStack(
            alignment: .leading,
            spacing: 10
        ) {
            Label(
                "Ingredients",
                systemImage:
                    "basket.fill"
            )
            .font(.headline)

            if ingredients.isEmpty {
                Text(
                    "No ingredient details are available."
                )
                .font(.subheadline)
                .foregroundStyle(
                    .secondary
                )
            } else {
                ForEach(ingredients) {
                    ingredient in

                    HStack(
                        alignment: .firstTextBaseline
                    ) {
                        VStack(
                            alignment: .leading,
                            spacing: 2
                        ) {
                            HStack(spacing: 5) {
                                Text(
                                    ingredient.name
                                )

                                if ingredient
                                    .isOptional {
                                    Text("Optional")
                                        .font(.caption2)
                                        .foregroundStyle(
                                            .secondary
                                        )
                                }
                            }

                            if let note =
                                ingredient
                                    .preparationNote,
                               !note.isEmpty {
                                Text(note)
                                    .font(.caption)
                                    .foregroundStyle(
                                        .secondary
                                    )
                            }
                        }

                        Spacer()

                        Text(
                            ingredientQuantityText(
                                ingredient
                            )
                        )
                        .font(
                            .subheadline
                                .weight(.semibold)
                        )
                        .multilineTextAlignment(
                            .trailing
                        )
                    }

                    if ingredient.id
                        != ingredients.last?.id {
                        Divider()
                    }
                }
            }
        }
        .compactCard()
    }

    private var methodCard:
        some View {
        VStack(
            alignment: .leading,
            spacing: 12
        ) {
            Label(
                "Full method",
                systemImage:
                    "list.number"
            )
            .font(.headline)

            if steps.isEmpty {
                Text(
                    "No recipe steps are available."
                )
                .font(.subheadline)
                .foregroundStyle(
                    .secondary
                )
            } else {
                ForEach(
                    Array(
                        steps.enumerated()
                    ),
                    id: \.element.id
                ) {
                    index,
                    step in

                    HStack(
                        alignment: .top,
                        spacing: 10
                    ) {
                        Text(
                            "\(index + 1)"
                        )
                        .font(
                            .caption
                                .weight(.bold)
                        )
                        .foregroundStyle(
                            isCurrentStep(
                                step
                            )
                            ? Color.white
                            : Color.secondary
                        )
                        .frame(
                            width: 24,
                            height: 24
                        )
                        .background(
                            isCurrentStep(
                                step
                            )
                            ? Color.green
                            : Color(
                                .tertiarySystemGroupedBackground
                            ),
                            in: Circle()
                        )

                        VStack(
                            alignment: .leading,
                            spacing: 4
                        ) {
                            Text(
                                step.instruction
                            )
                            .font(.subheadline)

                            if step
                                .durationMinutes
                                > 0 {
                                Label(
                                    AppDurationFormatter.string(
                                        minutes:
                                            step.durationMinutes
                                    ),
                                    systemImage:
                                        "clock"
                                )
                                .font(.caption)
                                .foregroundStyle(
                                    .secondary
                                )
                            }
                        }
                    }
                }
            }
        }
        .compactCard()
    }

    private var sharedPrepCard:
        some View {
        VStack(
            alignment: .leading,
            spacing: 10
        ) {
            Label(
                "Shared preparation",
                systemImage:
                    "square.3.layers.3d"
            )
            .font(.headline)
            .foregroundStyle(.blue)

            Text(
                "Used by \(sharedPrepRecipeNames.count) recipes"
            )
            .font(
                .subheadline
                    .weight(.semibold)
            )

            ForEach(
                sharedPrepRecipeNames,
                id: \.self
            ) { name in
                Label(
                    name,
                    systemImage:
                        "fork.knife"
                )
                .font(.subheadline)
            }

            if let explanation =
                task.sharedPrepExplanation {
                Divider()

                Text(explanation)
                    .font(.subheadline)
                    .foregroundStyle(
                        .secondary
                    )
            }
        }
        .compactCard()
    }

    private var batchCard:
        some View {
        VStack(
            alignment: .leading,
            spacing: 8
        ) {
            Label(
                "\(task.batchMealCount) meals combined",
                systemImage:
                    "square.stack.3d.up.fill"
            )
            .font(.headline)
            .foregroundStyle(.blue)

            if let explanation =
                task.batchExplanation {
                Text(explanation)
                    .font(.subheadline)
            }
        }
        .compactCard()
    }

    private var issuesCard:
        some View {
        DisclosureGroup(
            isExpanded:
                $showIssues
        ) {
            VStack(
                alignment: .leading,
                spacing: 8
            ) {
                Text(warningExplanation)
                    .font(.subheadline)

                Text(warningResolution)
                    .font(.caption)
                    .foregroundStyle(
                        .secondary
                    )
            }
            .padding(.top, 8)
        } label: {
            Label(
                "Scheduling note",
                systemImage:
                    "exclamationmark.triangle"
            )
            .font(.subheadline)
            .foregroundStyle(
                .secondary
            )
        }
        .compactCard()
    }

    private func metric(
        icon: String,
        value: String,
        label: String
    ) -> some View {
        VStack(
            alignment: .leading,
            spacing: 2
        ) {
            Label(
                value,
                systemImage: icon
            )
            .font(
                .subheadline
                    .weight(.semibold)
            )

            Text(label)
                .font(.caption2)
                .foregroundStyle(
                    .secondary
                )
        }
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
    }

    private func isCurrentStep(
        _ step: ScheduleRecipeStep
    ) -> Bool {
        guard let taskID =
            task.recipeTaskID
        else {
            return false
        }

        // Source-step linkage is not included in the schedule row,
        // so the closest stable indication is the task position.
        // The exact task instructions still appear in the summary.
        return step.position
            == task.position
            || step.id == taskID
    }

    private func servingsText(
        _ value: Double
    ) -> String {
        value.formatted(
            .number.precision(
                .fractionLength(0...1)
            )
        )
    }

    private var hasWarning: Bool {
        task.warningMessage != nil
            || task.hasConflict
    }

    private var warningTitle: String {
        task.warningMessage
        ?? (
            task.hasConflict
            ? "Overlapping task"
            : "Scheduling note"
        )
    }

    private var warningExplanation:
        String {
        switch warningTitle {
        case "Cooking is disabled for this day.":
            return "This work was placed on a day where cooking is disabled."

        case "Outside the configured task window.":
            return "The generated time falls outside your preferred task window."

        case "Exceeds the active-cooking limit.":
            return "The active work exceeds the maximum configured for this day."

        case "Overlapping task":
            return "This task overlaps another scheduled task."

        default:
            return warningTitle
        }
    }

    private var warningResolution:
        String {
        switch warningTitle {
        case "Cooking is disabled for this day.":
            return "Enable cooking for this day or move the meal."

        case "Outside the configured task window.":
            return "Adjust the meal time or widen the task window."

        case "Exceeds the active-cooking limit.":
            return "Increase the limit or move preparation to another day."

        case "Overlapping task":
            return "Adjust meal times or reduce simultaneous preparation."

        default:
            return "Review the schedule settings if this placement is inconvenient."
        }
    }
}

private extension View {
    func compactCard() -> some View {
        self
            .padding(14)
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
            .background(
                Color(
                    .secondarySystemGroupedBackground
                ),
                in: RoundedRectangle(
                    cornerRadius: 16,
                    style: .continuous
                )
            )
    }
}
