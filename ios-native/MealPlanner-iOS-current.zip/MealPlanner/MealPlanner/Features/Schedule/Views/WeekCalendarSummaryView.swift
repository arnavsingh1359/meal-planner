import SwiftUI

struct WeekCalendarSummaryView: View {
    let summaries:
        [ScheduleDaySummary]
    let selectedDate: Date
    let onSelect: (Date) -> Void

    var body: some View {
        GeometryReader { geometry in
            let spacing: CGFloat = 5
            let width =
                (
                    geometry.size.width
                    - spacing * 6
                ) / 7

            HStack(
                alignment: .top,
                spacing: spacing
            ) {
                ForEach(summaries) { item in
                    let selected =
                        Calendar.current
                            .isDate(
                                item.date,
                                inSameDayAs:
                                    selectedDate
                            )

                    Button {
                        onSelect(item.date)
                    } label: {
                        VStack(spacing: 4) {
                            Text(
                                item.date.formatted(
                                    .dateTime
                                        .weekday(
                                            .abbreviated
                                        )
                                )
                            )
                            .font(
                                .caption2
                                    .weight(.semibold)
                            )
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)

                            Text(
                                item.date.formatted(
                                    .dateTime.day()
                                )
                            )
                            .font(
                                .subheadline
                                    .weight(.semibold)
                            )

                            HStack(spacing: 3) {
                                if item.mealCount > 0 {
                                    Image(
                                        systemName:
                                            "fork.knife"
                                    )
                                }

                                if item.taskCount > 0 {
                                    Image(
                                        systemName:
                                            "clock.fill"
                                    )
                                }

                                if item.warningCount > 0 {
                                    Image(
                                        systemName:
                                            "exclamationmark.triangle.fill"
                                    )
                                    .foregroundStyle(
                                        selected
                                        ? Color.white
                                        : Color.orange
                                    )
                                }
                            }
                            .font(.caption2)
                            .frame(height: 13)

                            Spacer(minLength: 0)

                            ProgressView(
                                value:
                                    item
                                        .completionFraction
                            )
                            .progressViewStyle(
                                .linear
                            )
                            .tint(
                                selected
                                ? .white
                                : .green
                            )
                            .frame(
                                width:
                                    max(
                                        24,
                                        width - 12
                                    ),
                                height: 4
                            )
                        }
                        .foregroundStyle(
                            selected
                            ? Color.white
                            : Color.primary
                        )
                        .padding(.vertical, 7)
                        .frame(
                            width: width,
                            height: 88
                        )
                        .background(
                            selected
                            ? Color.green
                            : Color(
                                .secondarySystemGroupedBackground
                            ),
                            in: RoundedRectangle(
                                cornerRadius: 12,
                                style:
                                    .continuous
                            )
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .frame(height: 88)
    }
}
