import Foundation

nonisolated struct ScheduleRecipePrepOperation:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let recipeID: UUID
    let ingredientPosition: Int
    let sourceStepPositions: [Int]
    let canonicalIngredientName: String
    let displayIngredientName: String
    let action: String
    let preparationState: String
    let quantity: Double
    let unit: String
    let canMakeAhead: Bool
    let maximumMakeAheadHours: Int
    let storageMethod: String
    let batchKey: String
    let confidence: Double
    let manuallyEdited: Bool
    let analysisVersion: String
    let position: Int

    enum CodingKeys:
        String,
        CodingKey {

        case id
        case recipeID = "recipe_id"
        case ingredientPosition =
            "ingredient_position"
        case sourceStepPositions =
            "source_step_positions"
        case canonicalIngredientName =
            "canonical_ingredient_name"
        case displayIngredientName =
            "display_ingredient_name"
        case action
        case preparationState =
            "preparation_state"
        case quantity
        case unit
        case canMakeAhead =
            "can_make_ahead"
        case maximumMakeAheadHours =
            "maximum_make_ahead_hours"
        case storageMethod =
            "storage_method"
        case batchKey = "batch_key"
        case confidence
        case manuallyEdited =
            "manually_edited"
        case analysisVersion =
            "analysis_version"
        case position
    }
}

nonisolated struct ScheduleRecipeTask: Codable, Identifiable, Hashable {
    let id: UUID
    let recipeID: UUID
    let title: String
    let instructions: String?
    let taskType: String
    let activeMinutes: Int
    let passiveMinutes: Int
    let dayOffset: Int
    let startBeforeMealMinutes: Int
    let canBatch: Bool
    let batchKey: String?
    let canMakeAhead: Bool
    let maximumMakeAheadHours: Int
    let storageMethod: String
    let unattended: Bool
    let blocksActiveWork: Bool
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case recipeID = "recipe_id"
        case title
        case instructions
        case taskType = "task_type"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case dayOffset = "day_offset"
        case startBeforeMealMinutes = "start_before_meal_minutes"
        case canBatch = "can_batch"
        case batchKey = "batch_key"
        case canMakeAhead =
            "can_make_ahead"
        case maximumMakeAheadHours =
            "maximum_make_ahead_hours"
        case storageMethod =
            "storage_method"
        case unattended
        case blocksActiveWork = "blocks_active_work"
        case position
    }
}

nonisolated struct ScheduleRecipeSummary:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let name: String
    let defaultServings: Double
    let minimumBatchServings: Double
    let maximumBatchServings: Double
    let refrigeratorLifeDays: Int

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case defaultServings =
            "default_servings"
        case minimumBatchServings =
            "minimum_batch_servings"
        case maximumBatchServings =
            "maximum_batch_servings"
        case refrigeratorLifeDays =
            "refrigerator_life_days"
    }
}


nonisolated struct ScheduleRecipeIngredient:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let recipeID: UUID
    let name: String
    let quantity: Double
    let unit: String
    let preparationNote: String?
    let isOptional: Bool
    let scalingBehavior: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case recipeID = "recipe_id"
        case name
        case quantity
        case unit
        case preparationNote =
            "preparation_note"
        case isOptional =
            "is_optional"
        case scalingBehavior =
            "scaling_behavior"
        case position
    }

    func quantityText(
        selectedServings: Double,
        baseServings: Double
    ) -> String {
        if scalingBehavior == "to_taste" {
            return "To taste"
        }

        let scaledQuantity: Double

        if scalingBehavior == "fixed"
            || baseServings <= 0 {
            scaledQuantity = quantity
        } else {
            scaledQuantity =
                quantity
                * selectedServings
                / baseServings
        }

        let amount =
            scaledQuantity.formatted(
                .number.precision(
                    .fractionLength(0...2)
                )
            )

        return unit.isEmpty
            ? amount
            : "\(amount) \(unit)"
    }
}

nonisolated struct ScheduleRecipeStep:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let recipeID: UUID
    let instruction: String
    let durationMinutes: Int
    let stepType: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case recipeID = "recipe_id"
        case instruction
        case durationMinutes =
            "duration_minutes"
        case stepType =
            "step_type"
        case position
    }
}

nonisolated struct ScheduleGeneratedTask: Codable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID
    let weekStart: String
    let taskDate: String
    let weekPlanEntryID: UUID
    let recipeID: UUID
    let recipeTaskID: UUID?
    let title: String
    let instructions: String?
    let scheduledStart: Date
    let scheduledEnd: Date
    let activeMinutes: Int
    let passiveMinutes: Int
    let isCompleted: Bool
    let isManuallyAdjusted: Bool
    let hasConflict: Bool
    let warningMessage: String?
    let batchID: UUID?
    let batchServings: Double
    let batchMealCount: Int
    let batchExplanation: String?
    let coveredWeekPlanEntryIDs: [UUID]
    let isSharedPrep: Bool
    let sharedPrepKey: String?
    let sharedPrepRecipeIDs: [UUID]
    let sharedPrepRecipeNames: [String]
    let sharedPrepTaskIDs: [UUID]
    let sharedPrepExplanation: String?
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case weekStart = "week_start"
        case taskDate = "task_date"
        case weekPlanEntryID = "week_plan_entry_id"
        case recipeID = "recipe_id"
        case recipeTaskID = "recipe_task_id"
        case title
        case instructions
        case scheduledStart = "scheduled_start"
        case scheduledEnd = "scheduled_end"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case isCompleted = "is_completed"
        case isManuallyAdjusted = "is_manually_adjusted"
        case hasConflict = "has_conflict"
        case warningMessage =
            "warning_message"
        case batchID = "batch_id"
        case batchServings =
            "batch_servings"
        case batchMealCount =
            "batch_meal_count"
        case batchExplanation =
            "batch_explanation"
        case coveredWeekPlanEntryIDs =
            "covered_week_plan_entry_ids"
        case isSharedPrep =
            "is_shared_prep"
        case sharedPrepKey =
            "shared_prep_key"
        case sharedPrepRecipeIDs =
            "shared_prep_recipe_ids"
        case sharedPrepRecipeNames =
            "shared_prep_recipe_names"
        case sharedPrepTaskIDs =
            "shared_prep_task_ids"
        case sharedPrepExplanation =
            "shared_prep_explanation"
        case position
    }
}

nonisolated struct ScheduleTaskInsert: Encodable {
    let userID: UUID
    let weekStart: String
    let taskDate: String
    let weekPlanEntryID: UUID
    let recipeID: UUID
    let recipeTaskID: UUID?
    let title: String
    let instructions: String?
    let scheduledStart: Date
    let scheduledEnd: Date
    let activeMinutes: Int
    let passiveMinutes: Int
    let isCompleted: Bool
    let isManuallyAdjusted: Bool
    let hasConflict: Bool
    let warningMessage: String?
    let batchID: UUID?
    let batchServings: Double
    let batchMealCount: Int
    let batchExplanation: String?
    let coveredWeekPlanEntryIDs: [UUID]
    let isSharedPrep: Bool
    let sharedPrepKey: String?
    let sharedPrepRecipeIDs: [UUID]
    let sharedPrepRecipeNames: [String]
    let sharedPrepTaskIDs: [UUID]
    let sharedPrepExplanation: String?
    let position: Int

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case weekStart = "week_start"
        case taskDate = "task_date"
        case weekPlanEntryID = "week_plan_entry_id"
        case recipeID = "recipe_id"
        case recipeTaskID = "recipe_task_id"
        case title
        case instructions
        case scheduledStart = "scheduled_start"
        case scheduledEnd = "scheduled_end"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case isCompleted = "is_completed"
        case isManuallyAdjusted = "is_manually_adjusted"
        case hasConflict = "has_conflict"
        case warningMessage =
            "warning_message"
        case batchID = "batch_id"
        case batchServings =
            "batch_servings"
        case batchMealCount =
            "batch_meal_count"
        case batchExplanation =
            "batch_explanation"
        case coveredWeekPlanEntryIDs =
            "covered_week_plan_entry_ids"
        case isSharedPrep =
            "is_shared_prep"
        case sharedPrepKey =
            "shared_prep_key"
        case sharedPrepRecipeIDs =
            "shared_prep_recipe_ids"
        case sharedPrepRecipeNames =
            "shared_prep_recipe_names"
        case sharedPrepTaskIDs =
            "shared_prep_task_ids"
        case sharedPrepExplanation =
            "shared_prep_explanation"
        case position
    }
}

nonisolated struct ScheduleCompletionUpdate: Encodable {
    let isCompleted: Bool

    enum CodingKeys: String, CodingKey {
        case isCompleted = "is_completed"
    }
}

nonisolated struct ScheduleDaySummary: Identifiable, Hashable {
    let date: Date
    let mealCount: Int
    let taskCount: Int
    let completedCount: Int
    let warningCount: Int
    let nextTaskTitle: String?

    var id: Date {
        date
    }

    var completionFraction: Double {
        guard taskCount > 0 else {
            return 0
        }

        return Double(completedCount)
            / Double(taskCount)
    }
}

nonisolated struct ScheduleMealSlotRecord: Codable {
    let id: UUID
    let dayOfWeek: Int
    let position: Int
    let name: String
    let eatTime: String
    let readyTime: String

    enum CodingKeys: String, CodingKey {
        case id
        case dayOfWeek = "day_of_week"
        case position
        case name
        case eatTime = "eat_time"
        case readyTime = "ready_time"
    }
}

nonisolated struct ScheduleDayPreferenceRecord: Codable {
    let dayOfWeek: Int
    let earliestTaskTime: String
    let latestTaskTime: String
    let eveningPrepStart: String
    let eveningPrepEnd: String
    let maxActiveCookingMinutes: Int
    let cookingAllowed: Bool

    enum CodingKeys: String, CodingKey {
        case dayOfWeek = "day_of_week"
        case earliestTaskTime = "earliest_task_time"
        case latestTaskTime = "latest_task_time"
        case eveningPrepStart = "evening_prep_start"
        case eveningPrepEnd = "evening_prep_end"
        case maxActiveCookingMinutes = "max_active_cooking_minutes"
        case cookingAllowed = "cooking_allowed"
    }
}

nonisolated struct ScheduleGlobalPreferenceRecord: Codable {
    let conflictGroupingMinutes: Int
    let preferredBatchDays: [String]
    let preserveManualAdjustments: Bool

    enum CodingKeys: String, CodingKey {
        case conflictGroupingMinutes = "conflict_grouping_minutes"
        case preferredBatchDays = "preferred_batch_days"
        case preserveManualAdjustments = "preserve_manual_adjustments"
    }
}

nonisolated struct SchedulerDayWindow: Hashable {
    let dayNumber: Int
    let earliestTaskTime: String
    let latestTaskTime: String
    let maxActiveCookingMinutes: Int
    let cookingAllowed: Bool
}

nonisolated struct SchedulerTaskTemplate: Identifiable, Hashable {
    let id: UUID
    let position: Int
    let activeMinutes: Int
    let passiveMinutes: Int
    let dayOffset: Int
    let startBeforeMealMinutes: Int
    let blocksActiveWork: Bool
}

nonisolated struct SchedulerExistingPlacement: Hashable {
    let start: Date
    let end: Date
    let blocksActiveWork: Bool
}

nonisolated struct SchedulerTaskPlacement: Identifiable, Hashable {
    let id: UUID
    let position: Int
    let start: Date
    let end: Date
    let activeMinutes: Int
    let passiveMinutes: Int
    let hasConflict: Bool
    let warningMessage: String?
}

nonisolated enum SchedulerPlacementEngine {
    static func makePlacements(
        mealReadyAt: Date,
        templates: [SchedulerTaskTemplate],
        windows: [SchedulerDayWindow],
        existingPlacements: [SchedulerExistingPlacement],
        conflictGroupingMinutes: Int,
        calendar: Calendar = .current
    ) -> [SchedulerTaskPlacement] {
        let orderedTemplates = templates.sorted {
            $0.position < $1.position
        }

        var reversePlacements: [SchedulerTaskPlacement] = []
        var placedActiveIntervals = existingPlacements
        var dependencyCursor = mealReadyAt
        let conflictTolerance = max(0, conflictGroupingMinutes)

        for template in orderedTemplates.reversed() {
            let activeMinutes = max(0, template.activeMinutes)
            let passiveMinutes = max(0, template.passiveMinutes)
            let duration = max(1, activeMinutes + passiveMinutes)

            let offsetMealReadyAt = calendar.date(
                byAdding: .day,
                value: -max(0, template.dayOffset),
                to: mealReadyAt
            ) ?? mealReadyAt

            let preferredStart = calendar.date(
                byAdding: .minute,
                value: -max(0, template.startBeforeMealMinutes),
                to: offsetMealReadyAt
            ) ?? offsetMealReadyAt

            let preferredEnd = calendar.date(
                byAdding: .minute,
                value: duration,
                to: preferredStart
            ) ?? preferredStart

            let dependencyDeadline = minDate(
                dependencyCursor,
                offsetMealReadyAt
            )

            let requestedEnd = minDate(
                preferredEnd,
                dependencyDeadline
            )

            let placement = place(
                template: template,
                requestedEnd: requestedEnd,
                duration: duration,
                activeMinutes: activeMinutes,
                passiveMinutes: passiveMinutes,
                mealReadyAt: mealReadyAt,
                windows: windows,
                existingPlacements: placedActiveIntervals,
                conflictGroupingMinutes: conflictTolerance,
                calendar: calendar
            )

            reversePlacements.append(placement)

            if template.blocksActiveWork {
                placedActiveIntervals.append(
                    SchedulerExistingPlacement(
                        start: placement.start,
                        end: placement.end,
                        blocksActiveWork: true
                    )
                )
            }

            dependencyCursor = placement.start
        }

        return reversePlacements.sorted {
            $0.position < $1.position
        }
    }

    private static func place(
        template: SchedulerTaskTemplate,
        requestedEnd: Date,
        duration: Int,
        activeMinutes: Int,
        passiveMinutes: Int,
        mealReadyAt: Date,
        windows: [SchedulerDayWindow],
        existingPlacements: [SchedulerExistingPlacement],
        conflictGroupingMinutes: Int,
        calendar: Calendar
    ) -> SchedulerTaskPlacement {
        let dayNumber = schedulerDayNumber(
            for: requestedEnd,
            calendar: calendar
        )

        let window = windows.first {
            $0.dayNumber == dayNumber
        }

        var start: Date
        var end: Date
        var warning: String?

        if let window {
            let earliest = dateByApplyingTime(
                window.earliestTaskTime,
                to: requestedEnd,
                calendar: calendar
            )

            let latest = dateByApplyingTime(
                window.latestTaskTime,
                to: requestedEnd,
                calendar: calendar
            )

            let latestAllowedEnd = minDate(
                requestedEnd,
                latest
            )

            let candidateStart = calendar.date(
                byAdding: .minute,
                value: -duration,
                to: latestAllowedEnd
            ) ?? latestAllowedEnd

            if candidateStart < earliest {
                start = earliest
                end = calendar.date(
                    byAdding: .minute,
                    value: duration,
                    to: start
                ) ?? start
                warning = "Cannot fit within configured task window."
            } else {
                start = candidateStart
                end = latestAllowedEnd
            }

            if !window.cookingAllowed && activeMinutes > 0 {
                warning = "Cooking is disabled for this day."
            } else if activeMinutes > window.maxActiveCookingMinutes {
                warning = "Exceeds the active-cooking limit."
            } else if start < earliest || end > latest {
                warning = warning ?? "Outside the configured task window."
            }
        } else {
            end = requestedEnd
            start = calendar.date(
                byAdding: .minute,
                value: -duration,
                to: end
            ) ?? end
        }

        if end > mealReadyAt && warning == nil {
            warning = "Ends after meal ready time."
        }

        let hasConflict = template.blocksActiveWork
            && existingPlacements.contains { existing in
                guard existing.blocksActiveWork else {
                    return false
                }

                return overlapMinutes(
                    start,
                    end,
                    existing.start,
                    existing.end
                ) > conflictGroupingMinutes
            }

        return SchedulerTaskPlacement(
            id: template.id,
            position: template.position,
            start: start,
            end: end,
            activeMinutes: activeMinutes,
            passiveMinutes: passiveMinutes,
            hasConflict: hasConflict,
            warningMessage: warning
        )
    }

    private static func minDate(
        _ first: Date,
        _ second: Date
    ) -> Date {
        first < second ? first : second
    }

    private static func overlapMinutes(
        _ firstStart: Date,
        _ firstEnd: Date,
        _ secondStart: Date,
        _ secondEnd: Date
    ) -> Int {
        let start = max(firstStart, secondStart)
        let end = min(firstEnd, secondEnd)

        guard start < end else {
            return 0
        }

        return max(
            0,
            Int(end.timeIntervalSince(start) / 60)
        )
    }

    private static func schedulerDayNumber(
        for date: Date,
        calendar: Calendar
    ) -> Int {
        let weekday = calendar.component(
            .weekday,
            from: date
        )

        return weekday == 1 ? 7 : weekday - 1
    }

    private static func dateByApplyingTime(
        _ value: String,
        to date: Date,
        calendar: Calendar
    ) -> Date {
        let parts = value.split(separator: ":")

        let hour = parts.first.flatMap {
            Int($0)
        } ?? 0

        let minute = parts.dropFirst().first.flatMap {
            Int($0)
        } ?? 0

        return calendar.date(
            bySettingHour: hour,
            minute: minute,
            second: 0,
            of: date
        ) ?? date
    }
}
