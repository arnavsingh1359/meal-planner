import Foundation

nonisolated struct ScheduleRecipePrepOperation:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let recipeID: UUID
    let ingredientPosition: Int
    let sourceStepPositions: [Int]
    let canonicalIngredientName: String
    let displayIngredientName: String
    let action: String
    let preparationState: String
    let quantity: Double
    let unit: String
    let canMakeAhead: Bool
    let maximumMakeAheadHours: Int
    let storageMethod: String
    let batchKey: String
    let confidence: Double
    let manuallyEdited: Bool
    let analysisVersion: String
    let position: Int

    enum CodingKeys:
        String,
        CodingKey {

        case id
        case recipeID = "recipe_id"
        case ingredientPosition =
            "ingredient_position"
        case sourceStepPositions =
            "source_step_positions"
        case canonicalIngredientName =
            "canonical_ingredient_name"
        case displayIngredientName =
            "display_ingredient_name"
        case action
        case preparationState =
            "preparation_state"
        case quantity
        case unit
        case canMakeAhead =
            "can_make_ahead"
        case maximumMakeAheadHours =
            "maximum_make_ahead_hours"
        case storageMethod =
            "storage_method"
        case batchKey = "batch_key"
        case confidence
        case manuallyEdited =
            "manually_edited"
        case analysisVersion =
            "analysis_version"
        case position
    }
}

nonisolated struct ScheduleRecipeTask: Codable, Identifiable, Hashable {
    let id: UUID
    let recipeID: UUID
    let title: String
    let instructions: String?
    let taskType: String
    let activeMinutes: Int
    let passiveMinutes: Int
    let dayOffset: Int
    let startBeforeMealMinutes: Int
    let canBatch: Bool
    let batchKey: String?
    let canMakeAhead: Bool
    let maximumMakeAheadHours: Int
    let storageMethod: String
    let unattended: Bool
    let blocksActiveWork: Bool
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case recipeID = "recipe_id"
        case title
        case instructions
        case taskType = "task_type"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case dayOffset = "day_offset"
        case startBeforeMealMinutes = "start_before_meal_minutes"
        case canBatch = "can_batch"
        case batchKey = "batch_key"
        case canMakeAhead =
            "can_make_ahead"
        case maximumMakeAheadHours =
            "maximum_make_ahead_hours"
        case storageMethod =
            "storage_method"
        case unattended
        case blocksActiveWork = "blocks_active_work"
        case position
    }
}

nonisolated struct ScheduleRecipeSummary:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let name: String
    let defaultServings: Double
    let minimumBatchServings: Double
    let maximumBatchServings: Double
    let refrigeratorLifeDays: Int

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case defaultServings =
            "default_servings"
        case minimumBatchServings =
            "minimum_batch_servings"
        case maximumBatchServings =
            "maximum_batch_servings"
        case refrigeratorLifeDays =
            "refrigerator_life_days"
    }
}


nonisolated struct ScheduleRecipeIngredient:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let recipeID: UUID
    let name: String
    let quantity: Double
    let unit: String
    let preparationNote: String?
    let isOptional: Bool
    let scalingBehavior: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case recipeID = "recipe_id"
        case name
        case quantity
        case unit
        case preparationNote =
            "preparation_note"
        case isOptional =
            "is_optional"
        case scalingBehavior =
            "scaling_behavior"
        case position
    }

    func quantityText(
        selectedServings: Double,
        baseServings: Double
    ) -> String {
        if scalingBehavior == "to_taste" {
            return "To taste"
        }

        let scaledQuantity: Double

        if scalingBehavior == "fixed"
            || baseServings <= 0 {
            scaledQuantity = quantity
        } else {
            scaledQuantity =
                quantity
                * selectedServings
                / baseServings
        }

        let amount =
            scaledQuantity.formatted(
                .number.precision(
                    .fractionLength(0...2)
                )
            )

        return unit.isEmpty
            ? amount
            : "\(amount) \(unit)"
    }
}

nonisolated struct ScheduleRecipeStep:
    Codable,
    Identifiable,
    Hashable {

    let id: UUID
    let recipeID: UUID
    let instruction: String
    let durationMinutes: Int
    let stepType: String
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case recipeID = "recipe_id"
        case instruction
        case durationMinutes =
            "duration_minutes"
        case stepType =
            "step_type"
        case position
    }
}

nonisolated struct ScheduleGeneratedTask: Codable, Identifiable, Hashable {
    let id: UUID
    let userID: UUID
    let weekStart: String
    let taskDate: String
    let weekPlanEntryID: UUID
    let recipeID: UUID
    let recipeTaskID: UUID?
    let title: String
    let instructions: String?
    let scheduledStart: Date
    let scheduledEnd: Date
    let activeMinutes: Int
    let passiveMinutes: Int
    let isCompleted: Bool
    let isManuallyAdjusted: Bool
    let hasConflict: Bool
    let warningMessage: String?
    let batchID: UUID?
    let batchServings: Double
    let batchMealCount: Int
    let batchExplanation: String?
    let coveredWeekPlanEntryIDs: [UUID]
    let isSharedPrep: Bool
    let sharedPrepKey: String?
    let sharedPrepRecipeIDs: [UUID]
    let sharedPrepRecipeNames: [String]
    let sharedPrepTaskIDs: [UUID]
    let sharedPrepExplanation: String?
    let position: Int

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case weekStart = "week_start"
        case taskDate = "task_date"
        case weekPlanEntryID = "week_plan_entry_id"
        case recipeID = "recipe_id"
        case recipeTaskID = "recipe_task_id"
        case title
        case instructions
        case scheduledStart = "scheduled_start"
        case scheduledEnd = "scheduled_end"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case isCompleted = "is_completed"
        case isManuallyAdjusted = "is_manually_adjusted"
        case hasConflict = "has_conflict"
        case warningMessage =
            "warning_message"
        case batchID = "batch_id"
        case batchServings =
            "batch_servings"
        case batchMealCount =
            "batch_meal_count"
        case batchExplanation =
            "batch_explanation"
        case coveredWeekPlanEntryIDs =
            "covered_week_plan_entry_ids"
        case isSharedPrep =
            "is_shared_prep"
        case sharedPrepKey =
            "shared_prep_key"
        case sharedPrepRecipeIDs =
            "shared_prep_recipe_ids"
        case sharedPrepRecipeNames =
            "shared_prep_recipe_names"
        case sharedPrepTaskIDs =
            "shared_prep_task_ids"
        case sharedPrepExplanation =
            "shared_prep_explanation"
        case position
    }
}

nonisolated struct ScheduleTaskInsert: Encodable {
    let userID: UUID
    let weekStart: String
    let taskDate: String
    let weekPlanEntryID: UUID
    let recipeID: UUID
    let recipeTaskID: UUID?
    let title: String
    let instructions: String?
    let scheduledStart: Date
    let scheduledEnd: Date
    let activeMinutes: Int
    let passiveMinutes: Int
    let isCompleted: Bool
    let isManuallyAdjusted: Bool
    let hasConflict: Bool
    let warningMessage: String?
    let batchID: UUID?
    let batchServings: Double
    let batchMealCount: Int
    let batchExplanation: String?
    let coveredWeekPlanEntryIDs: [UUID]
    let isSharedPrep: Bool
    let sharedPrepKey: String?
    let sharedPrepRecipeIDs: [UUID]
    let sharedPrepRecipeNames: [String]
    let sharedPrepTaskIDs: [UUID]
    let sharedPrepExplanation: String?
    let position: Int

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case weekStart = "week_start"
        case taskDate = "task_date"
        case weekPlanEntryID = "week_plan_entry_id"
        case recipeID = "recipe_id"
        case recipeTaskID = "recipe_task_id"
        case title
        case instructions
        case scheduledStart = "scheduled_start"
        case scheduledEnd = "scheduled_end"
        case activeMinutes = "active_minutes"
        case passiveMinutes = "passive_minutes"
        case isCompleted = "is_completed"
        case isManuallyAdjusted = "is_manually_adjusted"
        case hasConflict = "has_conflict"
        case warningMessage =
            "warning_message"
        case batchID = "batch_id"
        case batchServings =
            "batch_servings"
        case batchMealCount =
            "batch_meal_count"
        case batchExplanation =
            "batch_explanation"
        case coveredWeekPlanEntryIDs =
            "covered_week_plan_entry_ids"
        case isSharedPrep =
            "is_shared_prep"
        case sharedPrepKey =
            "shared_prep_key"
        case sharedPrepRecipeIDs =
            "shared_prep_recipe_ids"
        case sharedPrepRecipeNames =
            "shared_prep_recipe_names"
        case sharedPrepTaskIDs =
            "shared_prep_task_ids"
        case sharedPrepExplanation =
            "shared_prep_explanation"
        case position
    }
}

nonisolated struct ScheduleCompletionUpdate: Encodable {
    let isCompleted: Bool

    enum CodingKeys: String, CodingKey {
        case isCompleted = "is_completed"
    }
}

nonisolated struct ScheduleDaySummary: Identifiable, Hashable {
    let date: Date
    let mealCount: Int
    let taskCount: Int
    let completedCount: Int
    let warningCount: Int
    let nextTaskTitle: String?

    var id: Date {
        date
    }

    var completionFraction: Double {
        guard taskCount > 0 else {
            return 0
        }

        return Double(completedCount)
            / Double(taskCount)
    }
}

nonisolated struct ScheduleMealSlotRecord: Codable {
    let id: UUID
    let dayOfWeek: Int
    let position: Int
    let name: String
    let eatTime: String
    let readyTime: String

    enum CodingKeys: String, CodingKey {
        case id
        case dayOfWeek = "day_of_week"
        case position
        case name
        case eatTime = "eat_time"
        case readyTime = "ready_time"
    }
}

nonisolated struct ScheduleDayPreferenceRecord: Codable {
    let dayOfWeek: Int
    let earliestTaskTime: String
    let latestTaskTime: String
    let eveningPrepStart: String
    let eveningPrepEnd: String
    let maxActiveCookingMinutes: Int
    let cookingAllowed: Bool

    enum CodingKeys: String, CodingKey {
        case dayOfWeek = "day_of_week"
        case earliestTaskTime = "earliest_task_time"
        case latestTaskTime = "latest_task_time"
        case eveningPrepStart = "evening_prep_start"
        case eveningPrepEnd = "evening_prep_end"
        case maxActiveCookingMinutes = "max_active_cooking_minutes"
        case cookingAllowed = "cooking_allowed"
    }
}

nonisolated struct ScheduleGlobalPreferenceRecord: Codable {
    let conflictGroupingMinutes: Int
    let preferredBatchDays: [String]
    let preserveManualAdjustments: Bool

    enum CodingKeys: String, CodingKey {
        case conflictGroupingMinutes = "conflict_grouping_minutes"
        case preferredBatchDays = "preferred_batch_days"
        case preserveManualAdjustments = "preserve_manual_adjustments"
    }
}
