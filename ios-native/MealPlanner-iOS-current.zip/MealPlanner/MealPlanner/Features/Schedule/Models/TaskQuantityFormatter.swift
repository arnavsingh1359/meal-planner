import Foundation

nonisolated struct ScheduledTaskQuantityDisplayLine:
    Identifiable,
    Hashable {

    let id: String
    let text: String
    let ingredientName: String
    let quantityText: String
}

nonisolated protocol ScheduledTaskQuantityContext {
    var weekPlanEntryID: UUID { get }
    var recipeID: UUID { get }
    var recipeTaskID: UUID? { get }
    var title: String { get }
    var instructions: String? { get }
    var batchServings: Double { get }
    var coveredWeekPlanEntryIDs: [UUID] { get }
    var isSharedPrep: Bool { get }
    var sharedPrepKey: String? { get }
}

extension ScheduleGeneratedTask:
    ScheduledTaskQuantityContext {}

nonisolated enum ScheduledTaskQuantityResolver {
    static func lines<T: ScheduledTaskQuantityContext>(
        for task: T,
        entries: [WeekPlanEntry] = [],
        recipes: [ScheduleRecipeSummary],
        recipeTasks: [ScheduleRecipeTask],
        prepOperations: [ScheduleRecipePrepOperation],
        ingredients: [ScheduleRecipeIngredient],
        limit: Int = 3
    ) -> [ScheduledTaskQuantityDisplayLine] {
        let taskTemplate = task.recipeTaskID.flatMap { taskID in
            recipeTasks.first { $0.id == taskID }
        }

        let involvedEntries = plannedEntries(
            for: task,
            entries: entries
        )

        if !involvedEntries.isEmpty {
            let aggregated = aggregateQuantitiesFromEntries(
                task: task,
                taskTemplate: taskTemplate,
                entries: involvedEntries,
                recipes: recipes,
                prepOperations: prepOperations,
                ingredients: ingredients
            )

            if !aggregated.isEmpty {
                return Array(
                    sortedAggregated(aggregated)
                        .prefix(max(1, limit))
                        .enumerated()
                        .map { index, value in
                            ScheduledTaskQuantityDisplayLine(
                                id: "entry-quantity-\(index)-\(value.normalizedIngredientName)-\(value.unit)",
                                text: value.displayText,
                                ingredientName: value.ingredientName,
                                quantityText: value.quantityText
                            )
                        }
                )
            }
        }

        return fallbackLines(
            for: task,
            taskTemplate: taskTemplate,
            recipes: recipes,
            prepOperations: prepOperations,
            ingredients: ingredients,
            limit: limit
        )
    }

    static func summaryText<T: ScheduledTaskQuantityContext>(
        for task: T,
        entries: [WeekPlanEntry] = [],
        recipes: [ScheduleRecipeSummary],
        recipeTasks: [ScheduleRecipeTask],
        prepOperations: [ScheduleRecipePrepOperation],
        ingredients: [ScheduleRecipeIngredient],
        limit: Int = 2
    ) -> String? {
        let resolvedLines = lines(
            for: task,
            entries: entries,
            recipes: recipes,
            recipeTasks: recipeTasks,
            prepOperations: prepOperations,
            ingredients: ingredients,
            limit: limit
        )

        guard !resolvedLines.isEmpty else {
            return nil
        }

        return resolvedLines
            .map(\.text)
            .joined(separator: " • ")
    }

    private static func plannedEntries<T: ScheduledTaskQuantityContext>(
        for task: T,
        entries: [WeekPlanEntry]
    ) -> [WeekPlanEntry] {
        guard !entries.isEmpty else {
            return []
        }

        let coveredIDs = Set(task.coveredWeekPlanEntryIDs)

        let matches: [WeekPlanEntry]

        if coveredIDs.isEmpty {
            matches = entries.filter {
                $0.id == task.weekPlanEntryID
            }
        } else {
            matches = entries.filter {
                coveredIDs.contains($0.id)
            }
        }

        return matches.sorted { lhs, rhs in
            if lhs.mealDate != rhs.mealDate {
                return lhs.mealDate < rhs.mealDate
            }

            if lhs.position != rhs.position {
                return lhs.position < rhs.position
            }

            return lhs.id.uuidString < rhs.id.uuidString
        }
    }

    private static func aggregateQuantitiesFromEntries<T: ScheduledTaskQuantityContext>(
        task: T,
        taskTemplate: ScheduleRecipeTask?,
        entries: [WeekPlanEntry],
        recipes: [ScheduleRecipeSummary],
        prepOperations: [ScheduleRecipePrepOperation],
        ingredients: [ScheduleRecipeIngredient]
    ) -> [AggregatedQuantity] {
        var buckets: [String: AggregatedQuantity] = [:]

        for entry in entries {
            let recipeID = entry.recipeID
            let baseServings = max(
                0.5,
                recipes.first { $0.id == recipeID }?.defaultServings ?? 1
            )
            let selectedServings = max(0.0, entry.servings)

            let entryPrepOperations = matchingPrepOperations(
                for: task,
                recipeID: recipeID,
                taskTemplate: taskTemplate,
                prepOperations: prepOperations
            )

            if !entryPrepOperations.isEmpty {
                for operation in entryPrepOperations {
                    let matchedIngredient = ingredients.first {
                        $0.recipeID == recipeID
                            && $0.position == operation.ingredientPosition
                    }

                    let rawQuantity = matchedIngredient?.quantity ?? operation.quantity
                    let unit = matchedIngredient?.unit ?? operation.unit
                    let ingredientName = matchedIngredient?.name ?? operation.displayIngredientName
                    let scalingBehavior = matchedIngredient?.scalingBehavior ?? "linear"

                    addQuantity(
                        rawQuantity: rawQuantity,
                        unit: unit,
                        ingredientName: ingredientName,
                        scalingBehavior: scalingBehavior,
                        selectedServings: selectedServings,
                        baseServings: baseServings,
                        operationPosition: operation.position,
                        into: &buckets
                    )
                }

                continue
            }

            let entryIngredients = matchingIngredients(
                for: task,
                recipeID: recipeID,
                ingredients: ingredients
            )

            for ingredient in entryIngredients {
                addQuantity(
                    rawQuantity: ingredient.quantity,
                    unit: ingredient.unit,
                    ingredientName: ingredient.name,
                    scalingBehavior: ingredient.scalingBehavior,
                    selectedServings: selectedServings,
                    baseServings: baseServings,
                    operationPosition: ingredient.position,
                    into: &buckets
                )
            }
        }

        return Array(buckets.values)
    }

    private static func addQuantity(
        rawQuantity: Double,
        unit: String,
        ingredientName: String,
        scalingBehavior: String,
        selectedServings: Double,
        baseServings: Double,
        operationPosition: Int,
        into buckets: inout [String: AggregatedQuantity]
    ) {
        let cleanedName = ingredientName
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard !cleanedName.isEmpty else {
            return
        }

        let scaledQuantity: Double

        if scalingBehavior == "to_taste" {
            scaledQuantity = 0
        } else if scalingBehavior == "fixed" || baseServings <= 0 {
            scaledQuantity = rawQuantity
        } else {
            scaledQuantity = rawQuantity * selectedServings / baseServings
        }

        let cleanedUnit = unit
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let normalizedName = normalizedIngredientKey(cleanedName)
        let key = "\(normalizedName)|\(cleanedUnit.lowercased())"

        if var existing = buckets[key] {
            existing.quantity += scaledQuantity
            existing.sortPosition = min(existing.sortPosition, operationPosition)
            buckets[key] = existing
        } else {
            buckets[key] = AggregatedQuantity(
                ingredientName: cleanedName,
                normalizedIngredientName: normalizedName,
                quantity: scaledQuantity,
                unit: cleanedUnit,
                isToTaste: scalingBehavior == "to_taste",
                sortPosition: operationPosition
            )
        }
    }

    private static func fallbackLines<T: ScheduledTaskQuantityContext>(
        for task: T,
        taskTemplate: ScheduleRecipeTask?,
        recipes: [ScheduleRecipeSummary],
        prepOperations: [ScheduleRecipePrepOperation],
        ingredients: [ScheduleRecipeIngredient],
        limit: Int
    ) -> [ScheduledTaskQuantityDisplayLine] {
        let baseServings = max(
            0.5,
            recipes.first { $0.id == task.recipeID }?.defaultServings ?? 1
        )

        let selectedServings = max(0.5, task.batchServings)

        let matchedPrepOperations = matchingPrepOperations(
            for: task,
            recipeID: task.recipeID,
            taskTemplate: taskTemplate,
            prepOperations: prepOperations
        )

        if !matchedPrepOperations.isEmpty {
            return Array(
                matchedPrepOperations
                    .sorted { $0.position < $1.position }
                    .map { operation in
                        let matchedIngredient = ingredients.first {
                            $0.recipeID == task.recipeID
                                && $0.position == operation.ingredientPosition
                        }

                        let quantityText = formattedQuantity(
                            quantity: matchedIngredient?.quantity ?? operation.quantity,
                            unit: matchedIngredient?.unit ?? operation.unit,
                            scalingBehavior: matchedIngredient?.scalingBehavior ?? "linear",
                            selectedServings: selectedServings,
                            baseServings: baseServings
                        )

                        let ingredientName = (matchedIngredient?.name ?? operation.displayIngredientName)
                            .trimmingCharacters(in: .whitespacesAndNewlines)

                        return ScheduledTaskQuantityDisplayLine(
                            id: "prep-\(operation.id.uuidString)",
                            text: "\(quantityText) \(ingredientName)".trimmedWhitespace,
                            ingredientName: ingredientName,
                            quantityText: quantityText
                        )
                    }
                    .prefix(max(1, limit))
            )
        }

        let matchedIngredients = matchingIngredients(
            for: task,
            recipeID: task.recipeID,
            ingredients: ingredients
        )

        return Array(
            matchedIngredients
                .sorted { $0.position < $1.position }
                .map { ingredient in
                    let quantityText = ingredient.quantityText(
                        selectedServings: selectedServings,
                        baseServings: baseServings
                    )

                    return ScheduledTaskQuantityDisplayLine(
                        id: "ingredient-\(ingredient.id.uuidString)",
                        text: "\(quantityText) \(ingredient.name)".trimmedWhitespace,
                        ingredientName: ingredient.name,
                        quantityText: quantityText
                    )
                }
                .prefix(max(1, limit))
        )
    }

    private static func matchingPrepOperations<T: ScheduledTaskQuantityContext>(
        for task: T,
        recipeID: UUID,
        taskTemplate: ScheduleRecipeTask?,
        prepOperations: [ScheduleRecipePrepOperation]
    ) -> [ScheduleRecipePrepOperation] {
        let taskText = normalizedSearchText(
            [
                task.title,
                task.instructions ?? "",
                taskTemplate?.title ?? "",
                taskTemplate?.instructions ?? ""
            ]
            .joined(separator: " ")
        )

        let taskBatchKey = taskTemplate?.batchKey?.normalizedKey
        let sharedPrepKey = task.sharedPrepKey?.normalizedKey

        let recipeMatches = prepOperations.filter {
            $0.recipeID == recipeID
        }

        let batchKeyMatches = recipeMatches.filter { operation in
            let operationKey = operation.batchKey.normalizedKey

            return !operationKey.isEmpty
                && (operationKey == taskBatchKey
                    || operationKey == sharedPrepKey)
        }

        if !batchKeyMatches.isEmpty {
            return deduplicated(batchKeyMatches)
        }

        let textMatches = recipeMatches.filter { operation in
            let ingredient = normalizedSearchText(operation.displayIngredientName)
            let canonical = normalizedSearchText(operation.canonicalIngredientName)
            let action = normalizedSearchText(operation.action)
            let state = normalizedSearchText(operation.preparationState)

            let mentionsIngredient = textMentionsIngredient(
                taskText: taskText,
                ingredientNames: [ingredient, canonical]
            )

            let mentionsAction = action.isEmpty
                || taskText.contains(action)
                || (!state.isEmpty && taskText.contains(state))

            return mentionsIngredient && mentionsAction
        }

        return deduplicated(textMatches)
    }

    private static func matchingIngredients<T: ScheduledTaskQuantityContext>(
        for task: T,
        recipeID: UUID,
        ingredients: [ScheduleRecipeIngredient]
    ) -> [ScheduleRecipeIngredient] {
        let taskText = normalizedSearchText(
            [task.title, task.instructions ?? ""].joined(separator: " ")
        )

        return ingredients.filter { ingredient in
            ingredient.recipeID == recipeID
                && textMentionsIngredient(
                    taskText: taskText,
                    ingredientNames: [normalizedSearchText(ingredient.name)]
                )
        }
    }

    private static func deduplicated(
        _ operations: [ScheduleRecipePrepOperation]
    ) -> [ScheduleRecipePrepOperation] {
        var seen = Set<String>()

        return operations.filter { operation in
            let key = "\(operation.recipeID.uuidString)|\(operation.ingredientPosition)|\(operation.batchKey.normalizedKey)"
            return seen.insert(key).inserted
        }
    }

    private static func formattedQuantity(
        quantity: Double,
        unit: String,
        scalingBehavior: String,
        selectedServings: Double,
        baseServings: Double
    ) -> String {
        if scalingBehavior == "to_taste" {
            return "To taste"
        }

        let scaled: Double

        if scalingBehavior == "fixed" || baseServings <= 0 {
            scaled = quantity
        } else {
            scaled = quantity * selectedServings / baseServings
        }

        let amount = scaled.formatted(
            .number.precision(.fractionLength(0...2))
        )

        let cleanedUnit = unit.trimmingCharacters(in: .whitespacesAndNewlines)

        return cleanedUnit.isEmpty ? amount : "\(amount) \(cleanedUnit)"
    }

    private static func textMentionsIngredient(
        taskText: String,
        ingredientNames: [String]
    ) -> Bool {
        let taskTokens = Set(taskText.split(separator: " ").map(String.init))

        for name in ingredientNames where !name.isEmpty {
            if taskText.contains(name) {
                return true
            }

            let tokens = name
                .split(separator: " ")
                .map(String.init)
                .filter { $0.count > 2 }

            if tokens.contains(where: { taskTokens.contains($0) }) {
                return true
            }
        }

        return false
    }


    private static func sortedAggregated(_ values: [AggregatedQuantity]) -> [AggregatedQuantity] {
        values.sorted { lhs, rhs in
            if lhs.sortPosition != rhs.sortPosition {
                return lhs.sortPosition < rhs.sortPosition
            }

            if lhs.ingredientName != rhs.ingredientName {
                return lhs.ingredientName.localizedCaseInsensitiveCompare(rhs.ingredientName) == .orderedAscending
            }

            return lhs.unit < rhs.unit
        }
    }

    private static func normalizedIngredientKey(_ value: String) -> String {
        let normalized = normalizedSearchText(value)

        switch normalized {
        case "bell peppers", "capsicum", "capsicums":
            return "bell pepper"
        case "tomatoes":
            return "tomato"
        case "onions":
            return "onion"
        case "coriander", "coriander leaves", "cilantro", "fresh coriander":
            return "cilantro"
        case "green chili", "green chillies", "green chilies", "green chilli":
            return "green chilli"
        default:
            return normalized
        }
    }

    private static func normalizedSearchText(_ value: String) -> String {
        value
            .lowercased()
            .replacingOccurrences(
                of: #"[^a-z0-9 ]"#,
                with: " ",
                options: .regularExpression
            )
            .split(separator: " ")
            .joined(separator: " ")
    }
}

private struct AggregatedQuantity: Hashable {
    var ingredientName: String
    var normalizedIngredientName: String
    var quantity: Double
    var unit: String
    var isToTaste: Bool
    var sortPosition: Int

    var quantityText: String {
        guard !isToTaste else {
            return "To taste"
        }

        let amount = quantity.formatted(
            .number.precision(.fractionLength(0...2))
        )

        return unit.isEmpty ? amount : "\(amount) \(unit)"
    }

    var displayText: String {
        "\(quantityText) \(ingredientName)".trimmedWhitespace
    }
}

private extension String {
    var normalizedKey: String {
        lowercased()
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var trimmedWhitespace: String {
        split(separator: " ")
            .joined(separator: " ")
    }
}
