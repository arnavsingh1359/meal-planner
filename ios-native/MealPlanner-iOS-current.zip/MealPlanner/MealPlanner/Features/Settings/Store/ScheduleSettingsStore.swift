import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class ScheduleSettingsStore {
    private(set) var isLoading = false
    private(set) var isSaving = false
    private(set) var hasLoaded = false

    var preferences =
        SchedulerPreferencesDraft()

    var days =
        ScheduleSettingsStore.defaultDays()

    var mealSlots =
        ScheduleSettingsStore.defaultMealSlots()

    var selectedDay = ScheduleDay.monday.rawValue

    var errorMessage: String?
    var successMessage: String?

    private var savedSnapshot:
        SettingsSnapshot?

    let conflictGroupingOptions = [
        15,
        30,
        45,
        60,
        90,
        120
    ]

    var selectedDayName: String {
        ScheduleDay(
            rawValue: selectedDay
        )?.fullName ?? "Monday"
    }

    var configuredMealSlotCount: Int {
        mealSlots.count
    }

    var preferredBatchDayCount: Int {
        preferences.preferredBatchDays.count
    }

    var preferredBatchDaySummary: String {
        ScheduleDay.allCases
            .filter {
                preferences
                    .preferredBatchDays
                    .contains(
                        $0.fullName.lowercased()
                    )
            }
            .map(\.shortName)
            .joined(separator: ", ")
    }

    var selectedDaySlots: [MealSlotDraft] {
        mealSlots
            .filter {
                $0.dayOfWeek == selectedDay
            }
            .sorted {
                $0.position < $1.position
            }
    }

    var hasUnsavedChanges: Bool {
        guard let savedSnapshot else {
            return false
        }

        return currentSnapshot
            != savedSnapshot
    }

    var validationMessage: String? {
        guard preferences
            .conflictGroupingMinutes > 0
        else {
            return "Conflict grouping must be greater than zero."
        }

        for day in days {
            guard timeMinutes(
                day.earliestTaskTime
            ) < timeMinutes(
                day.latestTaskTime
            ) else {
                return "\(day.day.fullName): earliest task must be before latest task."
            }

            guard timeMinutes(
                day.eveningPrepStart
            ) <= timeMinutes(
                day.eveningPrepEnd
            ) else {
                return "\(day.day.fullName): evening preparation start must be before its end."
            }

            guard day.maxActiveCookingMinutes
                >= 0,
                  day.maxActiveCookingMinutes
                <= 1_440
            else {
                return "\(day.day.fullName): maximum active cooking must be between 0 and 1,440 minutes."
            }
        }

        for slot in mealSlots {
            if slot.name
                .trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
                .isEmpty {
                return "Every meal slot needs a name."
            }
        }

        return nil
    }

    var canSave: Bool {
        hasLoaded
            && !isLoading
            && !isSaving
            && validationMessage == nil
            && hasUnsavedChanges
    }

    func load() async {
        guard !isLoading else {
            return
        }

        isLoading = true
        errorMessage = nil
        successMessage = nil

        defer {
            isLoading = false
        }

        do {
            let session = try await AppSupabase
                .client
                .auth
                .session

            async let preferenceRequest:
                [SchedulerPreferencesRecord] =
                try await AppSupabase
                    .client
                    .from(
                        "scheduler_preferences"
                    )
                    .select()
                    .eq(
                        "user_id",
                        value:
                            session.user.id
                                .uuidString
                    )
                    .execute()
                    .value

            async let dayRequest:
                [DayScheduleRecord] =
                try await AppSupabase
                    .client
                    .from(
                        "day_schedule_preferences"
                    )
                    .select()
                    .eq(
                        "user_id",
                        value:
                            session.user.id
                                .uuidString
                    )
                    .order(
                        "day_of_week",
                        ascending: true
                    )
                    .execute()
                    .value

            async let slotRequest:
                [MealSlotRecord] =
                try await AppSupabase
                    .client
                    .from(
                        "meal_slot_preferences"
                    )
                    .select()
                    .eq(
                        "user_id",
                        value:
                            session.user.id
                                .uuidString
                    )
                    .order(
                        "day_of_week",
                        ascending: true
                    )
                    .order(
                        "position",
                        ascending: true
                    )
                    .execute()
                    .value

            let loadedPreferences =
                try await preferenceRequest

            let loadedDays =
                try await dayRequest

            let loadedSlots =
                try await slotRequest

            preferences =
                loadedPreferences.first.map(
                    SchedulerPreferencesDraft.init
                ) ?? SchedulerPreferencesDraft()

            days = loadedDays.isEmpty
                ? ScheduleSettingsStore.defaultDays()
                : loadedDays.map(
                    DayScheduleDraft.init
                )

            mealSlots = loadedSlots.isEmpty
                ? ScheduleSettingsStore.defaultMealSlots()
                : loadedSlots.map(
                    MealSlotDraft.init
                )

            normalizePositions()

            hasLoaded = true
            savedSnapshot = currentSnapshot
        } catch {
            guard !isCancellation(error) else {
                return
            }

            errorMessage =
                error.localizedDescription
        }
    }

    func refresh() async {
        if hasUnsavedChanges {
            errorMessage =
                "Save or reset your changes before refreshing."
            return
        }

        await load()
    }

    func save() async -> Bool {
        if let validationMessage {
            errorMessage = validationMessage
            return false
        }

        guard !isSaving else {
            return false
        }

        isSaving = true
        errorMessage = nil
        successMessage = nil

        defer {
            isSaving = false
        }

        normalizePositions()

        let parameters =
            SaveSchedulerSettingsParameters(
                global:
                    SchedulerGlobalSavePayload(
                        conflictGroupingMinutes:
                            preferences
                                .conflictGroupingMinutes,
                        preferredBatchDays:
                            Array(
                                preferences
                                    .preferredBatchDays
                            )
                            .sorted(),
                        preserveManualAdjustments:
                            preferences
                                .preserveManualAdjustments
                    ),
                days: days.map {
                    DayScheduleSavePayload(
                        dayOfWeek:
                            $0.dayOfWeek,
                        earliestTaskTime:
                            $0.earliestTaskTime,
                        latestTaskTime:
                            $0.latestTaskTime,
                        leaveHomeTime:
                            $0.leaveHomeTime,
                        returnHomeTime:
                            $0.returnHomeTime,
                        eveningPrepStart:
                            $0.eveningPrepStart,
                        eveningPrepEnd:
                            $0.eveningPrepEnd,
                        maxActiveCookingMinutes:
                            $0.maxActiveCookingMinutes,
                        cookingAllowed:
                            $0.cookingAllowed
                    )
                },
                slots: mealSlots.map {
                    MealSlotSavePayload(
                        id: $0.id,
                        dayOfWeek:
                            $0.dayOfWeek,
                        position:
                            $0.position,
                        name:
                            $0.name
                                .trimmingCharacters(
                                    in:
                                        .whitespacesAndNewlines
                                ),
                        recipeCategory:
                            $0.recipeCategory.rawValue,
                        eatTime:
                            $0.eatTime,
                        readyTime:
                            $0.readyTime,
                        preparationMode:
                            $0.preparationMode.rawValue
                    )
                }
            )

        do {
            try await saveSettings(
                parameters: parameters
            )

            savedSnapshot = currentSnapshot
            successMessage =
                "Scheduling settings saved."

            return true
        } catch {
            errorMessage =
                error.localizedDescription
            return false
        }
    }

    private func saveSettings(
        parameters:
            SaveSchedulerSettingsParameters
    ) async throws {
        do {
            try await AppSupabase
                .client
                .rpc(
                    "save_scheduler_settings",
                    params: parameters
                )
                .execute()
        } catch {
            guard isTransientConnectionError(
                error
            ) else {
                throw error
            }

            try await Task.sleep(
                for: .milliseconds(450)
            )

            try await AppSupabase
                .client
                .rpc(
                    "save_scheduler_settings",
                    params: parameters
                )
                .execute()
        }
    }

    func resetToDefaults() {
        preferences =
            SchedulerPreferencesDraft()

        days =
            ScheduleSettingsStore.defaultDays()

        mealSlots =
            ScheduleSettingsStore.defaultMealSlots()

        selectedDay =
            ScheduleDay.monday.rawValue

        errorMessage = nil
        successMessage =
            "Defaults restored locally. Tap Save to apply them."
    }

    func toggleBatchDay(
        _ day: ScheduleDay
    ) {
        let key =
            day.fullName.lowercased()

        if preferences
            .preferredBatchDays
            .contains(key) {
            preferences
                .preferredBatchDays
                .remove(key)
        } else {
            preferences
                .preferredBatchDays
                .insert(key)
        }
    }

    func addMealSlot() {
        let nextPosition =
            selectedDaySlots.count

        mealSlots.append(
            MealSlotDraft(
                dayOfWeek: selectedDay,
                position: nextPosition,
                name: "Meal",
                recipeCategory: .any,
                eatTime: "18:00",
                readyTime: "18:00",
                preparationMode: .fresh
            )
        )

        normalizePositions()
    }

    func deleteMealSlot(
        id: UUID
    ) {
        mealSlots.removeAll {
            $0.id == id
        }

        normalizePositions()
    }

    func moveMealSlot(
        id: UUID,
        direction: Int
    ) {
        var orderedSlots =
            selectedDaySlots

        guard let currentIndex =
            orderedSlots.firstIndex(
                where: {
                    $0.id == id
                }
            )
        else {
            return
        }

        let targetIndex =
            currentIndex + direction

        guard orderedSlots.indices
            .contains(targetIndex)
        else {
            return
        }

        orderedSlots.swapAt(
            currentIndex,
            targetIndex
        )

        for index in orderedSlots.indices {
            orderedSlots[index].position =
                index
        }

        let movedSlotIDs = Set(
            orderedSlots.map(\.id)
        )

        mealSlots.removeAll {
            movedSlotIDs.contains($0.id)
        }

        mealSlots.append(
            contentsOf: orderedSlots
        )
    }

    func updateDay(
        _ value: DayScheduleDraft
    ) {
        guard let index =
            days.firstIndex(
                where: {
                    $0.dayOfWeek
                        == value.dayOfWeek
                }
            )
        else {
            return
        }

        days[index] = value
    }

    func updateMealSlot(
        _ value: MealSlotDraft
    ) {
        guard let index =
            mealSlots.firstIndex(
                where: {
                    $0.id == value.id
                }
            )
        else {
            return
        }

        mealSlots[index] = value
    }

    func clearMessages() {
        errorMessage = nil
        successMessage = nil
    }

    static func defaultDays()
        -> [DayScheduleDraft] {
        ScheduleDay.allCases.map {
            DayScheduleDraft(
                dayOfWeek: $0.rawValue
            )
        }
    }

    static func defaultMealSlots()
        -> [MealSlotDraft] {
        ScheduleDay.allCases.flatMap {
            day in

            [
                MealSlotDraft(
                    dayOfWeek: day.rawValue,
                    position: 0,
                    name: "Breakfast",
                    recipeCategory:
                        .breakfast,
                    eatTime: "08:00",
                    readyTime: "08:00",
                    preparationMode:
                        .fresh
                ),
                MealSlotDraft(
                    dayOfWeek: day.rawValue,
                    position: 1,
                    name: "Lunch",
                    recipeCategory: .lunch,
                    eatTime: "12:30",
                    readyTime: "08:10",
                    preparationMode:
                        .packed
                ),
                MealSlotDraft(
                    dayOfWeek: day.rawValue,
                    position: 2,
                    name: "Snack",
                    recipeCategory: .snack,
                    eatTime: "17:00",
                    readyTime: "08:15",
                    preparationMode:
                        .packed
                ),
                MealSlotDraft(
                    dayOfWeek: day.rawValue,
                    position: 3,
                    name: "Dinner",
                    recipeCategory:
                        .dinner,
                    eatTime: "19:30",
                    readyTime: "19:30",
                    preparationMode:
                        .fresh
                )
            ]
        }
    }

    private var currentSnapshot:
        SettingsSnapshot {
        SettingsSnapshot(
            preferences: preferences,
            days: days.sorted {
                $0.dayOfWeek
                    < $1.dayOfWeek
            },
            mealSlots: mealSlots.sorted {
                if $0.dayOfWeek
                    == $1.dayOfWeek {
                    return $0.position
                        < $1.position
                }

                return $0.dayOfWeek
                    < $1.dayOfWeek
            }
        )
    }

    private func normalizePositions() {
        for day in ScheduleDay.allCases {
            let ordered = mealSlots
                .filter {
                    $0.dayOfWeek
                        == day.rawValue
                }
                .sorted {
                    $0.position
                        < $1.position
                }

            for (
                position,
                slot
            ) in ordered.enumerated() {
                guard let index =
                    mealSlots.firstIndex(
                        where: {
                            $0.id == slot.id
                        }
                    )
                else {
                    continue
                }

                mealSlots[index]
                    .position = position
            }
        }
    }

    private func timeMinutes(
        _ value: String
    ) -> Int {
        let parts =
            value.split(separator: ":")

        guard parts.count >= 2,
              let hour = Int(parts[0]),
              let minute = Int(parts[1])
        else {
            return 0
        }

        return hour * 60 + minute
    }

    private func isTransientConnectionError(
        _ error: Error
    ) -> Bool {
        let nsError = error as NSError

        guard nsError.domain
            == NSURLErrorDomain
        else {
            return false
        }

        return [
            NSURLErrorNetworkConnectionLost,
            NSURLErrorTimedOut,
            NSURLErrorCannotConnectToHost,
            NSURLErrorNotConnectedToInternet
        ]
        .contains(nsError.code)
    }

    private func isCancellation(
        _ error: Error
    ) -> Bool {
        if error is CancellationError {
            return true
        }

        let nsError = error as NSError

        return nsError.domain
            == NSURLErrorDomain
            && nsError.code
            == NSURLErrorCancelled
    }
}

private struct SettingsSnapshot:
    Equatable {

    let preferences:
        SchedulerPreferencesDraft

    let days:
        [DayScheduleDraft]

    let mealSlots:
        [MealSlotDraft]
}
