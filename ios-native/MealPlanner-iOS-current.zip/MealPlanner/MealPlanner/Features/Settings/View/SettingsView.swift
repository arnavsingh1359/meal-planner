import SwiftUI

struct SettingsView: View {
    @State private var store =
        ScheduleSettingsStore()

    @State private var showResetConfirmation =
        false

    @FocusState private var focusedSlotNameID:
        UUID?

    var body: some View {
        Group {
            if store.isLoading
                && !store.hasLoaded {
                ProgressView(
                    "Loading settings…"
                )
            } else {
                settingsContent
            }
        }
        .navigationTitle("Settings")
        .navigationBarTitleDisplayMode(
            .inline
        )
        .toolbar {
            ToolbarItem(
                placement:
                    .confirmationAction
            ) {
                Button {
                    focusedSlotNameID = nil

                    Task {
                        await store.save()
                    }
                } label: {
                    if store.isSaving {
                        ProgressView()
                    } else {
                        Text("Save")
                    }
                }
                .disabled(!store.canSave)
            }
        }
        .task {
            if !store.hasLoaded {
                await store.load()
            }
        }
        .confirmationDialog(
            "Reset scheduling defaults?",
            isPresented:
                $showResetConfirmation,
            titleVisibility: .visible
        ) {
            Button(
                "Reset defaults",
                role: .destructive
            ) {
                store.resetToDefaults()
            }

            Button(
                "Cancel",
                role: .cancel
            ) {}
        } message: {
            Text(
                "This changes the current draft. Tap Save afterward to apply the defaults."
            )
        }
    }

    private var settingsContent:
        some View {
        ScrollView {
            VStack(spacing: 16) {
                introCard

                if let validation =
                    store.validationMessage {
                    messageCard(
                        validation,
                        color: .red,
                        icon:
                            "exclamationmark.triangle.fill"
                    )
                } else if let error =
                    store.errorMessage {
                    messageCard(
                        error,
                        color: .red,
                        icon:
                            "exclamationmark.triangle.fill"
                    )
                } else if let success =
                    store.successMessage {
                    messageCard(
                        success,
                        color: .green,
                        icon:
                            "checkmark.circle.fill"
                    )
                }

                summaryCards
                globalSettingsCard
                daySelector
                dayScheduleCard
                mealSlotsCard
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
        }
        .background(
            Color(.systemGroupedBackground)
        )
        .scrollDismissesKeyboard(
            .interactively
        )
        .refreshable {
            await store.refresh()
        }
    }

    private var introCard: some View {
        VStack(
            alignment: .leading,
            spacing: 6
        ) {
            Text("Scheduling preferences")
                .font(
                    .caption.weight(.semibold)
                )
                .foregroundStyle(.green)
                .textCase(.uppercase)

            Text(
                "Define your normal availability and exactly which meals or snacks appear on each day."
            )
            .font(.subheadline)
            .foregroundStyle(.secondary)
        }
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
    }

    private var summaryCards: some View {
        HStack(spacing: 10) {
            summaryCard(
                title: "Meal slots",
                value:
                    "\(store.configuredMealSlotCount)",
                detail: "Across seven days"
            )

            summaryCard(
                title: "Grouping",
                value:
                    "\(store.preferences.conflictGroupingMinutes)",
                detail: "Minutes"
            )

            summaryCard(
                title: "Batch days",
                value:
                    "\(store.preferredBatchDayCount)",
                detail:
                    store.preferredBatchDaySummary.isEmpty
                    ? "None"
                    : store.preferredBatchDaySummary
            )
        }
    }

    private var globalSettingsCard:
        some View {
        settingsCard(
            title: "Scheduler defaults",
            subtitle:
                "Global behavior used when schedules are generated."
        ) {
            HStack {
                Text("Conflict grouping")
                    .font(
                        .subheadline
                            .weight(.semibold)
                    )

                Spacer()

                Picker(
                    "Conflict grouping",
                    selection:
                        $store
                            .preferences
                            .conflictGroupingMinutes
                ) {
                    ForEach(
                        store.conflictGroupingOptions,
                        id: \.self
                    ) { minutes in
                        Text(
                            AppDurationFormatter.string(
                                minutes: minutes
                            )
                        )
                        .tag(minutes)
                    }
                }
                .labelsHidden()
                .pickerStyle(.menu)
            }

            Divider()

            VStack(
                alignment: .leading,
                spacing: 10
            ) {
                Text(
                    "Preferred batch-cooking days"
                )
                .font(
                    .subheadline
                        .weight(.semibold)
                )

                LazyVGrid(
                    columns: [
                        GridItem(
                            .adaptive(
                                minimum: 86
                            ),
                            spacing: 8
                        )
                    ],
                    spacing: 8
                ) {
                    ForEach(
                        ScheduleDay.allCases
                    ) { day in
                        let selected =
                            store.preferences
                                .preferredBatchDays
                                .contains(
                                    day.fullName
                                        .lowercased()
                                )

                        Button {
                            store.toggleBatchDay(
                                day
                            )
                        } label: {
                            HStack(spacing: 6) {
                                Image(
                                    systemName:
                                        selected
                                        ? "checkmark.square.fill"
                                        : "square"
                                )

                                Text(day.shortName)
                            }
                            .font(
                                .caption
                                    .weight(.semibold)
                            )
                            .foregroundStyle(
                                selected
                                ? Color.green
                                : Color.primary
                            )
                            .padding(
                                .horizontal,
                                10
                            )
                            .frame(height: 36)
                            .frame(
                                maxWidth:
                                    .infinity
                            )
                            .background(
                                selected
                                ? Color.green
                                    .opacity(0.12)
                                : Color(
                                    .tertiarySystemGroupedBackground
                                ),
                                in:
                                    RoundedRectangle(
                                        cornerRadius:
                                            10,
                                        style:
                                            .continuous
                                    )
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            Divider()

            Toggle(
                "Preserve manually adjusted tasks",
                isOn:
                    $store
                        .preferences
                        .preserveManualAdjustments
            )

            Text(
                "When regenerating a schedule, manually moved tasks remain where you placed them."
            )
            .font(.caption)
            .foregroundStyle(.secondary)

            Divider()

            Button(
                "Reset defaults",
                role: .destructive
            ) {
                showResetConfirmation = true
            }
        }
    }

    private var daySelector: some View {
        GeometryReader { geometry in
            let spacing: CGFloat = 6
            let totalSpacing =
                spacing * CGFloat(
                    ScheduleDay.allCases.count - 1
                )
            let itemWidth =
                max(
                    42,
                    (
                        geometry.size.width
                        - totalSpacing
                    )
                    / CGFloat(
                        ScheduleDay.allCases.count
                    )
                )

            HStack(spacing: spacing) {
                ForEach(
                    ScheduleDay.allCases
                ) { day in
                    Button {
                        focusedSlotNameID = nil
                        store.selectedDay =
                            day.rawValue
                    } label: {
                        VStack(spacing: 2) {
                            Text(day.shortName)
                                .font(
                                    .caption
                                        .weight(
                                            .semibold
                                        )
                                )

                            Text(
                                "\(slotCount(for: day))"
                            )
                            .font(.caption2)
                        }
                        .foregroundStyle(
                            store.selectedDay
                                == day.rawValue
                            ? Color.white
                            : Color.primary
                        )
                        .frame(
                            width: itemWidth,
                            height: 46
                        )
                        .background(
                            store.selectedDay
                                == day.rawValue
                            ? Color.green
                            : Color(
                                .secondarySystemGroupedBackground
                            ),
                            in: RoundedRectangle(
                                cornerRadius: 12,
                                style:
                                    .continuous
                            )
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .frame(height: 46)
    }

    @ViewBuilder
    private var dayScheduleCard:
        some View {
        if let day = currentDay {
            settingsCard(
                title: day.day.fullName,
                subtitle:
                    "Availability and cooking limits for this day."
            ) {
                timePair(
                    firstTitle:
                        "Earliest task",
                    first:
                        dayBinding(
                            day.id,
                            \.earliestTaskTime
                        ),
                    secondTitle:
                        "Latest task",
                    second:
                        dayBinding(
                            day.id,
                            \.latestTaskTime
                        )
                )

                Divider()

                timePair(
                    firstTitle:
                        "Leave home",
                    first:
                        dayBinding(
                            day.id,
                            \.leaveHomeTime
                        ),
                    secondTitle:
                        "Return home",
                    second:
                        dayBinding(
                            day.id,
                            \.returnHomeTime
                        )
                )

                Divider()

                timePair(
                    firstTitle:
                        "Evening prep starts",
                    first:
                        dayBinding(
                            day.id,
                            \.eveningPrepStart
                        ),
                    secondTitle:
                        "Evening prep ends",
                    second:
                        dayBinding(
                            day.id,
                            \.eveningPrepEnd
                        )
                )

                Divider()

                Stepper(
                    value:
                        dayIntBinding(
                            day.id,
                            \.maxActiveCookingMinutes
                        ),
                    in: 0...1_440,
                    step: 15
                ) {
                    LabeledContent(
                        "Maximum active cooking",
                        value:
                            AppDurationFormatter.string(
                                minutes:
                                    day.maxActiveCookingMinutes
                            )
                    )
                }

                Divider()

                Toggle(
                    "Cooking is allowed",
                    isOn:
                        dayBoolBinding(
                            day.id,
                            \.cookingAllowed
                        )
                )
            }
        }
    }

    private var mealSlotsCard:
        some View {
        settingsCard(
            title: "Meal and snack slots",
            subtitle:
                "Add as many slots as needed, including morning and afternoon snacks."
        ) {
            ForEach(
                store.selectedDaySlots
            ) { slot in
                mealSlotEditor(slot)

                if slot.id
                    != store.selectedDaySlots
                        .last?.id {
                    Divider()
                }
            }

            Button {
                focusedSlotNameID = nil
                store.addMealSlot()
            } label: {
                Label(
                    "Add meal slot",
                    systemImage: "plus.circle"
                )
                .frame(
                    maxWidth: .infinity
                )
            }
            .buttonStyle(.bordered)
            .tint(.green)
        }
    }

    private func mealSlotEditor(
        _ slot: MealSlotDraft
    ) -> some View {
        VStack(
            alignment: .leading,
            spacing: 12
        ) {
            HStack {
                Text(
                    "Slot \(slot.position + 1)"
                )
                .font(
                    .subheadline
                        .weight(.semibold)
                )

                Spacer()

                Button {
                    focusedSlotNameID = nil
                    store.moveMealSlot(
                        id: slot.id,
                        direction: -1
                    )
                } label: {
                    Image(
                        systemName:
                            "arrow.up"
                    )
                }
                .disabled(
                    slot.position == 0
                )

                Button {
                    focusedSlotNameID = nil
                    store.moveMealSlot(
                        id: slot.id,
                        direction: 1
                    )
                } label: {
                    Image(
                        systemName:
                            "arrow.down"
                    )
                }
                .disabled(
                    slot.position
                        == store.selectedDaySlots
                            .count - 1
                )

                Button(
                    role: .destructive
                ) {
                    focusedSlotNameID = nil
                    store.deleteMealSlot(
                        id: slot.id
                    )
                } label: {
                    Image(
                        systemName: "trash"
                    )
                }
            }

            TextField(
                "Slot name",
                text:
                    slotBinding(
                        slot.id,
                        \.name,
                        fallback:
                            slot.name
                    )
            )
            .focused(
                $focusedSlotNameID,
                equals: slot.id
            )
            .submitLabel(.done)
            .onSubmit {
                focusedSlotNameID = nil
            }
            .textInputAutocapitalization(
                .words
            )
            .padding(10)
            .background(
                Color(
                    .tertiarySystemGroupedBackground
                ),
                in: RoundedRectangle(
                    cornerRadius: 10,
                    style: .continuous
                )
            )

            HStack(spacing: 12) {
                VStack(
                    alignment: .leading,
                    spacing: 5
                ) {
                    Text("Recipe category")
                        .font(.caption)
                        .foregroundStyle(
                            .secondary
                        )

                    Picker(
                        "Recipe category",
                        selection:
                            slotCategoryBinding(
                                slot.id
                            )
                    ) {
                        ForEach(
                            MealSlotCategory
                                .allCases
                        ) { category in
                            Text(category.label)
                                .tag(category)
                        }
                    }
                    .labelsHidden()
                    .pickerStyle(.menu)
                }

                Spacer()

                VStack(
                    alignment: .leading,
                    spacing: 5
                ) {
                    Text("Preparation")
                        .font(.caption)
                        .foregroundStyle(
                            .secondary
                        )

                    Picker(
                        "Preparation",
                        selection:
                            slotModeBinding(
                                slot.id
                            )
                    ) {
                        ForEach(
                            MealPreparationMode
                                .allCases
                        ) { mode in
                            Text(mode.label)
                                .tag(mode)
                        }
                    }
                    .labelsHidden()
                    .pickerStyle(.menu)
                }
            }

            timePair(
                firstTitle: "Eat at",
                first:
                    slotBinding(
                        slot.id,
                        \.eatTime,
                        fallback:
                            slot.eatTime
                    ),
                secondTitle: "Ready by",
                second:
                    slotBinding(
                        slot.id,
                        \.readyTime,
                        fallback:
                            slot.readyTime
                    )
            )
        }
        .padding(.vertical, 4)
    }

    private func timePair(
        firstTitle: String,
        first: Binding<String>,
        secondTitle: String,
        second: Binding<String>
    ) -> some View {
        HStack(spacing: 12) {
            timeField(
                title: firstTitle,
                value: first
            )

            timeField(
                title: secondTitle,
                value: second
            )
        }
    }

    private func timeField(
        title: String,
        value: Binding<String>
    ) -> some View {
        VStack(
            alignment: .leading,
            spacing: 5
        ) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)

            DatePicker(
                title,
                selection:
                    timeDateBinding(
                        value
                    ),
                displayedComponents:
                    .hourAndMinute
            )
            .labelsHidden()
            .datePickerStyle(.compact)
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
        }
        .frame(maxWidth: .infinity)
    }

    private func settingsCard<Content: View>(
        title: String,
        subtitle: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(
            alignment: .leading,
            spacing: 12
        ) {
            Text(title)
                .font(.headline)

            Text(subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)

            content()
        }
        .padding(16)
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .background(
            Color(
                .secondarySystemGroupedBackground
            ),
            in: RoundedRectangle(
                cornerRadius: 18,
                style: .continuous
            )
        )
    }

    private func summaryCard(
        title: String,
        value: String,
        detail: String
    ) -> some View {
        VStack(
            alignment: .leading,
            spacing: 4
        ) {
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)

            Text(value)
                .font(.title3.bold())

            Text(detail)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .padding(12)
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .background(
            Color(
                .secondarySystemGroupedBackground
            ),
            in: RoundedRectangle(
                cornerRadius: 14,
                style: .continuous
            )
        )
    }

    private func messageCard(
        _ message: String,
        color: Color,
        icon: String
    ) -> some View {
        Label(message, systemImage: icon)
            .font(.footnote)
            .foregroundStyle(color)
            .padding(12)
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
            .background(
                color.opacity(0.09),
                in: RoundedRectangle(
                    cornerRadius: 12,
                    style: .continuous
                )
            )
    }

    private func slotCount(
        for day: ScheduleDay
    ) -> Int {
        store.mealSlots.filter {
            $0.dayOfWeek == day.rawValue
        }.count
    }

    private var currentDay:
        DayScheduleDraft? {
        store.days.first {
            $0.dayOfWeek
                == store.selectedDay
        }
    }

    private func dayBinding<Value>(
        _ id: Int,
        _ keyPath:
            WritableKeyPath<
                DayScheduleDraft,
                Value
            >
    ) -> Binding<Value> {
        Binding {
            store.days.first {
                $0.id == id
            }![keyPath: keyPath]
        } set: { newValue in
            guard var value =
                store.days.first(
                    where: {
                        $0.id == id
                    }
                )
            else {
                return
            }

            value[keyPath: keyPath] =
                newValue

            store.updateDay(value)
        }
    }

    private func dayIntBinding(
        _ id: Int,
        _ keyPath:
            WritableKeyPath<
                DayScheduleDraft,
                Int
            >
    ) -> Binding<Int> {
        dayBinding(id, keyPath)
    }

    private func dayBoolBinding(
        _ id: Int,
        _ keyPath:
            WritableKeyPath<
                DayScheduleDraft,
                Bool
            >
    ) -> Binding<Bool> {
        dayBinding(id, keyPath)
    }

    private func slotBinding<Value>(
        _ id: UUID,
        _ keyPath:
            WritableKeyPath<
                MealSlotDraft,
                Value
            >,
        fallback: Value
    ) -> Binding<Value> {
        Binding {
            guard let slot =
                store.mealSlots.first(
                    where: {
                        $0.id == id
                    }
                )
            else {
                return fallback
            }

            return slot[
                keyPath: keyPath
            ]
        } set: { newValue in
            guard var value =
                store.mealSlots.first(
                    where: {
                        $0.id == id
                    }
                )
            else {
                return
            }

            value[keyPath: keyPath] =
                newValue

            store.updateMealSlot(value)
        }
    }

    private func slotCategoryBinding(
        _ id: UUID
    ) -> Binding<MealSlotCategory> {
        slotBinding(
            id,
            \.recipeCategory,
            fallback: .any
        )
    }

    private func slotModeBinding(
        _ id: UUID
    ) -> Binding<MealPreparationMode> {
        slotBinding(
            id,
            \.preparationMode,
            fallback: .fresh
        )
    }

    private func timeDateBinding(
        _ string: Binding<String>
    ) -> Binding<Date> {
        Binding {
            dateFromTime(
                string.wrappedValue
            )
        } set: { date in
            string.wrappedValue =
                timeFromDate(date)
        }
    }

    private func dateFromTime(
        _ value: String
    ) -> Date {
        let parts =
            value.split(separator: ":")

        let hour =
            parts.first.flatMap {
                Int($0)
            } ?? 0

        let minute =
            parts.dropFirst()
                .first.flatMap {
                    Int($0)
                } ?? 0

        return Calendar.current.date(
            bySettingHour: hour,
            minute: minute,
            second: 0,
            of: Date()
        ) ?? Date()
    }

    private func timeFromDate(
        _ date: Date
    ) -> String {
        let components =
            Calendar.current.dateComponents(
                [.hour, .minute],
                from: date
            )

        return String(
            format: "%02d:%02d",
            components.hour ?? 0,
            components.minute ?? 0
        )
    }
}
