import Foundation

enum ScheduleDay: Int, CaseIterable, Identifiable, Codable {
    case monday = 1
    case tuesday
    case wednesday
    case thursday
    case friday
    case saturday
    case sunday

    var id: Int {
        rawValue
    }

    var shortName: String {
        switch self {
        case .monday:
            return "Mon"
        case .tuesday:
            return "Tue"
        case .wednesday:
            return "Wed"
        case .thursday:
            return "Thu"
        case .friday:
            return "Fri"
        case .saturday:
            return "Sat"
        case .sunday:
            return "Sun"
        }
    }

    var fullName: String {
        switch self {
        case .monday:
            return "Monday"
        case .tuesday:
            return "Tuesday"
        case .wednesday:
            return "Wednesday"
        case .thursday:
            return "Thursday"
        case .friday:
            return "Friday"
        case .saturday:
            return "Saturday"
        case .sunday:
            return "Sunday"
        }
    }
}

enum MealSlotCategory: String, CaseIterable, Identifiable, Codable {
    case breakfast
    case lunch
    case dinner
    case snack
    case any

    var id: String {
        rawValue
    }

    var label: String {
        switch self {
        case .breakfast:
            return "Breakfast"
        case .lunch:
            return "Lunch"
        case .dinner:
            return "Dinner"
        case .snack:
            return "Snack"
        case .any:
            return "Any"
        }
    }
}

enum MealPreparationMode: String, CaseIterable, Identifiable, Codable {
    case fresh
    case packed
    case leftovers
    case batchPrepared = "batch_prepared"

    var id: String {
        rawValue
    }

    var label: String {
        switch self {
        case .fresh:
            return "Fresh"
        case .packed:
            return "Packed"
        case .leftovers:
            return "Leftovers"
        case .batchPrepared:
            return "Batch prepared"
        }
    }
}

struct SchedulerPreferencesRecord: Codable {
    let userID: UUID
    let conflictGroupingMinutes: Int
    let preferredBatchDays: [String]
    let preserveManualAdjustments: Bool

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case conflictGroupingMinutes =
            "conflict_grouping_minutes"
        case preferredBatchDays =
            "preferred_batch_days"
        case preserveManualAdjustments =
            "preserve_manual_adjustments"
    }
}

struct DayScheduleRecord: Codable, Identifiable {
    let userID: UUID
    let dayOfWeek: Int
    let earliestTaskTime: String
    let latestTaskTime: String
    let leaveHomeTime: String
    let returnHomeTime: String
    let eveningPrepStart: String
    let eveningPrepEnd: String
    let maxActiveCookingMinutes: Int
    let cookingAllowed: Bool

    var id: Int {
        dayOfWeek
    }

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case dayOfWeek = "day_of_week"
        case earliestTaskTime =
            "earliest_task_time"
        case latestTaskTime =
            "latest_task_time"
        case leaveHomeTime =
            "leave_home_time"
        case returnHomeTime =
            "return_home_time"
        case eveningPrepStart =
            "evening_prep_start"
        case eveningPrepEnd =
            "evening_prep_end"
        case maxActiveCookingMinutes =
            "max_active_cooking_minutes"
        case cookingAllowed =
            "cooking_allowed"
    }
}

struct MealSlotRecord: Codable, Identifiable {
    let id: UUID
    let userID: UUID
    let dayOfWeek: Int
    let position: Int
    let name: String
    let recipeCategory: String
    let eatTime: String
    let readyTime: String
    let preparationMode: String

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case dayOfWeek = "day_of_week"
        case position
        case name
        case recipeCategory =
            "recipe_category"
        case eatTime = "eat_time"
        case readyTime = "ready_time"
        case preparationMode =
            "preparation_mode"
    }
}

struct SchedulerPreferencesDraft: Equatable {
    var conflictGroupingMinutes = 60
    var preferredBatchDays: Set<String> = [
        "saturday",
        "sunday"
    ]
    var preserveManualAdjustments = true

    init() {}

    init(record: SchedulerPreferencesRecord) {
        conflictGroupingMinutes =
            record.conflictGroupingMinutes

        preferredBatchDays = Set(
            record.preferredBatchDays.map {
                $0.lowercased()
            }
        )

        preserveManualAdjustments =
            record.preserveManualAdjustments
    }
}

struct DayScheduleDraft: Identifiable, Equatable {
    let dayOfWeek: Int

    var earliestTaskTime: String
    var latestTaskTime: String
    var leaveHomeTime: String
    var returnHomeTime: String
    var eveningPrepStart: String
    var eveningPrepEnd: String
    var maxActiveCookingMinutes: Int
    var cookingAllowed: Bool

    var id: Int {
        dayOfWeek
    }

    var day: ScheduleDay {
        ScheduleDay(rawValue: dayOfWeek)
            ?? .monday
    }

    init(
        dayOfWeek: Int,
        earliestTaskTime: String = "09:00",
        latestTaskTime: String = "21:30",
        leaveHomeTime: String = "08:30",
        returnHomeTime: String = "18:00",
        eveningPrepStart: String = "18:30",
        eveningPrepEnd: String = "21:00",
        maxActiveCookingMinutes: Int = 75,
        cookingAllowed: Bool = true
    ) {
        self.dayOfWeek = dayOfWeek
        self.earliestTaskTime =
            Self.normalizedTime(earliestTaskTime)
        self.latestTaskTime =
            Self.normalizedTime(latestTaskTime)
        self.leaveHomeTime =
            Self.normalizedTime(leaveHomeTime)
        self.returnHomeTime =
            Self.normalizedTime(returnHomeTime)
        self.eveningPrepStart =
            Self.normalizedTime(eveningPrepStart)
        self.eveningPrepEnd =
            Self.normalizedTime(eveningPrepEnd)
        self.maxActiveCookingMinutes =
            maxActiveCookingMinutes
        self.cookingAllowed =
            cookingAllowed
    }

    init(record: DayScheduleRecord) {
        self.init(
            dayOfWeek: record.dayOfWeek,
            earliestTaskTime:
                record.earliestTaskTime,
            latestTaskTime:
                record.latestTaskTime,
            leaveHomeTime:
                record.leaveHomeTime,
            returnHomeTime:
                record.returnHomeTime,
            eveningPrepStart:
                record.eveningPrepStart,
            eveningPrepEnd:
                record.eveningPrepEnd,
            maxActiveCookingMinutes:
                record.maxActiveCookingMinutes,
            cookingAllowed:
                record.cookingAllowed
        )
    }

    private static func normalizedTime(
        _ value: String
    ) -> String {
        String(value.prefix(5))
    }
}

struct MealSlotDraft: Identifiable, Equatable {
    let id: UUID
    var dayOfWeek: Int
    var position: Int
    var name: String
    var recipeCategory: MealSlotCategory
    var eatTime: String
    var readyTime: String
    var preparationMode: MealPreparationMode

    init(
        id: UUID = UUID(),
        dayOfWeek: Int,
        position: Int,
        name: String,
        recipeCategory: MealSlotCategory,
        eatTime: String,
        readyTime: String,
        preparationMode: MealPreparationMode
    ) {
        self.id = id
        self.dayOfWeek = dayOfWeek
        self.position = position
        self.name = name
        self.recipeCategory = recipeCategory
        self.eatTime = String(eatTime.prefix(5))
        self.readyTime = String(readyTime.prefix(5))
        self.preparationMode = preparationMode
    }

    init(record: MealSlotRecord) {
        self.init(
            id: record.id,
            dayOfWeek: record.dayOfWeek,
            position: record.position,
            name: record.name,
            recipeCategory:
                MealSlotCategory(
                    rawValue:
                        record.recipeCategory
                ) ?? .any,
            eatTime: record.eatTime,
            readyTime: record.readyTime,
            preparationMode:
                MealPreparationMode(
                    rawValue:
                        record.preparationMode
                ) ?? .fresh
        )
    }
}

struct SchedulerGlobalSavePayload: Encodable {
    let conflictGroupingMinutes: Int
    let preferredBatchDays: [String]
    let preserveManualAdjustments: Bool

    enum CodingKeys: String, CodingKey {
        case conflictGroupingMinutes =
            "conflict_grouping_minutes"
        case preferredBatchDays =
            "preferred_batch_days"
        case preserveManualAdjustments =
            "preserve_manual_adjustments"
    }
}

struct DayScheduleSavePayload: Encodable {
    let dayOfWeek: Int
    let earliestTaskTime: String
    let latestTaskTime: String
    let leaveHomeTime: String
    let returnHomeTime: String
    let eveningPrepStart: String
    let eveningPrepEnd: String
    let maxActiveCookingMinutes: Int
    let cookingAllowed: Bool

    enum CodingKeys: String, CodingKey {
        case dayOfWeek = "day_of_week"
        case earliestTaskTime =
            "earliest_task_time"
        case latestTaskTime =
            "latest_task_time"
        case leaveHomeTime =
            "leave_home_time"
        case returnHomeTime =
            "return_home_time"
        case eveningPrepStart =
            "evening_prep_start"
        case eveningPrepEnd =
            "evening_prep_end"
        case maxActiveCookingMinutes =
            "max_active_cooking_minutes"
        case cookingAllowed =
            "cooking_allowed"
    }
}

struct MealSlotSavePayload: Encodable {
    let id: UUID
    let dayOfWeek: Int
    let position: Int
    let name: String
    let recipeCategory: String
    let eatTime: String
    let readyTime: String
    let preparationMode: String

    enum CodingKeys: String, CodingKey {
        case id
        case dayOfWeek = "day_of_week"
        case position
        case name
        case recipeCategory =
            "recipe_category"
        case eatTime = "eat_time"
        case readyTime = "ready_time"
        case preparationMode =
            "preparation_mode"
    }
}

struct SaveSchedulerSettingsParameters: Encodable {
    let global: SchedulerGlobalSavePayload
    let days: [DayScheduleSavePayload]
    let slots: [MealSlotSavePayload]

    enum CodingKeys: String, CodingKey {
        case global = "p_global"
        case days = "p_days"
        case slots = "p_slots"
    }
}
