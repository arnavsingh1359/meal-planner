import Foundation
import Observation
import Supabase

@MainActor
@Observable
final class SessionStore {
    private(set) var session: Session?
    private(set) var isLoading = true

    var isAuthenticated: Bool {
        session != nil
    }

    var userEmail: String {
        session?.user.email ?? ""
    }

    private var authListenerTask:
        Task<Void, Never>?

    init() {
        session =
            AppSupabase.client.auth.currentSession

        authListenerTask = Task {
            [weak self] in

            guard let self else {
                return
            }

            for await (_, session) in
                AppSupabase
                    .client
                    .auth
                    .authStateChanges {
                self.session = session
                self.isLoading = false
            }
        }

        isLoading = false
    }

    func signIn(
        email: String,
        password: String
    ) async throws {
        let session =
            try await AppSupabase
                .client
                .auth
                .signIn(
                    email: email,
                    password: password
                )

        self.session = session
    }

    func signUp(
        email: String,
        password: String
    ) async throws -> Bool {
        let response =
            try await AppSupabase
                .client
                .auth
                .signUp(
                    email: email,
                    password: password
                )

        session = response.session

        return response.session == nil
    }

    func signOut() async throws {
        try await AppSupabase
            .client
            .auth
            .signOut()

        session = nil
    }

}
