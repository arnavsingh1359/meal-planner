import Foundation
import Supabase

enum AppConfigurationError: LocalizedError {
    case missingValue(String)
    case unresolvedValue(String)
    case invalidURL(String)

    var errorDescription: String? {
        switch self {
        case .missingValue(let key):
            return "Missing configuration value: \(key)"

        case .unresolvedValue(let key):
            return "The build setting for \(key) was not resolved."

        case .invalidURL(let value):
            return "Invalid Supabase URL: \(value)"
        }
    }
}

enum AppSupabase {
    static let client: SupabaseClient = {
        do {
            let urlString = try requiredInfoValue("SupabaseURL")
            let publishableKey = try requiredInfoValue(
                "SupabasePublishableKey"
            )

            guard let url = URL(string: urlString) else {
                throw AppConfigurationError.invalidURL(urlString)
            }

            return SupabaseClient(
                supabaseURL: url,
                supabaseKey: publishableKey,
                options: .init(
                    auth: .init(
                        emitLocalSessionAsInitialSession:
                            true
                    )
                )
            )
        } catch {
            fatalError(
                "Could not initialize Supabase: \(error.localizedDescription)"
            )
        }
    }()

    private static func requiredInfoValue(
        _ key: String
    ) throws -> String {
        guard
            let rawValue = Bundle.main.object(
                forInfoDictionaryKey: key
            ) as? String
        else {
            throw AppConfigurationError.missingValue(key)
        }

        let value = rawValue.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !value.isEmpty else {
            throw AppConfigurationError.missingValue(key)
        }

        guard !value.hasPrefix("$(") else {
            throw AppConfigurationError.unresolvedValue(key)
        }

        return value
    }
}
