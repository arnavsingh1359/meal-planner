import Foundation

nonisolated enum AppDurationFormatter {
    static func string(
        minutes totalMinutes: Int
    ) -> String {
        let safeMinutes = max(0, totalMinutes)

        guard safeMinutes > 0 else {
            return "0 min"
        }

        let days = safeMinutes / 1_440
        let hours =
            (safeMinutes % 1_440) / 60
        let minutes = safeMinutes % 60

        var parts: [String] = []

        if days > 0 {
            parts.append(
                days == 1
                ? "1 day"
                : "\(days) days"
            )
        }

        if hours > 0 {
            parts.append(
                "\(hours) hr"
            )
        }

        if minutes > 0 {
            parts.append(
                "\(minutes) min"
            )
        }

        return parts.joined(separator: " ")
    }

    static func optionalString(
        minutes: Int?
    ) -> String {
        guard let minutes else {
            return "—"
        }

        return string(minutes: minutes)
    }
}
