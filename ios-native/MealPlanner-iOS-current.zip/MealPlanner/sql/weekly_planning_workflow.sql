-- Weekly planning workflow support
-- Run this in Supabase SQL Editor.
-- It creates a durable checklist for the Saturday/Sunday weekly planning flow.

create table if not exists public.weekly_planning_statuses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  week_start date not null,
  status text not null default 'not_started',
  menu_selected_at timestamptz,
  servings_confirmed_at timestamptz,
  pantry_reviewed_at timestamptz,
  shopping_generated_at timestamptz,
  schedule_generated_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint weekly_planning_statuses_unique_week unique (user_id, week_start),
  constraint weekly_planning_statuses_valid_status check (
    status in (
      'not_started',
      'menu_selected',
      'servings_confirmed',
      'pantry_reviewed',
      'shopping_generated',
      'schedule_generated',
      'complete'
    )
  )
);

create index if not exists weekly_planning_statuses_user_week_idx
  on public.weekly_planning_statuses (user_id, week_start);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_weekly_planning_statuses_updated_at
  on public.weekly_planning_statuses;

create trigger set_weekly_planning_statuses_updated_at
before update on public.weekly_planning_statuses
for each row
execute function public.set_updated_at();

alter table public.weekly_planning_statuses enable row level security;

drop policy if exists "weekly planning select own rows"
  on public.weekly_planning_statuses;

create policy "weekly planning select own rows"
on public.weekly_planning_statuses
for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "weekly planning insert own rows"
  on public.weekly_planning_statuses;

create policy "weekly planning insert own rows"
on public.weekly_planning_statuses
for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "weekly planning update own rows"
  on public.weekly_planning_statuses;

create policy "weekly planning update own rows"
on public.weekly_planning_statuses
for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "weekly planning delete own rows"
  on public.weekly_planning_statuses;

create policy "weekly planning delete own rows"
on public.weekly_planning_statuses
for delete
to authenticated
using (auth.uid() = user_id);
