-- Pantry + shopping support SQL for the iOS Meal Planner app.
-- Safe to run multiple times. This file does not delete or overwrite data.

-- 1) Helpful indexes for the app queries.
create index if not exists idx_ingredients_user_id_name
on public.ingredients (user_id, lower(name));

create index if not exists idx_ingredients_user_id_category
on public.ingredients (user_id, category);

create index if not exists idx_pantry_items_user_id_updated_at
on public.pantry_items (user_id, updated_at desc);

create index if not exists idx_pantry_items_user_id_ingredient_id
on public.pantry_items (user_id, ingredient_id);

-- 2) Optional duplicate diagnostics.
-- If this returns rows, the app will still work, but you may see duplicate pantry cards.
select
  user_id,
  ingredient_id,
  count(*) as duplicate_count
from public.pantry_items
group by user_id, ingredient_id
having count(*) > 1
order by duplicate_count desc;

-- 3) Optional uniqueness guard.
-- Run this only after the duplicate diagnostic above returns zero rows.
-- create unique index if not exists idx_pantry_items_one_row_per_ingredient
-- on public.pantry_items (user_id, ingredient_id);

-- 4) Shape check for the two tables used by the iOS Pantry screen.
select
  table_name,
  column_name,
  data_type,
  is_nullable,
  column_default
from information_schema.columns
where table_schema = 'public'
  and table_name in ('ingredients', 'pantry_items')
order by table_name, ordinal_position;
