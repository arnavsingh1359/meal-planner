-- Reset the current authenticated user's weekly planning checklist to incomplete.
-- Run in Supabase SQL Editor while authenticated as your app user.
-- This clears all manual completion timestamps for all weekly planning rows belonging to you.

update public.weekly_planning_statuses
set
  status = 'not_started',
  menu_selected_at = null,
  servings_confirmed_at = null,
  pantry_reviewed_at = null,
  shopping_generated_at = null,
  schedule_generated_at = null,
  completed_at = null,
  updated_at = now()
where user_id = auth.uid();

-- Verify reset state.
select
  week_start,
  status,
  menu_selected_at,
  servings_confirmed_at,
  pantry_reviewed_at,
  shopping_generated_at,
  schedule_generated_at,
  completed_at
from public.weekly_planning_statuses
where user_id = auth.uid()
order by week_start desc;
