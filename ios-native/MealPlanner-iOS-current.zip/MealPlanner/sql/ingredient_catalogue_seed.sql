-- MealPlanner iOS ingredient catalogue seed
-- Safe to run multiple times. Inserts missing catalogue ingredients for the current single-user app.
-- It does not delete or overwrite existing ingredients or pantry_items.

create index if not exists idx_mealplanner_ingredients_user_lower_name
on public.ingredients (user_id, lower(name));

create index if not exists idx_mealplanner_pantry_items_user_ingredient
on public.pantry_items (user_id, ingredient_id);

create index if not exists idx_mealplanner_pantry_items_stock_status
on public.pantry_items (user_id, stock_status);

do $$
declare
  target_user_id uuid;
begin
  target_user_id := auth.uid();

  if target_user_id is null then
    select user_id
    into target_user_id
    from public.ingredients
    order by created_at nulls last
    limit 1;
  end if;

  if target_user_id is null then
    select user_id
    into target_user_id
    from public.pantry_items
    order by created_at nulls last
    limit 1;
  end if;

  if target_user_id is null then
    raise exception 'Could not infer user_id. Log in through the app once or insert one ingredient first, then rerun this file.';
  end if;

  insert into public.ingredients (user_id, name, category, default_unit, approximate_allowed)
  select target_user_id, seed.name, seed.category, seed.default_unit, seed.approximate_allowed
  from (
    values
      -- Produce
      ('Onion','Produce','whole',true),
      ('Red Onion','Produce','whole',true),
      ('Yellow Onion','Produce','whole',true),
      ('Tomato','Produce','whole',true),
      ('Roma Tomato','Produce','whole',true),
      ('Cherry Tomatoes','Produce','g',true),
      ('Potato','Produce','whole',true),
      ('Sweet Potato','Produce','whole',true),
      ('Carrot','Produce','whole',true),
      ('Cucumber','Produce','whole',true),
      ('Bell Pepper','Produce','whole',true),
      ('Green Bell Pepper','Produce','whole',true),
      ('Red Bell Pepper','Produce','whole',true),
      ('Capsicum','Produce','whole',true),
      ('Green Chili','Produce','whole',true),
      ('Jalapeno','Produce','whole',true),
      ('Serrano Pepper','Produce','whole',true),
      ('Ginger','Produce','g',true),
      ('Garlic','Produce','clove',true),
      ('Ginger Garlic Paste','Produce','tbsp',true),
      ('Cilantro','Produce','bunch',true),
      ('Coriander Leaves','Produce','bunch',true),
      ('Mint','Produce','bunch',true),
      ('Curry Leaves','Produce','sprig',true),
      ('Spinach','Produce','g',true),
      ('Methi Leaves','Produce','bunch',true),
      ('Cabbage','Produce','whole',true),
      ('Cauliflower','Produce','whole',true),
      ('Broccoli','Produce','whole',true),
      ('Green Beans','Produce','g',true),
      ('Peas','Produce','g',true),
      ('Corn','Produce','g',true),
      ('Mushrooms','Produce','g',true),
      ('Eggplant','Produce','whole',true),
      ('Brinjal','Produce','whole',true),
      ('Okra','Produce','g',true),
      ('Bhindi','Produce','g',true),
      ('Zucchini','Produce','whole',true),
      ('Lemon','Fruit','whole',true),
      ('Lime','Fruit','whole',true),
      ('Avocado','Fruit','whole',true),
      ('Banana','Fruit','whole',true),
      ('Apple','Fruit','whole',true),
      ('Orange','Fruit','whole',true),
      ('Mango','Fruit','whole',true),
      ('Berries','Fruit','g',true),

      -- Grains and breads
      ('Rice','Grains','g',true),
      ('Basmati Rice','Grains','g',true),
      ('Brown Rice','Grains','g',true),
      ('Jasmine Rice','Grains','g',true),
      ('Sona Masoori Rice','Grains','g',true),
      ('Poha','Grains','g',true),
      ('Rava','Grains','g',true),
      ('Semolina','Grains','g',true),
      ('Oats','Grains','g',true),
      ('Quinoa','Grains','g',true),
      ('Pasta','Grains','g',true),
      ('Noodles','Grains','g',true),
      ('Bread','Bakery','slice',true),
      ('Tortilla','Bakery','whole',true),
      ('Roti','Bakery','whole',true),
      ('Flour Tortilla','Bakery','whole',true),
      ('Whole Wheat Flour','Baking','g',true),
      ('Atta','Baking','g',true),
      ('All-Purpose Flour','Baking','g',true),
      ('Maida','Baking','g',true),
      ('Besan','Baking','g',true),
      ('Rice Flour','Baking','g',true),
      ('Cornstarch','Baking','g',true),

      -- Legumes and beans
      ('Toor Dal','Legumes','g',true),
      ('Moong Dal','Legumes','g',true),
      ('Masoor Dal','Legumes','g',true),
      ('Chana Dal','Legumes','g',true),
      ('Urad Dal','Legumes','g',true),
      ('Chickpeas','Legumes','g',true),
      ('Kabuli Chana','Legumes','g',true),
      ('Black Chana','Legumes','g',true),
      ('Rajma','Legumes','g',true),
      ('Kidney Beans','Legumes','g',true),
      ('Black Beans','Legumes','g',true),
      ('Pinto Beans','Legumes','g',true),
      ('Lentils','Legumes','g',true),
      ('Canned Chickpeas','Canned','can',true),
      ('Canned Black Beans','Canned','can',true),
      ('Canned Kidney Beans','Canned','can',true),
      ('Canned Tomatoes','Canned','can',true),
      ('Tomato Paste','Canned','tbsp',true),
      ('Tomato Sauce','Canned','ml',true),

      -- Dairy and eggs
      ('Milk','Dairy','ml',true),
      ('Whole Milk','Dairy','ml',true),
      ('Greek Yogurt','Dairy','g',true),
      ('Yogurt','Dairy','g',true),
      ('Curd','Dairy','g',true),
      ('Dahi','Dairy','g',true),
      ('Paneer','Dairy','g',true),
      ('Tofu','Protein','g',true),
      ('Cheese','Dairy','g',true),
      ('Cheddar Cheese','Dairy','g',true),
      ('Mozzarella','Dairy','g',true),
      ('Butter','Dairy','tbsp',true),
      ('Ghee','Dairy','tbsp',true),
      ('Cream','Dairy','ml',true),
      ('Eggs','Dairy','whole',true),

      -- Meat and seafood
      ('Chicken','Meat','g',true),
      ('Chicken Breast','Meat','g',true),
      ('Chicken Thigh','Meat','g',true),
      ('Ground Chicken','Meat','g',true),
      ('Ground Turkey','Meat','g',true),
      ('Turkey','Meat','g',true),
      ('Mutton','Meat','g',true),
      ('Lamb','Meat','g',true),
      ('Ground Beef','Meat','g',true),
      ('Fish','Seafood','g',true),
      ('Salmon','Seafood','g',true),
      ('Shrimp','Seafood','g',true),

      -- Oils, condiments, sauces
      ('Oil','Oils','ml',true),
      ('Vegetable Oil','Oils','ml',true),
      ('Olive Oil','Oils','tbsp',true),
      ('Avocado Oil','Oils','tbsp',true),
      ('Mustard Oil','Oils','tbsp',true),
      ('Coconut Oil','Oils','tbsp',true),
      ('Sesame Oil','Oils','tsp',true),
      ('Vinegar','Condiments','tbsp',true),
      ('Rice Vinegar','Condiments','tbsp',true),
      ('Soy Sauce','Condiments','tbsp',true),
      ('Sriracha','Condiments','tbsp',true),
      ('Hot Sauce','Condiments','tbsp',true),
      ('Ketchup','Condiments','tbsp',true),
      ('Mustard','Condiments','tbsp',true),
      ('Mayonnaise','Condiments','tbsp',true),
      ('Peanut Butter','Condiments','tbsp',true),
      ('Tahini','Condiments','tbsp',true),
      ('Coconut Milk','Canned','ml',true),
      ('Tamarind Paste','Condiments','tsp',true),

      -- Spices and pantry staples
      ('Salt','Spices','tsp',true),
      ('Sugar','Baking','g',true),
      ('Brown Sugar','Baking','g',true),
      ('Jaggery','Baking','g',true),
      ('Honey','Condiments','tbsp',true),
      ('Maple Syrup','Condiments','tbsp',true),
      ('Turmeric','Spices','tsp',true),
      ('Cumin Seeds','Spices','tsp',true),
      ('Cumin Powder','Spices','tsp',true),
      ('Coriander Powder','Spices','tsp',true),
      ('Red Chili Powder','Spices','tsp',true),
      ('Kashmiri Chili Powder','Spices','tsp',true),
      ('Garam Masala','Spices','tsp',true),
      ('Chaat Masala','Spices','tsp',true),
      ('Kitchen King Masala','Spices','tsp',true),
      ('Biryani Masala','Spices','tsp',true),
      ('Sambar Powder','Spices','tsp',true),
      ('Rasam Powder','Spices','tsp',true),
      ('Mustard Seeds','Spices','tsp',true),
      ('Fenugreek Seeds','Spices','tsp',true),
      ('Hing','Spices','pinch',true),
      ('Asafoetida','Spices','pinch',true),
      ('Black Pepper','Spices','tsp',true),
      ('Cinnamon','Spices','stick',true),
      ('Cloves','Spices','whole',true),
      ('Cardamom','Spices','pod',true),
      ('Bay Leaf','Spices','whole',true),
      ('Kasuri Methi','Spices','tbsp',true),
      ('Sesame Seeds','Spices','tbsp',true),
      ('Peanuts','Nuts & Seeds','g',true),
      ('Cashews','Nuts & Seeds','g',true),
      ('Almonds','Nuts & Seeds','g',true),
      ('Raisins','Nuts & Seeds','g',true),

      -- Frozen and convenience
      ('Frozen Peas','Frozen','g',true),
      ('Frozen Mixed Vegetables','Frozen','g',true),
      ('Frozen Paratha','Frozen','whole',true),
      ('Frozen Roti','Frozen','whole',true),
      ('Frozen Paneer','Frozen','g',true),
      ('Frozen Spinach','Frozen','g',true),

      -- Beverages and misc
      ('Tea','Beverages','tsp',true),
      ('Coffee','Beverages','tbsp',true),
      ('Cocoa Powder','Baking','tbsp',true),
      ('Baking Powder','Baking','tsp',true),
      ('Baking Soda','Baking','tsp',true),
      ('Yeast','Baking','tsp',true),
      ('Water','Other','ml',true)
  ) as seed(name, category, default_unit, approximate_allowed)
  where not exists (
    select 1
    from public.ingredients existing
    where existing.user_id = target_user_id
      and lower(trim(existing.name)) = lower(trim(seed.name))
  );
end $$;

-- Diagnostic: duplicate catalogue names for the inferred/current user.
-- This query is informational only.
with target as (
  select coalesce(
    auth.uid(),
    (select user_id from public.ingredients order by created_at nulls last limit 1),
    (select user_id from public.pantry_items order by created_at nulls last limit 1)
  ) as user_id
)
select lower(trim(i.name)) as normalized_name, count(*) as duplicate_count
from public.ingredients i, target t
where i.user_id = t.user_id
group by lower(trim(i.name))
having count(*) > 1
order by duplicate_count desc, normalized_name;
