import Foundation
import Testing
@testable import MealPlanner

struct WeekPlanningTests {
    @Test("Adding a recipe to the weekly plan defaults to one serving")
    func recipeDefaultPlannedServingsIsOne() {
        let recipe = WeekRecipeSummary(
            id: UUID(),
            name: "Four Serving Recipe",
            mealTypes: ["dinner"],
            defaultServings: 4,
            preparationMinutes: 10,
            cookingMinutes: 20,
            cleanupMinutes: 5,
            creatorName: "Test",
            analysisStatus: "compliant",
            complianceScore: 1
        )

        #expect(recipe.defaultServings == 4)
        #expect(recipe.defaultPlannedServings == 1)
    }
}
