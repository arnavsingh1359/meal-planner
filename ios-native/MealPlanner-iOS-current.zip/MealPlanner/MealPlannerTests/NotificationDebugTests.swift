import Foundation
import Testing
@testable import MealPlanner

struct NotificationDebugTests {

    @Test("Every notification kind has a debug reminder")
    func everyKindHasDebugReminder() {
        let start = date("2026-07-01T12:00:00Z")
        let reminders = MealPlannerNotificationPlanner.allDebugReminders(
            startingAt: start,
            spacingSeconds: 10
        )

        #expect(reminders.count == MealPlannerNotificationKind.allCases.count)
        #expect(Set(reminders.map(\.kind)) == Set(MealPlannerNotificationKind.allCases))
        #expect(reminders.allSatisfy { $0.id.hasPrefix(MealPlannerNotificationPlanner.identifierPrefix + "debug.") })
        #expect(reminders.allSatisfy { $0.threadIdentifier == "mealplanner.debug" })
    }

    @Test("Debug reminders are staggered so they can be observed one by one")
    func debugRemindersAreStaggered() {
        let start = date("2026-07-01T12:00:00Z")
        let reminders = MealPlannerNotificationPlanner.allDebugReminders(
            startingAt: start,
            spacingSeconds: 10
        )

        #expect(reminders[0].fireDate == start.addingTimeInterval(10))
        #expect(reminders[1].fireDate == start.addingTimeInterval(20))
        #expect(reminders[2].fireDate == start.addingTimeInterval(30))
    }

    @Test("Debug reminder destinations route to the right app area")
    func debugReminderDestinationsAreCorrect() {
        let planning = MealPlannerNotificationPlanner.debugReminder(
            kind: .weeklyPlanning
        )
        let shopping = MealPlannerNotificationPlanner.debugReminder(
            kind: .shoppingReminder
        )
        let cooking = MealPlannerNotificationPlanner.debugReminder(
            kind: .cookingTask
        )

        #expect(planning.destination == "planning")
        #expect(shopping.destination == "shopping")
        #expect(cooking.destination == "schedule")
    }

    private func date(_ value: String) -> Date {
        ISO8601DateFormatter().date(from: value)!
    }
}
