import Foundation
import Testing
@testable import MealPlanner

struct ShoppingDisplayUnitTests {
    private let recipeID = UUID(uuidString: "00000000-0000-0000-0000-000000000101")!
    private let mealID = UUID(uuidString: "00000000-0000-0000-0000-000000000201")!

    @Test("Shopping keeps rice measured in recipe cups instead of converting to liters")
    func riceMeasuredInCupsStaysInCups() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [
                meal(servings: 1, baseServings: 1)
            ],
            recipeIngredients: [
                ingredient(name: "Rice", quantity: 1.5, unit: "cups")
            ],
            pantryItems: []
        )

        #expect(result.count == 1)
        #expect(result[0].canonicalName == "rice")
        #expect(result[0].unit == "cup")
        #expect(abs(result[0].neededQuantity - 1.5) < 0.000_1)
        #expect(result[0].quantityText == "1.5 cup")
    }

    @Test("Shopping subtracts pantry volume but still displays the recipe unit")
    func pantryVolumeSubtractionKeepsRecipeUnit() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [
                meal(servings: 1, baseServings: 1)
            ],
            recipeIngredients: [
                ingredient(name: "Milk", quantity: 2, unit: "cups")
            ],
            pantryItems: [
                pantry(name: "Milk", quantity: 240, unit: "ml")
            ]
        )

        #expect(result.count == 1)
        #expect(result[0].unit == "cup")
        #expect(abs(result[0].requiredQuantity - 2) < 0.000_1)
        #expect(abs(result[0].pantryQuantity - 1) < 0.000_1)
        #expect(abs(result[0].neededQuantity - 1) < 0.000_1)
    }

    @Test("Mixed compatible volume units prefer the larger recipe unit")
    func mixedVolumeUnitsPreferLargerRecipeUnit() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [
                meal(servings: 1, baseServings: 1)
            ],
            recipeIngredients: [
                ingredient(name: "Oil", quantity: 1, unit: "cup"),
                ingredient(name: "Oil", quantity: 2, unit: "tbsp"),
                ingredient(name: "Oil", quantity: 1, unit: "tsp")
            ],
            pantryItems: []
        )

        #expect(result.count == 1)
        #expect(result[0].unit == "cup")
        #expect(abs(result[0].neededQuantity - (275.0 / 240.0)) < 0.000_1)
    }

    @Test("Recipe serving scaling happens before display-unit conversion")
    func servingsScaleBeforeDisplayUnitConversion() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [
                meal(servings: 2, baseServings: 4)
            ],
            recipeIngredients: [
                ingredient(name: "Rice", quantity: 4, unit: "cups")
            ],
            pantryItems: []
        )

        #expect(result.count == 1)
        #expect(result[0].unit == "cup")
        #expect(abs(result[0].neededQuantity - 2) < 0.000_1)
    }

    private func meal(
        servings: Double = 1,
        baseServings: Double = 1
    ) -> ShoppingPlannedMeal {
        ShoppingPlannedMeal(
            id: mealID,
            recipeID: recipeID,
            recipeName: "Test Recipe",
            mealDate: "2026-07-01",
            slotName: "Dinner",
            servings: servings,
            baseServings: baseServings
        )
    }

    private func ingredient(
        name: String,
        quantity: Double,
        unit: String,
        shoppingIncluded: Bool = true,
        scalingBehavior: String = "linear"
    ) -> ShoppingRecipeIngredient {
        ShoppingRecipeIngredient(
            id: UUID(),
            recipeID: recipeID,
            name: name,
            quantity: quantity,
            unit: unit,
            isOptional: false,
            scalingBehavior: scalingBehavior,
            shoppingIncluded: shoppingIncluded,
            position: 0
        )
    }

    private func pantry(
        name: String,
        quantity: Double,
        unit: String,
        trackingMode: String = "exact",
        stockStatus: String = "enough"
    ) -> PantryStockItem {
        PantryStockItem(
            id: UUID(),
            userID: nil,
            trackingMode: trackingMode,
            name: name,
            quantity: quantity,
            unit: unit,
            stockStatus: stockStatus,
            category: nil,
            defaultUnit: unit,
            approximateAllowed: true
        )
    }
}
