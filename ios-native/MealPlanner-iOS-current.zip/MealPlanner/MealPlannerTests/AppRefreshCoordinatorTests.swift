import Testing
@testable import MealPlanner

@MainActor
struct AppRefreshCoordinatorTests {
    @Test("Week changes invalidate dependent pages")
    func weekChangesInvalidateDependentPages() {
        let coordinator = AppRefreshCoordinator()

        coordinator.weekPlanChanged()

        #expect(coordinator.weekVersion == 1)
        #expect(coordinator.todayVersion == 1)
        #expect(coordinator.scheduleVersion == 1)
        #expect(coordinator.shoppingVersion == 1)
        #expect(coordinator.pantryVersion == 0)
        #expect(coordinator.recipesVersion == 0)
    }

    @Test("Pantry changes invalidate shopping and today")
    func pantryChangesInvalidateShoppingAndToday() {
        let coordinator = AppRefreshCoordinator()

        coordinator.pantryChanged()

        #expect(coordinator.pantryVersion == 1)
        #expect(coordinator.shoppingVersion == 1)
        #expect(coordinator.todayVersion == 1)
        #expect(coordinator.weekVersion == 0)
        #expect(coordinator.scheduleVersion == 0)
    }

    @Test("Task completion changes invalidate schedule and today")
    func taskCompletionInvalidatesScheduleAndToday() {
        let coordinator = AppRefreshCoordinator()

        coordinator.taskCompletionChanged()

        #expect(coordinator.scheduleVersion == 1)
        #expect(coordinator.todayVersion == 1)
        #expect(coordinator.shoppingVersion == 0)
    }

    @Test("Recipe changes invalidate downstream planning pages")
    func recipesInvalidateDownstreamPlanningPages() {
        let coordinator = AppRefreshCoordinator()

        coordinator.recipesChanged()

        #expect(coordinator.recipesVersion == 1)
        #expect(coordinator.weekVersion == 1)
        #expect(coordinator.scheduleVersion == 1)
        #expect(coordinator.shoppingVersion == 1)
        #expect(coordinator.todayVersion == 1)
        #expect(coordinator.pantryVersion == 0)
    }

    @Test("Checklist-only shopping changes update Today without reloading Shopping")
    func checklistOnlyShoppingChangesUpdateToday() {
        let coordinator = AppRefreshCoordinator()

        coordinator.shoppingChecklistChanged()

        #expect(coordinator.todayVersion == 1)
        #expect(coordinator.shoppingVersion == 0)
    }

    @Test("Mark all changed increments every page token")
    func markAllChangedIncrementsEveryPageToken() {
        let coordinator = AppRefreshCoordinator()

        coordinator.markAllChanged()

        #expect(coordinator.todayVersion == 1)
        #expect(coordinator.weekVersion == 1)
        #expect(coordinator.scheduleVersion == 1)
        #expect(coordinator.recipesVersion == 1)
        #expect(coordinator.shoppingVersion == 1)
        #expect(coordinator.pantryVersion == 1)
        #expect(coordinator.settingsVersion == 1)
    }
}
