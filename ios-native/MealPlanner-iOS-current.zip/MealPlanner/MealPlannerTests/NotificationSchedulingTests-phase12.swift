import Foundation
import Testing
@testable import MealPlanner

struct NotificationSchedulingTests {
    @Test("Completed weekly planning schedules no weekly planning reminders")
    func completedPlanningSchedulesNoPlanningReminders() {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!

        let weekStart = date("2026-07-05T00:00:00Z")
        let now = date("2026-07-03T12:00:00Z")

        let reminders = MealPlannerNotificationPlanner.weeklyPlanningReminders(
            input: MealPlannerNotificationPlanningInput(
                weekStart: weekStart,
                isComplete: true,
                nextStepTitle: "Menu"
            ),
            now: now,
            calendar: calendar
        )

        #expect(reminders.isEmpty)
    }

    @Test("Incomplete weekly planning schedules Saturday and Sunday reminders")
    func incompletePlanningSchedulesWeekendReminders() {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!

        let weekStart = date("2026-07-05T00:00:00Z")
        let now = date("2026-07-03T12:00:00Z")

        let reminders = MealPlannerNotificationPlanner.weeklyPlanningReminders(
            input: MealPlannerNotificationPlanningInput(
                weekStart: weekStart,
                isComplete: false,
                nextStepTitle: "Pantry"
            ),
            now: now,
            calendar: calendar
        )

        #expect(reminders.count == 4)
        #expect(reminders.map(\.kind).allSatisfy { $0 == .weeklyPlanning })
        #expect(reminders[0].title == "Plan next week’s meals")
        #expect(reminders[1].body.contains("Pantry"))
    }

    @Test("Old planning reminders are not kept after their time has passed")
    func passedPlanningRemindersAreFiltered() {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!

        let reminders = MealPlannerNotificationPlanner.weeklyPlanningReminders(
            input: MealPlannerNotificationPlanningInput(
                weekStart: date("2026-07-05T00:00:00Z"),
                isComplete: false,
                nextStepTitle: "Schedule"
            ),
            now: date("2026-07-04T19:00:00Z"),
            calendar: calendar
        )

        #expect(reminders.count == 2)
        #expect(reminders.allSatisfy { $0.fireDate > date("2026-07-04T19:00:00Z") })
    }

    @Test("Clustered active tasks create session reminders instead of many individual reminders")
    func clusteredTasksCreateSessionReminders() {
        let now = date("2026-07-01T06:00:00Z")
        let tasks = [
            task("Dice onion", start: "2026-07-01T07:00:00Z", end: "2026-07-01T07:05:00Z", active: 5, position: 0),
            task("Cook rice", start: "2026-07-01T07:10:00Z", end: "2026-07-01T07:35:00Z", active: 25, position: 1),
            task("Assemble bowl", start: "2026-07-01T07:40:00Z", end: "2026-07-01T07:50:00Z", active: 10, position: 2)
        ]

        let reminders = MealPlannerNotificationPlanner.cookingReminders(
            tasks: tasks,
            now: now
        )

        #expect(reminders.contains { $0.kind == .cookingSession && $0.title.contains("30 minutes") })
        #expect(reminders.contains { $0.kind == .cookingSession && $0.title.contains("starts now") })
        #expect(!reminders.contains { $0.id.contains("cooking-task") })
    }

    @Test("Single active task creates before and start reminders")
    func singleTaskCreatesTaskReminders() {
        let reminders = MealPlannerNotificationPlanner.cookingReminders(
            tasks: [
                task("Marinate chicken", start: "2026-07-01T16:00:00Z", end: "2026-07-01T17:14:00Z", active: 5, passive: 69)
            ],
            now: date("2026-07-01T15:00:00Z")
        )

        #expect(reminders.contains { $0.kind == .cookingTask && $0.id.contains("before") })
        #expect(reminders.contains { $0.kind == .cookingTask && $0.id.contains("start") })
    }

    @Test("Passive task completion reminders are scheduled for marination and soaking")
    func passiveCompletionReminderIsScheduled() {
        let reminders = MealPlannerNotificationPlanner.cookingReminders(
            tasks: [
                task("Marinate chicken", start: "2026-07-01T16:00:00Z", end: "2026-07-01T17:14:00Z", active: 5, passive: 69)
            ],
            now: date("2026-07-01T15:00:00Z")
        )

        #expect(reminders.contains { $0.kind == .passiveTaskFinished })
    }

    @Test("Completed tasks do not schedule cooking reminders")
    func completedTasksDoNotNotify() {
        let reminders = MealPlannerNotificationPlanner.cookingReminders(
            tasks: [
                task("Cook rice", start: "2026-07-01T16:00:00Z", end: "2026-07-01T16:25:00Z", active: 25, completed: true)
            ],
            now: date("2026-07-01T15:00:00Z")
        )

        #expect(reminders.isEmpty)
    }

    @Test("Overdue reminders are delayed and sent at most once per reschedule cycle")
    func overdueReminderIsScheduledForLateTask() {
        let now = date("2026-07-01T08:00:00Z")
        let reminders = MealPlannerNotificationPlanner.cookingReminders(
            tasks: [
                task("Dice tomato", start: "2026-07-01T07:00:00Z", end: "2026-07-01T07:07:00Z", active: 7)
            ],
            now: now
        )

        #expect(reminders.contains { $0.kind == .overdueTask })
        #expect(reminders.first { $0.kind == .overdueTask }?.fireDate ?? now > now)
    }

    @Test("Shopping reminders are not scheduled when no unchecked items exist")
    func noShoppingReminderForEmptyList() {
        let reminders = MealPlannerNotificationPlanner.shoppingReminders(
            input: MealPlannerNotificationShoppingInput(
                weekStart: date("2026-07-05T00:00:00Z"),
                uncheckedItemCount: 0
            ),
            now: date("2026-07-03T12:00:00Z")
        )

        #expect(reminders.isEmpty)
    }

    @Test("Shopping reminders are scheduled for unchecked items")
    func shoppingReminderForUncheckedItems() {
        let reminders = MealPlannerNotificationPlanner.shoppingReminders(
            input: MealPlannerNotificationShoppingInput(
                weekStart: date("2026-07-05T00:00:00Z"),
                uncheckedItemCount: 12
            ),
            now: date("2026-07-03T12:00:00Z")
        )

        #expect(reminders.count == 2)
        #expect(reminders[0].body.contains("12"))
        #expect(reminders.allSatisfy { $0.destination == "shopping" })
    }

    @Test("All generated notification identifiers use the meal planner prefix")
    func identifiersUsePrefix() {
        let drafts = MealPlannerNotificationPlanner.makeAllNotifications(
            planning: MealPlannerNotificationPlanningInput(
                weekStart: date("2026-07-05T00:00:00Z"),
                isComplete: false,
                nextStepTitle: "Menu"
            ),
            tasks: [
                task("Cook rice", start: "2026-07-01T16:00:00Z", end: "2026-07-01T16:25:00Z", active: 25)
            ],
            shopping: MealPlannerNotificationShoppingInput(
                weekStart: date("2026-07-05T00:00:00Z"),
                uncheckedItemCount: 3
            ),
            now: date("2026-07-01T12:00:00Z")
        )

        #expect(!drafts.isEmpty)
        #expect(drafts.allSatisfy { $0.id.hasPrefix(MealPlannerNotificationPlanner.identifierPrefix) })
    }

    private func task(
        _ title: String,
        start: String,
        end: String,
        active: Int,
        passive: Int = 0,
        completed: Bool = false,
        position: Int = 0
    ) -> MealPlannerNotificationTask {
        MealPlannerNotificationTask(
            id: UUID(),
            title: title,
            scheduledStart: date(start),
            scheduledEnd: date(end),
            activeMinutes: active,
            passiveMinutes: passive,
            isCompleted: completed,
            hasConflict: false,
            warningMessage: nil,
            batchID: nil,
            batchMealCount: 1,
            isSharedPrep: false,
            position: position
        )
    }

    private func date(_ value: String) -> Date {
        ISO8601DateFormatter().date(from: value)!
    }
}
