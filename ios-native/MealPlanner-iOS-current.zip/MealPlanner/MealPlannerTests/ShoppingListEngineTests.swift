import Foundation
import Testing
@testable import MealPlanner

struct ShoppingListEngineTests {
    private let paneerRecipeID = UUID(uuidString: "00000000-0000-0000-0000-000000000001")!
    private let chickenRecipeID = UUID(uuidString: "00000000-0000-0000-0000-000000000002")!
    private let unusedRecipeID = UUID(uuidString: "00000000-0000-0000-0000-000000000003")!

    @Test("Empty weekly menu produces an empty shopping list")
    func emptyWeeklyMenuProducesEmptyShoppingList() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [],
            recipeIngredients: [ingredient(recipeID: paneerRecipeID, name: "Paneer", quantity: 200, unit: "g")],
            pantryItems: []
        )

        #expect(result.isEmpty)
    }

    @Test("Shopping list only uses recipes present in the weekly menu")
    func shoppingListUsesOnlyWeeklyMenuRecipes() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Paneer Bhurji")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Paneer", quantity: 200, unit: "g"),
                ingredient(recipeID: unusedRecipeID, name: "Chicken", quantity: 500, unit: "g")
            ],
            pantryItems: []
        )

        #expect(result.count == 1)
        #expect(result[0].canonicalName == "paneer")
        #expect(result[0].neededQuantity == 200)
    }

    @Test("Ingredient quantities scale by planned servings")
    func ingredientQuantitiesScaleByPlannedServings() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [
                meal(
                    recipeID: paneerRecipeID,
                    recipeName: "Paneer Bhurji",
                    servings: 4,
                    baseServings: 2
                )
            ],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Paneer", quantity: 200, unit: "g")
            ],
            pantryItems: []
        )

        #expect(result.count == 1)
        #expect(result[0].neededQuantity == 400)
        #expect(result[0].unit == "g")
    }

    @Test("Repeated weekly meals consolidate ingredient quantities")
    func repeatedWeeklyMealsConsolidateIngredientQuantities() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [
                meal(recipeID: paneerRecipeID, recipeName: "Paneer Bhurji"),
                meal(recipeID: paneerRecipeID, recipeName: "Paneer Bhurji")
            ],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Paneer", quantity: 200, unit: "g")
            ],
            pantryItems: []
        )

        #expect(result.count == 1)
        #expect(result[0].neededQuantity == 400)
        #expect(result[0].sourceMealCount == 2)
    }

    @Test("Multiple weekly recipes consolidate matching ingredients")
    func multipleWeeklyRecipesConsolidateMatchingIngredients() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [
                meal(recipeID: paneerRecipeID, recipeName: "Paneer Bhurji"),
                meal(recipeID: chickenRecipeID, recipeName: "Chicken Bowl")
            ],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Onion", quantity: 1, unit: "count"),
                ingredient(recipeID: chickenRecipeID, name: "Onions", quantity: 2, unit: "count")
            ],
            pantryItems: []
        )

        let onion = result.first { $0.canonicalName == "onion" }
        #expect(onion?.neededQuantity == 3)
        #expect(onion?.sourceRecipeNames == ["Chicken Bowl", "Paneer Bhurji"])
    }

    @Test("Full pantry stock removes an ingredient from shopping")
    func fullPantryStockRemovesIngredientFromShopping() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Paneer Bhurji")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Paneer", quantity: 200, unit: "g")
            ],
            pantryItems: [pantry(name: "Paneer", quantity: 250, unit: "g")]
        )

        #expect(result.isEmpty)
    }

    @Test("Partial pantry stock leaves only missing quantity")
    func partialPantryStockLeavesOnlyMissingQuantity() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Paneer Bhurji")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Paneer", quantity: 500, unit: "g")
            ],
            pantryItems: [pantry(name: "Paneer", quantity: 200, unit: "g")]
        )

        #expect(result.count == 1)
        #expect(result[0].neededQuantity == 300)
        #expect(result[0].requiredQuantity == 500)
        #expect(result[0].pantryQuantity == 200)
    }

    @Test("Pantry aliases are subtracted from matching weekly ingredients")
    func pantryAliasesAreSubtracted() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Kathi Roll")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Cilantro", quantity: 2, unit: "bunch")
            ],
            pantryItems: [pantry(name: "Coriander leaves", quantity: 1, unit: "bunch")]
        )

        #expect(result.count == 1)
        #expect(result[0].canonicalName == "coriander leaves")
        #expect(result[0].neededQuantity == 1)
    }

    @Test("Mass units convert and consolidate grams and kilograms")
    func massUnitsConvertAndConsolidate() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Dal Rice")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Rice", quantity: 1.5, unit: "kg")
            ],
            pantryItems: [pantry(name: "Rice", quantity: 250, unit: "g")]
        )

        #expect(result.count == 1)
        #expect(result[0].unit == "kg")
        #expect(abs(result[0].neededQuantity - 1.25) < 0.000_1)
    }

    @Test("Volume units convert and consolidate liters and milliliters")
    func volumeUnitsConvertAndConsolidate() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Lassi")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Milk", quantity: 1, unit: "L")
            ],
            pantryItems: [pantry(name: "Milk", quantity: 250, unit: "ml")]
        )

        #expect(result.count == 1)
        #expect(result[0].unit == "ml")
        #expect(result[0].neededQuantity == 750)
    }

    @Test("Spoon and cup units convert to compatible volume")
    func spoonAndCupUnitsConvertToVolume() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Dressing")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Oil", quantity: 1, unit: "cup"),
                ingredient(recipeID: paneerRecipeID, name: "Oil", quantity: 2, unit: "tbsp"),
                ingredient(recipeID: paneerRecipeID, name: "Oil", quantity: 1, unit: "tsp")
            ],
            pantryItems: []
        )

        #expect(result.count == 1)
        #expect(result[0].unit == "ml")
        #expect(result[0].neededQuantity == 275)
    }

    @Test("Indian kitchen aliases normalize common duplicate names")
    func indianKitchenAliasesNormalizeCommonDuplicateNames() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Stir Fry")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Capsicum", quantity: 1, unit: "count"),
                ingredient(recipeID: paneerRecipeID, name: "Bell peppers", quantity: 2, unit: "count"),
                ingredient(recipeID: paneerRecipeID, name: "Green chillies", quantity: 3, unit: "count"),
                ingredient(recipeID: paneerRecipeID, name: "Green chili", quantity: 4, unit: "count")
            ],
            pantryItems: []
        )

        let bellPepper = result.first { $0.canonicalName == "bell pepper" }
        let greenChili = result.first { $0.canonicalName == "green chili" }

        #expect(bellPepper?.neededQuantity == 3)
        #expect(greenChili?.neededQuantity == 7)
    }

    @Test("Fixed quantity ingredients do not scale with servings")
    func fixedQuantityIngredientsDoNotScale() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [
                meal(
                    recipeID: paneerRecipeID,
                    recipeName: "Pulao",
                    servings: 6,
                    baseServings: 2
                )
            ],
            recipeIngredients: [
                ingredient(
                    recipeID: paneerRecipeID,
                    name: "Bay leaf",
                    quantity: 1,
                    unit: "count",
                    scalingBehavior: "fixed"
                )
            ],
            pantryItems: []
        )

        #expect(result.count == 1)
        #expect(result[0].neededQuantity == 1)
    }

    @Test("To-taste ingredients are excluded from shopping")
    func toTasteIngredientsAreExcluded() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Raita")],
            recipeIngredients: [
                ingredient(
                    recipeID: paneerRecipeID,
                    name: "Salt",
                    quantity: 1,
                    unit: "tsp",
                    scalingBehavior: "to_taste"
                )
            ],
            pantryItems: []
        )

        #expect(result.isEmpty)
    }

    @Test("Ingredients marked as not shopping-included are excluded")
    func notShoppingIncludedIngredientsAreExcluded() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Tea")],
            recipeIngredients: [
                ingredient(
                    recipeID: paneerRecipeID,
                    name: "Water",
                    quantity: 500,
                    unit: "ml",
                    shoppingIncluded: false
                )
            ],
            pantryItems: []
        )

        #expect(result.isEmpty)
    }

    @Test("Custom units consolidate only when the custom unit matches")
    func customUnitsConsolidateOnlyWhenMatching() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Herb Rice")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Mint", quantity: 1, unit: "packet"),
                ingredient(recipeID: paneerRecipeID, name: "Mint", quantity: 1, unit: "bunch")
            ],
            pantryItems: []
        )

        #expect(result.count == 2)
        #expect(Set(result.map(\.unit)) == ["packet", "count"])
    }

    @Test("Shopping generation is deterministic and does not create duplicates")
    func shoppingGenerationIsDeterministic() {
        let meals = [
            meal(recipeID: paneerRecipeID, recipeName: "Paneer Bhurji"),
            meal(recipeID: chickenRecipeID, recipeName: "Chicken Bowl")
        ]
        let ingredients = [
            ingredient(recipeID: paneerRecipeID, name: "Onion", quantity: 1, unit: "count"),
            ingredient(recipeID: chickenRecipeID, name: "Onions", quantity: 1, unit: "count"),
            ingredient(recipeID: paneerRecipeID, name: "Paneer", quantity: 200, unit: "g")
        ]

        let first = ShoppingListEngine.generate(
            plannedMeals: meals,
            recipeIngredients: ingredients,
            pantryItems: []
        )

        let second = ShoppingListEngine.generate(
            plannedMeals: meals,
            recipeIngredients: ingredients,
            pantryItems: []
        )

        #expect(first == second)
        #expect(Set(first.map(\.id)).count == first.count)
    }

    @Test("Generated list is sorted by category then ingredient name")
    func generatedListIsSortedByCategoryThenIngredientName() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: paneerRecipeID, recipeName: "Meal")],
            recipeIngredients: [
                ingredient(recipeID: paneerRecipeID, name: "Tomato", quantity: 1, unit: "count"),
                ingredient(recipeID: paneerRecipeID, name: "Milk", quantity: 1, unit: "L"),
                ingredient(recipeID: paneerRecipeID, name: "Paneer", quantity: 200, unit: "g")
            ],
            pantryItems: []
        )

        #expect(result.map(\.displayName) == ["Milk", "Paneer", "Tomato"])
    }

    // MARK: - Helpers

    private func meal(
        recipeID: UUID,
        recipeName: String,
        servings: Double = 2,
        baseServings: Double = 2
    ) -> ShoppingPlannedMeal {
        ShoppingPlannedMeal(
            id: UUID(),
            recipeID: recipeID,
            recipeName: recipeName,
            mealDate: "2026-07-06",
            slotName: "Dinner",
            servings: servings,
            baseServings: baseServings
        )
    }

    private func ingredient(
        recipeID: UUID,
        name: String,
        quantity: Double,
        unit: String,
        isOptional: Bool = false,
        scalingBehavior: String = "linear",
        shoppingIncluded: Bool = true
    ) -> ShoppingRecipeIngredient {
        ShoppingRecipeIngredient(
            id: UUID(),
            recipeID: recipeID,
            name: name,
            quantity: quantity,
            unit: unit,
            isOptional: isOptional,
            scalingBehavior: scalingBehavior,
            shoppingIncluded: shoppingIncluded,
            position: 0
        )
    }

    private func pantry(
        name: String,
        quantity: Double,
        unit: String,
        category: String? = nil
    ) -> PantryStockItem {
        PantryStockItem(
            id: UUID(),
            userID: nil,
            name: name,
            quantity: quantity,
            unit: unit,
            category: category,
            notes: nil,
            updatedAt: nil
        )
    }
}

struct ShoppingListPantryStatusTests {
    private let recipeID = UUID(uuidString: "00000000-0000-0000-0000-000000000101")!

    @Test("Approximate enough pantry stock covers matching weekly ingredient")
    func approximateEnoughStockCoversMatchingIngredient() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: recipeID, recipeName: "Dal Rice")],
            recipeIngredients: [
                ingredient(recipeID: recipeID, name: "Rice", quantity: 500, unit: "g")
            ],
            pantryItems: [
                pantry(name: "Rice", trackingMode: "approximate", quantity: 0, unit: "", stockStatus: "enough")
            ]
        )

        #expect(result.isEmpty)
    }

    @Test("Approximate low pantry stock does not cover weekly ingredient")
    func approximateLowStockDoesNotCoverIngredient() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: recipeID, recipeName: "Dal Rice")],
            recipeIngredients: [
                ingredient(recipeID: recipeID, name: "Rice", quantity: 500, unit: "g")
            ],
            pantryItems: [
                pantry(name: "Rice", trackingMode: "approximate", quantity: 0, unit: "", stockStatus: "low")
            ]
        )

        #expect(result.count == 1)
        #expect(result[0].neededQuantity == 500)
    }

    @Test("Out pantry stock does not subtract from weekly ingredient")
    func outStockDoesNotSubtractFromShopping() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: recipeID, recipeName: "Lassi")],
            recipeIngredients: [
                ingredient(recipeID: recipeID, name: "Milk", quantity: 1, unit: "L")
            ],
            pantryItems: [
                pantry(name: "Milk", trackingMode: "exact", quantity: 1, unit: "L", stockStatus: "out")
            ]
        )

        #expect(result.count == 1)
        #expect(result[0].neededQuantity == 1)
        #expect(result[0].unit == "L")
    }

    @Test("Approximate pantry aliases cover matching weekly ingredients across units")
    func approximatePantryAliasesCoverAcrossUnits() {
        let result = ShoppingListEngine.generate(
            plannedMeals: [meal(recipeID: recipeID, recipeName: "Kathi Roll")],
            recipeIngredients: [
                ingredient(recipeID: recipeID, name: "Cilantro", quantity: 2, unit: "bunch")
            ],
            pantryItems: [
                pantry(name: "Coriander leaves", trackingMode: "approximate", quantity: 0, unit: "", stockStatus: "plenty")
            ]
        )

        #expect(result.isEmpty)
    }

    private func meal(
        recipeID: UUID,
        recipeName: String,
        servings: Double = 2,
        baseServings: Double = 2
    ) -> ShoppingPlannedMeal {
        ShoppingPlannedMeal(
            id: UUID(),
            recipeID: recipeID,
            recipeName: recipeName,
            mealDate: "2026-07-06",
            slotName: "Dinner",
            servings: servings,
            baseServings: baseServings
        )
    }

    private func ingredient(
        recipeID: UUID,
        name: String,
        quantity: Double,
        unit: String,
        scalingBehavior: String = "linear",
        shoppingIncluded: Bool = true
    ) -> ShoppingRecipeIngredient {
        ShoppingRecipeIngredient(
            id: UUID(),
            recipeID: recipeID,
            name: name,
            quantity: quantity,
            unit: unit,
            isOptional: false,
            scalingBehavior: scalingBehavior,
            shoppingIncluded: shoppingIncluded,
            position: 0
        )
    }

    private func pantry(
        name: String,
        trackingMode: String,
        quantity: Double,
        unit: String,
        stockStatus: String
    ) -> PantryStockItem {
        PantryStockItem(
            id: UUID(),
            userID: nil,
            trackingMode: trackingMode,
            name: name,
            quantity: quantity,
            unit: unit,
            stockStatus: stockStatus
        )
    }
}
