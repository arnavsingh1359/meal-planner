import Foundation
import Testing
@testable import MealPlanner

struct TodayDashboardTests {
    @Test("Today dashboard separates overdue, next-up, later, and completed tasks")
    func taskSectionsSeparateStatuses() {
        let now = referenceDate(hour: 12, minute: 0)

        let overdue = task(
            title: "Cook rice",
            start: referenceDate(hour: 9, minute: 0),
            end: referenceDate(hour: 9, minute: 30),
            position: 0
        )

        let next = task(
            title: "Dice onion",
            start: referenceDate(hour: 12, minute: 30),
            end: referenceDate(hour: 12, minute: 40),
            position: 1
        )

        let later = task(
            title: "Cook dinner",
            start: referenceDate(hour: 18, minute: 0),
            end: referenceDate(hour: 18, minute: 45),
            position: 2
        )

        let completed = task(
            title: "Soak chickpeas",
            start: referenceDate(hour: 7, minute: 0),
            end: referenceDate(hour: 7, minute: 5),
            isCompleted: true,
            position: 3
        )

        let sections = TodayDashboardBuilder.taskSections(
            tasks: [later, completed, overdue, next],
            now: now
        )

        #expect(sections.map(\.status) == [
            .overdue,
            .nextUp,
            .later,
            .completed
        ])
        #expect(sections[0].tasks.map(\.title) == ["Cook rice"])
        #expect(sections[1].tasks.map(\.title) == ["Dice onion"])
        #expect(sections[2].tasks.map(\.title) == ["Cook dinner"])
        #expect(sections[3].tasks.map(\.title) == ["Soak chickpeas"])
    }

    @Test("Today dashboard chooses the earliest unfinished task as next up")
    func nextUpUsesEarliestUnfinishedTask() {
        let now = referenceDate(hour: 10, minute: 0)
        let later = task(
            title: "Dinner prep",
            start: referenceDate(hour: 17, minute: 0),
            end: referenceDate(hour: 17, minute: 20),
            position: 1
        )
        let earlier = task(
            title: "Lunch prep",
            start: referenceDate(hour: 11, minute: 0),
            end: referenceDate(hour: 11, minute: 20),
            position: 0
        )

        let nextID = TodayDashboardBuilder.nextUnfinishedTaskID(
            tasks: [later, earlier],
            now: now
        )

        #expect(nextID == earlier.id)
    }

    @Test("Today summary counts meals, completion, overdue tasks, warnings, and shopping")
    func summaryCountsDashboardMetrics() {
        let now = referenceDate(hour: 12, minute: 0)
        let todayTasks = [
            task(
                title: "Overdue warning",
                start: referenceDate(hour: 8, minute: 0),
                end: referenceDate(hour: 8, minute: 20),
                hasConflict: true,
                position: 0
            ),
            task(
                title: "Completed",
                start: referenceDate(hour: 9, minute: 0),
                end: referenceDate(hour: 9, minute: 10),
                isCompleted: true,
                position: 1
            ),
            task(
                title: "Later",
                start: referenceDate(hour: 18, minute: 0),
                end: referenceDate(hour: 18, minute: 30),
                position: 2
            )
        ]

        let weekTasks = todayTasks + [
            task(
                title: "Tomorrow warning",
                start: referenceDate(day: 2, hour: 10, minute: 0),
                end: referenceDate(day: 2, hour: 10, minute: 15),
                warningMessage: "Outside window",
                position: 3
            )
        ]

        let summary = TodayDashboardBuilder.summary(
            todayTasks: todayTasks,
            weekTasks: weekTasks,
            todayMeals: [meal("Breakfast"), meal("Dinner")],
            weekMealCount: 9,
            shoppingItemsRemaining: 5,
            now: now
        )

        #expect(summary.mealCountToday == 2)
        #expect(summary.taskCountToday == 3)
        #expect(summary.completedTaskCountToday == 1)
        #expect(summary.overdueTaskCountToday == 1)
        #expect(summary.warningCountToday == 1)
        #expect(summary.mealsPlannedThisWeek == 9)
        #expect(summary.tasksRemainingThisWeek == 3)
        #expect(summary.shoppingItemsRemainingThisWeek == 5)
        #expect(summary.scheduleWarningsThisWeek == 2)
        #expect(summary.hasUrgentIssues)
    }

    @Test("Today meals sort by meal slot position then name")
    func mealsSortBySlotPosition() {
        let dinner = meal(
            "Dinner",
            slotPosition: 3,
            recipeName: "Dal"
        )
        let breakfast = meal(
            "Breakfast",
            slotPosition: 0,
            recipeName: "Oats"
        )
        let lunch = meal(
            "Lunch",
            slotPosition: 1,
            recipeName: "Rice Bowl"
        )

        let sorted = TodayDashboardBuilder.sortedMeals([
            dinner,
            lunch,
            breakfast
        ])

        #expect(sorted.map(\.slotName) == [
            "Breakfast",
            "Lunch",
            "Dinner"
        ])
    }

    @Test("Today task duration uses human-readable app duration formatting")
    func taskDurationUsesHumanReadableFormatting() {
        let value = task(
            title: "Marinate chicken",
            start: referenceDate(hour: 8, minute: 0),
            end: referenceDate(hour: 9, minute: 14),
            activeMinutes: 5,
            passiveMinutes: 69,
            position: 0
        )

        #expect(value.durationText == "1 hr 14 min")
    }

    private func task(
        title: String,
        start: Date,
        end: Date,
        activeMinutes: Int = 10,
        passiveMinutes: Int = 0,
        isCompleted: Bool = false,
        hasConflict: Bool = false,
        warningMessage: String? = nil,
        position: Int
    ) -> TodayTaskItem {
        TodayTaskItem(
            id: UUID(),
            weekPlanEntryID: UUID(),
            recipeID: UUID(),
            recipeTaskID: nil,
            title: title,
            instructions: nil,
            scheduledStart: start,
            scheduledEnd: end,
            activeMinutes: activeMinutes,
            passiveMinutes: passiveMinutes,
            isCompleted: isCompleted,
            hasConflict: hasConflict,
            warningMessage: warningMessage,
            batchServings: 1,
            coveredWeekPlanEntryIDs: [],
            isSharedPrep: false,
            sharedPrepKey: nil,
            quantityLines: [],
            position: position
        )
    }

    private func meal(
        _ slotName: String,
        slotPosition: Int = 0,
        recipeName: String = "Recipe"
    ) -> TodayMealItem {
        TodayMealItem(
            id: UUID(),
            recipeID: UUID(),
            mealDate: "2026-07-01",
            slotName: slotName,
            slotPosition: slotPosition,
            recipeName: recipeName,
            servings: 1,
            notes: ""
        )
    }

    private func referenceDate(
        day: Int = 1,
        hour: Int,
        minute: Int
    ) -> Date {
        var components = DateComponents()
        components.calendar = Calendar(identifier: .gregorian)
        components.timeZone = TimeZone(secondsFromGMT: 0)
        components.year = 2026
        components.month = 7
        components.day = day
        components.hour = hour
        components.minute = minute
        return components.date!
    }
}
