import Foundation
import Testing
@testable import MealPlanner

struct WeeklyPlanningWorkflowTests {

    @Test("Weekly planning progresses in the correct order")
    func weeklyPlanningProgressesInCorrectOrder() {
        var progress = WeeklyPlanningProgress(
            weekStart: "2026-07-05"
        )

        #expect(progress.status == .notStarted)
        #expect(progress.nextIncompleteStep == .menuSelected)

        progress.mark(
            .menuSelected,
            timestamp: "2026-07-04T14:00:00Z"
        )

        #expect(progress.status == .menuSelected)
        #expect(progress.isComplete(.menuSelected))
        #expect(progress.nextIncompleteStep == .servingsConfirmed)

        progress.mark(
            .pantryReviewed,
            timestamp: "2026-07-04T15:00:00Z"
        )

        #expect(progress.status == .pantryReviewed)
        #expect(progress.isComplete(.menuSelected))
        #expect(progress.isComplete(.servingsConfirmed))
        #expect(progress.isComplete(.pantryReviewed))
        #expect(progress.nextIncompleteStep == .shoppingGenerated)
    }

    @Test("Marking planning complete fills prerequisite steps")
    func markingCompleteFillsPrerequisites() {
        var progress = WeeklyPlanningProgress(
            weekStart: "2026-07-05"
        )

        progress.mark(
            .complete,
            timestamp: "2026-07-04T18:30:00Z"
        )

        #expect(progress.status == .complete)
        #expect(progress.isComplete(.menuSelected))
        #expect(progress.isComplete(.servingsConfirmed))
        #expect(progress.isComplete(.pantryReviewed))
        #expect(progress.isComplete(.shoppingGenerated))
        #expect(progress.isComplete(.scheduleGenerated))
        #expect(progress.isComplete(.complete))
        #expect(progress.remainingStepCount == 0)
    }

    @Test("Saturday and Sunday show planning prompt when incomplete")
    func weekendPromptVisibility() throws {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!

        let saturday = try #require(
            ISO8601DateFormatter().date(
                from: "2026-07-04T15:00:00Z"
            )
        )
        let sunday = try #require(
            ISO8601DateFormatter().date(
                from: "2026-07-05T08:00:00Z"
            )
        )
        let monday = try #require(
            ISO8601DateFormatter().date(
                from: "2026-07-06T08:00:00Z"
            )
        )

        let incomplete = WeeklyPlanningProgress(
            weekStart: "2026-07-05"
        )

        #expect(
            WeeklyPlanningReminderPolicy.shouldShowPlanningPrompt(
                progress: incomplete,
                date: saturday,
                calendar: calendar
            )
        )

        #expect(
            WeeklyPlanningReminderPolicy.shouldShowPlanningPrompt(
                progress: incomplete,
                date: sunday,
                calendar: calendar
            )
        )

        #expect(
            !WeeklyPlanningReminderPolicy.shouldShowPlanningPrompt(
                progress: incomplete,
                date: monday,
                calendar: calendar
            )
        )
    }

    @Test("Started planning remains visible after Saturday")
    func startedPlanningRemainsVisible() throws {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!

        let monday = try #require(
            ISO8601DateFormatter().date(
                from: "2026-07-06T08:00:00Z"
            )
        )

        var progress = WeeklyPlanningProgress(
            weekStart: "2026-07-05"
        )
        progress.mark(
            .menuSelected,
            timestamp: "2026-07-04T14:00:00Z"
        )

        #expect(
            WeeklyPlanningReminderPolicy.shouldShowPlanningPrompt(
                progress: progress,
                date: monday,
                calendar: calendar
            )
        )
    }

    @Test("Completed planning hides prompt")
    func completedPlanningHidesPrompt() throws {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!

        let saturday = try #require(
            ISO8601DateFormatter().date(
                from: "2026-07-04T20:00:00Z"
            )
        )

        var progress = WeeklyPlanningProgress(
            weekStart: "2026-07-05"
        )
        progress.mark(
            .complete,
            timestamp: "2026-07-04T20:00:00Z"
        )

        #expect(
            !WeeklyPlanningReminderPolicy.shouldShowPlanningPrompt(
                progress: progress,
                date: saturday,
                calendar: calendar
            )
        )
    }

    @Test("Urgency text escalates Saturday evening and Sunday")
    func urgencyTextEscalates() throws {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!

        let saturdayAfternoon = try #require(
            ISO8601DateFormatter().date(
                from: "2026-07-04T15:00:00Z"
            )
        )
        let saturdayEvening = try #require(
            ISO8601DateFormatter().date(
                from: "2026-07-04T19:00:00Z"
            )
        )
        let sundayMorning = try #require(
            ISO8601DateFormatter().date(
                from: "2026-07-05T08:00:00Z"
            )
        )

        let progress = WeeklyPlanningProgress(
            weekStart: "2026-07-05"
        )

        #expect(
            WeeklyPlanningReminderPolicy.urgencyText(
                progress: progress,
                date: saturdayAfternoon,
                calendar: calendar
            ).contains("before Sunday")
        )

        #expect(
            WeeklyPlanningReminderPolicy.urgencyText(
                progress: progress,
                date: saturdayEvening,
                calendar: calendar
            ).contains("tonight")
        )

        #expect(
            WeeklyPlanningReminderPolicy.urgencyText(
                progress: progress,
                date: sundayMorning,
                calendar: calendar
            ).contains("now")
        )
    }
}
