import SwiftUI
import Testing
@testable import MealPlanner

struct AppAppearanceTests {

    @Test("Appearance preferences map to SwiftUI color schemes")
    func appearancePreferencesMapToColorSchemes() {
        #expect(AppAppearancePreference.system.colorScheme == nil)
        #expect(AppAppearancePreference.light.colorScheme == .light)
        #expect(AppAppearancePreference.dark.colorScheme == .dark)
    }

    @Test("Appearance preferences map to UIKit interface styles")
    func appearancePreferencesMapToUIKitStyles() {
        #expect(AppAppearancePreference.system.interfaceStyle == .unspecified)
        #expect(AppAppearancePreference.light.interfaceStyle == .light)
        #expect(AppAppearancePreference.dark.interfaceStyle == .dark)
    }

    @Test("Appearance preferences expose stable display names")
    func appearancePreferencesExposeStableDisplayNames() {
        #expect(AppAppearancePreference.system.displayName == "System")
        #expect(AppAppearancePreference.light.displayName == "Light")
        #expect(AppAppearancePreference.dark.displayName == "Dark")
    }

    @Test("Appearance storage key is stable")
    func appearanceStorageKeyIsStable() {
        #expect(AppTheme.appearanceStorageKey == "prepflow.appearancePreference")
    }
}
