import Foundation
import Testing
@testable import MealPlanner

struct MealPlannerTests {

    // MARK: - Duration formatting

    @Test("Duration formatter handles zero and negative values")
    func durationFormatterHandlesZeroAndNegativeValues() {
        #expect(AppDurationFormatter.string(minutes: 0) == "0 min")
        #expect(AppDurationFormatter.string(minutes: -10) == "0 min")
    }

    @Test("Duration formatter handles values below one hour")
    func durationFormatterHandlesMinutes() {
        #expect(AppDurationFormatter.string(minutes: 5) == "5 min")
        #expect(AppDurationFormatter.string(minutes: 45) == "45 min")
        #expect(AppDurationFormatter.string(minutes: 59) == "59 min")
    }

    @Test("Duration formatter handles whole and partial hours")
    func durationFormatterHandlesHours() {
        #expect(AppDurationFormatter.string(minutes: 60) == "1 hr")
        #expect(AppDurationFormatter.string(minutes: 74) == "1 hr 14 min")
        #expect(AppDurationFormatter.string(minutes: 90) == "1 hr 30 min")
        #expect(AppDurationFormatter.string(minutes: 120) == "2 hr")
        #expect(AppDurationFormatter.string(minutes: 125) == "2 hr 5 min")
    }

    @Test("Duration formatter handles day-length durations")
    func durationFormatterHandlesDays() {
        #expect(AppDurationFormatter.string(minutes: 1_440) == "1 day")
        #expect(AppDurationFormatter.string(minutes: 1_500) == "1 day 1 hr")
        #expect(AppDurationFormatter.string(minutes: 2_945) == "2 days 1 hr 5 min")
    }

    @Test("Optional duration formatter handles nil")
    func optionalDurationFormatterHandlesNil() {
        #expect(AppDurationFormatter.optionalString(minutes: nil) == "—")
        #expect(AppDurationFormatter.optionalString(minutes: 74) == "1 hr 14 min")
    }

    // MARK: - Draft normalization

    @Test("Recipe draft normalization trims and standardizes user input")
    func recipeDraftNormalization() {
        var draft = RecipeEditorDraft()
        draft.name = "  Chicken Bowl  "
        draft.description = "  Weeknight dinner  "
        draft.mealTypes = [" Dinner ", "LUNCH"]
        draft.defaultServings = " 2.00 "
        draft.preparationMinutes = " 010 "
        draft.freezerAllowed = false
        draft.freezerLifeDays = "30"

        var ingredient = RecipeIngredientDraft()
        ingredient.name = "  Onion "
        ingredient.quantity = " 1.00 "
        ingredient.unit = " count "
        ingredient.preparationNote = " diced "
        draft.ingredients = [ingredient]

        var step = RecipeStepDraft()
        step.instruction = "  Dice the onion. "
        step.durationMinutes = " 06 "
        step.stepType = " ACTIVE "
        draft.steps = [step]

        let normalized = draft.normalized

        #expect(normalized.name == "Chicken Bowl")
        #expect(normalized.description == "Weeknight dinner")
        #expect(normalized.mealTypes == ["dinner", "lunch"])
        #expect(normalized.defaultServings == "2")
        #expect(normalized.preparationMinutes == "10")
        #expect(normalized.freezerLifeDays.isEmpty)
        #expect(normalized.ingredients[0].name == "Onion")
        #expect(normalized.ingredients[0].quantity == "1")
        #expect(normalized.ingredients[0].unit == "count")
        #expect(normalized.ingredients[0].preparationNote == "diced")
        #expect(normalized.steps[0].instruction == "Dice the onion.")
        #expect(normalized.steps[0].durationMinutes == "6")
        #expect(normalized.steps[0].stepType == "active")
    }

    // MARK: - Ingredient scaling

    @Test("Ingredient quantities scale with servings")
    func ingredientQuantitiesScaleWithServings() {
        let ingredient = RecipeDetailIngredient(
            id: UUID(),
            ingredientID: nil,
            name: "Rice",
            quantity: 200,
            unit: "g",
            preparationNote: nil,
            isOptional: false,
            scalingBehavior: "linear",
            shoppingIncluded: true,
            preparationState: nil,
            position: 0
        )

        #expect(
            ingredient.scaledQuantity(
                selectedServings: 4,
                baseServings: 2
            ) == 400
        )
    }

    @Test("Fixed ingredients do not scale with servings")
    func fixedIngredientsDoNotScale() {
        let ingredient = RecipeDetailIngredient(
            id: UUID(),
            ingredientID: nil,
            name: "Bay leaf",
            quantity: 1,
            unit: "count",
            preparationNote: nil,
            isOptional: false,
            scalingBehavior: "fixed",
            shoppingIncluded: true,
            preparationState: nil,
            position: 0
        )

        #expect(
            ingredient.scaledQuantity(
                selectedServings: 8,
                baseServings: 2
            ) == 1
        )
    }

    @Test("Ingredient scaling safely handles a zero base serving count")
    func ingredientScalingHandlesZeroBaseServings() {
        let ingredient = RecipeDetailIngredient(
            id: UUID(),
            ingredientID: nil,
            name: "Salt",
            quantity: 2,
            unit: "tsp",
            preparationNote: nil,
            isOptional: false,
            scalingBehavior: "linear",
            shoppingIncluded: true,
            preparationState: nil,
            position: 0
        )

        #expect(
            ingredient.scaledQuantity(
                selectedServings: 4,
                baseServings: 0
            ) == 2
        )
    }

    // MARK: - Task inference

    @Test("Task inference classifies active preparation")
    func taskInferenceClassifiesPreparation() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("Dice the onion", minutes: 6)],
            ingredients: [ingredient("Onion")]
        )

        #expect(tasks.count == 1)
        #expect(tasks[0].taskType == "preparation")
        #expect(tasks[0].activeMinutes == "6")
        #expect(tasks[0].passiveMinutes == "0")
        #expect(tasks[0].canBatch)
        #expect(tasks[0].blocksActiveWork)
        #expect(tasks[0].canMakeAhead)
        #expect(tasks[0].storageMethod == "refrigerated")
    }

    @Test("Task inference separates active and passive marination time")
    func taskInferenceClassifiesMarination() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("Marinate the chicken", minutes: 74)],
            ingredients: [ingredient("Chicken")]
        )

        #expect(tasks.count == 1)
        #expect(tasks[0].taskType == "marinating")
        #expect(tasks[0].activeMinutes == "5")
        #expect(tasks[0].passiveMinutes == "69")
        #expect(tasks[0].unattended)
        #expect(!tasks[0].blocksActiveWork)
        #expect(tasks[0].canMakeAhead)
        #expect(tasks[0].storageMethod == "refrigerated")
    }

    @Test("Task inference separates active and passive baking time")
    func taskInferenceClassifiesBaking() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("Bake for 30 minutes", minutes: 30)],
            ingredients: []
        )

        #expect(tasks.count == 1)
        #expect(tasks[0].taskType == "cooking")
        #expect(tasks[0].activeMinutes == "5")
        #expect(tasks[0].passiveMinutes == "25")
        #expect(tasks[0].unattended)
        #expect(!tasks[0].blocksActiveWork)
    }

    @Test("Task inference treats overnight soaking as a prior-day task")
    func taskInferenceMovesLongSoakingToPriorDay() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("Soak the chickpeas overnight", minutes: 480)],
            ingredients: [ingredient("Chickpeas")]
        )

        #expect(tasks.count == 1)
        #expect(tasks[0].taskType == "soaking")
        #expect(tasks[0].dayOffset == "1")
        #expect(tasks[0].activeMinutes == "5")
        #expect(tasks[0].passiveMinutes == "475")
    }

    @Test("Task inference ignores empty instructions")
    func taskInferenceIgnoresEmptyInstructions() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("   ", minutes: 10)],
            ingredients: []
        )

        #expect(tasks.isEmpty)
    }

    @Test("Task inference preserves source step positions")
    func taskInferencePreservesStepPositions() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [
                step("Dice the onion", minutes: 5),
                step("Cook the rice", minutes: 20)
            ],
            ingredients: [ingredient("Onion"), ingredient("Rice")]
        )

        #expect(tasks.count == 2)
        #expect(tasks[0].sourceStepPositions == [0])
        #expect(tasks[1].sourceStepPositions == [1])
    }

    // MARK: - Recipe compliance

    @Test("Compliance engine recognizes preparation notes")
    func complianceRecognizesPreparationNotes() {
        var draft = baseRecipeDraft()
        draft.ingredients = [ingredient("Onion", note: "diced")]
        draft.steps = [step("Cook the onion until soft", minutes: 8)]

        let report = RecipeComplianceEngine.analyze(draft: draft)

        #expect(report.operations.count == 1)
        #expect(report.operations[0].canonicalIngredientName == "onion")
        #expect(report.operations[0].action == "dice")
        #expect(report.operations[0].preparationState == "diced")
        #expect(report.operations[0].canMakeAhead)
        #expect(report.operations[0].storageMethod == "refrigerated")
    }

    @Test("Compliance engine recognizes explicit preparation steps")
    func complianceRecognizesExplicitPreparationSteps() {
        var draft = baseRecipeDraft()
        draft.ingredients = [ingredient("Garlic")]
        draft.steps = [
            step("Mince the garlic", minutes: 3),
            step("Cook until fragrant", minutes: 2)
        ]

        let report = RecipeComplianceEngine.analyze(draft: draft)

        #expect(report.operations.contains { operation in
            operation.canonicalIngredientName == "garlic"
                && operation.action == "mince"
                && operation.sourceStepPositions == [0]
        })
    }

    @Test("Compliance score remains inside the valid range")
    func complianceScoreIsClamped() {
        var draft = baseRecipeDraft()
        draft.ingredients = [
            ingredient("Onion"),
            ingredient("Garlic"),
            ingredient("Ginger"),
            ingredient("Tomato"),
            ingredient("Bell pepper"),
            ingredient("Chicken")
        ]
        draft.steps = [step("Prepare all ingredients", minutes: 10)]

        let report = RecipeComplianceEngine.analyze(draft: draft)

        #expect(report.score >= 0)
        #expect(report.score <= 1)
    }

    @Test("A fully specified preparation recipe avoids blocking issues")
    func fullySpecifiedRecipeAvoidsBlockingIssues() {
        var draft = baseRecipeDraft()
        draft.ingredients = [
            ingredient("Onion", note: "diced"),
            ingredient("Garlic", note: "minced"),
            ingredient("Bell pepper", note: "sliced")
        ]
        draft.steps = [
            step("Dice the onion", minutes: 5),
            step("Mince the garlic", minutes: 3),
            step("Slice the bell pepper", minutes: 5),
            step("Cook everything until tender", minutes: 12)
        ]

        let report = RecipeComplianceEngine.analyze(draft: draft)

        #expect(!report.issues.contains { $0.severity == .blocking })
        #expect(report.operations.count == 3)
    }

    // MARK: - Helpers

    private func baseRecipeDraft() -> RecipeEditorDraft {
        var draft = RecipeEditorDraft()
        draft.name = "Test Recipe"
        draft.mealTypes = ["dinner"]
        draft.defaultServings = "2"
        return draft
    }

    private func ingredient(
        _ name: String,
        quantity: String = "1",
        unit: String = "count",
        note: String = ""
    ) -> RecipeIngredientDraft {
        var value = RecipeIngredientDraft()
        value.name = name
        value.quantity = quantity
        value.unit = unit
        value.preparationNote = note
        return value
    }

    private func step(
        _ instruction: String,
        minutes: Int,
        type: String = "active"
    ) -> RecipeStepDraft {
        var value = RecipeStepDraft()
        value.instruction = instruction
        value.durationMinutes = String(minutes)
        value.stepType = type
        return value
    }
}
