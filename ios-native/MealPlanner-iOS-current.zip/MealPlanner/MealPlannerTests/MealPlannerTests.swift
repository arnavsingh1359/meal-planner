import Foundation
import Testing
@testable import MealPlanner

struct MealPlannerTests {

    // MARK: - Duration formatting

    @Test("Duration formatter handles zero and negative values")
    func durationFormatterHandlesZeroAndNegativeValues() {
        #expect(AppDurationFormatter.string(minutes: 0) == "0 min")
        #expect(AppDurationFormatter.string(minutes: -10) == "0 min")
    }

    @Test("Duration formatter handles values below one hour")
    func durationFormatterHandlesMinutes() {
        #expect(AppDurationFormatter.string(minutes: 5) == "5 min")
        #expect(AppDurationFormatter.string(minutes: 45) == "45 min")
        #expect(AppDurationFormatter.string(minutes: 59) == "59 min")
    }

    @Test("Duration formatter handles whole and partial hours")
    func durationFormatterHandlesHours() {
        #expect(AppDurationFormatter.string(minutes: 60) == "1 hr")
        #expect(AppDurationFormatter.string(minutes: 74) == "1 hr 14 min")
        #expect(AppDurationFormatter.string(minutes: 90) == "1 hr 30 min")
        #expect(AppDurationFormatter.string(minutes: 120) == "2 hr")
        #expect(AppDurationFormatter.string(minutes: 125) == "2 hr 5 min")
    }

    @Test("Duration formatter handles day-length durations")
    func durationFormatterHandlesDays() {
        #expect(AppDurationFormatter.string(minutes: 1_440) == "1 day")
        #expect(AppDurationFormatter.string(minutes: 1_500) == "1 day 1 hr")
        #expect(AppDurationFormatter.string(minutes: 2_945) == "2 days 1 hr 5 min")
    }

    @Test("Optional duration formatter handles nil")
    func optionalDurationFormatterHandlesNil() {
        #expect(AppDurationFormatter.optionalString(minutes: nil) == "—")
        #expect(AppDurationFormatter.optionalString(minutes: 74) == "1 hr 14 min")
    }

    // MARK: - Draft normalization

    @Test("Recipe draft normalization trims and standardizes user input")
    func recipeDraftNormalization() {
        var draft = RecipeEditorDraft()
        draft.name = "  Chicken Bowl  "
        draft.description = "  Weeknight dinner  "
        draft.mealTypes = [" Dinner ", "LUNCH"]
        draft.defaultServings = " 2.00 "
        draft.preparationMinutes = " 010 "
        draft.freezerAllowed = false
        draft.freezerLifeDays = "30"

        var ingredient = RecipeIngredientDraft()
        ingredient.name = "  Onion "
        ingredient.quantity = " 1.00 "
        ingredient.unit = " count "
        ingredient.preparationNote = " diced "
        draft.ingredients = [ingredient]

        var step = RecipeStepDraft()
        step.instruction = "  Dice the onion. "
        step.durationMinutes = " 06 "
        step.stepType = " ACTIVE "
        draft.steps = [step]

        let normalized = draft.normalized

        #expect(normalized.name == "Chicken Bowl")
        #expect(normalized.description == "Weeknight dinner")
        #expect(normalized.mealTypes == ["dinner", "lunch"])
        #expect(normalized.defaultServings == "2")
        #expect(normalized.preparationMinutes == "10")
        #expect(normalized.freezerLifeDays.isEmpty)
        #expect(normalized.ingredients[0].name == "Onion")
        #expect(normalized.ingredients[0].quantity == "1")
        #expect(normalized.ingredients[0].unit == "count")
        #expect(normalized.ingredients[0].preparationNote == "diced")
        #expect(normalized.steps[0].instruction == "Dice the onion.")
        #expect(normalized.steps[0].durationMinutes == "6")
        #expect(normalized.steps[0].stepType == "active")
    }

    // MARK: - Ingredient scaling

    @Test("Ingredient quantities scale with servings")
    func ingredientQuantitiesScaleWithServings() {
        let ingredient = RecipeDetailIngredient(
            id: UUID(),
            ingredientID: nil,
            name: "Rice",
            quantity: 200,
            unit: "g",
            preparationNote: nil,
            isOptional: false,
            scalingBehavior: "linear",
            shoppingIncluded: true,
            preparationState: nil,
            position: 0
        )

        #expect(
            ingredient.scaledQuantity(
                selectedServings: 4,
                baseServings: 2
            ) == 400
        )
    }

    @Test("Fixed ingredients do not scale with servings")
    func fixedIngredientsDoNotScale() {
        let ingredient = RecipeDetailIngredient(
            id: UUID(),
            ingredientID: nil,
            name: "Bay leaf",
            quantity: 1,
            unit: "count",
            preparationNote: nil,
            isOptional: false,
            scalingBehavior: "fixed",
            shoppingIncluded: true,
            preparationState: nil,
            position: 0
        )

        #expect(
            ingredient.scaledQuantity(
                selectedServings: 8,
                baseServings: 2
            ) == 1
        )
    }

    @Test("Ingredient scaling safely handles a zero base serving count")
    func ingredientScalingHandlesZeroBaseServings() {
        let ingredient = RecipeDetailIngredient(
            id: UUID(),
            ingredientID: nil,
            name: "Salt",
            quantity: 2,
            unit: "tsp",
            preparationNote: nil,
            isOptional: false,
            scalingBehavior: "linear",
            shoppingIncluded: true,
            preparationState: nil,
            position: 0
        )

        #expect(
            ingredient.scaledQuantity(
                selectedServings: 4,
                baseServings: 0
            ) == 2
        )
    }

    // MARK: - Task inference

    @Test("Task inference classifies active preparation")
    func taskInferenceClassifiesPreparation() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("Dice the onion", minutes: 6)],
            ingredients: [ingredient("Onion")]
        )

        #expect(tasks.count == 1)
        #expect(tasks[0].taskType == "preparation")
        #expect(tasks[0].activeMinutes == "6")
        #expect(tasks[0].passiveMinutes == "0")
        #expect(tasks[0].canBatch)
        #expect(tasks[0].blocksActiveWork)
        #expect(tasks[0].canMakeAhead)
        #expect(tasks[0].storageMethod == "refrigerated")
    }

    @Test("Task inference separates active and passive marination time")
    func taskInferenceClassifiesMarination() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("Marinate the chicken", minutes: 74)],
            ingredients: [ingredient("Chicken")]
        )

        #expect(tasks.count == 1)
        #expect(tasks[0].taskType == "marinating")
        #expect(tasks[0].activeMinutes == "5")
        #expect(tasks[0].passiveMinutes == "69")
        #expect(tasks[0].unattended)
        #expect(!tasks[0].blocksActiveWork)
        #expect(tasks[0].canMakeAhead)
        #expect(tasks[0].storageMethod == "refrigerated")
    }

    @Test("Task inference separates active and passive baking time")
    func taskInferenceClassifiesBaking() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("Bake for 30 minutes", minutes: 30)],
            ingredients: []
        )

        #expect(tasks.count == 1)
        #expect(tasks[0].taskType == "cooking")
        #expect(tasks[0].activeMinutes == "5")
        #expect(tasks[0].passiveMinutes == "25")
        #expect(tasks[0].unattended)
        #expect(!tasks[0].blocksActiveWork)
    }

    @Test("Task inference treats overnight soaking as a prior-day task")
    func taskInferenceMovesLongSoakingToPriorDay() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("Soak the chickpeas overnight", minutes: 480)],
            ingredients: [ingredient("Chickpeas")]
        )

        #expect(tasks.count == 1)
        #expect(tasks[0].taskType == "soaking")
        #expect(tasks[0].dayOffset == "1")
        #expect(tasks[0].activeMinutes == "5")
        #expect(tasks[0].passiveMinutes == "475")
    }

    @Test("Task inference ignores empty instructions")
    func taskInferenceIgnoresEmptyInstructions() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [step("   ", minutes: 10)],
            ingredients: []
        )

        #expect(tasks.isEmpty)
    }

    @Test("Task inference preserves source step positions")
    func taskInferencePreservesStepPositions() {
        let tasks = RecipeTaskInferenceEngine.inferTasks(
            from: [
                step("Dice the onion", minutes: 5),
                step("Cook the rice", minutes: 20)
            ],
            ingredients: [ingredient("Onion"), ingredient("Rice")]
        )

        #expect(tasks.count == 2)
        #expect(tasks[0].sourceStepPositions == [0])
        #expect(tasks[1].sourceStepPositions == [1])
    }

    // MARK: - Recipe compliance

    @Test("Compliance engine recognizes preparation notes")
    func complianceRecognizesPreparationNotes() {
        var draft = baseRecipeDraft()
        draft.ingredients = [ingredient("Onion", note: "diced")]
        draft.steps = [step("Cook the onion until soft", minutes: 8)]

        let report = RecipeComplianceEngine.analyze(draft: draft)

        #expect(report.operations.count == 1)
        #expect(report.operations[0].canonicalIngredientName == "onion")
        #expect(report.operations[0].action == "dice")
        #expect(report.operations[0].preparationState == "diced")
        #expect(report.operations[0].canMakeAhead)
        #expect(report.operations[0].storageMethod == "refrigerated")
    }

    @Test("Compliance engine recognizes explicit preparation steps")
    func complianceRecognizesExplicitPreparationSteps() {
        var draft = baseRecipeDraft()
        draft.ingredients = [ingredient("Garlic")]
        draft.steps = [
            step("Mince the garlic", minutes: 3),
            step("Cook until fragrant", minutes: 2)
        ]

        let report = RecipeComplianceEngine.analyze(draft: draft)

        #expect(report.operations.contains { operation in
            operation.canonicalIngredientName == "garlic"
                && operation.action == "mince"
                && operation.sourceStepPositions == [0]
        })
    }

    @Test("Compliance score remains inside the valid range")
    func complianceScoreIsClamped() {
        var draft = baseRecipeDraft()
        draft.ingredients = [
            ingredient("Onion"),
            ingredient("Garlic"),
            ingredient("Ginger"),
            ingredient("Tomato"),
            ingredient("Bell pepper"),
            ingredient("Chicken")
        ]
        draft.steps = [step("Prepare all ingredients", minutes: 10)]

        let report = RecipeComplianceEngine.analyze(draft: draft)

        #expect(report.score >= 0)
        #expect(report.score <= 1)
    }

    @Test("A fully specified preparation recipe avoids blocking issues")
    func fullySpecifiedRecipeAvoidsBlockingIssues() {
        var draft = baseRecipeDraft()
        draft.ingredients = [
            ingredient("Onion", note: "diced"),
            ingredient("Garlic", note: "minced"),
            ingredient("Bell pepper", note: "sliced")
        ]
        draft.steps = [
            step("Dice the onion", minutes: 5),
            step("Mince the garlic", minutes: 3),
            step("Slice the bell pepper", minutes: 5),
            step("Cook everything until tender", minutes: 12)
        ]

        let report = RecipeComplianceEngine.analyze(draft: draft)

        #expect(!report.issues.contains { $0.severity == .blocking })
        #expect(report.operations.count == 3)
    }


    // MARK: - Scheduler placement

    @Test("Scheduler preserves task dependency order before ready-by time")
    func schedulerPreservesDependencyOrder() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 15,
                    startBeforeMealMinutes: 45
                ),
                schedulerTemplate(
                    position: 1,
                    activeMinutes: 30,
                    startBeforeMealMinutes: 30
                )
            ],
            windows: [standardWindow(dayNumber: 1)],
            existingPlacements: [],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 2)
        #expect(placements[0].end <= placements[1].start)
        #expect(placements[1].end <= readyAt)
        #expect(placements.allSatisfy { $0.warningMessage == nil })
    }

    @Test("Scheduler allows unattended passive time to overlap active work")
    func schedulerAllowsPassiveOverlap() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let existing = SchedulerExistingPlacement(
            start: testDate(
                2026,
                7,
                6,
                17,
                0,
                calendar: calendar
            ),
            end: testDate(
                2026,
                7,
                6,
                17,
                45,
                calendar: calendar
            ),
            blocksActiveWork: true
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 5,
                    passiveMinutes: 55,
                    startBeforeMealMinutes: 60,
                    blocksActiveWork: false
                )
            ],
            windows: [standardWindow(dayNumber: 1)],
            existingPlacements: [existing],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(!placements[0].hasConflict)
    }

    @Test("Scheduler ignores active overlaps inside the configured grouping tolerance")
    func schedulerIgnoresSmallActiveOverlapInsideTolerance() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let existing = SchedulerExistingPlacement(
            start: testDate(
                2026,
                7,
                6,
                17,
                0,
                calendar: calendar
            ),
            end: testDate(
                2026,
                7,
                6,
                17,
                45,
                calendar: calendar
            ),
            blocksActiveWork: true
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 45,
                    startBeforeMealMinutes: 60
                )
            ],
            windows: [standardWindow(dayNumber: 1)],
            existingPlacements: [existing],
            conflictGroupingMinutes: 60,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(!placements[0].hasConflict)
    }

    @Test("Scheduler flags active overlaps above the configured grouping tolerance")
    func schedulerFlagsLargeActiveOverlap() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let existing = SchedulerExistingPlacement(
            start: testDate(
                2026,
                7,
                6,
                16,
                30,
                calendar: calendar
            ),
            end: testDate(
                2026,
                7,
                6,
                17,
                45,
                calendar: calendar
            ),
            blocksActiveWork: true
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 75,
                    startBeforeMealMinutes: 90
                )
            ],
            windows: [standardWindow(dayNumber: 1)],
            existingPlacements: [existing],
            conflictGroupingMinutes: 30,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(placements[0].hasConflict)
    }

    @Test("Scheduler places tasks inside configured task windows when possible")
    func schedulerPlacesInsideWindow() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 60,
                    startBeforeMealMinutes: 60
                )
            ],
            windows: [
                standardWindow(
                    dayNumber: 1,
                    earliest: "16:00",
                    latest: "18:00"
                )
            ],
            existingPlacements: [],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(
            placements[0].start
                == testDate(
                    2026,
                    7,
                    6,
                    17,
                    0,
                    calendar: calendar
                )
        )
        #expect(placements[0].warningMessage == nil)
    }

    @Test("Scheduler reports impossible task windows explicitly")
    func schedulerReportsImpossibleWindow() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 90,
                    startBeforeMealMinutes: 90
                )
            ],
            windows: [
                standardWindow(
                    dayNumber: 1,
                    earliest: "17:00",
                    latest: "18:00"
                )
            ],
            existingPlacements: [],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(
            placements[0].warningMessage
                == "Cannot fit within configured task window."
        )
    }

    @Test("Scheduler reports disabled cooking days")
    func schedulerReportsDisabledCookingDay() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 30,
                    startBeforeMealMinutes: 45
                )
            ],
            windows: [
                standardWindow(
                    dayNumber: 1,
                    cookingAllowed: false
                )
            ],
            existingPlacements: [],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(
            placements[0].warningMessage
                == "Cooking is disabled for this day."
        )
    }

    @Test("Batch planner combines repeat meals inside storage and serving limits")
    func batchPlannerCombinesRepeatMeals() {
        let calendar = testCalendar()
        let recipeID = UUID()
        let slotID = UUID()
        let userID = UUID()

        let firstEntry = weekEntry(
            userID: userID,
            mealSlotID: slotID,
            recipeID: recipeID,
            mealDate: "2026-07-07",
            servings: 2
        )

        let secondEntry = weekEntry(
            userID: userID,
            mealSlotID: slotID,
            recipeID: recipeID,
            mealDate: "2026-07-09",
            servings: 2
        )

        let policy = BatchRecipePolicy(
            recipeID: recipeID,
            recipeName: "Dal",
            baseServings: 2,
            minimumBatchServings: 3,
            maximumBatchServings: 6,
            refrigeratorLifeDays: 4,
            allowsBatching: true
        )

        let batches = BatchPlanningEngine.makeBatches(
            demands: [
                BatchMealDemand(
                    id: firstEntry.id,
                    entry: firstEntry,
                    mealDate: testDate(
                        2026,
                        7,
                        7,
                        18,
                        0,
                        calendar: calendar
                    )
                ),
                BatchMealDemand(
                    id: secondEntry.id,
                    entry: secondEntry,
                    mealDate: testDate(
                        2026,
                        7,
                        9,
                        18,
                        0,
                        calendar: calendar
                    )
                )
            ],
            policies: [recipeID: policy],
            calendar: calendar
        )

        #expect(batches.count == 1)
        #expect(batches[0].isCombinedBatch)
        #expect(batches[0].coveredMealCount == 2)
        #expect(batches[0].totalServings == 4)
    }


    @Test("Scheduler keeps a three-task chain ordered and ready on time")
    func schedulerKeepsThreeTaskChainOrdered() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            19,
            0,
            calendar: calendar
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 10,
                    startBeforeMealMinutes: 60
                ),
                schedulerTemplate(
                    position: 1,
                    activeMinutes: 20,
                    startBeforeMealMinutes: 45
                ),
                schedulerTemplate(
                    position: 2,
                    activeMinutes: 15,
                    startBeforeMealMinutes: 20
                )
            ],
            windows: [standardWindow(dayNumber: 1)],
            existingPlacements: [],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 3)
        #expect(placements[0].end <= placements[1].start)
        #expect(placements[1].end <= placements[2].start)
        #expect(placements[2].end <= readyAt)
        #expect(placements.allSatisfy { !$0.hasConflict })
        #expect(placements.allSatisfy { $0.warningMessage == nil })
    }

    @Test("Scheduler places day-offset tasks on the previous day")
    func schedulerPlacesDayOffsetTasksOnPreviousDay() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            7,
            12,
            0,
            calendar: calendar
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 5,
                    passiveMinutes: 475,
                    dayOffset: 1,
                    startBeforeMealMinutes: 480,
                    blocksActiveWork: false
                )
            ],
            windows: [standardWindow(dayNumber: 1)],
            existingPlacements: [],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(
            calendar.component(.day, from: placements[0].start)
                == 6
        )
        #expect(placements[0].activeMinutes == 5)
        #expect(placements[0].passiveMinutes == 475)
    }

    @Test("Scheduler refuses absurd early starts when a window exists")
    func schedulerAvoidsAbsurdEarlyStarts() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            8,
            0,
            calendar: calendar
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 180,
                    startBeforeMealMinutes: 180
                )
            ],
            windows: [
                standardWindow(
                    dayNumber: 1,
                    earliest: "06:00",
                    latest: "22:00"
                )
            ],
            existingPlacements: [],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(
            calendar.component(.hour, from: placements[0].start)
                >= 6
        )
        #expect(
            placements[0].warningMessage
                == "Cannot fit within configured task window."
        )
    }

    @Test("Scheduler flags tasks that exceed the active cooking limit")
    func schedulerFlagsActiveCookingLimit() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 121,
                    startBeforeMealMinutes: 150
                )
            ],
            windows: [
                standardWindow(
                    dayNumber: 1,
                    maxActiveCookingMinutes: 120
                )
            ],
            existingPlacements: [],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(
            placements[0].warningMessage
                == "Exceeds the active-cooking limit."
        )
    }

    @Test("Scheduler does not conflict with existing passive tasks")
    func schedulerIgnoresExistingPassiveTasksForConflict() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let existing = SchedulerExistingPlacement(
            start: testDate(
                2026,
                7,
                6,
                16,
                30,
                calendar: calendar
            ),
            end: testDate(
                2026,
                7,
                6,
                17,
                45,
                calendar: calendar
            ),
            blocksActiveWork: false
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 75,
                    startBeforeMealMinutes: 90
                )
            ],
            windows: [standardWindow(dayNumber: 1)],
            existingPlacements: [existing],
            conflictGroupingMinutes: 0,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(!placements[0].hasConflict)
    }

    @Test("Scheduler treats overlap equal to tolerance as acceptable")
    func schedulerAcceptsOverlapEqualToTolerance() {
        let calendar = testCalendar()
        let readyAt = testDate(
            2026,
            7,
            6,
            18,
            0,
            calendar: calendar
        )

        let existing = SchedulerExistingPlacement(
            start: testDate(
                2026,
                7,
                6,
                17,
                0,
                calendar: calendar
            ),
            end: testDate(
                2026,
                7,
                6,
                17,
                30,
                calendar: calendar
            ),
            blocksActiveWork: true
        )

        let placements = SchedulerPlacementEngine.makePlacements(
            mealReadyAt: readyAt,
            templates: [
                schedulerTemplate(
                    position: 0,
                    activeMinutes: 60,
                    startBeforeMealMinutes: 60
                )
            ],
            windows: [standardWindow(dayNumber: 1)],
            existingPlacements: [existing],
            conflictGroupingMinutes: 30,
            calendar: calendar
        )

        #expect(placements.count == 1)
        #expect(!placements[0].hasConflict)
    }

    @Test("Batch planner keeps meals separate outside refrigerator life")
    func batchPlannerSeparatesMealsOutsideStorageWindow() {
        let calendar = testCalendar()
        let recipeID = UUID()
        let slotID = UUID()
        let userID = UUID()

        let policy = BatchRecipePolicy(
            recipeID: recipeID,
            recipeName: "Dal",
            baseServings: 2,
            minimumBatchServings: 3,
            maximumBatchServings: 8,
            refrigeratorLifeDays: 2,
            allowsBatching: true
        )

        let batches = BatchPlanningEngine.makeBatches(
            demands: [
                demand(
                    userID: userID,
                    mealSlotID: slotID,
                    recipeID: recipeID,
                    mealDate: "2026-07-07",
                    servings: 2,
                    calendar: calendar
                ),
                demand(
                    userID: userID,
                    mealSlotID: slotID,
                    recipeID: recipeID,
                    mealDate: "2026-07-11",
                    servings: 2,
                    calendar: calendar
                )
            ],
            policies: [recipeID: policy],
            calendar: calendar
        )

        #expect(batches.count == 2)
        #expect(batches.allSatisfy { !$0.isCombinedBatch })
    }

    @Test("Batch planner does not exceed maximum batch servings")
    func batchPlannerRespectsMaximumServings() {
        let calendar = testCalendar()
        let recipeID = UUID()
        let slotID = UUID()
        let userID = UUID()

        let policy = BatchRecipePolicy(
            recipeID: recipeID,
            recipeName: "Dal",
            baseServings: 2,
            minimumBatchServings: 3,
            maximumBatchServings: 5,
            refrigeratorLifeDays: 4,
            allowsBatching: true
        )

        let batches = BatchPlanningEngine.makeBatches(
            demands: [
                demand(
                    userID: userID,
                    mealSlotID: slotID,
                    recipeID: recipeID,
                    mealDate: "2026-07-07",
                    servings: 3,
                    calendar: calendar
                ),
                demand(
                    userID: userID,
                    mealSlotID: slotID,
                    recipeID: recipeID,
                    mealDate: "2026-07-08",
                    servings: 3,
                    calendar: calendar
                )
            ],
            policies: [recipeID: policy],
            calendar: calendar
        )

        #expect(batches.count == 2)
        #expect(batches.allSatisfy { $0.totalServings <= 5 })
    }

    @Test("Batch planner respects recipes that disallow batching")
    func batchPlannerRespectsBatchingDisabled() {
        let calendar = testCalendar()
        let recipeID = UUID()
        let slotID = UUID()
        let userID = UUID()

        let policy = BatchRecipePolicy(
            recipeID: recipeID,
            recipeName: "Fresh Sandwich",
            baseServings: 1,
            minimumBatchServings: 2,
            maximumBatchServings: 6,
            refrigeratorLifeDays: 3,
            allowsBatching: false
        )

        let batches = BatchPlanningEngine.makeBatches(
            demands: [
                demand(
                    userID: userID,
                    mealSlotID: slotID,
                    recipeID: recipeID,
                    mealDate: "2026-07-07",
                    servings: 1,
                    calendar: calendar
                ),
                demand(
                    userID: userID,
                    mealSlotID: slotID,
                    recipeID: recipeID,
                    mealDate: "2026-07-08",
                    servings: 1,
                    calendar: calendar
                )
            ],
            policies: [recipeID: policy],
            calendar: calendar
        )

        #expect(batches.count == 2)
        #expect(batches.allSatisfy { !$0.isCombinedBatch })
    }

    @Test("Shared prep planner combines compatible make-ahead operations")
    func sharedPrepPlannerCombinesCompatibleOperations() {
        let calendar = testCalendar()
        let recipeA = UUID()
        let recipeB = UUID()
        let userID = UUID()
        let slotID = UUID()

        let batchA = productionBatch(
            recipeID: recipeA,
            recipeName: "Paneer Curry",
            userID: userID,
            mealSlotID: slotID,
            mealDate: "2026-07-08",
            servings: 2,
            calendar: calendar
        )

        let batchB = productionBatch(
            recipeID: recipeB,
            recipeName: "Veg Bowl",
            userID: userID,
            mealSlotID: slotID,
            mealDate: "2026-07-08",
            servings: 2,
            calendar: calendar
        )

        let groups = SharedPrepPlanningEngine.makeGroups(
            candidates: [
                sharedCandidate(
                    batch: batchA,
                    recipeName: "Paneer Curry",
                    operation: prepOperation(
                        recipeID: recipeA,
                        ingredient: "onion",
                        action: "dice",
                        state: "diced",
                        batchKey: "onion:dice",
                        quantity: 1,
                        unit: "count"
                    ),
                    matchedTask: scheduleRecipeTask(
                        recipeID: recipeA,
                        title: "Dice onion",
                        activeMinutes: 5
                    )
                ),
                sharedCandidate(
                    batch: batchB,
                    recipeName: "Veg Bowl",
                    operation: prepOperation(
                        recipeID: recipeB,
                        ingredient: "onion",
                        action: "dice",
                        state: "diced",
                        batchKey: "onion:dice",
                        quantity: 1,
                        unit: "count"
                    ),
                    matchedTask: scheduleRecipeTask(
                        recipeID: recipeB,
                        title: "Dice onion",
                        activeMinutes: 5
                    )
                )
            ],
            preferredBatchDays: ["Tuesday"],
            weekDates: weekDatesStartingJuly6(calendar: calendar),
            calendar: calendar
        )

        #expect(groups.count == 1)
        #expect(groups[0].title == "Shared prep: Dice onion")
        #expect(groups[0].totalQuantity == 2)
        #expect(groups[0].activeMinutes == 8)
        #expect(groups[0].coveredEntryIDs.count == 2)
        #expect(groups[0].recipeNames == ["Paneer Curry", "Veg Bowl"])
    }

    @Test("Shared prep planner rejects same-recipe duplicates")
    func sharedPrepPlannerRejectsSameRecipeDuplicates() {
        let calendar = testCalendar()
        let recipeID = UUID()
        let userID = UUID()
        let slotID = UUID()

        let batchA = productionBatch(
            recipeID: recipeID,
            recipeName: "Dal",
            userID: userID,
            mealSlotID: slotID,
            mealDate: "2026-07-08",
            servings: 2,
            calendar: calendar
        )

        let batchB = productionBatch(
            recipeID: recipeID,
            recipeName: "Dal",
            userID: userID,
            mealSlotID: slotID,
            mealDate: "2026-07-09",
            servings: 2,
            calendar: calendar
        )

        let groups = SharedPrepPlanningEngine.makeGroups(
            candidates: [
                sharedCandidate(
                    batch: batchA,
                    recipeName: "Dal",
                    operation: prepOperation(
                        recipeID: recipeID,
                        ingredient: "onion",
                        action: "dice",
                        state: "diced",
                        batchKey: "onion:dice",
                        quantity: 1,
                        unit: "count"
                    ),
                    matchedTask: nil
                ),
                sharedCandidate(
                    batch: batchB,
                    recipeName: "Dal",
                    operation: prepOperation(
                        recipeID: recipeID,
                        ingredient: "onion",
                        action: "dice",
                        state: "diced",
                        batchKey: "onion:dice",
                        quantity: 1,
                        unit: "count"
                    ),
                    matchedTask: nil
                )
            ],
            preferredBatchDays: ["Tuesday"],
            weekDates: weekDatesStartingJuly6(calendar: calendar),
            calendar: calendar
        )

        #expect(groups.isEmpty)
    }

    @Test("Shared prep planner rejects low-confidence operations")
    func sharedPrepPlannerRejectsLowConfidenceOperations() {
        let calendar = testCalendar()
        let recipeA = UUID()
        let recipeB = UUID()
        let userID = UUID()
        let slotID = UUID()

        let groups = SharedPrepPlanningEngine.makeGroups(
            candidates: [
                sharedCandidate(
                    batch: productionBatch(
                        recipeID: recipeA,
                        recipeName: "A",
                        userID: userID,
                        mealSlotID: slotID,
                        mealDate: "2026-07-08",
                        servings: 2,
                        calendar: calendar
                    ),
                    recipeName: "A",
                    operation: prepOperation(
                        recipeID: recipeA,
                        ingredient: "onion",
                        action: "dice",
                        state: "diced",
                        batchKey: "onion:dice",
                        quantity: 1,
                        unit: "count",
                        confidence: 0.5
                    ),
                    matchedTask: nil
                ),
                sharedCandidate(
                    batch: productionBatch(
                        recipeID: recipeB,
                        recipeName: "B",
                        userID: userID,
                        mealSlotID: slotID,
                        mealDate: "2026-07-08",
                        servings: 2,
                        calendar: calendar
                    ),
                    recipeName: "B",
                    operation: prepOperation(
                        recipeID: recipeB,
                        ingredient: "onion",
                        action: "dice",
                        state: "diced",
                        batchKey: "onion:dice",
                        quantity: 1,
                        unit: "count",
                        confidence: 0.5
                    ),
                    matchedTask: nil
                )
            ],
            preferredBatchDays: ["Tuesday"],
            weekDates: weekDatesStartingJuly6(calendar: calendar),
            calendar: calendar
        )

        #expect(groups.isEmpty)
    }

    // MARK: - Helpers

    private func testCalendar() -> Calendar {
        var calendar = Calendar(
            identifier: .gregorian
        )
        calendar.timeZone = TimeZone(
            secondsFromGMT: 0
        )!
        return calendar
    }

    private func testDate(
        _ year: Int,
        _ month: Int,
        _ day: Int,
        _ hour: Int,
        _ minute: Int,
        calendar: Calendar
    ) -> Date {
        var components = DateComponents()
        components.calendar = calendar
        components.timeZone = calendar.timeZone
        components.year = year
        components.month = month
        components.day = day
        components.hour = hour
        components.minute = minute
        return components.date!
    }

    private func schedulerTemplate(
        id: UUID = UUID(),
        position: Int,
        activeMinutes: Int,
        passiveMinutes: Int = 0,
        dayOffset: Int = 0,
        startBeforeMealMinutes: Int,
        blocksActiveWork: Bool = true
    ) -> SchedulerTaskTemplate {
        SchedulerTaskTemplate(
            id: id,
            position: position,
            activeMinutes: activeMinutes,
            passiveMinutes: passiveMinutes,
            dayOffset: dayOffset,
            startBeforeMealMinutes:
                startBeforeMealMinutes,
            blocksActiveWork:
                blocksActiveWork
        )
    }

    private func standardWindow(
        dayNumber: Int,
        earliest: String = "06:00",
        latest: String = "22:00",
        maxActiveCookingMinutes: Int = 180,
        cookingAllowed: Bool = true
    ) -> SchedulerDayWindow {
        SchedulerDayWindow(
            dayNumber: dayNumber,
            earliestTaskTime: earliest,
            latestTaskTime: latest,
            maxActiveCookingMinutes:
                maxActiveCookingMinutes,
            cookingAllowed:
                cookingAllowed
        )
    }


    private func demand(
        userID: UUID,
        mealSlotID: UUID,
        recipeID: UUID,
        mealDate: String,
        servings: Double,
        position: Int = 0,
        calendar: Calendar
    ) -> BatchMealDemand {
        let entry = weekEntry(
            userID: userID,
            mealSlotID: mealSlotID,
            recipeID: recipeID,
            mealDate: mealDate,
            servings: servings,
            position: position
        )

        return BatchMealDemand(
            id: entry.id,
            entry: entry,
            mealDate: dateFromString(
                mealDate,
                hour: 18,
                calendar: calendar
            )
        )
    }

    private func productionBatch(
        recipeID: UUID,
        recipeName: String,
        userID: UUID,
        mealSlotID: UUID,
        mealDate: String,
        servings: Double,
        calendar: Calendar
    ) -> RecipeProductionBatch {
        let mealDemand = demand(
            userID: userID,
            mealSlotID: mealSlotID,
            recipeID: recipeID,
            mealDate: mealDate,
            servings: servings,
            calendar: calendar
        )

        return RecipeProductionBatch(
            id: UUID(),
            recipeID: recipeID,
            recipeName: recipeName,
            demands: [mealDemand],
            totalServings: servings,
            preparationDate: mealDemand.mealDate,
            isCombinedBatch: false,
            explanation: "Test batch"
        )
    }

    private func sharedCandidate(
        batch: RecipeProductionBatch,
        recipeName: String,
        operation: ScheduleRecipePrepOperation,
        matchedTask: ScheduleRecipeTask?
    ) -> SharedPrepOperationCandidate {
        SharedPrepOperationCandidate(
            id: UUID().uuidString,
            batch: batch,
            operation: operation,
            recipeName: recipeName,
            recipeBaseServings: 2,
            matchedTask: matchedTask
        )
    }

    private func prepOperation(
        recipeID: UUID,
        ingredient: String,
        action: String,
        state: String,
        batchKey: String,
        quantity: Double,
        unit: String,
        canMakeAhead: Bool = true,
        maxHours: Int = 72,
        confidence: Double = 0.95
    ) -> ScheduleRecipePrepOperation {
        ScheduleRecipePrepOperation(
            id: UUID(),
            recipeID: recipeID,
            ingredientPosition: 0,
            sourceStepPositions: [0],
            canonicalIngredientName: ingredient,
            displayIngredientName: ingredient.capitalized,
            action: action,
            preparationState: state,
            quantity: quantity,
            unit: unit,
            canMakeAhead: canMakeAhead,
            maximumMakeAheadHours: maxHours,
            storageMethod: "refrigerated",
            batchKey: batchKey,
            confidence: confidence,
            manuallyEdited: false,
            analysisVersion: "test",
            position: 0
        )
    }

    private func scheduleRecipeTask(
        recipeID: UUID,
        title: String,
        activeMinutes: Int,
        passiveMinutes: Int = 0
    ) -> ScheduleRecipeTask {
        ScheduleRecipeTask(
            id: UUID(),
            recipeID: recipeID,
            title: title,
            instructions: title,
            taskType: "preparation",
            activeMinutes: activeMinutes,
            passiveMinutes: passiveMinutes,
            dayOffset: 0,
            startBeforeMealMinutes: 60,
            canBatch: true,
            batchKey: nil,
            canMakeAhead: true,
            maximumMakeAheadHours: 72,
            storageMethod: "refrigerated",
            unattended: false,
            blocksActiveWork: true,
            position: 0
        )
    }

    private func weekDatesStartingJuly6(
        calendar: Calendar
    ) -> [Date] {
        (0..<7).map { offset in
            calendar.date(
                byAdding: .day,
                value: offset,
                to: testDate(
                    2026,
                    7,
                    6,
                    0,
                    0,
                    calendar: calendar
                )
            )!
        }
    }

    private func dateFromString(
        _ value: String,
        hour: Int,
        calendar: Calendar
    ) -> Date {
        let parts = value.split(separator: "-").compactMap {
            Int($0)
        }

        return testDate(
            parts[0],
            parts[1],
            parts[2],
            hour,
            0,
            calendar: calendar
        )
    }

    private func weekEntry(
        userID: UUID,
        mealSlotID: UUID,
        recipeID: UUID,
        mealDate: String,
        servings: Double,
        position: Int = 0
    ) -> WeekPlanEntry {
        WeekPlanEntry(
            id: UUID(),
            userID: userID,
            weekStart: "2026-07-06",
            mealDate: mealDate,
            mealSlotID: mealSlotID,
            recipeID: recipeID,
            servings: servings,
            notes: "",
            position: position
        )
    }

    private func baseRecipeDraft() -> RecipeEditorDraft {
        var draft = RecipeEditorDraft()
        draft.name = "Test Recipe"
        draft.mealTypes = ["dinner"]
        draft.defaultServings = "2"
        return draft
    }

    private func ingredient(
        _ name: String,
        quantity: String = "1",
        unit: String = "count",
        note: String = ""
    ) -> RecipeIngredientDraft {
        var value = RecipeIngredientDraft()
        value.name = name
        value.quantity = quantity
        value.unit = unit
        value.preparationNote = note
        return value
    }

    private func step(
        _ instruction: String,
        minutes: Int,
        type: String = "active"
    ) -> RecipeStepDraft {
        var value = RecipeStepDraft()
        value.instruction = instruction
        value.durationMinutes = String(minutes)
        value.stepType = type
        return value
    }
}
