//
//  MealPlannerTests.swift
//  MealPlannerTests
//
//  Created by Arnav Singh on 6/22/26.
//

import Testing
@testable import MealPlanner

struct MealPlannerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
