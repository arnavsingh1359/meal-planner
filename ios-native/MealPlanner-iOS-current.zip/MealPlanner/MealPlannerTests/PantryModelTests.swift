import Foundation
import Testing
@testable import MealPlanner

struct PantryModelTests {
    @Test("Exact pantry item displays quantity and unit")
    func exactPantryItemDisplaysQuantityAndUnit() {
        let item = PantryStockItem(
            id: UUID(),
            userID: nil,
            trackingMode: "exact",
            name: "Rice",
            quantity: 1.5,
            unit: "kg",
            stockStatus: "enough"
        )

        #expect(item.normalizedTrackingMode == .exact)
        #expect(item.normalizedStockStatus == .enough)
        #expect(item.quantityText == "1.5 kg")
        #expect(item.canSubtractFromShopping)
    }

    @Test("Approximate pantry item displays stock status")
    func approximatePantryItemDisplaysStockStatus() {
        let item = PantryStockItem(
            id: UUID(),
            userID: nil,
            trackingMode: "approximate",
            name: "Salt",
            quantity: 0,
            unit: "",
            stockStatus: "plenty"
        )

        #expect(item.normalizedTrackingMode == .approximate)
        #expect(item.quantityText == "Plenty")
        #expect(item.canSubtractFromShopping)
    }

    @Test("Low and out pantry statuses do not subtract from shopping")
    func lowAndOutStatusesDoNotSubtractFromShopping() {
        let low = PantryStockItem(
            id: UUID(),
            userID: nil,
            trackingMode: "approximate",
            name: "Onion",
            stockStatus: "low"
        )

        let out = PantryStockItem(
            id: UUID(),
            userID: nil,
            trackingMode: "exact",
            name: "Milk",
            quantity: 1,
            unit: "L",
            stockStatus: "out"
        )

        #expect(!low.canSubtractFromShopping)
        #expect(!out.canSubtractFromShopping)
    }

    @Test("Pantry database row joins ingredient catalogue data")
    func pantryDatabaseRowJoinsIngredientCatalogueData() {
        let ingredientID = UUID()
        let row = PantryItemDatabaseRow(
            id: UUID(),
            userID: UUID(),
            ingredientID: ingredientID,
            trackingMode: "exact",
            quantity: 500,
            unit: "g",
            stockStatus: "enough",
            expiryDate: "2026-07-10",
            notes: "Use soon",
            updatedAt: nil
        )

        let ingredient = PantryIngredientDatabaseRow(
            id: ingredientID,
            userID: UUID(),
            name: "Paneer",
            category: "Dairy",
            defaultUnit: "g",
            approximateAllowed: true
        )

        let item = row.stockItem(using: ingredient)

        #expect(item.ingredientID == ingredientID)
        #expect(item.name == "Paneer")
        #expect(item.category == "Dairy")
        #expect(item.defaultUnit == "g")
        #expect(item.approximateAllowed)
        #expect(item.expiryDate == "2026-07-10")
        #expect(item.notes == "Use soon")
    }

    @Test("Catalogue items track whether they are already in pantry")
    func catalogueItemTracksPantryState() {
        let row = PantryIngredientDatabaseRow(
            id: UUID(),
            userID: UUID(),
            name: "Coriander Leaves",
            category: "Produce",
            defaultUnit: "bunch",
            approximateAllowed: true
        )

        let item = PantryCatalogItem(row: row, isTracked: true)

        #expect(item.name == "Coriander Leaves")
        #expect(item.category == "Produce")
        #expect(item.defaultUnit == "bunch")
        #expect(item.isTracked)
    }
}
