import Foundation
import Testing
@testable import MealPlanner

struct ShoppingChecklistTests {
    @Test("Manual shopping item trims fields and rejects blank names")
    func manualItemValidation() {
        let blank = ManualShoppingItem(
            weekStart: "2026-06-28",
            name: "   ",
            quantity: 1,
            unit: "roll"
        )

        let valid = ManualShoppingItem(
            weekStart: "2026-06-28",
            name: "  Paper towels  ",
            quantity: 2,
            unit: " roll ",
            category: " Household ",
            note: " Costco "
        )

        #expect(!blank.isValid)
        #expect(valid.isValid)
        #expect(valid.name == "Paper towels")
        #expect(valid.unit == "roll")
        #expect(valid.category == "Household")
        #expect(valid.note == "Costco")
    }

    @Test("Checklist builder combines generated and manual items")
    func checklistBuilderCombinesItems() {
        let generated = ShoppingListItem(
            id: "rice|mass|g",
            canonicalName: "rice",
            displayName: "Rice",
            requiredQuantity: 1_000,
            pantryQuantity: 250,
            neededQuantity: 750,
            unit: "g",
            category: "Grains",
            sourceRecipeNames: ["Dal Rice"],
            sourceMealCount: 1
        )

        let manual = ManualShoppingItem(
            weekStart: "2026-06-28",
            name: "Paper towels",
            quantity: 2,
            unit: "roll",
            category: "Household"
        )

        let items = ShoppingChecklistBuilder.build(
            generatedItems: [generated],
            manualItems: [manual],
            checkedItemIDs: [],
            showCheckedItems: true
        )

        #expect(items.count == 2)
        #expect(items.contains { $0.displayName == "Rice" })
        #expect(items.contains { $0.displayName == "Paper towels" })
    }

    @Test("Checked items can be hidden")
    func checkedItemsCanBeHidden() {
        let generated = ShoppingListItem(
            id: "soy sauce|volume|ml",
            canonicalName: "soy sauce",
            displayName: "Soy Sauce",
            requiredQuantity: 90,
            pantryQuantity: 0,
            neededQuantity: 90,
            unit: "ml",
            category: "Pantry",
            sourceRecipeNames: ["Chicken Rice Bowl"],
            sourceMealCount: 1
        )

        let checkedID = "generated:\(generated.id)"

        let visible = ShoppingChecklistBuilder.build(
            generatedItems: [generated],
            manualItems: [],
            checkedItemIDs: [checkedID],
            showCheckedItems: true
        )

        let hidden = ShoppingChecklistBuilder.build(
            generatedItems: [generated],
            manualItems: [],
            checkedItemIDs: [checkedID],
            showCheckedItems: false
        )

        #expect(visible.count == 1)
        #expect(visible[0].isChecked)
        #expect(hidden.isEmpty)
    }

    @Test("Generated rows use compact meal-count source labels")
    func compactSourceLabels() {
        let oneMeal = ShoppingListItem(
            id: "bell pepper|count|count",
            canonicalName: "bell pepper",
            displayName: "Bell Pepper",
            requiredQuantity: 2,
            pantryQuantity: 0,
            neededQuantity: 2,
            unit: "count",
            category: "Produce",
            sourceRecipeNames: ["Omelette"],
            sourceMealCount: 1
        )

        let twoMeals = ShoppingListItem(
            id: "rice|mass|g",
            canonicalName: "rice",
            displayName: "Rice",
            requiredQuantity: 1_000,
            pantryQuantity: 0,
            neededQuantity: 1_000,
            unit: "g",
            category: "Grains",
            sourceRecipeNames: ["Dal Rice", "Chicken Bowl"],
            sourceMealCount: 2
        )

        #expect(oneMeal.compactSourceText == "Used in Omelette")
        #expect(twoMeals.compactSourceText == "Used in 2 meals")
    }

    @Test("Local checklist storage is week scoped")
    func localStorageIsWeekScoped() {
        let defaults = UserDefaults(suiteName: "ShoppingChecklistTests.\(UUID().uuidString)")!
        let weekOne = "2026-06-28"
        let weekTwo = "2026-07-05"

        let item = ManualShoppingItem(
            weekStart: weekOne,
            name: "Foil",
            quantity: 1,
            unit: "roll"
        )

        ShoppingChecklistLocalStorage.save(
            ShoppingChecklistSnapshot(
                checkedItemIDs: [item.stableChecklistID],
                manualItems: [item]
            ),
            weekStart: weekOne,
            defaults: defaults
        )

        let loadedOne = ShoppingChecklistLocalStorage.load(
            weekStart: weekOne,
            defaults: defaults
        )
        let loadedTwo = ShoppingChecklistLocalStorage.load(
            weekStart: weekTwo,
            defaults: defaults
        )

        #expect(loadedOne.manualItems.count == 1)
        #expect(loadedOne.checkedItemIDs.contains(item.stableChecklistID))
        #expect(loadedTwo.manualItems.isEmpty)
        #expect(loadedTwo.checkedItemIDs.isEmpty)
    }
}
