import Testing
@testable import MealPlanner

struct NotificationRoutingTests {
    @Test("Meal Planner notification user info routes to planning")
    func planningNotificationRoutesToPlanning() {
        let route = MealPlannerNotificationRoute.fromUserInfo([
            "source": "meal_planner",
            "destination": "planning"
        ])

        #expect(route == .planning)
    }

    @Test("Meal Planner notification user info routes to schedule")
    func scheduleNotificationRoutesToSchedule() {
        let route = MealPlannerNotificationRoute.fromUserInfo([
            "source": "meal_planner",
            "destination": "schedule"
        ])

        #expect(route == .schedule)
    }

    @Test("Meal Planner notification user info routes to shopping")
    func shoppingNotificationRoutesToShopping() {
        let route = MealPlannerNotificationRoute.fromUserInfo([
            "source": "meal_planner",
            "destination": "shopping"
        ])

        #expect(route == .shopping)
    }

    @Test("Unknown Meal Planner notification destination safely routes to Today")
    func unknownDestinationRoutesToToday() {
        let route = MealPlannerNotificationRoute.fromUserInfo([
            "source": "meal_planner",
            "destination": "something-weird"
        ])

        #expect(route == .today)
    }

    @Test("Non Meal Planner notification is ignored")
    func nonMealPlannerNotificationIsIgnored() {
        let route = MealPlannerNotificationRoute.fromUserInfo([
            "source": "other_app",
            "destination": "shopping"
        ])

        #expect(route == nil)
    }
}
